import { c as y, d as R, e as T } from "@nf-internal/chunk-KTNUIOPA";
import "@nf-internal/chunk-K4KGMBYV";
import { d as k, f as w } from "@nf-internal/chunk-HTXI7NN5";
import { v as I, w as x } from "@nf-internal/chunk-BVRKUVLO";
import "@nf-internal/chunk-PJKO2XHO";
import { c as f } from "@nf-internal/chunk-DBOLI3CQ";
import { i as E } from "@nf-internal/chunk-NTOTMM2V";
import { i as p, m as c, n as u, q as b, r as a } from "@nf-internal/chunk-DPCBKAOC";
import { h as g } from "@nf-internal/chunk-C4FLJMU7";
var _ = () => ":host([slot]){display:none;line-height:0;z-index:100}.reorder-icon{display:block}::slotted(ion-icon){font-size:dynamic-font(16px)}.reorder-icon{font-size:2.125rem;opacity:0.4}", B = () => ":host([slot]){display:none;line-height:0;z-index:100}.reorder-icon{display:block}::slotted(ion-icon){font-size:dynamic-font(16px)}.reorder-icon{font-size:1.9375rem;opacity:0.3}", z = class {
    constructor(e) { p(this, e); }
    onClick(e) { let t = this.el.closest("ion-reorder-group"); e.preventDefault(), (!t || !t.disabled) && e.stopImmediatePropagation(); }
    render() { let e = f(this); return c(u, { key: "b869db61ca6393cf1476f2111a66b387b567c6d1", class: e }, c("slot", { key: "a78edd1776835282b8b5c841377018f36c83296c" }, c("ion-icon", { key: "7fb067c47bbb9a7258e5063f028282cc097d0f94", icon: e === "ios" ? I : x, lazy: !1, class: "reorder-icon", part: "icon", "aria-hidden": "true" }))); }
    get el() { return b(this); }
};
z.style = { ios: _(), md: B() };
var H = () => ".reorder-list-active>*{display:block;-webkit-transition:-webkit-transform 300ms;transition:-webkit-transform 300ms;transition:transform 300ms;transition:transform 300ms, -webkit-transform 300ms;will-change:transform}.reorder-enabled{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.reorder-enabled ion-reorder{display:block;cursor:-webkit-grab;cursor:grab;pointer-events:all;-ms-touch-action:none;touch-action:none}.reorder-selected,.reorder-selected ion-reorder{cursor:-webkit-grabbing;cursor:grabbing}.reorder-selected{position:relative;-webkit-transition:none !important;transition:none !important;-webkit-box-shadow:0 0 10px rgba(0, 0, 0, 0.4);box-shadow:0 0 10px rgba(0, 0, 0, 0.4);opacity:0.8;z-index:100}.reorder-visible ion-reorder .reorder-icon{-webkit-transform:translate3d(0,  0,  0);transform:translate3d(0,  0,  0)}", Y = class {
    constructor(e) { p(this, e), this.ionItemReorder = a(this, "ionItemReorder", 7), this.ionReorderStart = a(this, "ionReorderStart", 7), this.ionReorderMove = a(this, "ionReorderMove", 7), this.ionReorderEnd = a(this, "ionReorderEnd", 7), this.lastToIndex = -1, this.cachedHeights = [], this.scrollElTop = 0, this.scrollElBottom = 0, this.scrollElInitial = 0, this.containerTop = 0, this.containerBottom = 0, this.state = 0, this.disabled = !0; }
    disabledChanged() { this.gesture && this.gesture.enable(!this.disabled); }
    connectedCallback() { return g(this, null, function* () { let e = w(this.el); e && (this.scrollEl = yield k(e)), this.gesture = (yield import("@nf-internal/index-CfgBF1SE-P7ED24W5")).createGesture({ el: this.el, gestureName: "reorder", gesturePriority: 110, threshold: 0, direction: "y", passive: !1, canStart: t => this.canStart(t), onStart: t => this.onStart(t), onMove: t => this.onMove(t), onEnd: () => this.onEnd() }), this.disabledChanged(); }); }
    disconnectedCallback() { this.onEnd(), this.gesture && (this.gesture.destroy(), this.gesture = void 0); }
    complete(e) { return Promise.resolve(this.completeReorder(e)); }
    canStart(e) { if (this.selectedItemEl || this.state !== 0)
        return !1; let o = e.event.target.closest("ion-reorder"); if (!o)
        return !1; let s = L(o, this.el); return s ? (e.data = s, !0) : !1; }
    onStart(e) { e.event.preventDefault(); let t = this.selectedItemEl = e.data, o = this.cachedHeights; o.length = 0; let s = this.el, r = s.__children || s.children; if (!r || r.length === 0)
        return; let n = 0; for (let l = 0; l < r.length; l++) {
        let d = r[l];
        n += d.offsetHeight, o.push(n), d.$ionIndex = l;
    } let i = s.getBoundingClientRect(); if (this.containerTop = i.top, this.containerBottom = i.bottom, this.scrollEl) {
        let l = this.scrollEl.getBoundingClientRect();
        this.scrollElInitial = this.scrollEl.scrollTop, this.scrollElTop = l.top + S, this.scrollElBottom = l.bottom - S;
    }
    else
        this.scrollElInitial = 0, this.scrollElTop = 0, this.scrollElBottom = 0; this.lastToIndex = m(t), this.selectedItemHeight = t.offsetHeight, this.state = 1, t.classList.add(C), y(), this.ionReorderStart.emit(); }
    onMove(e) { let t = this.selectedItemEl; if (!t)
        return; let o = this.autoscroll(e.currentY), s = this.containerTop - o, r = this.containerBottom - o, n = Math.max(s, Math.min(e.currentY, r)), i = o + n - e.startY, l = n - s, d = this.lastToIndex, h = this.itemIndexForTop(l); if (h !== this.lastToIndex) {
        let M = m(t);
        this.lastToIndex = h, R(), this.reorderMove(M, h);
    } t.style.transform = `translateY(${i}px)`, this.ionReorderMove.emit({ from: d, to: h }); }
    onEnd() { let e = this.selectedItemEl; if (this.state = 2, !e) {
        this.state = 0;
        return;
    } let t = this.lastToIndex, o = m(e); t === o ? this.completeReorder() : this.ionItemReorder.emit({ from: o, to: t, complete: this.completeReorder.bind(this) }), T(), this.ionReorderEnd.emit({ from: o, to: t, complete: this.completeReorder.bind(this) }); }
    completeReorder(e) { let t = this.selectedItemEl; if (t && this.state === 2) {
        let o = this.el.__children || this.el.children, s = o.length, r = this.lastToIndex, n = m(t);
        E(() => { if (r !== n && (e === void 0 || e === !0)) {
            let i = n < r ? o[r + 1] : o[r];
            this.el.insertBefore(t, i);
        } for (let i = 0; i < s; i++)
            o[i].style.transform = ""; }), Array.isArray(e) && (e = A(e, n, r)), t.style.transition = "", t.classList.remove(C), this.selectedItemEl = void 0, this.state = 0;
    } return e; }
    itemIndexForTop(e) { let t = this.cachedHeights; for (let o = 0; o < t.length; o++)
        if (t[o] > e)
            return o; return t.length - 1; }
    reorderMove(e, t) { let o = this.selectedItemHeight, s = this.el.__children || this.el.children; for (let r = 0; r < s.length; r++) {
        let n = s[r].style, i = "";
        r > e && r <= t ? i = `translateY(${-o}px)` : r < e && r >= t && (i = `translateY(${o}px)`), n.transform = i;
    } }
    autoscroll(e) { if (!this.scrollEl)
        return 0; let t = 0; return e < this.scrollElTop ? t = -v : e > this.scrollElBottom && (t = v), t !== 0 && this.scrollEl.scrollBy(0, t), this.scrollEl.scrollTop - this.scrollElInitial; }
    render() { let e = f(this); return c(u, { key: "9527bbdedaab63d31f562c874a7332ea60c4b47b", class: { [e]: !0, "reorder-enabled": !this.disabled, "reorder-list-active": this.state !== 0 } }); }
    get el() { return b(this); }
    static get watchers() { return { disabled: [{ disabledChanged: 0 }] }; }
}, m = e => e.$ionIndex, L = (e, t) => { let o; for (; e;) {
    if (o = e.parentElement, o === t)
        return e;
    e = o;
} }, S = 60, v = 10, C = "reorder-selected", A = (e, t, o) => { let s = e[t]; return e.splice(t, 1), e.splice(o, 0, s), e.slice(); };
Y.style = H();
export { z as ion_reorder, Y as ion_reorder_group };
/*! Bundled license information:

@ionic/core/dist/esm/ion-reorder_2.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
