import { h as a } from "@nf-internal/chunk-C4FLJMU7";
var E = (function (r) { return r.Unimplemented = "UNIMPLEMENTED", r.Unavailable = "UNAVAILABLE", r; })(E || {}), P = class extends Error {
    constructor(e, t, i) { super(e), this.message = e, this.code = t, this.data = i; }
}, M = r => { var e, t; return r?.androidBridge ? "android" : !((t = (e = r?.webkit) === null || e === void 0 ? void 0 : e.messageHandlers) === null || t === void 0) && t.bridge ? "ios" : "web"; }, G = r => { let e = r.CapacitorCustomPlatform || null, t = r.Capacitor || {}, i = t.Plugins = t.Plugins || {}, s = () => e !== null ? e.name : M(r), n = () => s() !== "web", c = o => { let l = b.get(o); return !!(l?.platforms.has(s()) || d(o)); }, d = o => { var l; return (l = t.PluginHeaders) === null || l === void 0 ? void 0 : l.find(O => O.name === o); }, f = o => r.console.error(o), b = new Map, C = (o, l = {}) => { let O = b.get(o); if (O)
    return console.warn(`Capacitor plugin "${o}" already registered. Cannot register plugins twice.`), O.proxy; let p = s(), L = d(o), v, q = () => a(null, null, function* () { return !v && p in l ? v = typeof l[p] == "function" ? v = yield l[p]() : v = l[p] : e !== null && !v && "web" in l && (v = typeof l.web == "function" ? v = yield l.web() : v = l.web), v; }), I = (u, h) => { var g, y; if (L) {
    let m = L?.methods.find(w => h === w.name);
    if (m)
        return m.rtype === "promise" ? w => t.nativePromise(o, h.toString(), w) : (w, A) => t.nativeCallback(o, h.toString(), w, A);
    if (u)
        return (g = u[h]) === null || g === void 0 ? void 0 : g.bind(u);
}
else {
    if (u)
        return (y = u[h]) === null || y === void 0 ? void 0 : y.bind(u);
    throw new P(`"${o}" plugin is not implemented on ${p}`, E.Unimplemented);
} }, U = u => { let h, g = (...y) => { let m = q().then(w => { let A = I(w, u); if (A) {
    let $ = A(...y);
    return h = $?.remove, $;
}
else
    throw new P(`"${o}.${u}()" is not implemented on ${p}`, E.Unimplemented); }); return u === "addListener" && (m.remove = () => a(null, null, function* () { return h(); })), m; }; return g.toString = () => `${u.toString()}() { [capacitor code] }`, Object.defineProperty(g, "name", { value: u, writable: !1, configurable: !1 }), g; }, H = U("addListener"), F = U("removeListener"), K = (u, h) => { let g = H({ eventName: u }, h), y = () => a(null, null, function* () { let w = yield g; F({ eventName: u, callbackId: w }, h); }), m = new Promise(w => g.then(() => w({ remove: y }))); return m.remove = () => a(null, null, function* () { console.warn("Using addListener() without 'await' is deprecated."), yield y(); }), m; }, j = new Proxy({}, { get(u, h) { switch (h) {
        case "$$typeof": return;
        case "toJSON": return () => ({});
        case "addListener": return L ? K : H;
        case "removeListener": return F;
        default: return U(h);
    } } }); return i[o] = j, b.set(o, { name: o, proxy: j, platforms: new Set([...Object.keys(l), ...L ? [p] : []]) }), j; }; return t.convertFileSrc || (t.convertFileSrc = o => o), t.getPlatform = s, t.handleError = f, t.isNativePlatform = n, t.isPluginAvailable = c, t.registerPlugin = C, t.Exception = P, t.DEBUG = !!t.DEBUG, t.isLoggingEnabled = !!t.isLoggingEnabled, t; }, V = r => r.Capacitor = G(r), D = V(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {}), x = D.registerPlugin, k = class {
    constructor() { this.listeners = {}, this.retainedEventArguments = {}, this.windowListeners = {}; }
    addListener(e, t) { let i = !1; this.listeners[e] || (this.listeners[e] = [], i = !0), this.listeners[e].push(t); let n = this.windowListeners[e]; n && !n.registered && this.addWindowListener(n), i && this.sendRetainedArgumentsForEvent(e); let c = () => a(this, null, function* () { return this.removeListener(e, t); }); return Promise.resolve({ remove: c }); }
    removeAllListeners() { return a(this, null, function* () { this.listeners = {}; for (let e in this.windowListeners)
        this.removeWindowListener(this.windowListeners[e]); this.windowListeners = {}; }); }
    notifyListeners(e, t, i) { let s = this.listeners[e]; if (!s) {
        if (i) {
            let n = this.retainedEventArguments[e];
            n || (n = []), n.push(t), this.retainedEventArguments[e] = n;
        }
        return;
    } s.forEach(n => n(t)); }
    hasListeners(e) { var t; return !!(!((t = this.listeners[e]) === null || t === void 0) && t.length); }
    registerWindowListener(e, t) { this.windowListeners[t] = { registered: !1, windowEventName: e, pluginEventName: t, handler: i => { this.notifyListeners(t, i); } }; }
    unimplemented(e = "not implemented") { return new D.Exception(e, E.Unimplemented); }
    unavailable(e = "not available") { return new D.Exception(e, E.Unavailable); }
    removeListener(e, t) { return a(this, null, function* () { let i = this.listeners[e]; if (!i)
        return; let s = i.indexOf(t); this.listeners[e].splice(s, 1), this.listeners[e].length || this.removeWindowListener(this.windowListeners[e]); }); }
    addWindowListener(e) { window.addEventListener(e.windowEventName, e.handler), e.registered = !0; }
    removeWindowListener(e) { e && (window.removeEventListener(e.windowEventName, e.handler), e.registered = !1); }
    sendRetainedArgumentsForEvent(e) { let t = this.retainedEventArguments[e]; t && (delete this.retainedEventArguments[e], t.forEach(i => { this.notifyListeners(e, i); })); }
}, Z = x("WebView"), B = r => encodeURIComponent(r).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape), _ = r => r.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent), S = class extends k {
    getCookies() { return a(this, null, function* () { let e = document.cookie, t = {}; return e.split(";").forEach(i => { if (i.length <= 0)
        return; let [s, n] = i.replace(/=/, "CAP_COOKIE").split("CAP_COOKIE"); s = _(s).trim(), n = _(n).trim(), t[s] = n; }), t; }); }
    setCookie(e) { return a(this, null, function* () { try {
        let t = B(e.key), i = B(e.value), s = e.expires ? `; expires=${e.expires.replace("expires=", "")}` : "", n = (e.path || "/").replace("path=", ""), c = e.url != null && e.url.length > 0 ? `domain=${e.url}` : "";
        document.cookie = `${t}=${i || ""}${s}; path=${n}; ${c};`;
    }
    catch (t) {
        return Promise.reject(t);
    } }); }
    deleteCookie(e) { return a(this, null, function* () { try {
        document.cookie = `${e.key}=; Max-Age=0`;
    }
    catch (t) {
        return Promise.reject(t);
    } }); }
    clearCookies() { return a(this, null, function* () { try {
        let e = document.cookie.split(";") || [];
        for (let t of e)
            document.cookie = t.replace(/^ +/, "").replace(/=.*/, `=;expires=${new Date().toUTCString()};path=/`);
    }
    catch (e) {
        return Promise.reject(e);
    } }); }
    clearAllCookies() { return a(this, null, function* () { try {
        yield this.clearCookies();
    }
    catch (e) {
        return Promise.reject(e);
    } }); }
}, N = x("CapacitorCookies", { web: () => new S }), W = r => a(null, null, function* () { return new Promise((e, t) => { let i = new FileReader; i.onload = () => { let s = i.result; e(s.indexOf(",") >= 0 ? s.split(",")[1] : s); }, i.onerror = s => t(s), i.readAsDataURL(r); }); }), z = (r = {}) => { let e = Object.keys(r); return Object.keys(r).map(s => s.toLocaleLowerCase()).reduce((s, n, c) => (s[n] = r[e[c]], s), {}); }, J = (r, e = !0) => r ? Object.entries(r).reduce((i, s) => { let [n, c] = s, d, f; return Array.isArray(c) ? (f = "", c.forEach(b => { d = e ? encodeURIComponent(b) : b, f += `${n}=${d}&`; }), f.slice(0, -1)) : (d = e ? encodeURIComponent(c) : c, f = `${n}=${d}`), `${i}&${f}`; }, "").substr(1) : null, Q = (r, e = {}) => { let t = Object.assign({ method: r.method || "GET", headers: r.headers }, e), s = z(r.headers)["content-type"] || ""; if (typeof r.data == "string")
    t.body = r.data;
else if (s.includes("application/x-www-form-urlencoded")) {
    let n = new URLSearchParams;
    for (let [c, d] of Object.entries(r.data || {}))
        n.set(c, d);
    t.body = n.toString();
}
else if (s.includes("multipart/form-data") || r.data instanceof FormData) {
    let n = new FormData;
    if (r.data instanceof FormData)
        r.data.forEach((d, f) => { n.append(f, d); });
    else
        for (let d of Object.keys(r.data))
            n.append(d, r.data[d]);
    t.body = n;
    let c = new Headers(t.headers);
    c.delete("content-type"), t.headers = c;
}
else
    (s.includes("application/json") || typeof r.data == "object") && (t.body = JSON.stringify(r.data)); return t; }, T = class extends k {
    request(e) { return a(this, null, function* () { let t = Q(e, e.webFetchExtra), i = J(e.params, e.shouldEncodeUrlParams), s = i ? `${e.url}?${i}` : e.url, n = yield fetch(s, t), c = n.headers.get("content-type") || "", { responseType: d = "text" } = n.ok ? e : {}; c.includes("application/json") && (d = "json"); let f, b; switch (d) {
        case "arraybuffer":
        case "blob":
            b = yield n.blob(), f = yield W(b);
            break;
        case "json":
            f = yield n.json();
            break;
        default: f = yield n.text();
    } let C = {}; return n.headers.forEach((o, l) => { C[l] = o; }), { data: f, headers: C, status: n.status, url: n.url }; }); }
    get(e) { return a(this, null, function* () { return this.request(Object.assign(Object.assign({}, e), { method: "GET" })); }); }
    post(e) { return a(this, null, function* () { return this.request(Object.assign(Object.assign({}, e), { method: "POST" })); }); }
    put(e) { return a(this, null, function* () { return this.request(Object.assign(Object.assign({}, e), { method: "PUT" })); }); }
    patch(e) { return a(this, null, function* () { return this.request(Object.assign(Object.assign({}, e), { method: "PATCH" })); }); }
    delete(e) { return a(this, null, function* () { return this.request(Object.assign(Object.assign({}, e), { method: "DELETE" })); }); }
}, ee = x("CapacitorHttp", { web: () => new T }), X = (function (r) { return r.Dark = "DARK", r.Light = "LIGHT", r.Default = "DEFAULT", r; })(X || {}), Y = (function (r) { return r.StatusBar = "StatusBar", r.NavigationBar = "NavigationBar", r; })(Y || {}), R = class extends k {
    setStyle() { return a(this, null, function* () { this.unavailable("not available for web"); }); }
    setAnimation() { return a(this, null, function* () { this.unavailable("not available for web"); }); }
    show() { return a(this, null, function* () { this.unavailable("not available for web"); }); }
    hide() { return a(this, null, function* () { this.unavailable("not available for web"); }); }
}, te = x("SystemBars", { web: () => new R });
export { D as Capacitor, N as CapacitorCookies, P as CapacitorException, ee as CapacitorHttp, E as ExceptionCode, Y as SystemBarType, te as SystemBars, X as SystemBarsStyle, k as WebPlugin, Z as WebView, Q as buildRequestInit, x as registerPlugin };
/*! Bundled license information:

@capacitor/core/dist/index.js:
  (*! Capacitor: https://capacitorjs.com/ - MIT License *)
*/
