import { a as q, d as We, h as se } from "@nf-internal/chunk-C4FLJMU7";
var Dt = We({ "./ion-accordion_2.entry.js": () => import("@nf-internal/ion-accordion_2.entry-M2N6SXXA"), "./ion-action-sheet.entry.js": () => import("@nf-internal/ion-action-sheet.entry-47Z4U2BY"), "./ion-alert.entry.js": () => import("@nf-internal/ion-alert.entry-NZAAOEO6"), "./ion-app_8.entry.js": () => import("@nf-internal/ion-app_8.entry-PQEICVZX"), "./ion-avatar_3.entry.js": () => import("@nf-internal/ion-avatar_3.entry-EKJ7GS56"), "./ion-back-button.entry.js": () => import("@nf-internal/ion-back-button.entry-5EHJWN7U"), "./ion-backdrop.entry.js": () => import("@nf-internal/ion-backdrop.entry-ID4RO6JR"), "./ion-breadcrumb_2.entry.js": () => import("@nf-internal/ion-breadcrumb_2.entry-FQSJ6DA6"), "./ion-button_2.entry.js": () => import("@nf-internal/ion-button_2.entry-YBHZLRT3"), "./ion-card_5.entry.js": () => import("@nf-internal/ion-card_5.entry-JCQFQMMJ"), "./ion-checkbox.entry.js": () => import("@nf-internal/ion-checkbox.entry-AJP6T3QS"), "./ion-chip.entry.js": () => import("@nf-internal/ion-chip.entry-6XXIYZ3V"), "./ion-col_3.entry.js": () => import("@nf-internal/ion-col_3.entry-5ID7MY6R"), "./ion-datetime-button.entry.js": () => import("@nf-internal/ion-datetime-button.entry-B2TXPEFK"), "./ion-datetime_3.entry.js": () => import("@nf-internal/ion-datetime_3.entry-AH2DJ3JS"), "./ion-fab_3.entry.js": () => import("@nf-internal/ion-fab_3.entry-43QAHRXQ"), "./ion-img.entry.js": () => import("@nf-internal/ion-img.entry-Y2JMO5LB"), "./ion-infinite-scroll_2.entry.js": () => import("@nf-internal/ion-infinite-scroll_2.entry-CVFYRGKH"), "./ion-input-otp.entry.js": () => import("@nf-internal/ion-input-otp.entry-C4PEMAGD"), "./ion-input-password-toggle.entry.js": () => import("@nf-internal/ion-input-password-toggle.entry-PHLPSXIX"), "./ion-input.entry.js": () => import("@nf-internal/ion-input.entry-DR4AYYZG"), "./ion-item-option_3.entry.js": () => import("@nf-internal/ion-item-option_3.entry-3S7JZG43"), "./ion-item_8.entry.js": () => import("@nf-internal/ion-item_8.entry-TUKL5FUF"), "./ion-loading.entry.js": () => import("@nf-internal/ion-loading.entry-NVTBPKZJ"), "./ion-menu_3.entry.js": () => import("@nf-internal/ion-menu_3.entry-6HLUJFU7"), "./ion-modal.entry.js": () => import("@nf-internal/ion-modal.entry-URGOSH2P"), "./ion-nav_2.entry.js": () => import("@nf-internal/ion-nav_2.entry-4OPQD37D"), "./ion-picker-column-option.entry.js": () => import("@nf-internal/ion-picker-column-option.entry-ZDYOLBX5"), "./ion-picker-column.entry.js": () => import("@nf-internal/ion-picker-column.entry-ZKNOW6MK"), "./ion-picker.entry.js": () => import("@nf-internal/ion-picker.entry-DCMLAF7N"), "./ion-popover.entry.js": () => import("@nf-internal/ion-popover.entry-MQFZPGIQ"), "./ion-progress-bar.entry.js": () => import("@nf-internal/ion-progress-bar.entry-WF3V4QGL"), "./ion-radio_2.entry.js": () => import("@nf-internal/ion-radio_2.entry-RAUG3WKD"), "./ion-range.entry.js": () => import("@nf-internal/ion-range.entry-Y4IPOJJB"), "./ion-refresher_2.entry.js": () => import("@nf-internal/ion-refresher_2.entry-3GQNPM3F"), "./ion-reorder_2.entry.js": () => import("@nf-internal/ion-reorder_2.entry-ORDNV536"), "./ion-ripple-effect.entry.js": () => import("@nf-internal/ion-ripple-effect.entry-SXLSKQSX"), "./ion-route_4.entry.js": () => import("@nf-internal/ion-route_4.entry-A2QXOFXT"), "./ion-searchbar.entry.js": () => import("@nf-internal/ion-searchbar.entry-Q73ALJZB"), "./ion-segment-content.entry.js": () => import("@nf-internal/ion-segment-content.entry-HT6JYVJV"), "./ion-segment-view.entry.js": () => import("@nf-internal/ion-segment-view.entry-I5ZWJJGW"), "./ion-segment_2.entry.js": () => import("@nf-internal/ion-segment_2.entry-47VTGAYX"), "./ion-select-modal.entry.js": () => import("@nf-internal/ion-select-modal.entry-NHLJVMM6"), "./ion-select_3.entry.js": () => import("@nf-internal/ion-select_3.entry-DSXBOTLD"), "./ion-spinner.entry.js": () => import("@nf-internal/ion-spinner.entry-TUM6XCM4"), "./ion-split-pane.entry.js": () => import("@nf-internal/ion-split-pane.entry-RBZS7JVH"), "./ion-tab-bar_2.entry.js": () => import("@nf-internal/ion-tab-bar_2.entry-7SQRRFF5"), "./ion-tab_2.entry.js": () => import("@nf-internal/ion-tab_2.entry-UPS6X6IP"), "./ion-text.entry.js": () => import("@nf-internal/ion-text.entry-YYMDX4ZI"), "./ion-textarea.entry.js": () => import("@nf-internal/ion-textarea.entry-FPJ4U4C4"), "./ion-toast.entry.js": () => import("@nf-internal/ion-toast.entry-2BRNNQQO"), "./ion-toggle.entry.js": () => import("@nf-internal/ion-toggle.entry-PDMY6Q3I") });
var zt = "ionic", B = { hotModuleReplacement: !1, hydratedSelectorName: "hydrated", lazyLoad: !0, propChangeCallback: !0, shadowDom: !0, slotRelocation: !0, state: !0, updatable: !0 }, be = class {
    constructor() { this.m = new Map; }
    reset(t) { this.m = new Map(Object.entries(t)); }
    get(t, s) { let n = this.m.get(t); return n !== void 0 ? n : s; }
    getBoolean(t, s = !1) { let n = this.m.get(t); return n === void 0 ? s : typeof n == "string" ? n === "true" : !!n; }
    getNumber(t, s) { let n = parseFloat(this.m.get(t)); return isNaN(n) ? s !== void 0 ? s : NaN : n; }
    set(t, s) { this.m.set(t, s); }
}, lt = new be, en = e => { try {
    let t = e.sessionStorage.getItem(ot);
    return t !== null ? JSON.parse(t) : {};
}
catch {
    return {};
} }, tn = (e, t) => { try {
    e.sessionStorage.setItem(ot, JSON.stringify(t));
}
catch {
    return;
} }, sn = e => { let t = {}; return e.location.search.slice(1).split("&").map(s => s.split("=")).map(([s, n]) => { try {
    return [decodeURIComponent(s), decodeURIComponent(n)];
}
catch {
    return ["", ""];
} }).filter(([s]) => Bt(s, qe)).map(([s, n]) => [s.slice(qe.length), n]).forEach(([s, n]) => { t[s] = n; }), t; }, Bt = (e, t) => e.substr(0, t.length) === t, qe = "ionic:", ot = "ionic-persist-config", P = (function (e) { return e.OFF = "OFF", e.ERROR = "ERROR", e.WARN = "WARN", e; })(P || {}), nn = (e, ...t) => { let s = lt.get("logLevel", P.WARN); if ([P.WARN].includes(s))
    return console.warn(`[Ionic Warning]: ${e}`, ...t); }, rn = (e, ...t) => { let s = lt.get("logLevel", P.ERROR); if ([P.ERROR, P.WARN].includes(s))
    return console.error(`[Ionic Error]: ${e}`, ...t); }, ln = (e, ...t) => console.error(`<${e.tagName.toLowerCase()}> must be used inside ${t.join(" or ")}.`), on = { isBrowser: !0 }, Ut = "http://www.w3.org/2000/svg", Ft = "http://www.w3.org/1999/xhtml", at = (e => (e.Undefined = "undefined", e.Null = "null", e.String = "string", e.Number = "number", e.SpecialNumber = "number", e.Boolean = "boolean", e.BigInt = "bigint", e))(at || {}), ct = (e => (e.Array = "array", e.Date = "date", e.Map = "map", e.Object = "object", e.RegularExpression = "regexp", e.Set = "set", e.Channel = "channel", e.Symbol = "symbol", e))(ct || {}), ye = "type", Se = "value", me = "serialized:";
function $t(e, t, s) { let n = typeof HTMLElement < "u" ? HTMLElement.prototype : null; for (; e && e !== n;) {
    let r = Object.getOwnPropertyDescriptor(e, t);
    if (r && (!s || r.get))
        return r;
    e = Object.getPrototypeOf(e);
} }
var Mt = (e, t) => { var s; let n = t.$cmpMeta$; Object.entries((s = n.$members$) != null ? s : {}).map(([i, [a]]) => { if (a & 31 || a & 32) {
    let l = e[i], $ = $t(Object.getPrototypeOf(e), i, !0) || Object.getOwnPropertyDescriptor(e, i);
    $ && Object.defineProperty(e, i, { get() { return $.get.call(this); }, set(o) { $.set.call(this, o); }, configurable: !0, enumerable: !0 }), t.$instanceValues$.has(i) ? e[i] = t.$instanceValues$.get(i) : l !== void 0 && (e[i] = l);
} }); }, E = e => { if (e.__stencil__getHostRef)
    return e.__stencil__getHostRef(); }, an = (e, t) => { t && (e.__stencil__getHostRef = () => t, t.$lazyInstance$ = e, t.$cmpMeta$.$flags$ & 512 && B.state && Mt(e, t)); }, Wt = (e, t) => { let s = { $flags$: 0, $hostElement$: e, $cmpMeta$: t, $instanceValues$: new Map, $serializerValues$: new Map }; s.$onInstancePromise$ = new Promise(r => s.$onInstanceResolve$ = r), s.$onReadyPromise$ = new Promise(r => s.$onReadyResolve$ = r), e["s-p"] = [], e["s-rc"] = [], s.$fetchedCbList$ = []; let n = s; return e.__stencil__getHostRef = () => n, n; }, He = (e, t) => t in e, F = (e, t) => (0, console.error)(e, t), Pe = new Map, qt = (e, t, s) => { let n = e.$tagName$.replace(/-/g, "_"), r = e.$lazyBundleId$; if (!r)
    return; let i = Pe.get(r); if (i)
    return i[n]; return Dt(`./${r}.entry.js`).then(a => (Pe.set(r, a), a[n]), a => { F(a, t.$hostElement$); }); }, ie = new Map, ft = [], Ht = "r", Pt = "o", xe = "s", Gt = "t", Yt = "c", J = "s-id", le = "sty-id", Ge = "c-id", Xt = "{visibility:hidden}.hydrated{visibility:inherit}", dt = "slot-fb{display:contents}slot-fb[hidden]{display:none}", Ye = "http://www.w3.org/1999/xlink", v = typeof window < "u" ? window : {}, cn = v.HTMLElement || class {
}, S = { $flags$: 0, $resourcesUrl$: "", jmp: e => e(), raf: e => requestAnimationFrame(e), ael: (e, t, s, n) => e.addEventListener(t, s, n), rel: (e, t, s, n) => e.removeEventListener(t, s, n), ce: (e, t) => new CustomEvent(e, t) }, Jt = B.shadowDom, Kt = (() => { var e; let t = !1; try {
    (e = v.document) == null || e.addEventListener("e", null, Object.defineProperty({}, "passive", { get() { t = !0; } }));
}
catch { } return t; })(), Zt = e => Promise.resolve(e), we = (() => { try {
    return v.document.adoptedStyleSheets ? (new CSSStyleSheet, typeof new CSSStyleSheet().replaceSync == "function") : !1;
}
catch { } return !1; })(), Te = we ? !!v.document && Object.getOwnPropertyDescriptor(v.document.adoptedStyleSheets, "length").writable : !1, Ae = !1, Le = [], ut = [], ht = (e, t) => s => { e.push(s), Ae || (Ae = !0, t && S.$flags$ & 4 ? De(Ee) : S.raf(Ee)); }, Xe = e => { for (let t = 0; t < e.length; t++)
    try {
        e[t](performance.now());
    }
    catch (s) {
        F(s);
    } e.length = 0; }, Ee = () => { Xe(Le), Xe(ut), (Ae = Le.length > 0) && S.raf(Ee); }, De = e => Zt().then(e), $n = ht(Le, !1), pt = ht(ut, !0), fn = e => { let t = new URL(e, S.$resourcesUrl$); return t.origin !== v.location.origin ? t.href : t.pathname; };
var X;
function Qt(e) { var t; let s = { mode: "open" }; s.delegatesFocus = !!(e.$flags$ & 16); let n = this.attachShadow(s); X === void 0 && (X = (t = void 0) != null ? t : null), X && (Te ? n.adoptedStyleSheets.push(X) : n.adoptedStyleSheets = [...n.adoptedStyleSheets, X]); }
var fe = e => { let t = L(e, "childNodes"); e.tagName && e.tagName.includes("-") && e["s-cr"] && e.tagName !== "SLOT-FB" && V(t, e.tagName).forEach(n => { n.nodeType === 1 && n.tagName === "SLOT-FB" && (ze(n, Y(n), !1).length ? n.hidden = !0 : n.hidden = !1); }); let s = 0; for (s = 0; s < t.length; s++) {
    let n = t[s];
    n.nodeType === 1 && L(n, "childNodes").length && fe(n);
} }, K = e => { let t = []; for (let s = 0; s < e.length; s++) {
    let n = e[s]["s-nr"] || void 0;
    n && n.isConnected && t.push(n);
} return t; };
function V(e, t, s) { let n = 0, r = [], i; for (; n < e.length; n++) {
    if (i = e[n], i["s-sr"] && (!t || i["s-hn"] === t) && (s === void 0 || Y(i) === s) && (r.push(i), typeof s < "u"))
        return r;
    r = [...r, ...V(i.childNodes, t, s)];
} return r; }
var ze = (e, t, s = !0) => { let n = []; (s && e["s-sr"] || !e["s-sr"]) && n.push(e); let r = e; for (; r = r.nextSibling;)
    Y(r) === t && (s || !r["s-sr"]) && n.push(r); return n; }, Je = (e, t) => e.nodeType === 1 ? e.getAttribute("slot") === null && t === "" || e.getAttribute("slot") === t : e["s-sn"] === t ? !0 : t === "", de = (e, t, s, n) => { if (e["s-ol"] && e["s-ol"].isConnected)
    return; let r = document.createTextNode(""); if (r["s-nr"] = e, !t["s-cr"] || !t["s-cr"].parentNode)
    return; let i = t["s-cr"].parentNode, a = s ? L(i, "prepend") : L(i, "appendChild"); if (typeof n < "u") {
    r["s-oo"] = n;
    let l = L(i, "childNodes"), $ = [r];
    l.forEach(o => { o["s-nr"] && $.push(o); }), $.sort((o, c) => !o["s-oo"] || o["s-oo"] < (c["s-oo"] || 0) ? -1 : !c["s-oo"] || c["s-oo"] < o["s-oo"] ? 1 : 0), $.forEach(o => a.call(i, o));
}
else
    a.call(i, r); e["s-ol"] = r, e["s-sh"] = t["s-hn"]; }, Y = e => typeof e["s-sn"] == "string" ? e["s-sn"] : e.nodeType === 1 && e.getAttribute("slot") || void 0;
function gt(e) {
    if (e.assignedElements || e.assignedNodes || !e["s-sr"])
        return;
    let t = s => function (n) {
        let r = [], i = this["s-sn"];
        n?.flatten && console.error(`
          Flattening is not supported for Stencil non-shadow slots.
          You can use \`.childNodes\` to nested slot fallback content.
          If you have a particular use case, please open an issue on the Stencil repo.
        `);
        let a = this["s-cr"].parentElement;
        return (a.__childNodes ? a.childNodes : K(a.childNodes)).forEach($ => { i === Y($) && r.push($); }), s ? r.filter($ => $.nodeType === 1) : r;
    }.bind(e);
    e.assignedElements = t(!0), e.assignedNodes = t(!1);
}
function ue(e) { e.dispatchEvent(new CustomEvent("slotchange", { bubbles: !1, cancelable: !1, composed: !1 })); }
function Be(e, t) { var s; if (t = t || ((s = e["s-ol"]) == null ? void 0 : s.parentElement), !t)
    return { slotNode: null, slotName: "" }; let n = e["s-sn"] = Y(e) || "", r = L(t, "childNodes"); return { slotNode: V(r, t.tagName, n)[0], slotName: n }; }
var Vt = e => { vt(e), es(e), ns(e), ss(e), os(e), rs(e), is(e), ls(e), as(e), cs(e), ts(e); }, vt = e => { if (e.__cloneNode)
    return; let t = e.__cloneNode = e.cloneNode; e.cloneNode = function (s) { let n = this, r = n.shadowRoot && Jt, i = t.call(n, r ? s : !1); if (!r && s) {
    let a = 0, l, $, o = ["s-id", "s-cr", "s-lr", "s-rc", "s-sc", "s-p", "s-cn", "s-sr", "s-sn", "s-hn", "s-ol", "s-nr", "s-si", "s-rf", "s-scs"], c = this.__childNodes || this.childNodes;
    for (; a < c.length; a++)
        l = c[a]["s-nr"], $ = o.every(d => !c[a][d]), l && (i.__appendChild ? i.__appendChild(l.cloneNode(!0)) : i.appendChild(l.cloneNode(!0))), $ && i.appendChild(c[a].cloneNode(!0));
} return i; }; }, es = e => { e.__appendChild || (e.__appendChild = e.appendChild, e.appendChild = function (t) { let { slotName: s, slotNode: n } = Be(t, this); if (n) {
    de(t, n);
    let r = ze(n, s), i = r[r.length - 1], a = L(i, "parentNode"), l = L(a, "insertBefore")(t, i.nextSibling);
    return ue(n), fe(this), l;
} return this.__appendChild(t); }); }, ts = e => { e.__removeChild || (e.__removeChild = e.removeChild, e.removeChild = function (t) { if (t && typeof t["s-sn"] < "u") {
    let s = this.__childNodes || this.childNodes;
    if (V(s, this.tagName, t["s-sn"]) && t.isConnected) {
        t.remove(), fe(this);
        return;
    }
} return this.__removeChild(t); }); }, ss = e => { e.__prepend || (e.__prepend = e.prepend, e.prepend = function (...t) { t.forEach(s => { typeof s == "string" && (s = this.ownerDocument.createTextNode(s)); let n = (s["s-sn"] = Y(s)) || "", r = L(this, "childNodes"), i = V(r, this.tagName, n)[0]; if (i) {
    de(s, i, !0);
    let l = ze(i, n)[0], $ = L(l, "parentNode"), o = L($, "insertBefore")(s, L(l, "nextSibling"));
    return ue(i), o;
} return s.nodeType === 1 && s.getAttribute("slot") && (s.hidden = !0), e.__prepend(s); }); }); }, ns = e => { e.__append || (e.__append = e.append, e.append = function (...t) { t.forEach(s => { typeof s == "string" && (s = this.ownerDocument.createTextNode(s)), this.appendChild(s); }); }); }, rs = e => { if (e.__insertAdjacentHTML)
    return; let t = e.insertAdjacentHTML; e.insertAdjacentHTML = function (s, n) { if (s !== "afterbegin" && s !== "beforeend")
    return t.call(this, s, n); let r = this.ownerDocument.createElement("_"), i; if (r.innerHTML = n, s === "afterbegin")
    for (; i = r.firstChild;)
        this.prepend(i);
else if (s === "beforeend")
    for (; i = r.firstChild;)
        this.append(i); }; }, is = e => { e.insertAdjacentText = function (t, s) { this.insertAdjacentHTML(t, s); }; }, ls = e => { if (e.__insertBefore)
    return; let t = e; t.__insertBefore || (t.__insertBefore = e.insertBefore, e.insertBefore = function (s, n) { let { slotName: r, slotNode: i } = Be(s, this), a = this.__childNodes ? this.childNodes : K(this.childNodes); if (i) {
    let $ = !1;
    if (a.forEach(o => { if (o === n || n === null) {
        if ($ = !0, n === null || r !== n["s-sn"]) {
            this.appendChild(s);
            return;
        }
        if (r === n["s-sn"]) {
            de(s, i);
            let c = L(n, "parentNode");
            L(c, "insertBefore")(s, n), ue(i);
        }
        return;
    } }), $)
        return s;
} let l = n?.__parentNode; return l && !this.isSameNode(l) ? this.appendChild(s) : this.__insertBefore(s, n); }); }, os = e => { if (e.__insertAdjacentElement)
    return; let t = e.insertAdjacentElement; e.insertAdjacentElement = function (s, n) { return s !== "afterbegin" && s !== "beforeend" ? t.call(this, s, n) : s === "afterbegin" ? (this.prepend(n), n) : (s === "beforeend" && this.append(n), n); }; }, as = e => { w("textContent", e), Object.defineProperty(e, "textContent", { get: function () { let t = ""; return (this.__childNodes ? this.childNodes : K(this.childNodes)).forEach(n => t += n.textContent || ""), t; }, set: function (t) { (this.__childNodes ? this.childNodes : K(this.childNodes)).forEach(n => { n["s-ol"] && n["s-ol"].remove(), n.remove(); }), this.insertAdjacentHTML("beforeend", t); } }); }, cs = e => { class t extends Array {
    item(n) { return this[n]; }
} w("children", e), Object.defineProperty(e, "children", { get() { return this.childNodes.filter(s => s.nodeType === 1); } }), Object.defineProperty(e, "childElementCount", { get() { return this.children.length; } }), w("firstChild", e), Object.defineProperty(e, "firstChild", { get() { return this.childNodes[0]; } }), w("lastChild", e), Object.defineProperty(e, "lastChild", { get() { return this.childNodes[this.childNodes.length - 1]; } }), w("childNodes", e), Object.defineProperty(e, "childNodes", { get() { let s = new t; return s.push(...K(this.__childNodes)), s; } }); }, $s = e => { !e || e.__nextSibling !== void 0 || !globalThis.Node || (fs(e), us(e), yt(e), e.nodeType === Node.ELEMENT_NODE && (ds(e), hs(e))); }, fs = e => { !e || e.__nextSibling || (w("nextSibling", e), Object.defineProperty(e, "nextSibling", { get: function () { var t; let s = (t = this["s-ol"]) == null ? void 0 : t.parentNode.childNodes, n = s?.indexOf(this); return s && n > -1 ? s[n + 1] : this.__nextSibling; } })); }, ds = e => { !e || e.__nextElementSibling || (w("nextElementSibling", e), Object.defineProperty(e, "nextElementSibling", { get: function () { var t; let s = (t = this["s-ol"]) == null ? void 0 : t.parentNode.children, n = s?.indexOf(this); return s && n > -1 ? s[n + 1] : this.__nextElementSibling; } })); }, us = e => { !e || e.__previousSibling || (w("previousSibling", e), Object.defineProperty(e, "previousSibling", { get: function () { var t; let s = (t = this["s-ol"]) == null ? void 0 : t.parentNode.childNodes, n = s?.indexOf(this); return s && n > -1 ? s[n - 1] : this.__previousSibling; } })); }, hs = e => { !e || e.__previousElementSibling || (w("previousElementSibling", e), Object.defineProperty(e, "previousElementSibling", { get: function () { var t; let s = (t = this["s-ol"]) == null ? void 0 : t.parentNode.children, n = s?.indexOf(this); return s && n > -1 ? s[n - 1] : this.__previousElementSibling; } })); }, yt = e => { !e || e.__parentNode || (w("parentNode", e), Object.defineProperty(e, "parentNode", { get: function () { var t; return ((t = this["s-ol"]) == null ? void 0 : t.parentNode) || this.__parentNode; }, set: function (t) { this.__parentNode = t; } })); }, ps = ["children", "nextElementSibling", "previousElementSibling"], gs = ["childNodes", "firstChild", "lastChild", "nextSibling", "previousSibling", "textContent", "parentNode"];
function w(e, t) { if (!globalThis.Node || !globalThis.Element)
    return; let s; ps.includes(e) ? s = Object.getOwnPropertyDescriptor(Element.prototype, e) : gs.includes(e) && (s = Object.getOwnPropertyDescriptor(Node.prototype, e)), s || (s = Object.getOwnPropertyDescriptor(t, e)), s && Object.defineProperty(t, "__" + e, s); }
function L(e, t) { if ("__" + t in e) {
    let s = e["__" + t];
    return typeof s != "function" ? s : s.bind(e);
}
else
    return typeof e[t] != "function" ? e[t] : e[t].bind(e); }
var D = (e, t = "") => () => { }, vs = (e, t) => () => { };
function St(e) { var t, s, n; return (n = (s = (t = e.head) == null ? void 0 : t.querySelector('meta[name="csp-nonce"]')) == null ? void 0 : s.getAttribute("content")) != null ? n : void 0; }
var U = new WeakMap, _t = (e, t, s) => { let n = ie.get(e); we && s ? (n = n || new CSSStyleSheet, typeof n == "string" ? n = t : n.replaceSync(t)) : n = t, ie.set(e, n); }, bt = (e, t, s) => { var n, r, i; let a = he(t, s), l = ie.get(a); if (!v.document)
    return a; if (e = e.nodeType === 11 ? e : v.document, l)
    if (typeof l == "string") {
        e = e.head || e;
        let $ = U.get(e), o;
        $ || U.set(e, $ = new Set);
        let c = e.querySelector(`[${le}="${a}"]`);
        if (c)
            c.textContent = l;
        else if (!$.has(a)) {
            o = v.document.createElement("style"), o.textContent = l;
            let d = (n = S.$nonce$) != null ? n : St(v.document);
            if (d != null && o.setAttribute("nonce", d), !(t.$flags$ & 1))
                if (e.nodeName === "HEAD") {
                    let f = e.querySelectorAll("link[rel=preconnect]"), h = f.length > 0 ? f[f.length - 1].nextSibling : e.querySelector("style");
                    e.insertBefore(o, h?.parentNode === e ? h : null);
                }
                else if ("host" in e)
                    if (we) {
                        let f = (r = e.defaultView) != null ? r : e.ownerDocument.defaultView, h = new f.CSSStyleSheet;
                        h.replaceSync(l), Te ? e.adoptedStyleSheets.unshift(h) : e.adoptedStyleSheets = [h, ...e.adoptedStyleSheets];
                    }
                    else {
                        let f = e.querySelector("style");
                        f ? f.textContent = l + f.textContent : e.prepend(o);
                    }
                else
                    e.append(o);
            t.$flags$ & 1 && e.insertBefore(o, null), t.$flags$ & 4 && (o.textContent += dt), $ && $.add(a);
        }
    }
    else {
        let $ = U.get(e);
        if ($ || U.set(e, $ = new Set), !$.has(a)) {
            let o = (i = e.defaultView) != null ? i : e.ownerDocument.defaultView, c;
            if (l.constructor === o.CSSStyleSheet)
                c = l;
            else {
                c = new o.CSSStyleSheet;
                for (let d = 0; d < l.cssRules.length; d++)
                    c.insertRule(l.cssRules[d].cssText, d);
            }
            if (Te ? e.adoptedStyleSheets.push(c) : e.adoptedStyleSheets = [...e.adoptedStyleSheets, c], $.add(a), "host" in e) {
                let d = e.querySelector(`[${le}="${a}"]`);
                d && pt(() => d.remove());
            }
        }
    } return a; }, ys = e => { let t = e.$cmpMeta$, s = e.$hostElement$, n = t.$flags$, r = D("attachStyles", t.$tagName$), i = bt(s.shadowRoot ? s.shadowRoot : s.getRootNode(), t, e.$modeName$); n & 10 && (s["s-sc"] = i, s.classList.add(i + "-h")), r(); }, he = (e, t) => "sc-" + (t && e.$flags$ & 32 ? e.$tagName$ + "-" + t : e.$tagName$), Ss = e => e.replace(/\/\*!@([^\/]+)\*\/[^\{]+\{/g, "$1{"), _s = () => { if (!v.document)
    return; let e = v.document.querySelectorAll(`[${le}]`), t = 0; for (; t < e.length; t++)
    _t(e[t].getAttribute(le), Ss(e[t].innerHTML), !0); }, bs = e => e != null && e !== void 0, Ue = e => (e = typeof e, e === "object" || e === "function"), mt = (e, t, ...s) => { typeof e == "string" && (e = e); let n = null, r = null, i = null, a = !1, l = !1, $ = [], o = d => { for (let f = 0; f < d.length; f++)
    n = d[f], Array.isArray(n) ? o(n) : n != null && typeof n != "boolean" && ((a = typeof e != "function" && !Ue(n)) && (n = String(n)), a && l ? $[$.length - 1].$text$ += n : $.push(a ? G(null, n) : n), l = a); }; if (o(s), t) {
    t.key && (r = t.key), t.name && (i = t.name);
    {
        let d = t.className || t.class;
        d && (t.class = typeof d != "object" ? d : Object.keys(d).filter(f => d[f]).join(" "));
    }
} if (typeof e == "function")
    return e(t === null ? {} : t, $, Ts); let c = G(e, null); return c.$attrs$ = t, $.length > 0 && (c.$children$ = $), c.$key$ = r, c.$name$ = i, c; }, G = (e, t) => { let s = { $flags$: 0, $tag$: e, $text$: t ?? null, $elm$: null, $children$: null }; return s.$attrs$ = null, s.$key$ = null, s.$name$ = null, s; }, ms = {}, xs = e => e && e.$tag$ === ms, Ts = { forEach: (e, t) => e.map(Ke).forEach(t), map: (e, t) => e.map(Ke).map(t).map(As) }, Ke = e => ({ vattrs: e.$attrs$, vchildren: e.$children$, vkey: e.$key$, vname: e.$name$, vtag: e.$tag$, vtext: e.$text$ }), As = e => { if (typeof e.vtag == "function") {
    let s = q({}, e.vattrs);
    return e.vkey && (s.key = e.vkey), e.vname && (s.name = e.vname), mt(e.vtag, s, ...e.vchildren || []);
} let t = G(e.vtag, e.vtext); return t.$attrs$ = e.vattrs, t.$children$ = e.vchildren, t.$key$ = e.vkey, t.$name$ = e.vname, t; }, Ls = (e, t, s, n) => { var r, i, a, l; let $ = D("hydrateClient", t), o = e.shadowRoot, c = [], d = [], f = [], h = o ? [] : null, u = G(t, null); u.$elm$ = e; let y; {
    let m = n.$cmpMeta$;
    m && m.$flags$ & 10 && e["s-sc"] ? (y = e["s-sc"], e.classList.add(y + "-h")) : e["s-sc"] && delete e["s-sc"];
} v.document && (!S.$orgLocNodes$ || !S.$orgLocNodes$.size) && Ie(v.document.body, S.$orgLocNodes$ = new Map), e[J] = s, e.removeAttribute(J), n.$vnode$ = Oe(u, c, d, h, e, e, s, f); let x = 0, T = c.length, p; for (x; x < T; x++) {
    p = c[x];
    let m = p.$hostId$ + "." + p.$nodeId$, N = S.$orgLocNodes$.get(m), A = p.$elm$;
    if (!o)
        A["s-hn"] = t.toUpperCase(), p.$tag$ === "slot" && (A["s-cr"] = e["s-cr"]);
    else if ((r = p.$tag$) != null && r.toString().includes("-") && p.$tag$ !== "slot-fb" && !p.$elm$.shadowRoot) {
        let te = E(p.$elm$);
        if (te) {
            let wt = he(te.$cmpMeta$, p.$elm$.getAttribute("s-mode")), Me = v.document.querySelector(`style[sty-id="${wt}"]`);
            Me && h.unshift(Me.cloneNode(!0));
        }
    }
    p.$tag$ === "slot" && (p.$name$ = p.$elm$["s-sn"] || p.$elm$.name || null, p.$children$ ? (p.$flags$ |= 2, p.$elm$.childNodes.length || p.$children$.forEach(te => { p.$elm$.appendChild(te.$elm$); })) : p.$flags$ |= 1), N && N.isConnected && (N.parentElement.shadowRoot && N["s-en"] === "" && N.parentNode.insertBefore(A, N.nextSibling), N.parentNode.removeChild(N), o || (A["s-oo"] = parseInt(p.$nodeId$))), N && !N["s-id"] && S.$orgLocNodes$.delete(m);
} let O = [], _ = f.length, g = 0, I, C, ee, b, ve = 0; for (g; g < _; g++)
    if (I = f[g], !(!I || !I.length))
        for (ee = I.length, C = 0, C; C < ee; C++) {
            if (b = I[C], O[b.hostId] || (O[b.hostId] = S.$orgLocNodes$.get(b.hostId)), !O[b.hostId])
                continue;
            let m = O[b.hostId];
            m.shadowRoot && b.node.parentElement !== m && m.insertBefore(b.node, (a = (i = I[C - 1]) == null ? void 0 : i.node) == null ? void 0 : a.nextSibling), (!m.shadowRoot || !o) && (b.slot["s-cr"] || (b.slot["s-cr"] = m["s-cr"], !b.slot["s-cr"] && m.shadowRoot ? b.slot["s-cr"] = m : b.slot["s-cr"] = (m.__childNodes || m.childNodes)[0]), de(b.node, b.slot, !1, b.node["s-oo"] || ve), (l = b.node.parentElement) != null && l.shadowRoot && b.node.getAttribute && b.node.getAttribute("slot") && b.node.removeAttribute("slot"), $s(b.node)), ve = (b.node["s-oo"] || ve) + 1;
        } if (y && d.length && d.forEach(m => { m.$elm$.parentElement.classList.add(y + "-s"); }), o && !o.childNodes.length) {
    let m = 0, N = h.length;
    if (N) {
        for (m; m < N; m++) {
            let A = h[m];
            A && o.appendChild(A);
        }
        Array.from(e.childNodes).forEach(A => { typeof A["s-en"] != "string" && typeof A["s-sn"] != "string" && (A.nodeType === 1 && A.slot && A.hidden ? A.removeAttribute("hidden") : A.nodeType === 8 && !A.nodeValue && A.parentNode.removeChild(A)); });
    }
} n.$hostElement$ = e, $(); }, Oe = (e, t, s, n, r, i, a, l = []) => { let $, o, c, d, f = r["s-sc"]; if (i.nodeType === 1) {
    if ($ = i.getAttribute(Ge), $ && (o = $.split("."), o[0] === a || o[0] === "0")) {
        c = Ze({ $flags$: 0, $hostId$: o[0], $nodeId$: o[1], $depth$: o[2], $index$: o[3], $tag$: i.tagName.toLowerCase(), $elm$: i, $attrs$: { class: i.className || "" } }), t.push(c), i.removeAttribute(Ge), e.$children$ || (e.$children$ = []), f && o[0] === a && (i["s-si"] = f, c.$attrs$.class += " " + f);
        let u = c.$elm$.getAttribute("s-sn");
        typeof u == "string" && (c.$tag$ === "slot-fb" && (Qe(u, o[2], c, i, e, t, s, n, l), f && i.classList.add(f)), c.$elm$["s-sn"] = u, c.$elm$.removeAttribute("s-sn")), c.$index$ !== void 0 && (e.$children$[c.$index$] = c), e = c, n && c.$depth$ === "0" && (n[c.$index$] = c.$elm$);
    }
    if (i.shadowRoot)
        for (d = i.shadowRoot.childNodes.length - 1; d >= 0; d--)
            Oe(e, t, s, n, r, i.shadowRoot.childNodes[d], a, l);
    let h = i.__childNodes || i.childNodes;
    for (d = h.length - 1; d >= 0; d--)
        Oe(e, t, s, n, r, h[d], a, l);
}
else if (i.nodeType === 8) {
    if (o = i.nodeValue.split("."), o[1] === a || o[1] === "0") {
        if ($ = o[0], c = Ze({ $hostId$: o[1], $nodeId$: o[2], $depth$: o[3], $index$: o[4] || "0", $elm$: i, $attrs$: null, $children$: null, $key$: null, $name$: null, $tag$: null, $text$: null }), $ === Gt)
            c.$elm$ = et(i, 3), c.$elm$ && c.$elm$.nodeType === 3 && (c.$text$ = c.$elm$.textContent, t.push(c), i.remove(), a === c.$hostId$ && (e.$children$ || (e.$children$ = []), e.$children$[c.$index$] = c), n && c.$depth$ === "0" && (n[c.$index$] = c.$elm$));
        else if ($ === Yt)
            c.$elm$ = et(i, 8), c.$elm$ && c.$elm$.nodeType === 8 && (t.push(c), i.remove());
        else if (c.$hostId$ === a)
            if ($ === xe) {
                let h = i["s-sn"] = o[5] || "";
                Qe(h, o[2], c, i, e, t, s, n, l);
            }
            else
                $ === Ht && (n ? i.remove() : (r["s-cr"] = i, i["s-cn"] = !0));
    }
}
else if (e && e.$tag$ === "style") {
    let h = G(null, i.textContent);
    h.$elm$ = i, h.$index$ = "0", e.$children$ = [h];
} return e; }, Ie = (e, t) => { if (e.nodeType === 1) {
    let s = e[J] || e.getAttribute(J);
    s && t.set(s, e);
    let n = 0;
    if (e.shadowRoot)
        for (; n < e.shadowRoot.childNodes.length; n++)
            Ie(e.shadowRoot.childNodes[n], t);
    let r = e.__childNodes || e.childNodes;
    for (n = 0; n < r.length; n++)
        Ie(r[n], t);
}
else if (e.nodeType === 8) {
    let s = e.nodeValue.split(".");
    s[0] === Pt && (t.set(s[1] + "." + s[2], e), e.nodeValue = "", e["s-en"] = s[3]);
} }, Ze = e => q(q({}, { $flags$: 0, $hostId$: null, $nodeId$: null, $depth$: null, $index$: "0", $elm$: null, $attrs$: null, $children$: null, $key$: null, $name$: null, $tag$: null, $text$: null }), e);
function Qe(e, t, s, n, r, i, a, l, $) { n["s-sr"] = !0, s.$name$ = e || null, s.$tag$ = "slot"; let o = r?.$elm$ ? r.$elm$["s-id"] || r.$elm$.getAttribute("s-id") : ""; if (l && v.document) {
    let c = s.$elm$ = v.document.createElement(s.$tag$);
    s.$name$ && s.$elm$.setAttribute("name", e), r.$elm$.shadowRoot && o && o !== s.$hostId$ ? L(r.$elm$, "insertBefore")(c, L(r.$elm$, "children")[0]) : L(L(n, "parentNode"), "insertBefore")(c, n), Ve($, t, e, n, s.$hostId$), n.remove(), s.$depth$ === "0" && (l[s.$index$] = s.$elm$);
}
else {
    let c = s.$elm$, d = o && o !== s.$hostId$ && r.$elm$.shadowRoot;
    Ve($, t, e, n, d ? o : s.$hostId$), gt(n), d && r.$elm$.insertBefore(c, r.$elm$.children[0]);
} i.push(s), a.push(s), r.$children$ || (r.$children$ = []), r.$children$[s.$index$] = s; }
var Ve = (e, t, s, n, r) => { var i, a; let l = n.nextSibling; if (e[t] = e[t] || [], !(!l || (i = l.nodeValue) != null && i.startsWith(xe + ".")))
    do
        l && ((l.getAttribute && l.getAttribute("slot") || l["s-sn"]) === s || s === "" && !l["s-sn"] && (!l.getAttribute || !l.getAttribute("slot")) && (l.nodeType === 8 || l.nodeType === 3)) && (l["s-sn"] = s, e[t].push({ slot: n, node: l, hostId: r })), l = l?.nextSibling;
    while (l && !((a = l.nodeValue) != null && a.startsWith(xe + "."))); }, et = (e, t) => { let s = e; do
    s = s.nextSibling;
while (s && (s.nodeType !== t || !s.nodeValue)); return s; }, Es = e => ft.map(t => t(e)).find(t => !!t), dn = e => ft.push(e), un = e => { var t; return (t = E(e)) == null ? void 0 : t.$modeName$; }, Fe = e => { if (!e)
    return; let t = Object.keys(e); if (t.length === 0)
    return; let s = !1; for (let r of t) {
    if (s)
        break;
    for (let i of e[r])
        if (typeof i == "string") {
            s = !0;
            break;
        }
} if (!s)
    return e; let n = {}; for (let r of t)
    n[r] = e[r].map(i => typeof i == "string" ? { [i]: 0 } : i); return n; }, Os = class M {
    static fromLocalValue(t) { let s = t[ye], n = Se in t ? t[Se] : void 0; switch (s) {
        case "string": return n;
        case "boolean": return n;
        case "bigint": return BigInt(n);
        case "undefined": return;
        case "null": return null;
        case "number": return n === "NaN" ? NaN : n === "-0" ? -0 : n === "Infinity" ? 1 / 0 : n === "-Infinity" ? -1 / 0 : n;
        case "array": return n.map(o => M.fromLocalValue(o));
        case "date": return new Date(n);
        case "map":
            let r = new Map;
            for (let [o, c] of n) {
                let d = typeof o == "object" && o !== null ? M.fromLocalValue(o) : o, f = M.fromLocalValue(c);
                r.set(d, f);
            }
            return r;
        case "object":
            let i = {};
            for (let [o, c] of n)
                i[o] = M.fromLocalValue(c);
            return i;
        case "regexp":
            let { pattern: a, flags: l } = n;
            return new RegExp(a, l);
        case "set":
            let $ = new Set;
            for (let o of n)
                $.add(M.fromLocalValue(o));
            return $;
        case "symbol": return Symbol(n);
        default: throw new Error(`Unsupported type: ${s}`);
    } }
    static fromLocalValueArray(t) { return t.map(s => M.fromLocalValue(s)); }
    static isLocalValueObject(t) { if (typeof t != "object" || t === null || !t.hasOwnProperty(ye))
        return !1; let s = t[ye]; return Object.values(q(q({}, at), ct)).includes(s) ? s !== "null" && s !== "undefined" ? t.hasOwnProperty(Se) : !0 : !1; }
};
function Is(e) { let t = atob(e), s = new Uint8Array(t.length); for (let n = 0; n < t.length; n++)
    s[n] = t.charCodeAt(n); return new TextDecoder().decode(s); }
function ks(e) { return typeof e != "string" || !e.startsWith(me) ? e : Os.fromLocalValue(JSON.parse(Is(e.slice(me.length)))); }
var ke = (e, t, s) => typeof e == "string" && e.startsWith(me) ? (e = ks(e), e) : e != null && !Ue(e) ? t & 4 ? e === "false" ? !1 : e === "" || !!e : t & 2 ? typeof e == "string" ? parseFloat(e) : typeof e == "number" ? e : NaN : t & 1 ? String(e) : e : e, Ns = e => { var t; return (t = E(e)) == null ? void 0 : t.$hostElement$; }, hn = (e, t, s) => { let n = Ns(e); return { emit: r => xt(n, t, { bubbles: !!(s & 4), composed: !!(s & 2), cancelable: !!(s & 1), detail: r }) }; }, xt = (e, t, s) => { let n = S.ce(t, s); return e.dispatchEvent(n), n; }, tt = (e, t, s, n, r, i, a) => { if (s === n)
    return; let l = He(e, t), $ = t.toLowerCase(); if (t === "class") {
    let o = e.classList, c = st(s), d = st(n);
    if ((e["s-si"] || e["s-sc"]) && a) {
        let f = e["s-sc"] || e["s-si"];
        d.push(f), c.forEach(h => { h.startsWith(f) && d.push(h); }), d = [...new Set(d)].filter(h => h), o.add(...d);
    }
    else
        o.remove(...c.filter(f => f && !d.includes(f))), o.add(...d.filter(f => f && !c.includes(f)));
}
else if (t === "style") {
    for (let o in s)
        (!n || n[o] == null) && (o.includes("-") ? e.style.removeProperty(o) : e.style[o] = "");
    for (let o in n)
        (!s || n[o] !== s[o]) && (o.includes("-") ? e.style.setProperty(o, n[o]) : e.style[o] = n[o]);
}
else if (t !== "key")
    if (t === "ref")
        n && ws(n, e);
    else if (!l && t[0] === "o" && t[1] === "n") {
        if (t[2] === "-" ? t = t.slice(3) : He(v, $) ? t = $.slice(2) : t = $[2] + t.slice(3), s || n) {
            let o = t.endsWith(Tt);
            t = t.replace(js, ""), s && S.rel(e, t, s, o), n && S.ael(e, t, n, o);
        }
    }
    else if (t[0] === "a" && t.startsWith("attr:")) {
        let o = t.slice(5), c;
        {
            let d = E(e);
            if (d && d.$cmpMeta$ && d.$cmpMeta$.$members$) {
                let f = d.$cmpMeta$.$members$[o];
                f && f[1] && (c = f[1]);
            }
        }
        c || (c = o.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase()), n == null || n === !1 ? (n !== !1 || e.getAttribute(c) === "") && e.removeAttribute(c) : e.setAttribute(c, n === !0 ? "" : n);
        return;
    }
    else if (t[0] === "p" && t.startsWith("prop:")) {
        let o = t.slice(5);
        try {
            e[o] = n;
        }
        catch { }
        return;
    }
    else {
        let o = Ue(n);
        if ((l || o && n !== null) && !r)
            try {
                if (e.tagName.includes("-"))
                    e[t] !== n && (e[t] = n);
                else {
                    let d = n ?? "";
                    t === "list" ? l = !1 : (s == null || e[t] !== d) && (typeof e.__lookupSetter__(t) == "function" ? e[t] = d : e.setAttribute(t, d));
                }
            }
            catch { }
        let c = !1;
        $ !== ($ = $.replace(/^xlink\:?/, "")) && (t = $, c = !0), n == null || n === !1 ? (n !== !1 || e.getAttribute(t) === "") && (c ? e.removeAttributeNS(Ye, t) : e.removeAttribute(t)) : (!l || i & 4 || r) && !o && e.nodeType === 1 && (n = n === !0 ? "" : n, c ? e.setAttributeNS(Ye, t, n) : e.setAttribute(t, n));
    } }, Cs = /\s/, st = e => (typeof e == "object" && e && "baseVal" in e && (e = e.baseVal), !e || typeof e != "string" ? [] : e.split(Cs)), Tt = "Capture", js = new RegExp(Tt + "$"), Ne = (e, t, s, n) => { let r = t.$elm$.nodeType === 11 && t.$elm$.host ? t.$elm$.host : t.$elm$, i = e && e.$attrs$ || {}, a = t.$attrs$ || {}; for (let l of nt(Object.keys(i)))
    l in a || tt(r, l, i[l], void 0, s, t.$flags$, n); for (let l of nt(Object.keys(a)))
    tt(r, l, i[l], a[l], s, t.$flags$, n); };
function nt(e) { return e.includes("ref") ? [...e.filter(t => t !== "ref"), "ref"] : e; }
var re, oe, W, Z = !1, ae = !1, pe = !1, k = !1, Ce = [], je = [], ce = (e, t, s) => { var n; let r = t.$children$[s], i = 0, a, l, $; if (Z || (pe = !0, r.$tag$ === "slot" && (r.$flags$ |= r.$children$ ? 2 : 1)), r.$text$ != null)
    a = r.$elm$ = v.document.createTextNode(r.$text$);
else if (r.$flags$ & 1)
    a = r.$elm$ = v.document.createTextNode(""), Ne(null, r, k);
else {
    if (k || (k = r.$tag$ === "svg"), !v.document)
        throw new Error("You are trying to render a Stencil component in an environment that doesn't support the DOM.");
    if (a = r.$elm$ = v.document.createElementNS(k ? Ut : Ft, !Z && B.slotRelocation && r.$flags$ & 2 ? "slot-fb" : r.$tag$), k && r.$tag$ === "foreignObject" && (k = !1), Ne(null, r, k), bs(re) && a["s-si"] !== re && a.classList.add(a["s-si"] = re), r.$children$) {
        let o = r.$tag$ === "template" ? a.content : a;
        for (i = 0; i < r.$children$.length; ++i)
            l = ce(e, r, i), l && o.appendChild(l);
    }
    r.$tag$ === "svg" ? k = !1 : a.tagName === "foreignObject" && (k = !0);
} return a["s-hn"] = W, r.$flags$ & 3 && (a["s-sr"] = !0, a["s-cr"] = oe, a["s-sn"] = r.$name$ || "", a["s-rf"] = (n = r.$attrs$) == null ? void 0 : n.ref, gt(a), $ = e && e.$children$ && e.$children$[s], $ && $.$tag$ === r.$tag$ && e.$elm$ && At(e.$elm$), kt(oe, a, t.$elm$, e?.$elm$)), a; }, At = e => { S.$flags$ |= 1; let t = e.closest(W.toLowerCase()); if (t != null) {
    let s = Array.from(t.__childNodes || t.childNodes).find(r => r["s-cr"]), n = Array.from(e.__childNodes || e.childNodes);
    for (let r of s ? n.reverse() : n)
        r["s-sh"] != null && (j(t, r, s ?? null), r["s-sh"] = void 0, pe = !0);
} S.$flags$ &= -2; }, $e = (e, t) => { S.$flags$ |= 1; let s = Array.from(e.__childNodes || e.childNodes); if (e["s-sr"]) {
    let n = e;
    for (; n = n.nextSibling;)
        n && n["s-sn"] === e["s-sn"] && n["s-sh"] === W && s.push(n);
} for (let n = s.length - 1; n >= 0; n--) {
    let r = s[n];
    r["s-hn"] !== W && r["s-ol"] && (j(Q(r).parentNode, r, Q(r)), r["s-ol"].remove(), r["s-ol"] = void 0, r["s-sh"] = void 0, pe = !0), t && $e(r, t);
} S.$flags$ &= -2; }, Lt = (e, t, s, n, r, i) => { let a = e["s-cr"] && e["s-cr"].parentNode || e, l; for (a.shadowRoot && a.tagName === W && (a = a.shadowRoot), s.$tag$ === "template" && (a = a.content); r <= i; ++r)
    n[r] && (l = ce(null, s, r), l && (n[r].$elm$ = l, j(a, l, Q(t)))); }, Et = (e, t, s) => { for (let n = t; n <= s; ++n) {
    let r = e[n];
    if (r) {
        let i = r.$elm$;
        It(r), i && (ae = !0, i["s-ol"] ? i["s-ol"].remove() : $e(i, !0), i.remove());
    }
} }, Rs = (e, t, s, n, r = !1) => { let i = 0, a = 0, l = 0, $ = 0, o = t.length - 1, c = t[0], d = t[o], f = n.length - 1, h = n[0], u = n[f], y, x, T = s.$tag$ === "template" ? e.content : e; for (; i <= o && a <= f;)
    if (c == null)
        c = t[++i];
    else if (d == null)
        d = t[--o];
    else if (h == null)
        h = n[++a];
    else if (u == null)
        u = n[--f];
    else if (ne(c, h, r))
        H(c, h, r), c = t[++i], h = n[++a];
    else if (ne(d, u, r))
        H(d, u, r), d = t[--o], u = n[--f];
    else if (ne(c, u, r))
        (c.$tag$ === "slot" || u.$tag$ === "slot") && $e(c.$elm$.parentNode, !1), H(c, u, r), j(T, c.$elm$, d.$elm$.nextSibling), c = t[++i], u = n[--f];
    else if (ne(d, h, r))
        (c.$tag$ === "slot" || u.$tag$ === "slot") && $e(d.$elm$.parentNode, !1), H(d, h, r), j(T, d.$elm$, c.$elm$), d = t[--o], h = n[++a];
    else {
        for (l = -1, $ = i; $ <= o; ++$)
            if (t[$] && t[$].$key$ !== null && t[$].$key$ === h.$key$) {
                l = $;
                break;
            }
        l >= 0 ? (x = t[l], x.$tag$ !== h.$tag$ ? y = ce(t && t[a], s, l) : (H(x, h, r), t[l] = void 0, y = x.$elm$), h = n[++a]) : (y = ce(t && t[a], s, a), h = n[++a]), y && j(Q(c.$elm$).parentNode, y, Q(c.$elm$));
    } i > o ? Lt(e, n[f + 1] == null ? null : n[f + 1].$elm$, s, n, a, f) : a > f && Et(t, i, o); }, ne = (e, t, s = !1) => e.$tag$ === t.$tag$ ? e.$tag$ === "slot" ? e.$name$ === t.$name$ : s ? (s && !e.$key$ && t.$key$ && (e.$key$ = t.$key$), !0) : e.$key$ === t.$key$ : !1, Q = e => e && e["s-ol"] || e, H = (e, t, s = !1) => { let n = t.$elm$ = e.$elm$, r = e.$children$, i = t.$children$, a = t.$tag$, l = t.$text$, $; l == null ? (k = a === "svg" ? !0 : a === "foreignObject" ? !1 : k, a === "slot" && !Z && e.$name$ !== t.$name$ && (t.$elm$["s-sn"] = t.$name$ || "", At(t.$elm$.parentElement)), Ne(e, t, k, s), r !== null && i !== null ? Rs(n, r, t, i, s) : i !== null ? (e.$text$ !== null && (n.textContent = ""), Lt(n, null, t, i, 0, i.length - 1)) : !s && B.updatable && r !== null ? Et(r, 0, r.length - 1) : s && B.updatable && r !== null && i === null && (t.$children$ = r), k && a === "svg" && (k = !1)) : ($ = n["s-cr"]) ? $.parentNode.textContent = l : e.$text$ !== l && (n.data = l); }, z = [], Ot = e => { let t, s, n, r = e.__childNodes || e.childNodes; for (let i of r) {
    if (i["s-sr"] && (t = i["s-cr"]) && t.parentNode) {
        s = t.parentNode.__childNodes || t.parentNode.childNodes;
        let a = i["s-sn"];
        for (n = s.length - 1; n >= 0; n--)
            if (t = s[n], !t["s-cn"] && !t["s-nr"] && t["s-hn"] !== i["s-hn"] && (!t["s-sh"] || t["s-sh"] !== i["s-hn"]))
                if (Je(t, a)) {
                    let l = z.find($ => $.$nodeToRelocate$ === t);
                    ae = !0, t["s-sn"] = t["s-sn"] || a, l ? (l.$nodeToRelocate$["s-sh"] = i["s-hn"], l.$slotRefNode$ = i) : (t["s-sh"] = i["s-hn"], z.push({ $slotRefNode$: i, $nodeToRelocate$: t })), t["s-sr"] && z.map($ => { Je($.$nodeToRelocate$, t["s-sn"]) && (l = z.find(o => o.$nodeToRelocate$ === t), l && !$.$slotRefNode$ && ($.$slotRefNode$ = l.$slotRefNode$)); });
                }
                else
                    z.some(l => l.$nodeToRelocate$ === t) || z.push({ $nodeToRelocate$: t });
    }
    i.nodeType === 1 && Ot(i);
} }, It = e => { e.$attrs$ && e.$attrs$.ref && Ce.push(() => e.$attrs$.ref(null)), e.$children$ && e.$children$.map(It); }, ws = (e, t) => { je.push(() => e(t)); }, Ds = () => { Ce.forEach(e => e()), Ce.length = 0, je.forEach(e => e()), je.length = 0; }, j = (e, t, s, n) => { if (typeof t["s-sn"] == "string" && t["s-sr"] && t["s-cr"])
    kt(t["s-cr"], t, e, t.parentElement);
else if (typeof t["s-sn"] == "string") {
    e.getRootNode().nodeType !== 11 && yt(t), e.insertBefore(t, s);
    let { slotNode: r } = Be(t);
    return r && !n && ue(r), t;
} return e.__insertBefore ? e.__insertBefore(t, s) : e?.insertBefore(t, s); };
function kt(e, t, s, n) { var r, i; let a; if (e && typeof t["s-sn"] == "string" && t["s-sr"] && e.parentNode && e.parentNode["s-sc"] && (a = t["s-si"] || e.parentNode["s-sc"])) {
    let l = t["s-sn"], $ = t["s-hn"];
    if ((r = s.classList) == null || r.add(a + "-s"), n && ((i = n.classList) != null && i.contains(a + "-s"))) {
        let o = (n.__childNodes || n.childNodes)[0], c = !1;
        for (; o;) {
            if (o["s-sn"] !== l && o["s-hn"] === $ && o["s-sr"]) {
                c = !0;
                break;
            }
            o = o.nextSibling;
        }
        c || n.classList.remove(a + "-s");
    }
} }
var zs = (e, t, s = !1) => { var n, r, i, a, l; let $ = e.$hostElement$, o = e.$cmpMeta$, c = e.$vnode$ || G(null, null), f = xs(t) ? t : mt(null, null, t); if (W = $.tagName, o.$attrsToReflect$ && (f.$attrs$ = f.$attrs$ || {}, o.$attrsToReflect$.forEach(([h, u]) => { f.$attrs$[u] = $[h]; })), s && f.$attrs$)
    for (let h of Object.keys(f.$attrs$))
        $.hasAttribute(h) && !["key", "ref", "style", "class"].includes(h) && (f.$attrs$[h] = $[h]); f.$tag$ = null, f.$flags$ |= 4, e.$vnode$ = f, f.$elm$ = c.$elm$ = $.shadowRoot || $, re = $["s-sc"], Z = !!(o.$flags$ & 1) && !(o.$flags$ & 128), oe = $["s-cr"], ae = !1, H(c, f, s); {
    if (S.$flags$ |= 1, pe) {
        Ot(f.$elm$);
        for (let h of z) {
            let u = h.$nodeToRelocate$;
            if (!u["s-ol"] && v.document) {
                let y = v.document.createTextNode("");
                y["s-nr"] = u, j(u.parentNode, u["s-ol"] = y, u, s);
            }
        }
        for (let h of z) {
            let u = h.$nodeToRelocate$, y = h.$slotRefNode$;
            if (u.nodeType === 1 && s && (u["s-ih"] = (n = u.hidden) != null ? n : !1), y) {
                let x = y.parentNode, T = y.nextSibling;
                if (T && T.nodeType === 1) {
                    let _ = (r = u["s-ol"]) == null ? void 0 : r.previousSibling;
                    for (; _;) {
                        let g = (i = _["s-nr"]) != null ? i : null;
                        if (g && g["s-sn"] === u["s-sn"] && x === (g.__parentNode || g.parentNode)) {
                            for (g = g.nextSibling; g === u || g?.["s-sr"];)
                                g = g?.nextSibling;
                            if (!g || !g["s-nr"]) {
                                T = g;
                                break;
                            }
                        }
                        _ = _.previousSibling;
                    }
                }
                let p = u.__parentNode || u.parentNode, O = u.__nextSibling || u.nextSibling;
                if ((!T && x !== p || O !== T) && u !== T) {
                    if (j(x, u, T, s), u.nodeType === 8 && u.nodeValue.startsWith("s-nt-")) {
                        let _ = v.document.createTextNode(u.nodeValue.replace(/^s-nt-/, ""));
                        _["s-hn"] = u["s-hn"], _["s-sn"] = u["s-sn"], _["s-sh"] = u["s-sh"], _["s-sr"] = u["s-sr"], _["s-ol"] = u["s-ol"], _["s-ol"]["s-nr"] = _, j(u.parentNode, _, u, s), u.parentNode.removeChild(u);
                    }
                    u.nodeType === 1 && u.tagName !== "SLOT-FB" && (u.hidden = (a = u["s-ih"]) != null ? a : !1);
                }
                u && typeof y["s-rf"] == "function" && y["s-rf"](y);
            }
            else
                u.nodeType === 1 && (u.hidden = !0);
        }
    }
    ae && fe(f.$elm$), S.$flags$ &= -2, z.length = 0;
} if (!Z && !(o.$flags$ & 1) && $["s-cr"]) {
    let h = f.$elm$.__childNodes || f.$elm$.childNodes;
    for (let u of h)
        if (u["s-hn"] !== W && !u["s-sh"]) {
            if (s && u["s-ih"] == null && (u["s-ih"] = (l = u.hidden) != null ? l : !1), u.nodeType === 1)
                u.hidden = !0;
            else if (u.nodeType === 3 && u.nodeValue.trim()) {
                let y = v.document.createComment("s-nt-" + u.nodeValue);
                y["s-sn"] = u["s-sn"], j(u.parentNode, y, u, s), u.parentNode.removeChild(u);
            }
        }
} oe = void 0, Ds(); }, Nt = (e, t) => { if (t && !e.$onRenderResolve$ && t["s-p"]) {
    let s = t["s-p"].push(new Promise(n => e.$onRenderResolve$ = () => { t["s-p"].splice(s - 1, 1), n(); }));
} }, ge = (e, t) => { if (e.$flags$ |= 16, e.$flags$ & 4) {
    e.$flags$ |= 512;
    return;
} Nt(e, e.$ancestorComponent$); let s = () => Bs(e, t); if (t) {
    queueMicrotask(() => { s(); });
    return;
} return pt(s); }, Bs = (e, t) => { let s = e.$hostElement$, n = D("scheduleUpdate", e.$cmpMeta$.$tagName$), r = e.$lazyInstance$; if (!r)
    throw new Error(`Can't render component <${s.tagName.toLowerCase()} /> with invalid Stencil runtime! Make sure this imported component is compiled with a \`externalRuntime: true\` flag. For more information, please refer to https://stenciljs.com/docs/custom-elements#externalruntime`); let i; return t ? (e.$deferredConnectedCallback$ && (e.$deferredConnectedCallback$ = !1, R(r, "connectedCallback", void 0, s)), e.$flags$ |= 256, e.$queuedListeners$ && (e.$queuedListeners$.map(([a, l]) => R(r, a, l, s)), e.$queuedListeners$ = void 0), e.$fetchedCbList$.length && e.$fetchedCbList$.forEach(a => a(s)), i = R(r, "componentWillLoad", void 0, s)) : i = R(r, "componentWillUpdate", void 0, s), i = rt(i, () => R(r, "componentWillRender", void 0, s)), n(), rt(i, () => Fs(e, r, t)); }, rt = (e, t) => Us(e) ? e.then(t).catch(s => { console.error(s), t(); }) : t(), Us = e => e instanceof Promise || e && e.then && typeof e.then == "function", Fs = (e, t, s) => se(null, null, function* () { var n; let r = e.$hostElement$, i = D("update", e.$cmpMeta$.$tagName$), a = r["s-rc"]; s && ys(e); let l = D("render", e.$cmpMeta$.$tagName$); Ms(e, t, r, s), a && (a.map($ => $()), r["s-rc"] = void 0), l(), i(); {
    let $ = (n = r["s-p"]) != null ? n : [], o = () => Ws(e);
    $.length === 0 ? o() : (Promise.all($).then(o).catch(o), e.$flags$ |= 4, $.length = 0);
} }), Ms = (e, t, s, n) => { try {
    t = t.render && t.render(), e.$flags$ &= -17, e.$flags$ |= 2, zs(e, t, n);
}
catch (r) {
    F(r, e.$hostElement$);
} return null; }, Ws = e => { let t = e.$cmpMeta$.$tagName$, s = e.$hostElement$, n = D("postUpdate", t), r = e.$lazyInstance$, i = e.$ancestorComponent$; R(r, "componentDidRender", void 0, s), e.$flags$ & 64 ? (R(r, "componentDidUpdate", void 0, s), n()) : (e.$flags$ |= 64, qs(s), R(r, "componentDidLoad", void 0, s), n(), e.$onReadyResolve$(s), i || Ct()), e.$onInstanceResolve$(s), e.$onRenderResolve$ && (e.$onRenderResolve$(), e.$onRenderResolve$ = void 0), e.$flags$ & 512 && De(() => ge(e, !1)), e.$flags$ &= -517; }, pn = e => { var t; {
    let s = E(e), n = (t = s?.$hostElement$) == null ? void 0 : t.isConnected;
    return n && (s.$flags$ & 18) === 2 && ge(s, !1), n;
} }, Ct = e => { var t; De(() => xt(v, "appload", { detail: { namespace: zt } })), (t = S.$orgLocNodes$) != null && t.size && S.$orgLocNodes$.clear(); }, R = (e, t, s, n) => { if (e && e[t])
    try {
        return e[t](s);
    }
    catch (r) {
        F(r, n);
    } }, qs = e => { var t; return e.classList.add((t = B.hydratedSelectorName) != null ? t : "hydrated"); }, Hs = (e, t) => E(e).$instanceValues$.get(t), _e = (e, t, s, n) => { let r = E(e); if (!r)
    return; if (!r)
    throw new Error(`Couldn't find host element for "${n.$tagName$}" as it is unknown to this Stencil runtime. This usually happens when integrating a 3rd party Stencil component with another Stencil component or application. Please reach out to the maintainers of the 3rd party Stencil component or report this on the Stencil Discord server (https://chat.stenciljs.com) or comment on this similar [GitHub issue](https://github.com/stenciljs/core/issues/5457).`); let i = r.$hostElement$, a = r.$instanceValues$.get(t), l = r.$flags$, $ = r.$lazyInstance$; s = ke(s, n.$members$[t][0]); let o = Number.isNaN(a) && Number.isNaN(s), c = s !== a && !o; if ((!(l & 8) || a === void 0) && c) {
    if (r.$instanceValues$.set(t, s), n.$watchers$) {
        let d = n.$watchers$[t];
        d && d.map(f => { try {
            let [[h, u]] = Object.entries(f);
            (l & 128 || u & 1) && ($ ? $[h](s, a, t) : r.$fetchedCbList$.push(() => { r.$lazyInstance$[h](s, a, t); }));
        }
        catch (h) {
            F(h, i);
        } });
    }
    if (l & 2) {
        if ($.componentShouldUpdate && $.componentShouldUpdate(s, a, t) === !1 && !(l & 16))
            return;
        l & 16 || ge(r, !1);
    }
} }, jt = (e, t, s) => { var n, r; let i = e.prototype; if (t.$members$ || B.propChangeCallback) {
    e.watchers && !t.$watchers$ && (t.$watchers$ = Fe(e.watchers)), e.deserializers && !t.$deserializers$ && (t.$deserializers$ = e.deserializers), e.serializers && !t.$serializers$ && (t.$serializers$ = e.serializers);
    let a = Object.entries((n = t.$members$) != null ? n : {});
    if (a.map(([l, [$]]) => { if ($ & 31 || s & 2 && $ & 32) {
        let { get: o, set: c } = $t(i, l) || {};
        o && (t.$members$[l][0] |= 2048), c && (t.$members$[l][0] |= 4096), (s & 1 || !o) && Object.defineProperty(i, l, { get() { {
                if ((t.$members$[l][0] & 2048) === 0)
                    return Hs(this, l);
                let d = E(this), f = d ? d.$lazyInstance$ : i;
                return f ? f[l] : void 0;
            } }, configurable: !0, enumerable: !0 }), Object.defineProperty(i, l, { set(d) { let f = E(this); if (f) {
                if (c) {
                    typeof ($ & 32 ? this[l] : f.$hostElement$[l]) > "u" && f.$instanceValues$.get(l) && (d = f.$instanceValues$.get(l)), c.apply(this, [ke(d, $)]), d = $ & 32 ? this[l] : f.$hostElement$[l], _e(this, l, d, t);
                    return;
                }
                {
                    if ((s & 1) === 0 || (t.$members$[l][0] & 4096) === 0) {
                        _e(this, l, d, t), s & 1 && !f.$lazyInstance$ && f.$fetchedCbList$.push(() => { t.$members$[l][0] & 4096 && f.$lazyInstance$[l] !== f.$instanceValues$.get(l) && (f.$lazyInstance$[l] = d); });
                        return;
                    }
                    let h = () => { let u = f.$lazyInstance$[l]; !f.$instanceValues$.get(l) && u && f.$instanceValues$.set(l, u), f.$lazyInstance$[l] = ke(d, $), _e(this, l, f.$lazyInstance$[l], t); };
                    f.$lazyInstance$ ? h() : f.$fetchedCbList$.push(() => { h(); });
                }
            } } });
    }
    else
        s & 1 && $ & 64 && Object.defineProperty(i, l, { value(...o) { var c; let d = E(this); return (c = d?.$onInstancePromise$) == null ? void 0 : c.then(() => { var f; return (f = d.$lazyInstance$) == null ? void 0 : f[l](...o); }); } }); }), s & 1) {
        let l = new Map;
        i.attributeChangedCallback = function ($, o, c) { S.jmp(() => { var d; let f = l.get($), h = E(this); if (this.hasOwnProperty(f) && B.lazyLoad && (c = this[f], delete this[f]), i.hasOwnProperty(f) && typeof this[f] == "number" && this[f] == c)
            return; if (f == null) {
            let p = h?.$flags$;
            if (h && p && !(p & 8) && c !== o) {
                let O = h.$lazyInstance$, _ = (d = t.$watchers$) == null ? void 0 : d[$];
                _?.forEach(g => { let [[I, C]] = Object.entries(g); O[I] != null && (p & 128 || C & 1) && O[I].call(O, c, o, $); });
            }
            return;
        } let u = a.find(([p]) => p === f), y = u && u[1][0] & 4, x = y && c === null && this[f] === void 0; y && (c = !(c === null || c === "false")); let T = Object.getOwnPropertyDescriptor(i, f); !x && c != this[f] && (!T.get || T.set) && (this[f] = c); }); }, e.observedAttributes = Array.from(new Set([...Object.keys((r = t.$watchers$) != null ? r : {}), ...a.filter(([$, o]) => o[0] & 31).map(([$, o]) => { var c; let d = o[1] || $; return l.set(d, $), o[0] & 512 && ((c = t.$attrsToReflect$) == null || c.push([$, d])), d; })]));
    }
} return e; }, Ps = (e, t, s, n) => se(null, null, function* () { let r; try {
    if ((t.$flags$ & 32) === 0) {
        if (t.$flags$ |= 32, s.$lazyBundleId$) {
            let $ = qt(s, t);
            if ($ && "then" in $) {
                let d = vs();
                r = yield $, d();
            }
            else
                r = $;
            if (!r)
                throw new Error(`Constructor for "${s.$tagName$}#${t.$modeName$}" was not found`);
            r.isProxied || (s.$watchers$ = Fe(r.watchers), s.$serializers$ = r.serializers, s.$deserializers$ = r.deserializers, jt(r, s, 2), r.isProxied = !0);
            let o = D("createInstance", s.$tagName$);
            t.$flags$ |= 8;
            try {
                new r(t);
            }
            catch (d) {
                F(d, e);
            }
            t.$flags$ &= -9, t.$flags$ |= 128, o(), s.$flags$ & 4 ? t.$deferredConnectedCallback$ = !0 : Re(t.$lazyInstance$, e);
        }
        else {
            r = e.constructor;
            let $ = e.localName;
            customElements.whenDefined($).then(() => t.$flags$ |= 128);
        }
        if (r && r.style) {
            let $;
            typeof r.style == "string" ? $ = r.style : typeof r.style != "string" && (t.$modeName$ = Es(e), t.$modeName$ && ($ = r.style[t.$modeName$]));
            let o = he(s, t.$modeName$);
            if (!ie.has(o) || B.hotModuleReplacement) {
                let c = D("registerStyles", s.$tagName$);
                _t(o, $, !!(s.$flags$ & 1)), c();
            }
        }
    }
    let i = t.$ancestorComponent$, a = () => ge(t, !0);
    i && i["s-rc"] ? i["s-rc"].push(a) : a();
}
catch (i) {
    F(i, e), t.$onRenderResolve$ && (t.$onRenderResolve$(), t.$onRenderResolve$ = void 0), t.$onReadyResolve$ && t.$onReadyResolve$(e);
} }), Re = (e, t) => { R(e, "connectedCallback", void 0, t); }, Gs = e => { if ((S.$flags$ & 1) === 0) {
    let t = E(e);
    if (!t)
        return;
    let s = t.$cmpMeta$, n = D("connectedCallback", s.$tagName$);
    if (t.$flags$ & 1)
        Rt(e, t, s.$listeners$), t?.$lazyInstance$ ? Re(t.$lazyInstance$, e) : t?.$onReadyPromise$ && t.$onReadyPromise$.then(() => Re(t.$lazyInstance$, e));
    else {
        t.$flags$ |= 1;
        let r;
        if (r = e.getAttribute(J), r) {
            if (s.$flags$ & 1) {
                let i = bt(e.shadowRoot, s, e.getAttribute("s-mode"));
                e.classList.remove(i + "-h", i + "-s");
            }
            else if (s.$flags$ & 2) {
                let i = he(s, e.getAttribute("s-mode"));
                e["s-sc"] = i;
            }
            Ls(e, s.$tagName$, r, t);
        }
        r || s.$flags$ & 12 && Ys(e);
        {
            let i = e;
            for (; i = i.parentNode || i.host;)
                if (i.nodeType === 1 && i.hasAttribute("s-id") && i["s-p"] || i["s-p"]) {
                    Nt(t, t.$ancestorComponent$ = i);
                    break;
                }
        }
        s.$members$ && Object.entries(s.$members$).map(([i, [a]]) => { if (a & 31 && Object.prototype.hasOwnProperty.call(e, i)) {
            let l = e[i];
            delete e[i], e[i] = l;
        } }), Ps(e, t, s);
    }
    n();
} }, Ys = e => { if (!v.document)
    return; let t = e["s-cr"] = v.document.createComment(""); t["s-cn"] = !0, j(e, t, e.firstChild); }, it = (e, t) => { R(e, "disconnectedCallback", void 0, t || e); }, Xs = e => se(null, null, function* () { if ((S.$flags$ & 1) === 0) {
    let t = E(e);
    t?.$rmListeners$ && (t.$rmListeners$.map(s => s()), t.$rmListeners$ = void 0), t?.$lazyInstance$ ? it(t.$lazyInstance$, e) : t?.$onReadyPromise$ && t.$onReadyPromise$.then(() => it(t.$lazyInstance$, e));
} U.has(e) && U.delete(e), e.shadowRoot && U.has(e.shadowRoot) && U.delete(e.shadowRoot); }), gn = (e, t = {}) => { var s; if (!v.document) {
    console.warn("Stencil: No document found. Skipping bootstrapping lazy components.");
    return;
} let n = D(), r = [], i = t.exclude || [], a = v.customElements, l = v.document.head, $ = l.querySelector("meta[charset]"), o = v.document.createElement("style"), c = [], d, f = !0; Object.assign(S, t), S.$resourcesUrl$ = new URL(t.resourcesUrl || "./", v.document.baseURI).href, S.$flags$ |= 2, _s(); let h = !1; if (e.map(u => { u[1].map(y => { var x, T; let p = { $flags$: y[0], $tagName$: y[1], $members$: y[2], $listeners$: y[3] }; p.$flags$ & 4 && (h = !0), p.$members$ = y[2], p.$listeners$ = y[3], p.$attrsToReflect$ = [], p.$watchers$ = Fe(y[4]), p.$serializers$ = (x = y[5]) != null ? x : {}, p.$deserializers$ = (T = y[6]) != null ? T : {}; let O = p.$tagName$, _ = class extends HTMLElement {
    "s-p";
    "s-rc";
    hasRegisteredEventListeners = !1;
    constructor(g) { if (super(g), g = this, Wt(g, p), p.$flags$ & 1) {
        if (!g.shadowRoot)
            Qt.call(g, p);
        else if (g.shadowRoot.mode !== "open")
            throw new Error(`Unable to re-use existing shadow root for ${p.$tagName$}! Mode is set to ${g.shadowRoot.mode} but Stencil only supports open shadow roots.`);
    } }
    connectedCallback() { let g = E(this); g && (this.hasRegisteredEventListeners || (this.hasRegisteredEventListeners = !0, Rt(this, g, p.$listeners$)), d && (clearTimeout(d), d = null), f ? c.push(this) : S.jmp(() => Gs(this))); }
    disconnectedCallback() { S.jmp(() => Xs(this)), S.raf(() => { var g; let I = E(this); if (!I)
        return; let C = c.findIndex(ee => ee === this); C > -1 && c.splice(C, 1), ((g = I?.$vnode$) == null ? void 0 : g.$elm$) instanceof Node && !I.$vnode$.$elm$.isConnected && delete I.$vnode$.$elm$; }); }
    componentOnReady() { var g; return (g = E(this)) == null ? void 0 : g.$onReadyPromise$; }
}; !(p.$flags$ & 1) && p.$flags$ & 256 ? Vt(_.prototype) : vt(_.prototype), p.$lazyBundleId$ = u[0], !i.includes(O) && !a.get(O) && (r.push(O), a.define(O, jt(_, p, 1))); }); }), r.length > 0 && (h && (o.textContent += dt), o.textContent += r.sort() + Xt, o.innerHTML.length)) {
    o.setAttribute("data-styles", "");
    let u = (s = S.$nonce$) != null ? s : St(v.document);
    u != null && o.setAttribute("nonce", u), l.insertBefore(o, $ ? $.nextSibling : l.firstChild);
} f = !1, c.length ? c.map(u => u.connectedCallback()) : S.jmp(() => d = setTimeout(Ct, 30)), n(); }, vn = (e, t) => t, Rt = (e, t, s, n) => { s && v.document && s.map(([r, i, a]) => { let l = Ks(v.document, e, r), $ = Js(t, a), o = Zs(r); S.ael(l, i, $, o), (t.$rmListeners$ = t.$rmListeners$ || []).push(() => S.rel(l, i, $, o)); }); }, Js = (e, t) => s => { var n; try {
    e.$flags$ & 256 ? (n = e.$lazyInstance$) == null || n[t](s) : (e.$queuedListeners$ = e.$queuedListeners$ || []).push([t, s]);
}
catch (r) {
    F(r, e.$hostElement$);
} }, Ks = (e, t, s) => s & 4 ? e : s & 8 ? v : s & 16 ? e.body : t, Zs = e => Kt ? { passive: (e & 1) !== 0, capture: (e & 2) !== 0 } : (e & 2) !== 0;
export { lt as a, en as b, tn as c, sn as d, nn as e, rn as f, ln as g, on as h, an as i, $n as j, pt as k, fn as l, mt as m, ms as n, dn as o, un as p, Ns as q, hn as r, pn as s, gn as t, vn as u };
/*! Bundled license information:

@ionic/core/dist/esm/index-tcQvqkiX.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
  (*!__STENCIL_STATIC_IMPORT_SWITCH__*)
*/
