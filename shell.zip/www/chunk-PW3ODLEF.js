import { c as P } from "@nf-internal/chunk-56RDUDAP";
import { a as S } from "@nf-internal/chunk-55MUSWHY";
import { a as x, d as B } from "@nf-internal/chunk-GNHA26NQ";
import { b as A } from "@nf-internal/chunk-PJKO2XHO";
import { c as C } from "@nf-internal/chunk-DBOLI3CQ";
import { b as R, f as k, g as F, h as O, k as E } from "@nf-internal/chunk-NTOTMM2V";
import { a as h, e as _, f as q } from "@nf-internal/chunk-DPCBKAOC";
import { h as p } from "@nf-internal/chunk-C4FLJMU7";
var b = '[tabindex]:not([tabindex^="-"]):not([hidden]):not([disabled]), input:not([type=hidden]):not([tabindex^="-"]):not([hidden]):not([disabled]), textarea:not([tabindex^="-"]):not([hidden]):not([disabled]), button:not([tabindex^="-"]):not([hidden]):not([disabled]), select:not([tabindex^="-"]):not([hidden]):not([disabled]), ion-checkbox:not([tabindex^="-"]):not([hidden]):not([disabled]), ion-radio:not([tabindex^="-"]):not([hidden]):not([disabled]), .ion-focusable:not([tabindex^="-"]):not([hidden]):not([disabled]), .ion-focusable[disabled="false"]:not([tabindex^="-"]):not([hidden])', N = (e, n) => { let t = e.querySelector(b); G(t, n ?? e); }, V = (e, n) => { let t = Array.from(e.querySelectorAll(b)), o = t.length > 0 ? t[t.length - 1] : null; G(o, n ?? e); }, G = (e, n) => { let t = e, o = e?.shadowRoot; if (o && (t = o.querySelector(b) || e), t) {
    let s = t.closest("ion-radio-group");
    s ? s.setFocus() : E(t);
}
else
    n.focus(); }, I = 0, $ = 0, y = new WeakMap, T = e => { var n; return e.showBackdrop !== !1 && !(((n = e.backdropBreakpoint) !== null && n !== void 0 ? n : 0) > 0); }, g = e => ({ create(t) { return H(e, t); }, dismiss(t, o, s) { return X(document, t, o, e, s); }, getTop() { return p(this, null, function* () { return w(document, e); }); } }), fe = g("ion-alert"), pe = g("ion-action-sheet"), ge = g("ion-loading"), ve = g("ion-modal"), he = g("ion-picker-legacy"), we = g("ion-popover"), be = g("ion-toast"), ye = e => { typeof document < "u" && J(document); let n = I++; e.overlayIndex = n; }, Oe = e => (e.hasAttribute("id") || (e.id = `ion-overlay-${++$}`), e.id), H = (e, n) => typeof window < "u" && typeof window.customElements < "u" ? window.customElements.whenDefined(e).then(() => { let t = document.createElement(e); return t.classList.add("overlay-hidden"), Object.assign(t, Object.assign(Object.assign({}, n), { hasController: !0 })), L(document).appendChild(t), new Promise(o => R(t, o)); }) : Promise.resolve(), z = e => e.classList.contains("overlay-hidden"), j = (e, n) => { let t = e, o = e?.shadowRoot; o && (t = o.querySelector(b) || e), t ? E(t) : n.focus(); }, Q = (e, n) => { let t = w(n, "ion-alert,ion-action-sheet,ion-loading,ion-modal,ion-picker-legacy,ion-popover"), o = e.target; if (!t || !o || t.classList.contains(se))
    return; let s = () => { if (t === o)
    t.lastFocus = void 0;
else if (o.tagName === "ION-TOAST")
    j(t.lastFocus, t);
else {
    let a = O(t);
    if (!a.contains(o))
        return;
    let i = a.querySelector(".ion-overlay-wrapper");
    if (!i)
        return;
    if (i.contains(o) || o === a.querySelector("ion-backdrop"))
        t.lastFocus = o;
    else {
        let c = t.lastFocus;
        N(i, t), c === n.activeElement && V(i, t), t.lastFocus = n.activeElement;
    }
} }, r = () => { if (t.contains(o))
    t.lastFocus = o;
else if (o.tagName === "ION-TOAST")
    j(t.lastFocus, t);
else {
    let a = t.lastFocus;
    N(t), a === n.activeElement && V(t), t.lastFocus = n.activeElement;
} }; t.shadowRoot ? r() : s(); }, J = e => { I === 0 && (I = 1, e.addEventListener("focus", n => { Q(n, e); }, !0), e.addEventListener("ionBackButton", n => { let t = w(e); t?.backdropDismiss && n.detail.register(B, () => { t.dismiss(void 0, D); }); }), x() || e.addEventListener("keydown", n => { if (n.key === "Escape") {
    let t = w(e);
    t?.backdropDismiss && t.dismiss(void 0, D);
} })); }, X = (e, n, t, o, s) => { let r = w(e, o, s); return r ? r.dismiss(n, t) : Promise.reject("overlay does not exist"); }, Z = (e, n) => (n === void 0 && (n = "ion-alert,ion-action-sheet,ion-loading,ion-modal,ion-picker-legacy,ion-popover,ion-toast"), Array.from(e.querySelectorAll(n)).filter(t => t.overlayIndex > 0)), W = (e, n) => Z(e, n).filter(t => !z(t)), w = (e, n, t) => { let o = W(e, n); return (t === void 0 ? o : o.filter(s => s.id === t)).slice(-1)[0]; }, M = (e = !1) => { let t = L(document).querySelector("ion-router-outlet, #ion-view-container-root"); t && (e ? t.setAttribute("aria-hidden", "true") : t.removeAttribute("aria-hidden")); }, Ee = (e, n, t, o, s) => p(null, null, function* () { var r, a; if (e.presented)
    return; e.el.tagName !== "ION-TOAST" && ee(e.el); let i = e.el, d = i.tagName !== "ION-TOAST" && i.focusTrap !== !1 && T(i); if (e.presented = !0, e.willPresent.emit(), d) {
    let l = L(document).querySelector("ion-router-outlet, #ion-view-container-root");
    l && l.contains(i) || M(!0), document.body.classList.add(S);
} (r = e.willPresentShorthand) === null || r === void 0 || r.emit(); let u = C(e), m = e.enterAnimation ? e.enterAnimation : h.get(n, u === "ios" ? t : o); if ((yield U(e, m, e.el, s)) && (e.didPresent.emit(), (a = e.didPresentShorthand) === null || a === void 0 || a.emit()), e.keyboardClose && (document.activeElement === null || !e.el.contains(document.activeElement))) {
    let v = O(e.el).querySelector('[role="dialog"][tabindex]'), l = v ?? e.el;
    try {
        l.focus({ preventScroll: !0 });
    }
    catch {
        l.focus();
    }
} e.el.removeAttribute("aria-hidden"), e.el.removeAttribute("inert"); }), ee = e => p(null, null, function* () { let n = document.activeElement; if (!n)
    return; n.blur(); let t = n?.shadowRoot; t && (n = t.querySelector(b) || n), yield e.onDidDismiss(), (document.activeElement === null || document.activeElement === document.body) && n.focus(); }), Ce = (e, n, t, o, s, r, a) => p(null, null, function* () { var i, c; if (!e.presented)
    return !1; let u = (A !== void 0 ? W(A) : []).filter(l => { let f = l; return f.tagName !== "ION-TOAST" && f.focusTrap !== !1 && T(f); }), m = e.el; m.tagName !== "ION-TOAST" && m.focusTrap !== !1 && T(m) && u.length === 1 && u[0].id === m.id && (M(!1), document.body.classList.remove(S)), e.presented = !1; try {
    e.el.style.setProperty("pointer-events", "none"), e.willDismiss.emit({ data: n, role: t }), (i = e.willDismissShorthand) === null || i === void 0 || i.emit({ data: n, role: t });
    let l = C(e), f = e.leaveAnimation ? e.leaveAnimation : h.get(o, l === "ios" ? s : r);
    t !== oe && (yield U(e, f, e.el, a)), e.didDismiss.emit({ data: n, role: t }), (c = e.didDismissShorthand) === null || c === void 0 || c.emit({ data: n, role: t }), (y.get(e) || []).forEach(Y => Y.destroy()), y.delete(e), e.el.classList.add("overlay-hidden"), e.el.style.removeProperty("pointer-events"), e.el.lastFocus !== void 0 && (e.el.lastFocus = void 0);
}
catch (l) {
    q(`[${e.el.tagName.toLowerCase()}] - `, l);
} return e.el.remove(), !0; }), L = e => e.querySelector("ion-app") || e.body, U = (e, n, t, o) => p(null, null, function* () { t.classList.remove("overlay-hidden"); let s = e.el, r = n(s, o); (!e.animated || !h.getBoolean("animated", !0)) && r.duration(0), e.keyboardClose && r.beforeAddWrite(() => { let i = t.ownerDocument.activeElement; i?.matches("input,ion-input, ion-textarea") && i.blur(); }); let a = y.get(e) || []; return y.set(e, [...a, r]), yield r.play(), !0; }), Ae = (e, n) => { let t, o = new Promise(s => t = s); return te(e, n, s => { t(s.detail); }), o; }, te = (e, n, t) => { let o = s => { F(e, n, o), t(s); }; k(e, n, o); }, Se = e => e === "cancel" || e === D, ne = e => e(), Ie = (e, n) => { if (typeof e == "function")
    return h.get("_zoneGate", ne)(() => { try {
        return e(n);
    }
    catch (o) {
        throw o;
    } }); }, D = "backdrop", oe = "gesture", Te = 39, De = e => { let n = !1, t, o = P(), s = (i = !1) => { if (t && !i)
    return { delegate: t, inline: n }; let { el: c, hasController: d, delegate: u } = e; return n = c.parentNode !== null && !d, t = n ? u || o : u, { inline: n, delegate: t }; }; return { attachViewToDom: i => p(null, null, function* () { let { delegate: c } = s(!0); if (c)
        return yield c.attachViewToDom(e.el, i); let { hasController: d } = e; if (d && i !== void 0)
        throw new Error("framework delegate is missing"); return null; }), removeViewFromDom: () => { let { delegate: i } = s(); i && e.el !== void 0 && i.removeViewFromDom(e.el.parentElement, e.el); } }; }, Le = () => { let e, n = () => { e && (e(), e = void 0); }; return { addClickListener: (o, s) => { n(); let r = s !== void 0 ? document.getElementById(s) : null; if (!r) {
        _(`[${o.tagName.toLowerCase()}] - A trigger element with the ID "${s}" was not found in the DOM. The trigger element must be in the DOM when the "trigger" property is set on an overlay component.`, o);
        return;
    } e = ((i, c) => { let d = () => { c.present(); }; return i.addEventListener("click", d), () => { i.removeEventListener("click", d); }; })(r, o); }, removeClickListener: n }; }, se = "ion-disable-focus-trap";
export { N as a, V as b, fe as c, pe as d, ge as e, ve as f, he as g, we as h, be as i, ye as j, Oe as k, w as l, Ee as m, Ce as n, Ae as o, Se as p, Ie as q, D as r, oe as s, Te as t, De as u, Le as v, se as w };
/*! Bundled license information:

@ionic/core/dist/esm/overlays-Dg0q2_tJ.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
