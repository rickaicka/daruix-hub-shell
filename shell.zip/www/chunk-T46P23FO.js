import { a as _, b as R } from "@nf-internal/chunk-C4FLJMU7";
import { DOCUMENT as A, \u0275getDOM as j } from "@angular/common";
import * as a from "@angular/core";
import { InjectionToken as L, \u0275RuntimeError as M, APP_ID as x, CSP_NONCE as H, PLATFORM_ID as k, ViewEncapsulation as p, \u0275TracingService as B, RendererStyleFlags2 as v, \u0275allLeavingAnimations as $ } from "@angular/core";
var C = class {
    _doc;
    constructor(n) { this._doc = n; }
    manager;
}, T = (() => { class r extends C {
    constructor(e) { super(e); }
    supports(e) { return !0; }
    addEventListener(e, t, s, o) { return e.addEventListener(t, s, o), () => this.removeEventListener(e, t, s, o); }
    removeEventListener(e, t, s, o) { return e.removeEventListener(t, s, o); }
    static \u0275fac = function (t) { return new (t || r)(a.\u0275\u0275inject(A)); };
    static \u0275prov = a.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac });
} return r; })(), F = new L(""), Z = (() => { class r {
    _zone;
    _plugins;
    _eventNameToPlugin = new Map;
    constructor(e, t) { this._zone = t, e.forEach(i => { i.manager = this; }); let s = e.filter(i => !(i instanceof T)); this._plugins = s.slice().reverse(); let o = e.find(i => i instanceof T); o && this._plugins.push(o); }
    addEventListener(e, t, s, o) { return this._findPluginFor(t).addEventListener(e, t, s, o); }
    getZone() { return this._zone; }
    _findPluginFor(e) { let t = this._eventNameToPlugin.get(e); if (t)
        return t; if (t = this._plugins.find(o => o.supports(e)), !t)
        throw new M(5101, !1); return this._eventNameToPlugin.set(e, t), t; }
    static \u0275fac = function (t) { return new (t || r)(a.\u0275\u0275inject(F), a.\u0275\u0275inject(a.NgZone)); };
    static \u0275prov = a.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac });
} return r; })(), m = "ng-app-id";
function P(r) { for (let n of r)
    n.remove(); }
function b(r, n) { let e = n.createElement("style"); return e.textContent = r, e; }
function G(r, n, e, t) { let s = r.head?.querySelectorAll(`style[${m}="${n}"],link[${m}="${n}"]`); if (s)
    for (let o of s)
        o.removeAttribute(m), o instanceof HTMLLinkElement ? t.set(o.href.slice(o.href.lastIndexOf("/") + 1), { usage: 0, elements: [o] }) : o.textContent && e.set(o.textContent, { usage: 0, elements: [o] }); }
function D(r, n) { let e = n.createElement("link"); return e.setAttribute("rel", "stylesheet"), e.setAttribute("href", r), e; }
var V = (() => { class r {
    doc;
    appId;
    nonce;
    inline = new Map;
    external = new Map;
    hosts = new Set;
    constructor(e, t, s, o = {}) { this.doc = e, this.appId = t, this.nonce = s, G(e, t, this.inline, this.external), this.hosts.add(e.head); }
    addStyles(e, t) { for (let s of e)
        this.addUsage(s, this.inline, b); t?.forEach(s => this.addUsage(s, this.external, D)); }
    removeStyles(e, t) { for (let s of e)
        this.removeUsage(s, this.inline); t?.forEach(s => this.removeUsage(s, this.external)); }
    addUsage(e, t, s) { let o = t.get(e); o ? o.usage++ : t.set(e, { usage: 1, elements: [...this.hosts].map(i => this.addElement(i, s(e, this.doc))) }); }
    removeUsage(e, t) { let s = t.get(e); s && (s.usage--, s.usage <= 0 && (P(s.elements), t.delete(e))); }
    ngOnDestroy() { for (let [, { elements: e }] of [...this.inline, ...this.external])
        P(e); this.hosts.clear(); }
    addHost(e) { this.hosts.add(e); for (let [t, { elements: s }] of this.inline)
        s.push(this.addElement(e, b(t, this.doc))); for (let [t, { elements: s }] of this.external)
        s.push(this.addElement(e, D(t, this.doc))); }
    removeHost(e) { this.hosts.delete(e); }
    addElement(e, t) { return this.nonce && t.setAttribute("nonce", this.nonce), typeof ngServerMode < "u" && ngServerMode && t.setAttribute(m, this.appId), e.appendChild(t); }
    static \u0275fac = function (t) { return new (t || r)(a.\u0275\u0275inject(A), a.\u0275\u0275inject(x), a.\u0275\u0275inject(H, 8), a.\u0275\u0275inject(k)); };
    static \u0275prov = a.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac });
} return r; })(), w = { svg: "http://www.w3.org/2000/svg", xhtml: "http://www.w3.org/1999/xhtml", xlink: "http://www.w3.org/1999/xlink", xml: "http://www.w3.org/XML/1998/namespace", xmlns: "http://www.w3.org/2000/xmlns/", math: "http://www.w3.org/1998/Math/MathML" }, O = /%COMP%/g;
var I = "%COMP%", z = `_nghost-${I}`, X = `_ngcontent-${I}`, Y = !0, q = new L("", { factory: () => Y });
function W(r) { return X.replace(O, r); }
function J(r) { return z.replace(O, r); }
function U(r, n) { return n.map(e => e.replace(O, r)); }
var se = (() => { class r {
    eventManager;
    sharedStylesHost;
    appId;
    removeStylesOnCompDestroy;
    doc;
    ngZone;
    nonce;
    tracingService;
    rendererByCompId = new Map;
    defaultRenderer;
    constructor(e, t, s, o, i, l, c = null, d = null) { this.eventManager = e, this.sharedStylesHost = t, this.appId = s, this.removeStylesOnCompDestroy = o, this.doc = i, this.ngZone = l, this.nonce = c, this.tracingService = d, this.defaultRenderer = new g(e, i, l, this.tracingService); }
    createRenderer(e, t) { if (!e || !t)
        return this.defaultRenderer; typeof ngServerMode < "u" && ngServerMode && (t.encapsulation === p.ShadowDom || t.encapsulation === p.ExperimentalIsolatedShadowDom) && (t = R(_({}, t), { encapsulation: p.Emulated })); let s = this.getOrCreateRenderer(e, t); return s instanceof E ? s.applyToHost(e) : s instanceof y && s.applyStyles(), s; }
    getOrCreateRenderer(e, t) { let s = this.rendererByCompId, o = s.get(t.id); if (!o) {
        let i = this.doc, l = this.ngZone, c = this.eventManager, d = this.sharedStylesHost, u = this.removeStylesOnCompDestroy, h = this.tracingService;
        switch (t.encapsulation) {
            case p.Emulated:
                o = new E(c, d, t, this.appId, u, i, l, h);
                break;
            case p.ShadowDom: return new S(c, e, t, i, l, this.nonce, h, d);
            case p.ExperimentalIsolatedShadowDom: return new S(c, e, t, i, l, this.nonce, h);
            default:
                o = new y(c, d, t, u, i, l, h);
                break;
        }
        s.set(t.id, o);
    } return o; }
    ngOnDestroy() { this.rendererByCompId.clear(); }
    componentReplaced(e) { this.rendererByCompId.delete(e); }
    static \u0275fac = function (t) { return new (t || r)(a.\u0275\u0275inject(Z), a.\u0275\u0275inject(V), a.\u0275\u0275inject(x), a.\u0275\u0275inject(q), a.\u0275\u0275inject(A), a.\u0275\u0275inject(a.NgZone), a.\u0275\u0275inject(H), a.\u0275\u0275inject(B, 8)); };
    static \u0275prov = a.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac });
} return r; })(), g = class {
    eventManager;
    doc;
    ngZone;
    tracingService;
    data = Object.create(null);
    throwOnSyntheticProps = !0;
    constructor(n, e, t, s) { this.eventManager = n, this.doc = e, this.ngZone = t, this.tracingService = s; }
    destroy() { }
    destroyNode = null;
    createElement(n, e) { return e ? this.doc.createElementNS(w[e] || e, n) : this.doc.createElement(n); }
    createComment(n) { return this.doc.createComment(n); }
    createText(n) { return this.doc.createTextNode(n); }
    appendChild(n, e) { (N(n) ? n.content : n).appendChild(e); }
    insertBefore(n, e, t) { n && (N(n) ? n.content : n).insertBefore(e, t); }
    removeChild(n, e) { e.remove(); }
    selectRootElement(n, e) { let t = typeof n == "string" ? this.doc.querySelector(n) : n; if (!t)
        throw new M(-5104, !1); return e || (t.textContent = ""), t; }
    parentNode(n) { return n.parentNode; }
    nextSibling(n) { return n.nextSibling; }
    setAttribute(n, e, t, s) { if (s) {
        e = s + ":" + e;
        let o = w[s];
        o ? n.setAttributeNS(o, e, t) : n.setAttribute(e, t);
    }
    else
        n.setAttribute(e, t); }
    removeAttribute(n, e, t) { if (t) {
        let s = w[t];
        s ? n.removeAttributeNS(s, e) : n.removeAttribute(`${t}:${e}`);
    }
    else
        n.removeAttribute(e); }
    addClass(n, e) { n.classList.add(e); }
    removeClass(n, e) { n.classList.remove(e); }
    setStyle(n, e, t, s) { s & (v.DashCase | v.Important) ? n.style.setProperty(e, t, s & v.Important ? "important" : "") : n.style[e] = t; }
    removeStyle(n, e, t) { t & v.DashCase ? n.style.removeProperty(e) : n.style[e] = ""; }
    setProperty(n, e, t) { n != null && (n[e] = t); }
    setValue(n, e) { n.nodeValue = e; }
    listen(n, e, t, s) { if (typeof n == "string" && (n = j().getGlobalEventTarget(this.doc, n), !n))
        throw new M(5102, !1); let o = this.decoratePreventDefault(t); return this.tracingService?.wrapEventListener && (o = this.tracingService.wrapEventListener(n, e, o)), this.eventManager.addEventListener(n, e, o, s); }
    decoratePreventDefault(n) { return e => { if (e === "__ngUnwrap__")
        return n; (typeof ngServerMode < "u" && ngServerMode ? this.ngZone.runGuarded(() => n(e)) : n(e)) === !1 && e.preventDefault(); }; }
};
function N(r) { return r.tagName === "TEMPLATE" && r.content !== void 0; }
var S = class extends g {
    hostEl;
    sharedStylesHost;
    shadowRoot;
    constructor(n, e, t, s, o, i, l, c) { super(n, s, o, l), this.hostEl = e, this.sharedStylesHost = c, this.shadowRoot = e.attachShadow({ mode: "open" }), this.sharedStylesHost && this.sharedStylesHost.addHost(this.shadowRoot); let d = t.styles; d = U(t.id, d); for (let h of d) {
        let f = document.createElement("style");
        i && f.setAttribute("nonce", i), f.textContent = h, this.shadowRoot.appendChild(f);
    } let u = t.getExternalStyles?.(); if (u)
        for (let h of u) {
            let f = D(h, s);
            i && f.setAttribute("nonce", i), this.shadowRoot.appendChild(f);
        } }
    nodeOrShadowRoot(n) { return n === this.hostEl ? this.shadowRoot : n; }
    appendChild(n, e) { return super.appendChild(this.nodeOrShadowRoot(n), e); }
    insertBefore(n, e, t) { return super.insertBefore(this.nodeOrShadowRoot(n), e, t); }
    removeChild(n, e) { return super.removeChild(null, e); }
    parentNode(n) { return this.nodeOrShadowRoot(super.parentNode(this.nodeOrShadowRoot(n))); }
    destroy() { this.sharedStylesHost && this.sharedStylesHost.removeHost(this.shadowRoot); }
}, y = class extends g {
    sharedStylesHost;
    removeStylesOnCompDestroy;
    styles;
    styleUrls;
    constructor(n, e, t, s, o, i, l, c) { super(n, o, i, l), this.sharedStylesHost = e, this.removeStylesOnCompDestroy = s; let d = t.styles; this.styles = c ? U(c, d) : d, this.styleUrls = t.getExternalStyles?.(c); }
    applyStyles() { this.sharedStylesHost.addStyles(this.styles, this.styleUrls); }
    destroy() { this.removeStylesOnCompDestroy && $.size === 0 && this.sharedStylesHost.removeStyles(this.styles, this.styleUrls); }
}, E = class extends y {
    contentAttr;
    hostAttr;
    constructor(n, e, t, s, o, i, l, c) { let d = s + "-" + t.id; super(n, e, t, o, i, l, c, d), this.contentAttr = W(d), this.hostAttr = J(d); }
    applyToHost(n) { this.applyStyles(), this.setAttribute(n, this.hostAttr, ""); }
    createElement(n, e) { let t = super.createElement(n, e); return super.setAttribute(t, this.contentAttr, ""), t; }
};
export { C as a, T as b, F as c, Z as d, V as e, q as f, se as g };
/*! Bundled license information:

@angular/platform-browser/fesm2022/_dom_renderer-chunk.mjs:
  (**
   * @license Angular v21.2.18
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
