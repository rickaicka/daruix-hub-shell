import { a as oe } from "@nf-internal/chunk-JYWXGWOM";
import { i as z } from "@nf-internal/chunk-VIUXLIDC";
import { a as O, e as Ae, f as ke, h as Ce, k as Pe } from "@nf-internal/chunk-VUYV6ZIW";
import { h as b } from "@nf-internal/chunk-C4FLJMU7";
var ne, re = (t, i, o) => { let s = i.startsWith("animation") ? (d = t, ne === void 0 && (ne = d.style.animationName === void 0 && d.style.webkitAnimationName !== void 0 ? "-webkit-" : ""), ne) : ""; var d; t.style.setProperty(s + i, o); }, j = (t = [], i) => { if (i !== void 0) {
    let o = Array.isArray(i) ? i : [i];
    return [...t, ...o];
} return t; }, Ye = t => { let i, o, s, d, y, w, f, C, W, P, n, u = [], $ = [], G = [], A = !1, H = {}, J = [], Q = [], X = {}, S = 0, B = !1, F = !1, L = !0, D = !1, I = !0, M = !1, le = t, Y = [], R = [], V = [], E = [], m = [], ce = [], de = [], fe = [], ue = [], me = [], v = [], qe = typeof AnimationEffect == "function" || oe !== void 0 && typeof oe.AnimationEffect == "function", h = typeof Element == "function" && typeof Element.prototype.animate == "function" && qe, pe = () => v, ge = (e, a) => { let r = a.findIndex(l => l.c === e); r > -1 && a.splice(r, 1); }, Z = (e, a) => ((a?.oneTimeCallback ? R : Y).push({ c: e, o: a }), n), he = () => { h && (v.forEach(e => { e.cancel(); }), v.length = 0); }, xe = () => { ce.forEach(e => { e?.parentNode && e.parentNode.removeChild(e); }), ce.length = 0; }, ee = () => y !== void 0 ? y : f ? f.getFill() : "both", K = () => C !== void 0 ? C : w !== void 0 ? w : f ? f.getDirection() : "normal", te = () => B ? "linear" : s !== void 0 ? s : f ? f.getEasing() : "linear", T = () => F ? 0 : W !== void 0 ? W : o !== void 0 ? o : f ? f.getDuration() : 0, ie = () => d !== void 0 ? d : f ? f.getIterations() : 1, ae = () => P !== void 0 ? P : i !== void 0 ? i : f ? f.getDelay() : 0, N = () => { S !== 0 && (S--, S === 0 && ((() => { ue.forEach(c => c()), me.forEach(c => c()); let e = L ? 1 : 0, a = J, r = Q, l = X; E.forEach(c => { let g = c.classList; a.forEach(k => g.add(k)), r.forEach(k => g.remove(k)); for (let k in l)
    l.hasOwnProperty(k) && re(c, k, l[k]); }), W = void 0, C = void 0, P = void 0, Y.forEach(c => c.c(e, n)), R.forEach(c => c.c(e, n)), R.length = 0, I = !0, L && (D = !0), L = !0; })(), f && f.animationFinish())); }, ve = () => { (() => { de.forEach(l => l()), fe.forEach(l => l()); let e = $, a = G, r = H; E.forEach(l => { let c = l.classList; e.forEach(g => c.add(g)), a.forEach(g => c.remove(g)); for (let g in r)
    r.hasOwnProperty(g) && re(l, g, r[g]); }); })(), u.length > 0 && h && (E.forEach(e => { let a = e.animate(u, { id: le, delay: ae(), duration: T(), easing: te(), iterations: ie(), fill: ee(), direction: K() }); a.pause(), v.push(a); }), v.length > 0 && (v[0].onfinish = () => { N(); })), A = !0; }, q = e => { e = Math.min(Math.max(e, 0), .9999), h && v.forEach(a => { a.currentTime = a.effect.getComputedTiming().delay + T() * e, a.pause(); }); }, ye = e => { v.forEach(a => { a.effect.updateTiming({ delay: ae(), duration: T(), easing: te(), iterations: ie(), fill: ee(), direction: K() }); }), e !== void 0 && q(e); }, p = (e = !1, a = !0, r) => (e && m.forEach(l => { l.update(e, a, r); }), h && ye(r), n), Ee = () => { A && (h ? v.forEach(e => { e.pause(); }) : E.forEach(e => { re(e, "animation-play-state", "paused"); }), M = !0); }, be = e => new Promise(a => { e?.sync && (F = !0, Z(() => F = !1, { oneTimeCallback: !0 })), A || ve(), D && (h && (q(0), ye()), D = !1), I && (S = m.length + 1, I = !1); let r = () => { ge(l, R), a(); }, l = () => { ge(r, V), a(); }; Z(l, { oneTimeCallback: !0 }), V.push({ c: r, o: { oneTimeCallback: !0 } }), m.forEach(c => { c.play(); }), h ? (v.forEach(c => { c.play(); }), u.length !== 0 && E.length !== 0 || N()) : N(), M = !1; }), we = (e, a) => { let r = u[0]; return r === void 0 || r.offset !== void 0 && r.offset !== 0 ? u = [{ offset: 0, [e]: a }, ...u] : r[e] = a, n; }; return n = { parentAnimation: f, elements: E, childAnimations: m, id: le, animationFinish: N, from: we, to: (e, a) => { let r = u[u.length - 1]; return r === void 0 || r.offset !== void 0 && r.offset !== 1 ? u = [...u, { offset: 1, [e]: a }] : r[e] = a, n; }, fromTo: (e, a, r) => we(e, a).to(e, r), parent: e => (f = e, n), play: be, pause: () => (m.forEach(e => { e.pause(); }), Ee(), n), stop: () => { m.forEach(e => { e.stop(); }), A && (he(), A = !1), B = !1, F = !1, I = !0, C = void 0, W = void 0, P = void 0, S = 0, D = !1, L = !0, M = !1, V.forEach(e => e.c(0, n)), V.length = 0; }, destroy: e => (m.forEach(a => { a.destroy(e); }), (a => { he(), a && xe(); })(e), E.length = 0, m.length = 0, u.length = 0, Y.length = 0, R.length = 0, A = !1, I = !0, n), keyframes: e => { let a = u !== e; return u = e, a && (r => { h && pe().forEach(l => { let c = l.effect; if (c.setKeyframes)
        c.setKeyframes(r);
    else {
        let g = new KeyframeEffect(c.target, r, c.getTiming());
        l.effect = g;
    } }); })(u), n; }, addAnimation: e => { if (e != null)
        if (Array.isArray(e))
            for (let a of e)
                a.parent(n), m.push(a);
        else
            e.parent(n), m.push(e); return n; }, addElement: e => { if (e != null)
        if (e.nodeType === 1)
            E.push(e);
        else if (e.length >= 0)
            for (let a = 0; a < e.length; a++)
                E.push(e[a]);
        else
            ke("createAnimation - Invalid addElement value."); return n; }, update: p, fill: e => (y = e, p(!0), n), direction: e => (w = e, p(!0), n), iterations: e => (d = e, p(!0), n), duration: e => (h || e !== 0 || (e = 1), o = e, p(!0), n), easing: e => (s = e, p(!0), n), delay: e => (i = e, p(!0), n), getWebAnimations: pe, getKeyframes: () => u, getFill: ee, getDirection: K, getDelay: ae, getIterations: ie, getEasing: te, getDuration: T, afterAddRead: e => (ue.push(e), n), afterAddWrite: e => (me.push(e), n), afterClearStyles: (e = []) => { for (let a of e)
        X[a] = ""; return n; }, afterStyles: (e = {}) => (X = e, n), afterRemoveClass: e => (Q = j(Q, e), n), afterAddClass: e => (J = j(J, e), n), beforeAddRead: e => (de.push(e), n), beforeAddWrite: e => (fe.push(e), n), beforeClearStyles: (e = []) => { for (let a of e)
        H[a] = ""; return n; }, beforeStyles: (e = {}) => (H = e, n), beforeRemoveClass: e => (G = j(G, e), n), beforeAddClass: e => ($ = j($, e), n), onFinish: Z, isRunning: () => S !== 0 && !M, progressStart: (e = !1, a) => (m.forEach(r => { r.progressStart(e, a); }), Ee(), B = e, A || ve(), p(!1, !0, a), n), progressStep: e => (m.forEach(a => { a.progressStep(e); }), q(e), n), progressEnd: (e, a, r) => (B = !1, m.forEach(l => { l.progressEnd(e, a, r); }), r !== void 0 && (W = r), D = !1, L = !0, e === 0 ? (C = K() === "reverse" ? "normal" : "reverse", C === "reverse" && (L = !1), h ? (p(), q(1 - a)) : (P = (1 - a) * T() * -1, p(!1, !1))) : e === 1 && (h ? (p(), q(a)) : (P = a * T() * -1, p(!1, !1))), e === void 0 || f || be(), n) }; };
var Be = "ionViewWillEnter", Fe = "ionViewDidEnter", Me = "ionViewWillLeave", Ve = "ionViewDidLeave", it = "ionViewWillUnload", x = t => { t.tabIndex = -1, t.focus(); }, U = t => t.offsetParent !== null, Te = "ion-last-focus", Ke = t => { if (O.get("focusManagerPriority", !1)) {
    let i = document.activeElement;
    i !== null && t?.contains(i) && i.setAttribute(Te, "true");
} }, Ne = t => { let i = O.get("focusManagerPriority", !1); if (Array.isArray(i) && !t.contains(document.activeElement)) {
    let o = t.querySelector(`[${Te}]`);
    if (o && U(o))
        return void x(o);
    for (let s of i)
        switch (s) {
            case "content":
                let d = t.querySelector('main, [role="main"]');
                if (d && U(d))
                    return void x(d);
                break;
            case "heading":
                let y = t.querySelector('h1, [role="heading"][aria-level="1"]');
                if (y && U(y))
                    return void x(y);
                break;
            case "banner":
                let w = t.querySelector('header, [role="banner"]');
                if (w && U(w))
                    return void x(w);
                break;
            default: Ae(`Unrecognized focus manager priority value ${s}`);
        }
    x(t);
} }, at = t => new Promise((i, o) => { Pe(() => { let s = Je(t); Oe(t, s), ze(t).then(d => { d.animation && d.animation.destroy(), Se(t), i(d); }, d => { Se(t), o(d); }).finally(() => { Re(s, !1); }); }); }), Oe = (t, i) => { let o = t.enteringEl, s = t.leavingEl; Ke(s), He(o, s, t.direction), Re(i, !0), t.showGoBack ? o.classList.add("can-go-back") : o.classList.remove("can-go-back"), Le(o, !1), o.style.setProperty("pointer-events", "none"), s && (Le(s, !1), s.style.setProperty("pointer-events", "none")); }, ze = t => b(null, null, function* () { let i = yield je(t); return i && Ce.isBrowser ? Ue(i, t) : _e(t); }), Se = t => { let i = t.enteringEl, o = t.leavingEl; i.classList.remove("ion-page-invisible"), i.style.removeProperty("pointer-events"), o !== void 0 && (o.classList.remove("ion-page-invisible"), o.style.removeProperty("pointer-events")), Ne(i); }, je = t => b(null, null, function* () { if (t.leavingEl && t.animated && t.duration !== 0)
    return t.animationBuilder ? t.animationBuilder : t.mode === "ios" ? (yield import("@nf-internal/p-C1aScSTo-73PCUXQA")).iosTransitionAnimation : (yield import("@nf-internal/p-DIE4pXMl-UOF7UFQ5")).mdTransitionAnimation; }), Ue = (t, i) => b(null, null, function* () { yield We(i, !0); let o = t(i.baseEl, i); De(i.enteringEl, i.leavingEl); let s = yield Ge(o, i); return i.progressCallback && i.progressCallback(void 0), s && Ie(i.enteringEl, i.leavingEl), { hasCompleted: s, animation: o }; }), _e = t => b(null, null, function* () { let i = t.enteringEl, o = t.leavingEl, s = O.get("focusManagerPriority", !1); return yield We(t, s), De(i, o), Ie(i, o), { hasCompleted: !0 }; }), We = (t, i) => b(null, null, function* () { (t.deepWait !== void 0 ? t.deepWait : i) && (yield Promise.all([se(t.enteringEl), se(t.leavingEl)])), yield $e(t.viewIsReady, t.enteringEl); }), $e = (t, i) => b(null, null, function* () { t && (yield t(i)); }), Ge = (t, i) => { let o = i.progressCallback, s = new Promise(d => { t.onFinish(y => d(y === 1)); }); return o ? (t.progressStart(!0), o(t)) : t.play(), s; }, De = (t, i) => { _(i, Me), _(t, Be); }, Ie = (t, i) => { _(t, Fe), _(i, Ve); }, _ = (t, i) => { if (t) {
    let o = new CustomEvent(i, { bubbles: !1, cancelable: !1 });
    t.dispatchEvent(o);
} }, ot = () => new Promise(t => z(() => z(() => t()))), se = t => b(null, null, function* () { let i = t; if (i) {
    if (i.componentOnReady != null) {
        if ((yield i.componentOnReady()) != null)
            return;
    }
    else if (i.__registerHost != null)
        return void (yield new Promise(s => z(s)));
    yield Promise.all(Array.from(i.children).map(se));
} }), Le = (t, i) => { i ? (t.setAttribute("aria-hidden", "true"), t.classList.add("ion-page-hidden")) : (t.hidden = !1, t.removeAttribute("aria-hidden"), t.classList.remove("ion-page-hidden")); }, He = (t, i, o) => { t !== void 0 && (t.style.zIndex = o === "back" ? "99" : "101"), i !== void 0 && (i.style.zIndex = "100"); }, Re = (t, i) => { if (!t)
    return; let o = "header-transitioning"; i ? t.classList.add(o) : t.classList.remove(o); }, nt = t => t.classList.contains("ion-page") ? t : t.querySelector(":scope > .ion-page, :scope > ion-nav, :scope > ion-tabs") || t, Je = t => { if (t.mode !== "ios")
    return null; let i = t.direction === "back" ? t.leavingEl : t.enteringEl; return i ? i.querySelector("ion-header") : null; };
export { Ye as a, Be as b, Fe as c, Me as d, Ve as e, it as f, at as g, _ as h, ot as i, se as j, Le as k, nt as l };
/*! Bundled license information:

@ionic/core/components/p-CmR5uXej.js:
@ionic/core/components/p-CtukzcyX.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
