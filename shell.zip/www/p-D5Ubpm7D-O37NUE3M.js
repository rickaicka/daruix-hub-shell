import { b as V, c as X } from "@nf-internal/chunk-C6YDS23S";
import { d as G, f as J, h as Q } from "@nf-internal/chunk-VDCIG7RT";
import { a as h, b as B } from "@nf-internal/chunk-JYWXGWOM";
import { b as F, f as T, g as C } from "@nf-internal/chunk-VIUXLIDC";
import "@nf-internal/chunk-VUYV6ZIW";
import { h as M } from "@nf-internal/chunk-C4FLJMU7";
var $ = new WeakMap, H = (e, t, o, r = 0, v = !1) => { $.has(e) !== o && (o ? oe(e, t, r, v) : ne(e, t)); }, oe = (e, t, o, r = !1) => { let v = t.parentNode, d = t.cloneNode(!1); d.classList.add("cloned-input"), d.tabIndex = -1, r && (d.disabled = !0); let S = e.ownerDocument.dir === "rtl"; d.style.insetInlineStart = S ? v.offsetWidth - t.offsetLeft - t.offsetWidth + "px" : `${t.offsetLeft}px`, v.appendChild(d), $.set(e, d); let K = S ? 9999 : -9999; e.style.pointerEvents = "none", t.style.transform = `translate3d(${K}px,${o}px,0) scale(0)`; }, ne = (e, t) => { let o = $.get(e); o && ($.delete(e), o.remove()), e.style.pointerEvents = "", t.style.transform = ""; }, q = "input, textarea, [no-blur], [contenteditable]", Z = "$ionPaddingTimer", j = (e, t, o) => { let r = e[Z]; r && clearTimeout(r), t > 0 ? e.style.setProperty("--keyboard-offset", `${t}px`) : e[Z] = setTimeout(() => { e.style.setProperty("--keyboard-offset", "0px"), o && o(); }, 120); }, _ = (e, t, o) => { e.addEventListener("focusout", () => { t && j(t, 0, o); }, { once: !0 }); }, P = 0, z = "data-ionic-skip-scroll-assist", Y = e => { var t; if (document.activeElement === e)
    return; let o = e.getAttribute("id"), r = e.closest(`label[for="${o}"]`), v = (t = document.activeElement) === null || t === void 0 ? void 0 : t.closest(`label[for="${o}"]`); r !== null && r === v || (e.setAttribute(z, "true"), e.focus()); }, ee = (e, t, o, r, v, d, S = !1, K = 0, I = !0) => M(null, null, function* () { if (!o && !r)
    return; let p = ((m, c, L, b) => { var n; return ((s, i, w, y) => { let l = s.top, u = s.bottom, a = i.top, f = a + 15, E = Math.min(i.bottom, y - w) - 50 - u, D = f - l, x = Math.round(E < 0 ? -E : D > 0 ? -D : 0), g = Math.min(x, l - a), A = Math.abs(g); return { scrollAmount: g, scrollDuration: Math.min(400, Math.max(150, A / .3)), scrollPadding: w, inputSafeY: 4 - (l - f) }; })(((n = m.closest("ion-item,[ion-item]")) !== null && n !== void 0 ? n : m).getBoundingClientRect(), c.getBoundingClientRect(), L, b); })(e, o || r, v, K); if (o && Math.abs(p.scrollAmount) < 4)
    return Y(t), void (d && o !== null && (j(o, P), _(t, o, () => P = 0))); if (H(e, t, !0, p.inputSafeY, S), Y(t), d && o && (P = p.scrollPadding, j(o, P)), typeof window < "u") {
    let m, c = () => M(null, null, function* () { m !== void 0 && clearTimeout(m), window.removeEventListener("ionKeyboardDidShow", L), window.removeEventListener("ionKeyboardDidShow", c), o && (yield Q(o, 0, p.scrollAmount, p.scrollDuration)), H(e, t, !1, p.inputSafeY), document.activeElement === t && Y(t), d && _(t, o, () => P = 0); }), L = () => { window.removeEventListener("ionKeyboardDidShow", L), window.addEventListener("ionKeyboardDidShow", c); };
    if (o) {
        let b = yield G(o);
        if (I && p.scrollAmount > b.scrollHeight - b.clientHeight - b.scrollTop)
            return t.type === "password" ? (p.scrollAmount += 50, window.addEventListener("ionKeyboardDidShow", L)) : window.addEventListener("ionKeyboardDidShow", c), void (m = setTimeout(c, 1e3));
    }
    c();
} }), de = (e, t) => M(null, null, function* () { if (B === void 0)
    return; let o = t === "ios", r = t === "android", v = e.getNumber("keyboardHeight", 290), d = e.getBoolean("scrollAssist", !0), S = e.getBoolean("hideCaretOnScroll", o), K = e.getBoolean("inputBlurring", !1), I = e.getBoolean("scrollPadding", !0), p = Array.from(B.querySelectorAll("ion-input, ion-textarea")), m = new WeakMap, c = new WeakMap, L = yield X.getResizeMode(), b = n => M(null, null, function* () { yield new Promise(l => F(n, l)); let s = n.shadowRoot || n, i = s.querySelector("input") || s.querySelector("textarea"), w = J(n), y = w ? null : n.closest("ion-footer"); if (i) {
    if (w && S && !m.has(n)) {
        let l = ((u, a, f) => { if (!f || !a)
            return () => { }; let E = A => { var k; (k = a) === k.getRootNode().activeElement && H(u, a, A); }, D = () => H(u, a, !1), x = () => E(!0), g = () => E(!1); return T(f, "ionScrollStart", x), T(f, "ionScrollEnd", g), a.addEventListener("blur", D), () => { C(f, "ionScrollStart", x), C(f, "ionScrollEnd", g), a.removeEventListener("blur", D); }; })(n, i, w);
        m.set(n, l);
    }
    if (i.type !== "date" && i.type !== "datetime-local" && (w || y) && d && !c.has(n)) {
        let l = ((u, a, f, E, D, x, g, A = !1) => { let k = x && (g === void 0 || g.mode === V.None), N = !1, O = h !== void 0 ? h.innerHeight : 0, R = te => { N !== !1 ? ee(u, a, f, E, te.detail.keyboardHeight, k, A, O, !1) : N = !0; }, W = () => { N = !1, h == null || h.removeEventListener("ionKeyboardDidShow", R), u.removeEventListener("focusout", W); }, U = () => M(null, null, function* () { a.hasAttribute(z) ? a.removeAttribute(z) : (ee(u, a, f, E, D, k, A, O), h == null || h.addEventListener("ionKeyboardDidShow", R), u.addEventListener("focusout", W)); }); return u.addEventListener("focusin", U), () => { u.removeEventListener("focusin", U), h == null || h.removeEventListener("ionKeyboardDidShow", R), u.removeEventListener("focusout", W); }; })(n, i, w, y, v, I, L, r);
        c.set(n, l);
    }
} }); K && (() => { let n = !0, s = !1, i = document; T(i, "ionScrollStart", () => { s = !0; }), i.addEventListener("focusin", () => { n = !0; }, !0), i.addEventListener("touchend", w => { if (s)
    return void (s = !1); let y = i.activeElement; if (!y || y.matches(q))
    return; let l = w.target; l !== y && (l.matches(q) || l.closest(q) || (n = !1, setTimeout(() => { n || y.blur(); }, 50))); }, !1); })(); for (let n of p)
    b(n); B.addEventListener("ionInputDidLoad", n => { b(n.detail); }), B.addEventListener("ionInputDidUnload", n => { (s => { if (S) {
    let i = m.get(s);
    i && i(), m.delete(s);
} if (d) {
    let i = c.get(s);
    i && i(), c.delete(s);
} })(n.detail); }); });
export { de as startInputShims };
/*! Bundled license information:

@ionic/core/components/p-D5Ubpm7D.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
