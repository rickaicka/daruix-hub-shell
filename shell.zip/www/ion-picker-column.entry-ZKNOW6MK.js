import { c as I, d as w, e as C } from "@nf-internal/chunk-KTNUIOPA";
import "@nf-internal/chunk-K4KGMBYV";
import { b as S } from "@nf-internal/chunk-JIWXQZSC";
import { b as y } from "@nf-internal/chunk-PJKO2XHO";
import { b as m, c as x } from "@nf-internal/chunk-DBOLI3CQ";
import { i as f } from "@nf-internal/chunk-NTOTMM2V";
import { i as A, m as l, n as E, q as O, r as P } from "@nf-internal/chunk-DPCBKAOC";
import { h as p } from "@nf-internal/chunk-C4FLJMU7";
var N = () => ":host{display:-ms-flexbox;display:flex;position:relative;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;max-width:100%;height:200px;font-size:22px;text-align:center}.assistive-focusable{left:0;right:0;top:0;bottom:0;position:absolute;z-index:1;pointer-events:none}.assistive-focusable:focus{outline:none}.picker-opts{-webkit-padding-start:16px;padding-inline-start:16px;-webkit-padding-end:16px;padding-inline-end:16px;padding-top:0px;padding-bottom:0px;min-width:26px;max-height:200px;outline:none;text-align:inherit;-webkit-scroll-snap-type:y mandatory;-ms-scroll-snap-type:y mandatory;scroll-snap-type:y mandatory;overflow-x:hidden;overflow-y:scroll;scrollbar-width:none}.picker-item-empty{padding-left:0;padding-right:0;padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;margin-top:0;margin-bottom:0;display:block;width:100%;height:34px;border:0px;outline:none;background:transparent;color:inherit;font-family:var(--ion-font-family, inherit);font-size:inherit;line-height:34px;text-align:inherit;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.picker-opts::-webkit-scrollbar{display:none}::slotted(ion-picker-column-option){display:block;scroll-snap-align:center}.picker-item-empty,:host(:not([disabled])) ::slotted(ion-picker-column-option.option-disabled){scroll-snap-align:none}::slotted([slot=prefix]),::slotted([slot=suffix]){max-width:200px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}::slotted([slot=prefix]){-webkit-padding-start:16px;padding-inline-start:16px;-webkit-padding-end:16px;padding-inline-end:16px;padding-top:0;padding-bottom:0;-ms-flex-pack:end;justify-content:end}::slotted([slot=suffix]){-webkit-padding-start:16px;padding-inline-start:16px;-webkit-padding-end:16px;padding-inline-end:16px;padding-top:0;padding-bottom:0;-ms-flex-pack:start;justify-content:start}:host(.picker-column-disabled) .picker-opts{overflow-y:hidden}:host(.picker-column-disabled) ::slotted(ion-picker-column-option){cursor:default;opacity:0.4;pointer-events:none}@media (any-hover: hover){:host(:focus) .picker-opts{outline:none;background:rgba(var(--ion-color-base-rgb), 0.2)}}", L = class {
    constructor(s) { A(this, s), this.ionChange = P(this, "ionChange", 7), this.isScrolling = !1, this.isColumnVisible = !1, this.canExitInputMode = !0, this.updateValueTextOnScroll = !1, this.ariaLabel = null, this.isActive = !1, this.disabled = !1, this.color = "primary", this.numericInput = !1, this.centerPickerItemInView = (e, t = !0, n = !0) => { let { isColumnVisible: i, scrollEl: o } = this; if (i && o) {
        let c = e.offsetTop - 3 * e.clientHeight + e.clientHeight / 2;
        o.scrollTop !== c && (this.canExitInputMode = n, this.updateValueTextOnScroll = !1, o.scroll({ top: c, left: 0, behavior: t ? "smooth" : void 0 }));
    } }, this.setPickerItemActiveState = (e, t) => { t ? e.classList.add(b) : e.classList.remove(b); }, this.inputModeChange = e => { if (!this.numericInput)
        return; let { useInputMode: t, inputModeColumn: n } = e.detail, i = n === void 0 || n === this.el; if (!t || !i) {
        this.setInputModeActive(!1);
        return;
    } this.setInputModeActive(!0); }, this.setInputModeActive = e => { if (this.isScrolling) {
        this.scrollEndCallback = () => { this.isActive = e; };
        return;
    } this.isActive = e; }, this.initializeScrollListener = () => { let e = m("ios"), { el: t, scrollEl: n } = this, i, o = this.activeItem, c = () => { f(() => { var u; if (!n)
        return; i && (clearTimeout(i), i = void 0), this.isScrolling || (e && I(), this.isScrolling = !0); let d = n.getBoundingClientRect(), v = d.x + d.width / 2, g = d.y + d.height / 2, k = t.getRootNode(), h = k instanceof ShadowRoot ? k : y; if (h === void 0)
        return; let a = h.elementsFromPoint(v, g).find(r => r.tagName === "ION-PICKER-COLUMN-OPTION"); if (a === void 0) {
        let r = h.elementFromPoint(v, g);
        r?.tagName === "ION-PICKER-COLUMN-OPTION" && (a = r);
    } o !== void 0 && this.setPickerItemActiveState(o, !1), !(a === void 0 || a.disabled) && (a !== o && (e && w(), this.canExitInputMode && this.exitInputMode()), o = a, this.setPickerItemActiveState(a, !0), this.updateValueTextOnScroll && ((u = this.assistiveFocusable) === null || u === void 0 || u.setAttribute("aria-valuetext", this.getOptionValueText(a))), i = setTimeout(() => { this.isScrolling = !1, this.updateValueTextOnScroll = !0, e && C(); let { scrollEndCallback: r } = this; r && (r(), this.scrollEndCallback = void 0), this.canExitInputMode = !0, this.setValue(a.value); }, 250)); }); }; f(() => { n && (n.addEventListener("scroll", c), this.destroyScrollListener = () => { n.removeEventListener("scroll", c); }); }); }, this.exitInputMode = () => { let { parentEl: e } = this; e != null && (e.exitInputMode(), this.el.classList.remove("picker-column-active")); }, this.findNextOption = (e = 1) => { let { activeItem: t } = this; if (!t)
        return null; let n = t, i = t.nextElementSibling; for (; i != null;) {
        if (e > 0 && e--, i.tagName === "ION-PICKER-COLUMN-OPTION" && !i.disabled && e === 0)
            return i;
        n = i, i = i.nextElementSibling;
    } return n; }, this.findPreviousOption = (e = 1) => { let { activeItem: t } = this; if (!t)
        return null; let n = t, i = t.previousElementSibling; for (; i != null;) {
        if (e > 0 && e--, i.tagName === "ION-PICKER-COLUMN-OPTION" && !i.disabled && e === 0)
            return i;
        n = i, i = i.previousElementSibling;
    } return n; }, this.onKeyDown = e => { let t = m("mobile"), n = null; switch (e.key) {
        case "ArrowDown":
            n = t ? this.findPreviousOption() : this.findNextOption();
            break;
        case "ArrowUp":
            n = t ? this.findNextOption() : this.findPreviousOption();
            break;
        case "PageUp":
            n = t ? this.findNextOption(5) : this.findPreviousOption(5);
            break;
        case "PageDown":
            n = t ? this.findPreviousOption(5) : this.findNextOption(5);
            break;
        case "Home":
            n = this.el.querySelector("ion-picker-column-option:first-of-type");
            break;
        case "End":
            n = this.el.querySelector("ion-picker-column-option:last-of-type");
            break;
    } n !== null && (this.setValue(n.value), e.preventDefault()); }, this.getOptionValueText = e => { var t; return e ? (t = e.getAttribute("aria-label")) !== null && t !== void 0 ? t : e.innerText : ""; }; }
    ariaLabelChanged(s) { this.ariaLabel = s; }
    valueChange() { this.isColumnVisible && this.scrollActiveItemIntoView(!0); }
    componentWillLoad() { let s = this.parentEl = this.el.closest("ion-picker"), e = t => { if (t[t.length - 1].isIntersecting) {
        let { activeItem: i, el: o } = this;
        this.isColumnVisible = !0;
        let c = o.querySelector(`.${b}`);
        c && this.setPickerItemActiveState(c, !1), this.scrollActiveItemIntoView(), i && this.setPickerItemActiveState(i, !0), this.initializeScrollListener();
    }
    else
        this.isColumnVisible = !1, this.destroyScrollListener && (this.destroyScrollListener(), this.destroyScrollListener = void 0); }; new IntersectionObserver(e, { threshold: .001, root: this.parentEl }).observe(this.el), s !== null && s.addEventListener("ionInputModeChange", t => this.inputModeChange(t)); }
    componentDidRender() { let { el: s, activeItem: e, isColumnVisible: t, value: n } = this; if (t && !e) {
        let i = s.querySelector("ion-picker-column-option");
        i !== null && i.value !== n && this.setValue(i.value);
    } }
    scrollActiveItemIntoView(s = !1) { return p(this, null, function* () { let e = this.activeItem; e && this.centerPickerItemInView(e, s, !1); }); }
    setValue(s) { return p(this, null, function* () { this.disabled === !0 || this.value === s || (this.value = s, this.ionChange.emit({ value: s })); }); }
    setFocus() { return p(this, null, function* () { this.assistiveFocusable && this.assistiveFocusable.focus(); }); }
    connectedCallback() { var s; this.ariaLabel = (s = this.el.getAttribute("aria-label")) !== null && s !== void 0 ? s : "Select a value"; }
    get activeItem() { let { value: s } = this; return Array.from(this.el.querySelectorAll("ion-picker-column-option")).find(t => !this.disabled && t.disabled ? !1 : t.value === s); }
    render() { let { color: s, disabled: e, isActive: t, numericInput: n } = this, i = x(this); return l(E, { key: "234c96a501d7ac413b9b0ea56b33017681e25b40", class: S(s, { [i]: !0, "picker-column-active": t, "picker-column-numeric-input": n, "picker-column-disabled": e }) }, l("slot", { key: "9dc15ea0601ddd2cb2e0a745e91e036a8bd96f8b", name: "prefix" }), l("div", { key: "de4fe28ee4bc46b7c0420d6ab0df0e7809443da9", class: "picker-opts", ref: o => { this.scrollEl = o; }, role: "slider", tabindex: this.disabled ? void 0 : 0, "aria-label": this.ariaLabel, "aria-valuemin": 0, "aria-valuemax": 0, "aria-valuenow": 0, "aria-valuetext": this.getOptionValueText(this.activeItem), "aria-orientation": "vertical", onKeyDown: o => this.onKeyDown(o) }, l("div", { key: "5297617462cc30e9444039ae032d8bdf718349af", class: "picker-item-empty", "aria-hidden": "true" }, "\xA0"), l("div", { key: "55ea39ef867bcb1a11a912d52ecd20cb886c5fb3", class: "picker-item-empty", "aria-hidden": "true" }, "\xA0"), l("div", { key: "3496730ce6182ebfd33e0ee4bafc130feb575a31", class: "picker-item-empty", "aria-hidden": "true" }, "\xA0"), l("slot", { key: "44c3628aa957d60f799dc7019f72fe8b676c7843" }), l("div", { key: "5a1809f6c949678a67e0d4b5bfe93ea335c0161d", class: "picker-item-empty", "aria-hidden": "true" }, "\xA0"), l("div", { key: "98fd57f1c66dbaebc2db2dd5da142671b3159fd1", class: "picker-item-empty", "aria-hidden": "true" }, "\xA0"), l("div", { key: "85590708abddfa885994e549deac64866fec938f", class: "picker-item-empty", "aria-hidden": "true" }, "\xA0")), l("slot", { key: "bb7e674f543696a80fcbfb1f68f2e975826898a6", name: "suffix" })); }
    get el() { return O(this); }
    static get watchers() { return { "aria-label": [{ ariaLabelChanged: 0 }], value: [{ valueChange: 0 }] }; }
}, b = "option-active";
L.style = N();
export { L as ion_picker_column };
/*! Bundled license information:

@ionic/core/dist/esm/ion-picker-column.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
