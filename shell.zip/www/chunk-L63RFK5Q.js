import { a as T, b as y, c as p, d as A, e as h, g as m } from "@nf-internal/chunk-T46P23FO";
import { a as M, h as f } from "@nf-internal/chunk-C4FLJMU7";
import { \u0275DomAdapter as F, \u0275setRootDomAdapter as P, \u0275parseCookieValue as B, \u0275getDOM as w, DOCUMENT as O, CommonModule as N, XhrFactory as V, \u0275PLATFORM_BROWSER_ID as x } from "@angular/common";
import * as s from "@angular/core";
import { \u0275global as u, \u0275RuntimeError as U, InjectionToken as de, ApplicationModule as j, \u0275INJECTOR_SCOPE as K, ErrorHandler as S, RendererFactory2 as H, \u0275TESTABILITY_GETTER as J, Testability as E, \u0275TESTABILITY as W, \u0275internalCreateApplication as _, createPlatformFactory as G, platformCore as Y, PLATFORM_ID as z, PLATFORM_INITIALIZER as X, \u0275resolveComponentResources as fe, \u0275setDocument as Z } from "@angular/core";
var R = class t extends F {
    supportsDOMEvents = !0;
    static makeCurrent() { P(new t); }
    onAndCancel(n, e, r, o) { return n.addEventListener(e, r, o), () => { n.removeEventListener(e, r, o); }; }
    dispatchEvent(n, e) { n.dispatchEvent(e); }
    remove(n) { n.remove(); }
    createElement(n, e) { return e = e || this.getDefaultDocument(), e.createElement(n); }
    createHtmlDocument() { return document.implementation.createHTMLDocument("fakeTitle"); }
    getDefaultDocument() { return document; }
    isElementNode(n) { return n.nodeType === Node.ELEMENT_NODE; }
    isShadowRoot(n) { return n instanceof DocumentFragment; }
    getGlobalEventTarget(n, e) { return e === "window" ? window : e === "document" ? n : e === "body" ? n.body : null; }
    getBaseHref(n) { let e = q(); return e == null ? null : Q(e); }
    resetBaseElement() { c = null; }
    getUserAgent() { return window.navigator.userAgent; }
    getCookie(n) { return B(document.cookie, n); }
}, c = null;
function q() { return c = c || document.head.querySelector("base"), c ? c.getAttribute("href") : null; }
function Q(t) { return new URL(t, document.baseURI).pathname; }
var v = class {
    addToWindow(n) { u.getAngularTestability = (r, o = !0) => { let i = n.findTestabilityInTree(r, o); if (i == null)
        throw new U(5103, !1); return i; }, u.getAllAngularTestabilities = () => n.getAllTestabilities(), u.getAllAngularRootElements = () => n.getAllRootElements(); let e = r => { let o = u.getAllAngularTestabilities(), i = o.length, a = function () { i--, i == 0 && r(); }; o.forEach(l => { l.whenStable(a); }); }; u.frameworkStabilizers || (u.frameworkStabilizers = []), u.frameworkStabilizers.push(e); }
    findTestabilityInTree(n, e, r) { if (e == null)
        return null; let o = n.getTestability(e); return o ?? (r ? w().isShadowRoot(e) ? this.findTestabilityInTree(n, e.host, !0) : this.findTestabilityInTree(n, e.parentElement, !0) : null); }
}, $ = (() => { class t {
    build() { return new XMLHttpRequest; }
    static \u0275fac = function (r) { return new (r || t); };
    static \u0275prov = s.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac });
} return t; })(), I = ["alt", "control", "meta", "shift"], ee = { "\b": "Backspace", "	": "Tab", "\x7F": "Delete", "\x1B": "Escape", Del: "Delete", Esc: "Escape", Left: "ArrowLeft", Right: "ArrowRight", Up: "ArrowUp", Down: "ArrowDown", Menu: "ContextMenu", Scroll: "ScrollLock", Win: "OS" }, te = { alt: t => t.altKey, control: t => t.ctrlKey, meta: t => t.metaKey, shift: t => t.shiftKey }, ne = (() => { class t extends T {
    constructor(e) { super(e); }
    supports(e) { return t.parseEventName(e) != null; }
    addEventListener(e, r, o, i) { let a = t.parseEventName(r), l = t.eventCallback(a.fullKey, o, this.manager.getZone()); return this.manager.getZone().runOutsideAngular(() => w().onAndCancel(e, a.domEventName, l, i)); }
    static parseEventName(e) { let r = e.toLowerCase().split("."), o = r.shift(); if (r.length === 0 || !(o === "keydown" || o === "keyup"))
        return null; let i = t._normalizeKey(r.pop()), a = "", l = r.indexOf("code"); if (l > -1 && (r.splice(l, 1), a = "code."), I.forEach(g => { let D = r.indexOf(g); D > -1 && (r.splice(D, 1), a += g + "."); }), a += i, r.length != 0 || i.length === 0)
        return null; let d = {}; return d.domEventName = o, d.fullKey = a, d; }
    static matchEventFullKeyCode(e, r) { let o = ee[e.key] || e.key, i = ""; return r.indexOf("code.") > -1 && (o = e.code, i = "code."), o == null || !o ? !1 : (o = o.toLowerCase(), o === " " ? o = "space" : o === "." && (o = "dot"), I.forEach(a => { if (a !== o) {
        let l = te[a];
        l(e) && (i += a + ".");
    } }), i += o, i === r); }
    static eventCallback(e, r, o) { return i => { t.matchEventFullKeyCode(i, e) && o.runGuarded(() => r(i)); }; }
    static _normalizeKey(e) { return e === "esc" ? "escape" : e; }
    static \u0275fac = function (r) { return new (r || t)(s.\u0275\u0275inject(O)); };
    static \u0275prov = s.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac });
} return t; })();
function Ee(t, n, e) { return f(this, null, function* () { let r = M({ rootComponent: t }, b(n, e)); return _(r); }); }
function Re(t, n) { return f(this, null, function* () { return _(b(t, n)); }); }
function b(t, n) { return { platformRef: n?.platformRef, appProviders: [...k, ...t?.providers ?? []], platformProviders: C }; }
function ve() { return [...L]; }
function re() { R.makeCurrent(); }
function oe() { return new S; }
function ie() { return Z(document), document; }
var C = [{ provide: z, useValue: x }, { provide: X, useValue: re, multi: !0 }, { provide: O, useFactory: ie }], ge = G(Y, "browser", C);
var L = [{ provide: J, useClass: v }, { provide: W, useClass: E }, { provide: E, useClass: E }], k = [{ provide: K, useValue: "root" }, { provide: S, useFactory: oe }, { provide: p, useClass: y, multi: !0 }, { provide: p, useClass: ne, multi: !0 }, m, h, A, { provide: H, useExisting: m }, { provide: V, useClass: $ }, []], De = (() => { class t {
    constructor() { }
    static \u0275fac = function (r) { return new (r || t); };
    static \u0275mod = s.\u0275\u0275defineNgModule({ type: t });
    static \u0275inj = s.\u0275\u0275defineInjector({ providers: [...k, ...L], imports: [N, j] });
} return t; })();
export { R as a, v as b, ne as c, Ee as d, Re as e, ve as f, ge as g, De as h };
/*! Bundled license information:

@angular/platform-browser/fesm2022/_browser-chunk.mjs:
  (**
   * @license Angular v21.2.18
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
