import { q as a, r as d } from "@nf-internal/chunk-BVRKUVLO";
import { b as p } from "@nf-internal/chunk-JIWXQZSC";
import { c } from "@nf-internal/chunk-DBOLI3CQ";
import { e as n, i as l, m as o, n as u, q as f } from "@nf-internal/chunk-DPCBKAOC";
import "@nf-internal/chunk-C4FLJMU7";
var w = () => "", m = () => "", I = class {
    constructor(t) { l(this, t), this.type = "password", this.togglePasswordVisibility = () => { let { inputElRef: s } = this; s && (s.type = s.type === "text" ? "password" : "text"); }; }
    onTypeChange(t) { if (t !== "text" && t !== "password") {
        n(`[ion-input-password-toggle] - Only inputs of type "text" or "password" are supported. Input of type "${t}" is not compatible.`, this.el);
        return;
    } }
    connectedCallback() { let { el: t } = this, s = this.inputElRef = t.closest("ion-input"); if (!s) {
        n("[ion-input-password-toggle] - No ancestor ion-input found. This component must be slotted inside of an ion-input.", t);
        return;
    } this.type = s.type; }
    disconnectedCallback() { this.inputElRef = null; }
    render() { var t, s; let { color: i, type: h } = this, r = c(this), g = (t = this.showIcon) !== null && t !== void 0 ? t : a, y = (s = this.hideIcon) !== null && s !== void 0 ? s : d, e = h === "text"; return o(u, { key: "91bc55664d496fe457518bd112865dd7811d0c17", class: p(i, { [r]: !0 }) }, o("ion-button", { key: "6344d6838f5cdcba54c6bf4b592f036092044de0", mode: r, color: i, fill: "clear", shape: "round", "aria-label": e ? "Hide password" : "Show password", "aria-pressed": e ? "true" : "false", type: "button", onPointerDown: b => { b.preventDefault(); }, onClick: this.togglePasswordVisibility }, o("ion-icon", { key: "a2bd9197c2635bf8cb155ff25ce022e7d7dc6d00", slot: "icon-only", "aria-hidden": "true", icon: e ? y : g }))); }
    get el() { return f(this); }
    static get watchers() { return { type: [{ onTypeChange: 0 }] }; }
};
I.style = { ios: w(), md: m() };
export { I as ion_input_password_toggle };
/*! Bundled license information:

@ionic/core/dist/esm/ion-input-password-toggle.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
