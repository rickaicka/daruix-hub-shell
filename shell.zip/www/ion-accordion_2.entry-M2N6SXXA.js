import { h as A } from "@nf-internal/chunk-BVRKUVLO";
import { c as p } from "@nf-internal/chunk-DBOLI3CQ";
import { a as u, f as b, g as y, h as v, i as h } from "@nf-internal/chunk-NTOTMM2V";
import { a as E, e as w, i as f, m as c, n as g, q as m, r as x } from "@nf-internal/chunk-DPCBKAOC";
import { h as d } from "@nf-internal/chunk-C4FLJMU7";
var k = () => ":host{display:block;position:relative;width:100%;background-color:var(--ion-background-color, #ffffff);overflow:hidden;z-index:0}:host(.accordion-expanding) ::slotted(ion-item[slot=header]),:host(.accordion-expanded) ::slotted(ion-item[slot=header]){--border-width:0px}:host(.accordion-animated){-webkit-transition:all 300ms cubic-bezier(0.25, 0.8, 0.5, 1);transition:all 300ms cubic-bezier(0.25, 0.8, 0.5, 1)}:host(.accordion-animated) #content{-webkit-transition:max-height 300ms cubic-bezier(0.25, 0.8, 0.5, 1);transition:max-height 300ms cubic-bezier(0.25, 0.8, 0.5, 1)}#content{overflow:hidden;will-change:max-height}:host(.accordion-collapsing) #content{max-height:0 !important}:host(.accordion-collapsed) #content{display:none}:host(.accordion-expanding) #content{max-height:0}:host(.accordion-expanding) #content-wrapper{overflow:auto}:host(.accordion-disabled) #header,:host(.accordion-readonly) #header,:host(.accordion-disabled) #content,:host(.accordion-readonly) #content{pointer-events:none}:host(.accordion-disabled) #header,:host(.accordion-disabled) #content{opacity:0.4}@media (prefers-reduced-motion: reduce){:host,#content{-webkit-transition:none !important;transition:none !important}}:host(.accordion-next) ::slotted(ion-item[slot=header]){--border-width:0.55px 0px 0.55px 0px}", C = () => ":host{display:block;position:relative;width:100%;background-color:var(--ion-background-color, #ffffff);overflow:hidden;z-index:0}:host(.accordion-expanding) ::slotted(ion-item[slot=header]),:host(.accordion-expanded) ::slotted(ion-item[slot=header]){--border-width:0px}:host(.accordion-animated){-webkit-transition:all 300ms cubic-bezier(0.25, 0.8, 0.5, 1);transition:all 300ms cubic-bezier(0.25, 0.8, 0.5, 1)}:host(.accordion-animated) #content{-webkit-transition:max-height 300ms cubic-bezier(0.25, 0.8, 0.5, 1);transition:max-height 300ms cubic-bezier(0.25, 0.8, 0.5, 1)}#content{overflow:hidden;will-change:max-height}:host(.accordion-collapsing) #content{max-height:0 !important}:host(.accordion-collapsed) #content{display:none}:host(.accordion-expanding) #content{max-height:0}:host(.accordion-expanding) #content-wrapper{overflow:auto}:host(.accordion-disabled) #header,:host(.accordion-readonly) #header,:host(.accordion-disabled) #content,:host(.accordion-readonly) #content{pointer-events:none}:host(.accordion-disabled) #header,:host(.accordion-disabled) #content{opacity:0.4}@media (prefers-reduced-motion: reduce){:host,#content{-webkit-transition:none !important;transition:none !important}}", S = class {
    constructor(t) { f(this, t), this.accordionGroupUpdateHandler = () => { let e = this.accordionGroupEl; if (e) {
        let o = e.value, n = this.value, s = Array.isArray(o) ? o.includes(n) : o === n, i = this.state === 4 || this.state === 8, a = s !== i;
        this.hasReceivedFirstUpdate && a && (this.hasInteracted = !0), o !== void 0 && (this.hasReceivedFirstUpdate = !0);
    } this.updateState(); }, this.state = 1, this.isNext = !1, this.isPrevious = !1, this.hasInteracted = !1, this.hasEverBeenExpanded = !1, this.hasReceivedFirstUpdate = !1, this.value = `ion-accordion-${G++}`, this.disabled = !1, this.readonly = !1, this.toggleIcon = A, this.toggleIconSlot = "end", this.setItemDefaults = () => { let e = this.getSlottedHeaderIonItem(); e && (e.button = !0, e.detail = !1, e.lines === void 0 && (e.lines = "full")); }, this.getSlottedHeaderIonItem = () => { let { headerEl: e } = this; if (!e)
        return; let o = e.querySelector("slot"); if (o && o.assignedElements !== void 0)
        return o.assignedElements().find(n => n.tagName === "ION-ITEM"); }, this.setAria = (e = !1) => { let o = this.getSlottedHeaderIonItem(); if (!o)
        return; let s = v(o).querySelector("button"); s && s.setAttribute("aria-expanded", `${e}`); }, this.slotToggleIcon = () => { let e = this.getSlottedHeaderIonItem(); if (!e)
        return; let { toggleIconSlot: o, toggleIcon: n } = this; if (e.querySelector(".ion-accordion-toggle-icon"))
        return; let i = document.createElement("ion-icon"); i.slot = o, i.lazy = !1, i.classList.add("ion-accordion-toggle-icon"), i.icon = n, i.setAttribute("aria-hidden", "true"), e.appendChild(i); }, this.expandAccordion = () => { let { contentEl: e, contentElWrapper: o } = this; if (e === void 0 || o === void 0) {
        this.state = 4, this.hasEverBeenExpanded = !0;
        return;
    } this.state !== 4 && (this.currentRaf !== void 0 && cancelAnimationFrame(this.currentRaf), this.hasEverBeenExpanded = !0, this.shouldAnimate() ? h(() => { this.state = 8, this.currentRaf = h(() => d(this, null, function* () { let n = o.offsetHeight, s = u(e, 2e3); e.style.setProperty("max-height", `${n}px`), yield s, this.state = 4, e.style.removeProperty("max-height"); })); }) : this.state = 4); }, this.collapseAccordion = () => { let { contentEl: e } = this; if (e === void 0) {
        this.state = 1;
        return;
    } this.state !== 1 && (this.currentRaf !== void 0 && cancelAnimationFrame(this.currentRaf), this.shouldAnimate() ? this.currentRaf = h(() => d(this, null, function* () { let o = e.offsetHeight; e.style.setProperty("max-height", `${o}px`), h(() => d(this, null, function* () { let n = u(e, 2e3); this.state = 2, yield n, this.state = 1, e.style.removeProperty("max-height"); })); })) : this.state = 1); }, this.shouldAnimate = () => !(!this.hasInteracted || !this.hasEverBeenExpanded || typeof window > "u" || matchMedia("(prefers-reduced-motion: reduce)").matches || !E.get("animated", !0) || this.accordionGroupEl && !this.accordionGroupEl.animated), this.updateState = () => d(this, null, function* () { let e = this.accordionGroupEl, o = this.value; if (!e)
        return; let n = e.value; if (Array.isArray(n) ? n.includes(o) : n === o)
        this.expandAccordion(), this.isNext = this.isPrevious = !1;
    else {
        this.collapseAccordion();
        let i = this.getNextSibling(), a = i?.value;
        a !== void 0 && (this.isPrevious = Array.isArray(n) ? n.includes(a) : n === a);
        let r = this.getPreviousSibling(), l = r?.value;
        l !== void 0 && (this.isNext = Array.isArray(n) ? n.includes(l) : n === l);
    } }), this.getNextSibling = () => { if (!this.el)
        return; let e = this.el.nextElementSibling; if (e?.tagName === "ION-ACCORDION")
        return e; }, this.getPreviousSibling = () => { if (!this.el)
        return; let e = this.el.previousElementSibling; if (e?.tagName === "ION-ACCORDION")
        return e; }; }
    valueChanged() { this.updateState(); }
    connectedCallback() { var t; let e = this.accordionGroupEl = (t = this.el) === null || t === void 0 ? void 0 : t.closest("ion-accordion-group"); e && (this.updateState(), b(e, "ionValueChange", this.accordionGroupUpdateHandler)); }
    disconnectedCallback() { let t = this.accordionGroupEl; t && y(t, "ionValueChange", this.accordionGroupUpdateHandler); }
    componentDidLoad() { this.setItemDefaults(), this.slotToggleIcon(), h(() => { let t = this.state === 4 || this.state === 8; this.setAria(t); }); }
    toggleExpanded() { let { accordionGroupEl: t, disabled: e, readonly: o, value: n, state: s } = this; if (!(e || o) && (this.hasInteracted = !0, t)) {
        let i = s === 1 || s === 2;
        t.requestAccordionToggle(n, i);
    } }
    render() { let { disabled: t, readonly: e } = this, o = p(this), n = this.state === 4 || this.state === 8, s = n ? "header expanded" : "header", i = n ? "content expanded" : "content"; return this.setAria(n), c(g, { key: "5c58b3809a4636d69f0f9957ecf1f50c42cdfc03", class: { [o]: !0, "accordion-expanding": this.state === 8, "accordion-expanded": this.state === 4, "accordion-collapsing": this.state === 2, "accordion-collapsed": this.state === 1, "accordion-next": this.isNext, "accordion-previous": this.isPrevious, "accordion-disabled": t, "accordion-readonly": e, "accordion-animated": this.shouldAnimate() }, tabindex: t ? "-1" : void 0 }, c("div", { key: "f76bc02347639b41c9a5be8a9488a8be8559cba7", onClick: () => this.toggleExpanded(), id: "header", part: s, "aria-controls": "content", ref: a => this.headerEl = a }, c("slot", { key: "e01744bf0af3200239e82c60c632ed36295db2da", name: "header" })), c("div", { key: "c613345a7e244ee361f76ff4ebed139d2a1b9572", id: "content", part: i, role: "region", "aria-labelledby": "header", ref: a => this.contentEl = a }, c("div", { key: "943b65d9a129759b4c213974ae5ed777b5f6166e", id: "content-wrapper", ref: a => this.contentElWrapper = a }, c("slot", { key: "b0df520dad9d5557df63a35f8206ada4a765d238", name: "content" })))); }
    static get delegatesFocus() { return !0; }
    get el() { return m(this); }
    static get watchers() { return { value: [{ valueChanged: 0 }] }; }
}, G = 0;
S.style = { ios: k(), md: C() };
var N = () => ":host{display:block}:host(.accordion-group-expand-inset){-webkit-margin-start:16px;margin-inline-start:16px;-webkit-margin-end:16px;margin-inline-end:16px;margin-top:16px;margin-bottom:16px}:host(.accordion-group-expand-inset) ::slotted(ion-accordion.accordion-expanding),:host(.accordion-group-expand-inset) ::slotted(ion-accordion.accordion-expanded){border-bottom:none}", H = () => ":host{display:block}:host(.accordion-group-expand-inset){-webkit-margin-start:16px;margin-inline-start:16px;-webkit-margin-end:16px;margin-inline-end:16px;margin-top:16px;margin-bottom:16px}:host(.accordion-group-expand-inset) ::slotted(ion-accordion){-webkit-box-shadow:0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12);box-shadow:0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12)}:host(.accordion-group-expand-inset) ::slotted(ion-accordion.accordion-expanding),:host(.accordion-group-expand-inset) ::slotted(ion-accordion.accordion-expanded){margin-left:0;margin-right:0;margin-top:16px;margin-bottom:16px;border-radius:6px}:host(.accordion-group-expand-inset) ::slotted(ion-accordion.accordion-previous){border-end-end-radius:6px;border-end-start-radius:6px}:host(.accordion-group-expand-inset) ::slotted(ion-accordion.accordion-next){border-start-start-radius:6px;border-start-end-radius:6px}:host(.accordion-group-expand-inset) ::slotted(ion-accordion):first-of-type{margin-left:0;margin-right:0;margin-top:0;margin-bottom:0}", P = class {
    constructor(t) { f(this, t), this.ionChange = x(this, "ionChange", 7), this.ionValueChange = x(this, "ionValueChange", 7), this.animated = !0, this.disabled = !1, this.readonly = !1, this.expand = "compact"; }
    valueChanged() {
        let { value: t, multiple: e } = this;
        !e && Array.isArray(t) && w(`[ion-accordion-group] - An array of values was passed, but multiple is "false". This is incorrect usage and may result in unexpected behaviors. To dismiss this warning, pass a string to the "value" property when multiple="false".

  Value Passed: [${t.map(o => `'${o}'`).join(", ")}]
`, this.el), this.ionValueChange.emit({ value: this.value });
    }
    disabledChanged() { return d(this, null, function* () { let { disabled: t } = this, e = yield this.getAccordions(); for (let o of e)
        o.disabled = t; }); }
    readonlyChanged() { return d(this, null, function* () { let { readonly: t } = this, e = yield this.getAccordions(); for (let o of e)
        o.readonly = t; }); }
    onKeydown(t) { return d(this, null, function* () { let e = document.activeElement; if (!e || !e.closest('ion-accordion [slot="header"]'))
        return; let n = e.tagName === "ION-ACCORDION" ? e : e.closest("ion-accordion"); if (!n || n.closest("ion-accordion-group") !== this.el)
        return; let i = yield this.getAccordions(), a = i.findIndex(l => l === n); if (a === -1)
        return; let r; t.key === "ArrowDown" ? r = this.findNextAccordion(i, a) : t.key === "ArrowUp" ? r = this.findPreviousAccordion(i, a) : t.key === "Home" ? r = i[0] : t.key === "End" && (r = i[i.length - 1]), r !== void 0 && r !== e && r.focus(); }); }
    componentDidLoad() { return d(this, null, function* () { this.disabled && this.disabledChanged(), this.readonly && this.readonlyChanged(), this.valueChanged(); }); }
    setValue(t) { let e = this.value = t; this.ionChange.emit({ value: e }); }
    requestAccordionToggle(t, e) { return d(this, null, function* () { let { multiple: o, value: n, readonly: s, disabled: i } = this; if (!(s || i))
        if (e)
            if (o) {
                let a = n ?? [], r = Array.isArray(a) ? a : [a];
                r.find(I => I === t) === void 0 && t !== void 0 && this.setValue([...r, t]);
            }
            else
                this.setValue(t);
        else if (o) {
            let a = n ?? [], r = Array.isArray(a) ? a : [a];
            this.setValue(r.filter(l => l !== t));
        }
        else
            this.setValue(void 0); }); }
    findNextAccordion(t, e) { let o = t[e + 1]; return o === void 0 ? t[0] : o; }
    findPreviousAccordion(t, e) { let o = t[e - 1]; return o === void 0 ? t[t.length - 1] : o; }
    getAccordions() { return d(this, null, function* () { return Array.from(this.el.querySelectorAll(":scope > ion-accordion")); }); }
    render() { let { disabled: t, readonly: e, expand: o } = this, n = p(this); return c(g, { key: "d1a79a93179474fbba66fcf11a92f4871dacc975", class: { [n]: !0, "accordion-group-disabled": t, "accordion-group-readonly": e, [`accordion-group-expand-${o}`]: !0 }, role: "presentation" }, c("slot", { key: "e6b8954b686d1fbb4fc92adb07fddc97a24b0a31" })); }
    get el() { return m(this); }
    static get watchers() { return { value: [{ valueChanged: 0 }], disabled: [{ disabledChanged: 0 }], readonly: [{ readonlyChanged: 0 }] }; }
};
P.style = { ios: N(), md: H() };
export { S as ion_accordion, P as ion_accordion_group };
/*! Bundled license information:

@ionic/core/dist/esm/ion-accordion_2.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
