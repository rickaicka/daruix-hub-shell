import { c as D, d as _, f as F } from "@nf-internal/chunk-HTXI7NN5";
import { b as O, d as I } from "@nf-internal/chunk-JIWXQZSC";
import { c as L } from "@nf-internal/chunk-DBOLI3CQ";
import { b as T, i as N, r as v } from "@nf-internal/chunk-NTOTMM2V";
import { e as m, f as g, i as p, m as b, n as U, q as j, r as w } from "@nf-internal/chunk-DPCBKAOC";
import { h as u } from "@nf-internal/chunk-C4FLJMU7";
var Rt = class {
    constructor(t) { p(this, t), this.ionRouteDataChanged = w(this, "ionRouteDataChanged", 7), this.url = ""; }
    onUpdate(t) { this.ionRouteDataChanged.emit(t); }
    onComponentProps(t, e) { if (t === e)
        return; let n = t ? Object.keys(t) : [], s = e ? Object.keys(e) : []; if (n.length !== s.length) {
        this.onUpdate(t);
        return;
    } for (let r of n)
        if (t[r] !== e[r]) {
            this.onUpdate(t);
            return;
        } }
    connectedCallback() { this.ionRouteDataChanged.emit(); }
    static get watchers() { return { url: [{ onUpdate: 0 }], component: [{ onUpdate: 0 }], componentProps: [{ onComponentProps: 0 }] }; }
}, yt = class {
    constructor(t) { p(this, t), this.ionRouteRedirectChanged = w(this, "ionRouteRedirectChanged", 7); }
    propDidChange() { this.ionRouteRedirectChanged.emit(); }
    connectedCallback() { this.ionRouteRedirectChanged.emit(); }
    static get watchers() { return { from: [{ propDidChange: 0 }], to: [{ propDidChange: 0 }] }; }
}, f = "root", $ = "forward", B = "back", d = t => "/" + t.filter(n => n.length > 0).join("/"), z = (t, e, n, s) => { let r = d(t); return e && (r = "#" + r), n !== void 0 && (r += "?" + n), s !== void 0 && (r += "#" + s), r; }, K = (t, e, n, s, r, i, o, a) => { let c = z([...h(e).segments, ...s], n, o, a); r === $ ? t.pushState(i, "", c) : t.replaceState(i, "", c); }, J = t => { let e = []; for (let n of t)
    for (let s of n.segments)
        if (s[0] === ":") {
            let r = n.params && n.params[s.slice(1)];
            if (!r)
                return null;
            e.push(r);
        }
        else
            s !== "" && e.push(s); return e; }, Q = (t, e) => { if (t.length > e.length)
    return null; if (t.length <= 1 && t[0] === "")
    return e; for (let n = 0; n < t.length; n++)
    if (t[n] !== e[n])
        return null; return e.length === t.length ? [""] : e.slice(t.length); }, X = (t, e, n) => { let s = h(e).segments, r = n ? t.hash.slice(1) : t.pathname, i = h(r).segments; return Q(s, i); }, h = t => { let e = [""], n, s; if (t != null) {
    let r = t.indexOf("#");
    r > -1 && (s = t.substring(r + 1), t = t.substring(0, r));
    let i = t.indexOf("?");
    i > -1 && (n = t.substring(i + 1), t = t.substring(0, i)), e = t.split("/").map(o => o.trim()).filter(o => o.length > 0), e.length === 0 && (e = [""]);
} return { segments: e, queryString: n, fragment: s }; }, Y = t => { console.group(`[ion-core] ROUTES[${t.length}]`); for (let e of t) {
    let n = [];
    e.forEach(r => n.push(...r.segments));
    let s = e.map(r => r.id);
    console.debug(`%c ${d(n)}`, "font-weight: bold; padding-left: 20px", "=>	", `(${s.join(", ")})`);
} console.groupEnd(); }, Z = t => { console.group(`[ion-core] REDIRECTS[${t.length}]`); for (let e of t)
    e.to && console.debug("FROM: ", `$c ${d(e.from)}`, "font-weight: bold", " TO: ", `$c ${d(e.to.segments)}`, "font-weight: bold"); console.groupEnd(); }, x = (t, e, n, s, r = !1, i) => u(null, null, function* () { try {
    let o = P(t);
    if (s >= e.length || !o)
        return r;
    yield new Promise(l => T(o, l));
    let a = e[s], c = yield o.setRouteId(a.id, a.params, n, i);
    return c.changed && (n = f, r = !0), r = yield x(c.element, e, n, s + 1, r, i), c.markVisible && (yield c.markVisible()), r;
}
catch (o) {
    return g("[ion-router] - Exception in writeNavState:", o), !1;
} }), V = t => u(null, null, function* () { let e = [], n, s = t; for (; n = P(s);) {
    let r = yield n.getRouteId();
    if (r)
        s = r.element, r.element = void 0, e.push(r);
    else
        break;
} return { ids: e, outlet: n }; }), tt = 30, et = 300, q = () => new Promise(t => N(() => t())), nt = t => { let e = t.closest(".ion-page"); return e === null ? document.querySelector(".ion-page") === null : e.closest(".ion-page-hidden, .tab-hidden") === null; }, rt = (t, e) => u(null, null, function* () { let s = typeof CSS < "u" && typeof CSS.escape == "function" ? CSS.escape(t) : null; for (let r = 0; r < tt; r++) {
    if (!e())
        return null;
    let i = [];
    if (s !== null)
        try {
            i = [...document.querySelectorAll(`#${s}, a[name="${s}"]`)];
        }
        catch {
            i = [...document.querySelectorAll(`#${s}`)];
        }
    else {
        let o = document.getElementById(t);
        o !== null && (i = [o]);
    }
    for (let o = i.length - 1; o >= 0; o--)
        if (nt(i[o]))
            return i[o];
    yield q();
} return null; }), st = (t, e = () => !0) => u(null, null, function* () { if (t == null || t === "")
    return !1; let n; try {
    n = decodeURIComponent(t);
}
catch {
    n = t;
} let s = yield rt(n, e); if (!s || !e())
    return !1; try {
    let r = F(s);
    if (r && D(r)) {
        let i = r, o = yield _(i);
        if (yield q(), !e())
            return !1;
        let a = s.getBoundingClientRect(), c = o.getBoundingClientRect(), l = a.top - c.top + o.scrollTop;
        yield i.scrollToPoint(o.scrollLeft, l, et);
    }
    else
        s.scrollIntoView({ behavior: "smooth" });
    return !0;
}
catch (r) {
    return g("[ion-router] - Exception in scrollToFragment:", r), !1;
} }), ot = () => P(document.body) ? Promise.resolve() : new Promise(t => { window.addEventListener("ionNavWillLoad", () => t(), { once: !0 }); }), A = ":not([no-router]) ion-nav, :not([no-router]) ion-tabs, :not([no-router]) ion-router-outlet", P = t => { if (!t)
    return; if (t.matches(A))
    return t; let e = t.querySelector(A); return e ?? void 0; }, it = (t, e) => { let { from: n, to: s } = e; if (s === void 0 || n.length > t.length)
    return !1; for (let r = 0; r < n.length; r++) {
    let i = n[r];
    if (i === "*")
        return !0;
    if (i !== t[r])
        return !1;
} return n.length === t.length; }, W = (t, e) => e.find(n => it(t, n)), at = (t, e) => { let n = Math.min(t.length, e.length), s = 0; for (let r = 0; r < n; r++) {
    let i = t[r], o = e[r];
    if (i.id.toLowerCase() !== o.id)
        break;
    if (i.params) {
        let a = Object.keys(i.params);
        if (a.length === o.segments.length) {
            let c = a.map(l => `:${l}`);
            for (let l = 0; l < c.length && c[l].toLowerCase() === o.segments[l]; l++)
                s++;
        }
    }
    s++;
} return s; }, ct = (t, e) => { let n = new k(t), s = !1, r; for (let o = 0; o < e.length; o++) {
    let a = e[o].segments;
    if (a[0] === "")
        s = !0;
    else {
        for (let c of a) {
            let l = n.next();
            if (c[0] === ":") {
                if (l === "")
                    return null;
                r = r || [];
                let S = r[o] || (r[o] = {});
                S[c.slice(1)] = l;
            }
            else if (l !== c)
                return null;
        }
        s = !1;
    }
} return (s ? s === (n.next() === "") : !0) ? r ? e.map((o, a) => ({ id: o.id, segments: o.segments, params: M(o.params, r[a]), beforeEnter: o.beforeEnter, beforeLeave: o.beforeLeave })) : e : null; }, M = (t, e) => t || e ? Object.assign(Object.assign({}, t), e) : void 0, lt = (t, e) => { let n = null, s = 0; for (let r of e) {
    let i = at(t, r);
    i > s && (n = r, s = i);
} return n ? n.map((r, i) => { var o; return { id: r.id, segments: r.segments, params: M(r.params, (o = t[i]) === null || o === void 0 ? void 0 : o.params) }; }) : null; }, C = (t, e) => { let n = null, s = 0; for (let r of e) {
    let i = ct(t, r);
    if (i !== null) {
        let o = ut(i);
        o > s && (s = o, n = i);
    }
} return n; }, ut = t => { let e = 1, n = 1; for (let s of t)
    for (let r of s.segments)
        r[0] === ":" ? e += Math.pow(1, n) : r !== "" && (e += Math.pow(2, n)), n++; return e; }, k = class {
    constructor(e) { this.segments = e.slice(); }
    next() { return this.segments.length > 0 ? this.segments.shift() : ""; }
}, y = (t, e) => e in t ? t[e] : t.hasAttribute(e) ? t.getAttribute(e) : null, E = t => Array.from(t.children).filter(e => e.tagName === "ION-ROUTE-REDIRECT").map(e => { let n = y(e, "to"); return { from: h(y(e, "from")).segments, to: n == null ? void 0 : h(n) }; }), R = t => ht(H(t)), H = t => Array.from(t.children).filter(e => e.tagName === "ION-ROUTE" && e.component).map(e => { let n = y(e, "component"); return { segments: h(y(e, "url")).segments, id: n.toLowerCase(), params: e.componentProps, beforeLeave: e.beforeLeave, beforeEnter: e.beforeEnter, children: H(e) }; }), ht = t => { let e = []; for (let n of t)
    G([], e, n); return e; }, G = (t, e, n) => { if (t = [...t, { id: n.id, segments: n.segments, params: n.params, beforeLeave: n.beforeLeave, beforeEnter: n.beforeEnter }], n.children.length === 0) {
    e.push(t);
    return;
} for (let s of n.children)
    G(t, e, s); }, St = class {
    constructor(t) { p(this, t), this.ionRouteWillChange = w(this, "ionRouteWillChange", 7), this.ionRouteDidChange = w(this, "ionRouteDidChange", 7), this.previousPath = null, this.busy = !1, this.state = 0, this.lastState = 0, this.fragmentScrollToken = 0, this.root = "/", this.useHash = !0; }
    componentWillLoad() { return u(this, null, function* () { yield ot(); let t = yield this.runGuards(this.getSegments()); if (t !== !0) {
        if (typeof t == "object") {
            let { redirect: n } = t, s = h(n);
            this.setSegments(s.segments, f, s.queryString, s.fragment), (yield this.writeNavStateRoot(s.segments, f)) && this.maybeScrollToFragment();
        }
        return;
    } (yield this.onRoutesChanged()) && this.maybeScrollToFragment(); }); }
    componentDidLoad() { window.addEventListener("ionRouteRedirectChanged", v(this.onRedirectChanged.bind(this), 10)), window.addEventListener("ionRouteDataChanged", v(this.onRoutesChanged.bind(this), 100)); }
    onPopState() { return u(this, null, function* () { let t = this.historyDirection(), e = this.getSegments(), n = yield this.runGuards(e); if (n !== !0)
        if (typeof n == "object")
            e = h(n.redirect).segments;
        else
            return !1; let s = yield this.writeNavStateRoot(e, t); return s && this.maybeScrollToFragment(), s; }); }
    onBackButton(t) { t.detail.register(0, e => { this.back(), e(); }); }
    canTransition() { return u(this, null, function* () { let t = yield this.runGuards(); return t !== !0 ? typeof t == "object" ? t.redirect : !1 : !0; }); }
    push(t, e = "forward", n) { return u(this, null, function* () { var s; if (t.startsWith(".")) {
        let a = (s = this.previousPath) !== null && s !== void 0 ? s : "/", c = new URL(t, `https://host/${a}`);
        t = c.pathname + c.search + c.hash;
    } let r = h(t), i = yield this.runGuards(r.segments); if (i !== !0)
        if (typeof i == "object")
            r = h(i.redirect);
        else
            return !1; this.setSegments(r.segments, e, r.queryString, r.fragment); let o = yield this.writeNavStateRoot(r.segments, e, n); return o && this.maybeScrollToFragment(), o; }); }
    back() { return window.history.back(), Promise.resolve(this.waitPromise); }
    printDebug() { return u(this, null, function* () { Y(R(this.el)), Z(E(this.el)); }); }
    navChanged(t) { return u(this, null, function* () { if (this.busy)
        return m("[ion-router] - Router is busy, navChanged was cancelled."), !1; let { ids: e, outlet: n } = yield V(window.document.body), s = R(this.el), r = lt(e, s); if (!r)
        return m("[ion-router] - No matching URL for", e.map(c => c.id)), !1; let i = J(r); if (!i)
        return m("[ion-router] - Router could not match path because some required param is missing."), !1; let a = d(i) === this.previousPath ? this.getFragment() : void 0; return this.setSegments(i, t, void 0, a), yield this.safeWriteNavState(n, r, f, i, null, e.length), !0; }); }
    onRedirectChanged() { let t = this.getSegments(); t && W(t, E(this.el)) && this.writeNavStateRoot(t, f); }
    onRoutesChanged() { return this.writeNavStateRoot(this.getSegments(), f); }
    historyDirection() { var t; let e = window; e.history.state === null && (this.state++, e.history.replaceState(this.state, e.document.title, (t = e.document.location) === null || t === void 0 ? void 0 : t.href)); let n = e.history.state, s = this.lastState; return this.lastState = n, n > s || n >= s && s > 0 ? $ : n < s ? B : f; }
    writeNavStateRoot(t, e, n) { return u(this, null, function* () { if (!t)
        return g("[ion-router] - URL is not part of the routing set."), !1; let s = E(this.el), r = W(t, s), i = null; if (r) {
        let { segments: c, queryString: l, fragment: S } = r.to;
        this.setSegments(c, e, l, S), i = r.from, t = c;
    } let o = R(this.el), a = C(t, o); return a ? this.safeWriteNavState(document.body, a, e, t, i, 0, n) : (g("[ion-router] - The path does not match any route."), !1); }); }
    safeWriteNavState(t, e, n, s, r, i = 0, o) { return u(this, null, function* () { let a = yield this.lock(), c = !1; try {
        c = yield this.writeNavState(t, e, n, s, r, i, o);
    }
    catch (l) {
        g("[ion-router] - Exception in safeWriteNavState:", l);
    } return a(), c; }); }
    lock() { return u(this, null, function* () { let t = this.waitPromise, e; return this.waitPromise = new Promise(n => e = n), t !== void 0 && (yield t), e; }); }
    runGuards() { return u(this, arguments, function* (t = this.getSegments(), e) { if (e === void 0 && (e = h(this.previousPath).segments), !t || !e)
        return !0; let n = R(this.el), s = C(e, n), r = s && s[s.length - 1].beforeLeave, i = r ? yield r() : !0; if (i === !1 || typeof i == "object")
        return i; let o = C(t, n), a = o && o[o.length - 1].beforeEnter; return a ? a() : !0; }); }
    writeNavState(t, e, n, s, r, i = 0, o) { return u(this, null, function* () { if (this.busy)
        return m("[ion-router] - Router is busy, transition was cancelled."), !1; this.busy = !0; let a = this.routeChangeEvent(s, r); a && this.ionRouteWillChange.emit(a); let c = yield x(t, e, n, i, !1, o); return this.busy = !1, a && this.ionRouteDidChange.emit(a), c; }); }
    setSegments(t, e, n, s) { this.state++, this.fragmentScrollToken++, K(window.history, this.root, this.useHash, t, e, this.state, n, s); }
    getSegments() { return X(window.location, this.root, this.useHash); }
    getFragment() { let t = this.useHash ? h(window.location.hash.slice(1)).fragment : window.location.hash.slice(1); return t || void 0; }
    maybeScrollToFragment() { let t = this.getFragment(); if (!t)
        return; let e = this.fragmentScrollToken; st(t, () => e === this.fragmentScrollToken).catch(() => { }); }
    routeChangeEvent(t, e) { let n = this.previousPath, s = d(t); if (this.previousPath = s, s === n)
        return null; let r = e ? d(e) : null; return { from: n, redirectedFrom: r, to: s }; }
    get el() { return j(this); }
}, ft = () => ":host{--background:transparent;--color:var(--ion-color-primary, #0054e9);background:var(--background);color:var(--color)}:host(.ion-color){color:var(--ion-color-base)}a{font-family:inherit;font-size:inherit;font-style:inherit;font-weight:inherit;letter-spacing:inherit;text-decoration:inherit;text-indent:inherit;text-overflow:inherit;text-transform:inherit;text-align:inherit;white-space:inherit;color:inherit}", dt = class {
    constructor(t) { p(this, t), this.routerDirection = "forward", this.onClick = e => { I(this.href, e, this.routerDirection, this.routerAnimation); }; }
    render() { let t = L(this), e = { href: this.href, rel: this.rel, target: this.target }; return b(U, { key: "8372835161d507c7b821b7536c55f912eb6ce704", onClick: this.onClick, class: O(this.color, { [t]: !0, "ion-activatable": !0 }) }, b("a", Object.assign({ key: "315966e14a17760f3f64197e8315200039787897" }, e), b("slot", { key: "95fc1697b884225e85e647dddcaa8f4af8b9a979" }))); }
};
dt.style = ft();
export { Rt as ion_route, yt as ion_route_redirect, St as ion_router, dt as ion_router_link };
/*! Bundled license information:

@ionic/core/dist/esm/ion-route_4.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
