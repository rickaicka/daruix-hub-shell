import { b as h, c as f, d as u, e as m, f as g } from "@nf-internal/chunk-2YSXI4CN";
import { a as b, d as c, e as p, f as v } from "@nf-internal/chunk-2YPJAHFP";
import "@nf-internal/chunk-C4FLJMU7";
var C = o => { let t = document.createElement("div"); t.innerHTML = o; for (let i = t.childNodes.length - 1; i >= 0; i--)
    t.childNodes[i].nodeName.toLowerCase() !== "svg" && t.removeChild(t.childNodes[i]); let e = t.firstElementChild; if (e && e.nodeName.toLowerCase() === "svg") {
    let i = e.getAttribute("class") || "";
    if (e.setAttribute("class", (i + " s-ion-icon").trim()), w(e))
        return t.innerHTML;
} return ""; }, w = o => { if (o.nodeType === 1) {
    if (o.nodeName.toLowerCase() === "script")
        return !1;
    for (let t = 0; t < o.attributes.length; t++) {
        let e = o.attributes[t].name;
        if (u(e) && e.toLowerCase().indexOf("on") === 0)
            return !1;
    }
    for (let t = 0; t < o.childNodes.length; t++)
        if (!w(o.childNodes[t]))
            return !1;
} return !0; }, I = o => o.startsWith("data:image/svg+xml"), L = o => o.indexOf(";utf8,") !== -1, r = new Map, y = new Map, a;
function l(o) { return r.set(o, ""), ""; }
var k = (o, t) => { let e = y.get(o); return e || (typeof fetch < "u" && typeof document < "u" ? I(o) && L(o) ? Promise.resolve(x(o)) : N(o, t) : Promise.resolve(l(o))); };
function x(o) { a || (a = new DOMParser); let e = a.parseFromString(o, "text/html").querySelector("svg"); if (e)
    return r.set(o, e.outerHTML), e.outerHTML; throw new Error(`Could not parse svg from ${o}`); }
function N(o, t) { let e = fetch(o).then(i => i.text().then(n => { n && t !== !1 && (n = C(n)); let s = n || ""; return r.set(o, s), s; }).catch(() => l(o))).catch(() => l(o)); return y.set(o, e), e; }
var O = ":host{display:inline-block;width:1em;height:1em;contain:strict;fill:currentColor;box-sizing:content-box !important}:host .ionicon{stroke:currentColor}.ionicon-fill-none{fill:none}.ionicon-stroke-width{stroke-width:var(--ionicon-stroke-width, 32px)}.icon-inner,.ionicon,svg{display:block;height:100%;width:100%}@supports (background: -webkit-named-image(i)){:host(.icon-rtl) .icon-inner{transform:scaleX(-1)}}@supports not selector(:dir(rtl)) and selector(:host-context([dir='rtl'])){:host(.icon-rtl) .icon-inner{transform:scaleX(-1)}}:host(.flip-rtl):host-context([dir='rtl']) .icon-inner{transform:scaleX(-1)}@supports selector(:dir(rtl)){:host(.flip-rtl:dir(rtl)) .icon-inner{transform:scaleX(-1)}:host(.flip-rtl:dir(ltr)) .icon-inner{transform:scaleX(1)}}:host(.icon-small){font-size:1.125rem !important}:host(.icon-large){font-size:2rem !important}:host(.ion-color){color:var(--ion-color-base) !important}:host(.ion-color-primary){--ion-color-base:var(--ion-color-primary, #3880ff)}:host(.ion-color-secondary){--ion-color-base:var(--ion-color-secondary, #0cd1e8)}:host(.ion-color-tertiary){--ion-color-base:var(--ion-color-tertiary, #f4a942)}:host(.ion-color-success){--ion-color-base:var(--ion-color-success, #10dc60)}:host(.ion-color-warning){--ion-color-base:var(--ion-color-warning, #ffce00)}:host(.ion-color-danger){--ion-color-base:var(--ion-color-danger, #f14141)}:host(.ion-color-light){--ion-color-base:var(--ion-color-light, #f4f5f8)}:host(.ion-color-medium){--ion-color-base:var(--ion-color-medium, #989aa2)}:host(.ion-color-dark){--ion-color-base:var(--ion-color-dark, #222428)}", z = class {
    constructor(o) { b(this, o), this.iconName = null, this.inheritedAttributes = {}, this.didLoadIcon = !1, this.isVisible = !1, this.mode = M(), this.lazy = !1, this.sanitize = !0; }
    componentWillLoad() { this.inheritedAttributes = m(this.el, ["aria-label"]); }
    connectedCallback() { this.waitUntilVisible(this.el, "50px", () => { this.isVisible = !0, this.loadIcon(); }); }
    componentDidLoad() { this.didLoadIcon || this.loadIcon(); }
    disconnectedCallback() { this.io && (this.io.disconnect(), this.io = void 0); }
    waitUntilVisible(o, t, e) { if (!!!(this.lazy && typeof window < "u" && window.IntersectionObserver))
        return e(); let n = this.io = new window.IntersectionObserver(s => { s[0].isIntersecting && (n.disconnect(), this.io = void 0, e()); }, { rootMargin: t }); n.observe(o); }
    loadIcon() { if (this.isVisible) {
        let o = h(this);
        o && (r.has(o) ? this.svgContent = r.get(o) : k(o, this.sanitize).then(() => this.svgContent = r.get(o)), this.didLoadIcon = !0);
    } this.iconName = f(this.name, this.icon, this.mode, this.ios, this.md); }
    render() { let { flipRtl: o, iconName: t, inheritedAttributes: e, el: i } = this, n = this.mode || "md", s = t ? (t.includes("arrow") || t.includes("chevron")) && o !== !1 : !1, d = o || s; return c(p, Object.assign({ key: "0578c899781ca145dd8205acd9670af39b57cf2e", role: "img", class: Object.assign(Object.assign({ [n]: !0 }, S(this.color)), { [`icon-${this.size}`]: !!this.size, "flip-rtl": d, "icon-rtl": d && g(i) }) }, e), this.svgContent ? c("div", { class: "icon-inner", innerHTML: this.svgContent }) : c("div", { class: "icon-inner" })); }
    static get assetsDirs() { return ["svg"]; }
    get el() { return v(this); }
    static get watchers() { return { name: ["loadIcon"], src: ["loadIcon"], icon: ["loadIcon"], ios: ["loadIcon"], md: ["loadIcon"] }; }
}, M = () => typeof document < "u" && document.documentElement.getAttribute("mode") || "md", S = o => o ? { "ion-color": !0, [`ion-color-${o}`]: !0 } : null;
z.style = O;
export { z as ion_icon };
