import { a as g, b as L, h as H } from "@nf-internal/chunk-C4FLJMU7";
import { untracked as u, \u0275RuntimeError as l, computed as a, runInInjectionContext as ue, Injector as ce, linkedSignal as C, signal as k, APP_ID as me, effect as ye, inject as pe } from "@angular/core";
import { AbstractControl as be, FormGroup as Se, FormArray as ve } from "@angular/forms";
import { SIGNAL as ne } from "@angular/core/primitives/signals";
var $ = 0;
function we() { return $; }
function y(r, e) { return (...t) => { try {
    return $ = e, r(...t);
}
finally {
    $ = 0;
} }; }
function Me(r) { return !r; }
function ie(r) { return r; }
function tt(r) { return r.kind === "root" ? r.fieldManager.injector : r.parent.structure.root.structure.injector; }
function f(r) { return Array.isArray(r); }
function w(r) { return (typeof r == "object" || typeof r == "function") && r != null; }
var p = Symbol(), V = Symbol(), P = class {
    predicates;
    fns = [];
    constructor(e) { this.predicates = e; }
    push(e) { this.fns.push(se(this.predicates, e)); }
    mergeIn(e) { let t = this.predicates ? e.fns.map(n => se(this.predicates, n)) : e.fns; this.fns.push(...t); }
}, A = class extends P {
    get defaultValue() { return !1; }
    compute(e) { return this.fns.some(t => { let n = t(e); return n && n !== V; }); }
}, M = class r extends P {
    ignore;
    static ignoreNull(e) { return new r(e, t => t === null); }
    constructor(e, t) { super(e), this.ignore = t; }
    get defaultValue() { return []; }
    compute(e) { return this.fns.reduce((t, n) => { let i = n(e); return i === void 0 || i === V ? t : f(i) ? [...t, ...this.ignore ? i.filter(s => !this.ignore(s)) : i] : this.ignore && this.ignore(i) ? t : [...t, i]; }, []); }
}, U = class extends M {
    constructor(e) { super(e, void 0); }
}, Y = class extends P {
    key;
    get defaultValue() { return this.key.reducer.getInitial(); }
    constructor(e, t) { super(e), this.key = t; }
    compute(e) { if (this.fns.length === 0)
        return this.key.reducer.getInitial(); let t = this.key.reducer.getInitial(); for (let n = 0; n < this.fns.length; n++) {
        let i = this.fns[n](e);
        i !== V && (t = this.key.reducer.reduce(t, i));
    } return t; }
};
function se(r, e) { return r.length === 0 ? e : t => { for (let n of r) {
    let i = t.stateOf(n.path), s = u(i.structure.pathKeys).length - n.depth;
    for (let o = 0; o < s; o++)
        i = i.structure.parent;
    if (!n.fn(i.context))
        return V;
} return e(t); }; }
var N = class {
    predicates;
    hidden;
    disabledReasons;
    readonly;
    syncErrors;
    syncTreeErrors;
    asyncErrors;
    metadata = new Map;
    constructor(e) { this.predicates = e, this.hidden = new A(e), this.disabledReasons = new U(e), this.readonly = new A(e), this.syncErrors = M.ignoreNull(e), this.syncTreeErrors = M.ignoreNull(e), this.asyncErrors = M.ignoreNull(e); }
    hasMetadata(e) { return this.metadata.has(e); }
    getMetadataKeys() { return this.metadata.keys(); }
    getMetadata(e) { return this.metadata.has(e) || this.metadata.set(e, new Y(this.predicates, e)), this.metadata.get(e); }
    mergeIn(e) { this.hidden.mergeIn(e.hidden), this.disabledReasons.mergeIn(e.disabledReasons), this.readonly.mergeIn(e.readonly), this.syncErrors.mergeIn(e.syncErrors), this.syncTreeErrors.mergeIn(e.syncTreeErrors), this.asyncErrors.mergeIn(e.asyncErrors); for (let t of e.getMetadataKeys()) {
        let n = e.metadata.get(t);
        this.getMetadata(t).mergeIn(n);
    } }
}, x = class {
    depth;
    constructor(e) { this.depth = e; }
    build() { return new K(this, [], 0); }
}, E = class r extends x {
    constructor(e) { super(e); }
    current;
    all = [];
    addHiddenRule(e) { this.getCurrent().addHiddenRule(e); }
    addDisabledReasonRule(e) { this.getCurrent().addDisabledReasonRule(e); }
    addReadonlyRule(e) { this.getCurrent().addReadonlyRule(e); }
    addSyncErrorRule(e) { this.getCurrent().addSyncErrorRule(e); }
    addSyncTreeErrorRule(e) { this.getCurrent().addSyncTreeErrorRule(e); }
    addAsyncErrorRule(e) { this.getCurrent().addAsyncErrorRule(e); }
    addMetadataRule(e, t) { this.getCurrent().addMetadataRule(e, t); }
    getChild(e) { if (e === p) {
        let t = this.getCurrent().children;
        t.size > (t.has(p) ? 1 : 0) && (this.current = void 0);
    } return this.getCurrent().getChild(e); }
    hasLogic(e) { return this === e ? !0 : this.all.some(({ builder: t }) => t.hasLogic(e)); }
    mergeIn(e, t) { t ? this.all.push({ builder: e, predicate: { fn: y(t.fn, this.depth), path: t.path } }) : this.all.push({ builder: e }), this.current = void 0; }
    getCurrent() { return this.current === void 0 && (this.current = new R(this.depth), this.all.push({ builder: this.current })), this.current; }
    static newRoot() { return new r(0); }
}, R = class extends x {
    logic = new N([]);
    children = new Map;
    constructor(e) { super(e); }
    addHiddenRule(e) { this.logic.hidden.push(y(e, this.depth)); }
    addDisabledReasonRule(e) { this.logic.disabledReasons.push(y(e, this.depth)); }
    addReadonlyRule(e) { this.logic.readonly.push(y(e, this.depth)); }
    addSyncErrorRule(e) { this.logic.syncErrors.push(y(e, this.depth)); }
    addSyncTreeErrorRule(e) { this.logic.syncTreeErrors.push(y(e, this.depth)); }
    addAsyncErrorRule(e) { this.logic.asyncErrors.push(y(e, this.depth)); }
    addMetadataRule(e, t) { this.logic.getMetadata(e).push(y(t, this.depth)); }
    getChild(e) { return this.children.has(e) || this.children.set(e, new E(this.depth + 1)), this.children.get(e); }
    hasLogic(e) { return this === e; }
}, K = class r {
    builder;
    predicates;
    depth;
    logic;
    constructor(e, t, n) { this.builder = e, this.predicates = t, this.depth = n, this.logic = e ? Ne(e, t, n) : new N([]); }
    getChild(e) { let t = this.builder ? le(this.builder, e) : []; if (t.length === 0)
        return new r(void 0, [], this.depth + 1); if (t.length === 1) {
        let { builder: n, predicates: i } = t[0];
        return new r(n, [...this.predicates, ...i.map(s => z(s, this.depth))], this.depth + 1);
    }
    else {
        let n = t.map(({ builder: i, predicates: s }) => new r(i, [...this.predicates, ...s.map(o => z(o, this.depth))], this.depth + 1));
        return new G(n);
    } }
    hasLogic(e) { return this.builder?.hasLogic(e) ?? !1; }
}, G = class r {
    all;
    logic;
    constructor(e) { this.all = e, this.logic = new N([]); for (let t of e)
        this.logic.mergeIn(t.logic); }
    getChild(e) { return new r(this.all.flatMap(t => t.getChild(e))); }
    hasLogic(e) { return this.all.some(t => t.hasLogic(e)); }
};
function le(r, e) { if (r instanceof E)
    return r.all.flatMap(({ builder: t, predicate: n }) => { let i = le(t, e); return n ? i.map(({ builder: s, predicates: o }) => ({ builder: s, predicates: [...o, n] })) : i; }); if (r instanceof R)
    return [...e !== p && r.children.has(p) ? [{ builder: r.getChild(p), predicates: [] }] : [], ...r.children.has(e) ? [{ builder: r.getChild(e), predicates: [] }] : []]; throw new l(1909, !1); }
function Ne(r, e, t) { let n = new N(e); if (r instanceof E) {
    let i = r.all.map(({ builder: s, predicate: o }) => new K(s, o ? [...e, z(o, t)] : e, t));
    for (let s of i)
        n.mergeIn(s.logic);
}
else if (r instanceof R)
    n.mergeIn(r.logic);
else
    throw new l(1909, !1); return n; }
function z(r, e) { return L(g({}, r), { depth: e }); }
var he = Symbol("PATH"), m = class r {
    keys;
    parent;
    keyInParent;
    root;
    children = new Map;
    fieldPathProxy = new Proxy(this, Ee);
    logicBuilder;
    constructor(e, t, n, i) { this.keys = e, this.parent = n, this.keyInParent = i, this.root = t ?? this, n || (this.logicBuilder = E.newRoot()); }
    get builder() { return this.logicBuilder ? this.logicBuilder : this.parent.builder.getChild(this.keyInParent); }
    getChild(e) { return this.children.has(e) || this.children.set(e, new r([...this.keys, e], this.root, this, e)), this.children.get(e); }
    mergeIn(e, t) { let n = e.compile(); this.builder.mergeIn(n.builder, t); }
    static unwrapFieldPath(e) { return e[he]; }
    static newRoot() { return new r([], void 0, void 0, void 0); }
}, Ee = { get(r, e) { return e === he ? r : r.getChild(e).fieldPathProxy; } }, I, D = new Map, S = class r {
    schemaFn;
    constructor(e) { this.schemaFn = e; }
    compile() { if (D.has(this))
        return D.get(this); let e = m.newRoot(); D.set(this, e); let t = I; try {
        I = e, this.schemaFn(e.fieldPathProxy);
    }
    finally {
        I = t;
    } return e; }
    static create(e) { return e instanceof r ? e : new r(e); }
    static rootCompile(e) { try {
        return D.clear(), e === void 0 ? m.newRoot() : e instanceof r ? e.compile() : new r(e).compile();
    }
    finally {
        D.clear();
    } }
};
function De(r) { return r instanceof S || typeof r == "function"; }
function _(r) { if (I !== m.unwrapFieldPath(r).root)
    throw new l(1908, !1); }
function rt(r, e, t) { return _(r), m.unwrapFieldPath(r).builder.addMetadataRule(e, t), e; }
var b = { list() { return { reduce: (r, e) => e === void 0 ? r : [...r, e], getInitial: () => [] }; }, min() { return { reduce: (r, e) => r === void 0 || e === void 0 ? r ?? e : Math.min(r, e), getInitial: () => { } }; }, max() { return { reduce: (r, e) => r === void 0 || e === void 0 ? r ?? e : Math.max(r, e), getInitial: () => { } }; }, or() { return { reduce: (r, e) => r || e, getInitial: () => !1 }; }, and() { return { reduce: (r, e) => r && e, getInitial: () => !0 }; }, override: Pe };
function Pe(r) { return { reduce: (e, t) => t, getInitial: () => r?.() }; }
var O = class {
    reducer;
    create;
    brand;
    constructor(e, t) { this.reducer = e, this.create = t; }
};
function v(r) { return new O(r ?? b.override()); }
function nt(r, e) { return new O(e ?? b.override(), r); }
var Re = v(b.or()), Te = v(b.max()), ke = v(b.min()), Ie = v(b.max()), Ce = v(b.min()), Ae = v(b.list());
function xe(r) { return r.errors().length > 0 ? "invalid" : r.pending() ? "unknown" : "valid"; }
var W = class {
    node;
    constructor(e) { this.node = e; }
    rawSyncTreeErrors = a(() => this.shouldSkipValidation() ? [] : [...this.node.logicNode.logic.syncTreeErrors.compute(this.node.context), ...this.node.structure.parent?.validationState.rawSyncTreeErrors() ?? []]);
    syncErrors = a(() => this.shouldSkipValidation() ? [] : [...this.node.logicNode.logic.syncErrors.compute(this.node.context), ...this.syncTreeErrors(), ...Ke(this.node.submitState.submissionErrors())]);
    syncValid = a(() => this.shouldSkipValidation() ? !0 : this.node.structure.reduceChildren(this.syncErrors().length === 0, (e, t) => t && e.validationState.syncValid(), Me));
    syncTreeErrors = a(() => this.rawSyncTreeErrors().filter(e => e.fieldTree === this.node.fieldTree));
    rawAsyncErrors = a(() => this.shouldSkipValidation() ? [] : [...this.node.logicNode.logic.asyncErrors.compute(this.node.context), ...this.node.structure.parent?.validationState.rawAsyncErrors() ?? []]);
    asyncErrors = a(() => this.shouldSkipValidation() ? [] : this.rawAsyncErrors().filter(e => e === "pending" || e.fieldTree === this.node.fieldTree));
    parseErrors = a(() => this.node.formFieldBindings().flatMap(e => e.parseErrors()));
    errors = a(() => [...this.parseErrors(), ...this.syncErrors(), ...this.asyncErrors().filter(e => e !== "pending")]);
    errorSummary = a(() => { let e = this.node.structure.reduceChildren(this.errors(), (t, n) => [...n, ...t.errorSummary()]); return (typeof ngServerMode > "u" || !ngServerMode) && u(() => e.sort(Fe)), e; });
    pending = a(() => this.node.structure.reduceChildren(this.asyncErrors().includes("pending"), (e, t) => t || e.validationState.asyncErrors().includes("pending")));
    status = a(() => { if (this.shouldSkipValidation())
        return "valid"; let e = xe(this); return this.node.structure.reduceChildren(e, (t, n) => n === "invalid" || t.validationState.status() === "invalid" ? "invalid" : n === "unknown" || t.validationState.status() === "unknown" ? "unknown" : "valid", t => t === "invalid"); });
    valid = a(() => this.status() === "valid");
    invalid = a(() => this.status() === "invalid");
    shouldSkipValidation = a(() => this.node.hidden() || this.node.disabled() || this.node.readonly());
};
function Ke(r) { return r === void 0 ? [] : f(r) ? r : [r]; }
function Oe(r, e) { if (f(r))
    for (let t of r)
        t.fieldTree ??= e;
else
    r && (r.fieldTree ??= e); return r; }
function oe(r) { return r.formField ? r.formField.element : r.fieldTree().formFieldBindings().reduce((e, t) => !e || !t.element ? e ?? t.element : e.compareDocumentPosition(t.element) & Node.DOCUMENT_POSITION_PRECEDING ? t.element : e, void 0); }
function Fe(r, e) { let t = oe(r), n = oe(e); return t === n ? 0 : t === void 0 || n === void 0 ? t === void 0 ? 1 : -1 : t.compareDocumentPosition(n) & Node.DOCUMENT_POSITION_PRECEDING ? 1 : -1; }
var ae = v(), X = class {
    node;
    cache = new WeakMap;
    constructor(e) { this.node = e; }
    resolve(e) { if (!this.cache.has(e)) {
        let t = a(() => { let n = m.unwrapFieldPath(e), i = this.node, s = we(); for (; s > 0 || !i.structure.logic.hasLogic(n.root.builder);)
            if (s--, i = i.structure.parent, i === void 0)
                throw new l(1900, !1); for (let o of n.keys)
            if (i = i.structure.getChild(o), i === void 0)
                throw new l(1901, !1); return i.fieldTree; });
        this.cache.set(e, t);
    } return this.cache.get(e)(); }
    get fieldTree() { return this.node.fieldProxy; }
    get state() { return this.node; }
    get value() { return this.node.structure.value; }
    get key() { return this.node.structure.keyInParent; }
    get pathKeys() { return this.node.structure.pathKeys; }
    index = a(() => { let e = this.key(); if (!f(u(this.node.structure.parent.value)))
        throw new l(1906, !1); return Number(e); });
    fieldTreeOf = e => this.resolve(e);
    stateOf = e => this.resolve(e)();
    valueOf = e => { let t = this.resolve(e)().value(); if (t instanceof be)
        throw new l(1907, !1); return t; };
}, q = class {
    node;
    metadata = new Map;
    constructor(e) { this.node = e; for (let t of this.node.logicNode.logic.getMetadataKeys())
        if (t.create) {
            let n = this.node.logicNode.logic.getMetadata(t), i = u(() => ue(this.node.structure.injector, () => t.create(a(() => n.compute(this.node.context)))));
            this.metadata.set(t, i);
        } }
    get(e) { if (this.has(e) && !this.metadata.has(e)) {
        if (e.create)
            throw new l(1912, !1);
        let t = this.node.logicNode.logic.getMetadata(e);
        this.metadata.set(e, a(() => t.compute(this.node.context)));
    } return this.metadata.get(e); }
    has(e) { return this.node.logicNode.logic.hasMetadata(e); }
}, je = { get(r, e, t) { let n = r(), i = n.structure.getChild(e); if (i !== void 0)
        return i.fieldTree; let s = u(n.value); if (f(s)) {
        if (e === "length")
            return n.value().length;
        if (e === Symbol.iterator)
            return () => (n.value(), Array.prototype[Symbol.iterator].apply(n.fieldTree));
    } if (w(s) && e === Symbol.iterator)
        return function* () { for (let o in t)
            yield [o, t[o]]; }; }, getOwnPropertyDescriptor(r, e) { let t = u(r().value), n = Reflect.getOwnPropertyDescriptor(t, e); return n && !n.configurable && (n.configurable = !0), n; }, ownKeys(r) { let e = u(r().value); return typeof e == "object" && e !== null ? Reflect.ownKeys(e) : []; } };
function Ve(r, e) { let t = a(() => r()[e()]); return t[ne] = r[ne], t.set = n => { r.update(i => _e(i, n, e())); }, t.update = n => { t.set(n(u(t))); }, t.asReadonly = () => t, t; }
function _e(r, e, t) { if (f(r)) {
    let n = [...r];
    return n[t] = e, n;
}
else
    return L(g({}, r), { [t]: e }); }
var F = class {
    logic;
    node;
    createChildNode;
    identitySymbol = Symbol();
    _injector = void 0;
    get injector() { return this._injector ??= ce.create({ providers: [], parent: this.fieldManager.injector }), this._injector; }
    constructor(e, t, n) { this.logic = e, this.node = t, this.createChildNode = n; }
    children() { let e = this.childrenMap(); return e === void 0 ? [] : Array.from(e.byPropertyKey.values()).map(t => u(t.reader)); }
    getChild(e) { let t = e.toString(), n = u(this.childrenMap)?.byPropertyKey.get(t)?.reader; return n || (n = this.createReader(t)), n(); }
    reduceChildren(e, t, n) { let i = this.childrenMap(); if (!i)
        return e; let s = e; for (let o of i.byPropertyKey.values()) {
        if (n?.(s))
            break;
        s = t(u(o.reader), s);
    } return s; }
    destroy() { this.injector.destroy(); }
    createKeyInParent(e, t, n) { if (e.kind === "root")
        return fe; if (t === void 0) {
        let i = n;
        return a(() => { if (this.parent.structure.getChild(i) !== this.node)
            throw new l(-1902, !1); return i; });
    }
    else {
        let i = n;
        return a(() => { let s = this.parent.structure.value(); if (!f(s))
            throw new l(1903, !1); let o = s[i]; if (w(o) && o.hasOwnProperty(this.parent.structure.identitySymbol) && o[this.parent.structure.identitySymbol] === t)
            return i; for (let d = 0; d < s.length; d++) {
            let c = s[d];
            if (w(c) && c.hasOwnProperty(this.parent.structure.identitySymbol) && c[this.parent.structure.identitySymbol] === t)
                return i = d.toString();
        } throw new l(1904, !1); });
    } }
    createChildrenMap() { return C({ source: this.value, computation: (e, t) => { if (!w(e))
            return; let n = t?.value ?? { byPropertyKey: new Map }, i, s = f(e); n !== void 0 && (s ? i = Le(n, e, this.identitySymbol) : i = He(n, e)); for (let o of Object.keys(e)) {
            let d, c = e[o];
            if (c === void 0) {
                n.byPropertyKey.has(o) && (i ??= g({}, n), i.byPropertyKey.delete(o));
                continue;
            }
            s && w(c) && !f(c) && (d = c[this.identitySymbol] ??= Symbol(""));
            let h;
            d && (n.byTrackingKey?.has(d) || (i ??= g({}, n), i.byTrackingKey ??= new Map, i.byTrackingKey.set(d, this.createChildNode(o, d, s))), h = (i ?? n).byTrackingKey.get(d));
            let B = n.byPropertyKey.get(o);
            B === void 0 ? (i ??= g({}, n), i.byPropertyKey.set(o, { reader: this.createReader(o), node: h ?? this.createChildNode(o, d, s) })) : h && h !== B.node && (i ??= g({}, n), B.node = h);
        } return i ?? n; } }); }
    createReader(e) { return a(() => this.childrenMap()?.byPropertyKey.get(e)?.node); }
}, Q = class extends F {
    fieldManager;
    value;
    get parent() { }
    get root() { return this.node; }
    get pathKeys() { return Be; }
    get keyInParent() { return fe; }
    childrenMap;
    constructor(e, t, n, i, s) { super(t, e, s), this.fieldManager = n, this.value = i, this.childrenMap = this.createChildrenMap(); }
}, J = class extends F {
    logic;
    parent;
    root;
    pathKeys;
    keyInParent;
    value;
    childrenMap;
    get fieldManager() { return this.root.structure.fieldManager; }
    constructor(e, t, n, i, s, o) { super(t, e, o), this.logic = t, this.parent = n, this.root = this.parent.structure.root, this.keyInParent = this.createKeyInParent({ kind: "child", parent: n, pathNode: void 0, logic: t, initialKeyInParent: s, identityInParent: i, fieldAdapter: void 0 }, i, s), this.pathKeys = a(() => [...n.structure.pathKeys(), this.keyInParent()]), this.value = Ve(this.parent.structure.value, this.keyInParent), this.childrenMap = this.createChildrenMap(), this.fieldManager.structures.add(this); }
};
var Be = a(() => []), fe = a(() => { throw new l(1905, !1); });
function Le(r, e, t) { let n, i = new Set(r.byPropertyKey.keys()), s = new Set(r.byTrackingKey?.keys()); for (let o = 0; o < e.length; o++) {
    let d = e[o];
    i.delete(o.toString()), w(d) && d.hasOwnProperty(t) && s.delete(d[t]);
} if (i.size > 0) {
    n ??= g({}, r);
    for (let o of i)
        n.byPropertyKey.delete(o);
} if (s.size > 0) {
    n ??= g({}, r);
    for (let o of s)
        n.byTrackingKey?.delete(o);
} return n; }
function He(r, e) { let t; for (let n of r.byPropertyKey.keys())
    e.hasOwnProperty(n) || (t ??= g({}, r), t.byPropertyKey.delete(n)); return t; }
var Z = class {
    node;
    selfSubmitting = k(!1);
    submissionErrors;
    constructor(e) { this.node = e, this.submissionErrors = C({ source: this.node.structure.value, computation: () => [] }); }
    submitting = a(() => this.selfSubmitting() || (this.node.structure.parent?.submitting() ?? !1));
}, T = class {
    structure;
    validationState;
    metadataState;
    nodeState;
    submitState;
    fieldAdapter;
    controlValue;
    _context = void 0;
    get context() { return this._context ??= new X(this); }
    fieldProxy = new Proxy(() => this, je);
    pathNode;
    constructor(e) { this.pathNode = e.pathNode, this.fieldAdapter = e.fieldAdapter, this.structure = this.fieldAdapter.createStructure(this, e), this.validationState = this.fieldAdapter.createValidationState(this, e), this.nodeState = this.fieldAdapter.createNodeState(this, e), this.metadataState = new q(this), this.submitState = new Z(this), this.controlValue = this.controlValueSignal(); }
    focusBoundControl(e) { this.getBindingForFocus()?.focus(e); }
    getBindingForFocus() { let e = this.formFieldBindings().filter(t => t.focus !== void 0).reduce(de, void 0); return e || this.structure.children().map(t => t.getBindingForFocus()).reduce(de, void 0); }
    pendingSync = C({ source: () => this.value(), computation: (e, t) => { t?.value?.abort(); } });
    get fieldTree() { return this.fieldProxy; }
    get logicNode() { return this.structure.logic; }
    get value() { return this.structure.value; }
    get keyInParent() { return this.structure.keyInParent; }
    get errors() { return this.validationState.errors; }
    get parseErrors() { return this.validationState.parseErrors; }
    get errorSummary() { return this.validationState.errorSummary; }
    get pending() { return this.validationState.pending; }
    get valid() { return this.validationState.valid; }
    get invalid() { return this.validationState.invalid; }
    get dirty() { return this.nodeState.dirty; }
    get touched() { return this.nodeState.touched; }
    get disabled() { return this.nodeState.disabled; }
    get disabledReasons() { return this.nodeState.disabledReasons; }
    get hidden() { return this.nodeState.hidden; }
    get readonly() { return this.nodeState.readonly; }
    get formFieldBindings() { return this.nodeState.formFieldBindings; }
    get submitting() { return this.submitState.submitting; }
    get name() { return this.nodeState.name; }
    get max() { return this.metadata(ke); }
    get maxLength() { return this.metadata(Ce); }
    get min() { return this.metadata(Te); }
    get minLength() { return this.metadata(Ie); }
    get pattern() { return this.metadata(Ae) ?? $e; }
    get required() { return this.metadata(Re) ?? Ue; }
    metadata(e) { return this.metadataState.get(e); }
    hasMetadata(e) { return this.metadataState.has(e); }
    markAsTouched() { u(() => { this.nodeState.markAsTouched(), this.flushSync(); }); }
    markAsDirty() { this.nodeState.markAsDirty(); }
    markAsPristine() { this.nodeState.markAsPristine(); }
    markAsUntouched() { this.nodeState.markAsUntouched(); }
    reset(e) { u(() => this._reset(e)); }
    _reset(e) { e !== void 0 && this.value.set(e), this.nodeState.markAsUntouched(), this.nodeState.markAsPristine(); for (let t of this.structure.children())
        t._reset(); }
    controlValueSignal() { let e = C(this.value), { set: t, update: n } = e; return e.set = i => { t(i), this.markAsDirty(), this.debounceSync(); }, e.update = i => { n(i), this.markAsDirty(), this.debounceSync(); }, e; }
    sync() { this.value.set(this.controlValue()); }
    flushSync() { let e = this.pendingSync(); e && !e.signal.aborted && (e.abort(), this.sync()); }
    debounceSync() { return H(this, null, function* () { let e = u(() => (this.pendingSync()?.abort(), this.nodeState.debouncer())); if (e) {
        let t = new AbortController, n = e(t.signal);
        if (n && (this.pendingSync.set(t), yield n, t.signal.aborted))
            return;
    } this.sync(); }); }
    static newRoot(e, t, n, i) { return i.newRoot(e, t, n, i); }
    createStructure(e) { return e.kind === "root" ? new Q(this, e.logic, e.fieldManager, e.value, this.newChild.bind(this)) : new J(this, e.logic, e.parent, e.identityInParent, e.initialKeyInParent, this.newChild.bind(this)); }
    newChild(e, t, n) { let i, s; return n ? (i = this.pathNode.getChild(p), s = this.structure.logic.getChild(p)) : (i = this.pathNode.getChild(e), s = this.structure.logic.getChild(e)), this.fieldAdapter.newChild({ kind: "child", parent: this, pathNode: i, logic: s, initialKeyInParent: e, identityInParent: t, fieldAdapter: this.fieldAdapter }); }
}, $e = a(() => []), Ue = a(() => !1);
function de(r, e) { return r ? e && r.element.compareDocumentPosition(e.element) & Node.DOCUMENT_POSITION_PRECEDING ? e : r : e; }
var ee = class {
    node;
    selfTouched = k(!1);
    selfDirty = k(!1);
    markAsTouched() { this.selfTouched.set(!0); }
    markAsDirty() { this.selfDirty.set(!0); }
    markAsPristine() { this.selfDirty.set(!1); }
    markAsUntouched() { this.selfTouched.set(!1); }
    formFieldBindings = k([]);
    constructor(e) { this.node = e; }
    dirty = a(() => { let e = this.selfDirty() && !this.isNonInteractive(); return this.node.structure.reduceChildren(e, (t, n) => n || t.nodeState.dirty(), ie); });
    touched = a(() => { let e = this.selfTouched() && !this.isNonInteractive(); return this.node.structure.reduceChildren(e, (t, n) => n || t.nodeState.touched(), ie); });
    disabledReasons = a(() => [...this.node.structure.parent?.nodeState.disabledReasons() ?? [], ...this.node.logicNode.logic.disabledReasons.compute(this.node.context)]);
    disabled = a(() => !!this.disabledReasons().length);
    readonly = a(() => (this.node.structure.parent?.nodeState.readonly() || this.node.logicNode.logic.readonly.compute(this.node.context)) ?? !1);
    hidden = a(() => (this.node.structure.parent?.nodeState.hidden() || this.node.logicNode.logic.hidden.compute(this.node.context)) ?? !1);
    name = a(() => { let e = this.node.structure.parent; return e ? `${e.name()}.${this.node.structure.keyInParent()}` : this.node.structure.fieldManager.rootName; });
    debouncer = a(() => { if (this.node.logicNode.logic.hasMetadata(ae)) {
        let t = this.node.logicNode.logic.getMetadata(ae).compute(this.node.context);
        if (t)
            return n => t(this.node.context, n);
    } return this.node.structure.parent?.nodeState.debouncer?.(); });
    isNonInteractive = a(() => this.hidden() || this.disabled() || this.readonly());
}, te = class {
    newRoot(e, t, n, i) { return new T({ kind: "root", fieldManager: e, value: t, pathNode: n, logic: n.builder.build(), fieldAdapter: i }); }
    newChild(e) { return new T(e); }
    createNodeState(e) { return new ee(e); }
    createValidationState(e) { return new W(e); }
    createStructure(e, t) { return e.createStructure(t); }
}, re = class {
    injector;
    rootName;
    submitOptions;
    constructor(e, t, n) { this.injector = e, this.rootName = t ?? `${this.injector.get(me)}.form${Ye++}`, this.submitOptions = n; }
    structures = new Set;
    createFieldManagementEffect(e) { ye(() => { let t = new Set; this.markStructuresLive(e, t); for (let n of this.structures)
        t.has(n) || (this.structures.delete(n), u(() => n.destroy())); }, { injector: this.injector }); }
    markStructuresLive(e, t) { t.add(e); for (let n of e.children())
        this.markStructuresLive(n.structure, t); }
}, Ye = 0;
function Ge(r) { let e, t, n; return r.length === 3 ? [e, t, n] = r : r.length === 2 ? De(r[1]) ? [e, t] = r : [e, n] = r : [e] = r, [e, t, n]; }
function it(...r) { let [e, t, n] = Ge(r), i = n?.injector ?? pe(ce), s = ue(i, () => S.rootCompile(t)), o = new re(i, n?.name, n?.submission), d = n?.adapter ?? new te, c = T.newRoot(o, e, s, d); return o.createFieldManagementEffect(c.structure), c.fieldTree; }
function st(r, e) { _(r); let t = m.unwrapFieldPath(r).getChild(p).fieldPathProxy; ze(t, e); }
function ze(r, e) { _(r), m.unwrapFieldPath(r).mergeIn(S.create(e)); }
function We(r, e, t) { _(r), m.unwrapFieldPath(r).mergeIn(S.create(t), { fn: e, path: r }); }
function ot(r, e, t) { We(r, ({ value: n }) => e(n()), t); }
function at(r, e) { return H(this, null, function* () { let t = u(r); if (u(t.submitState.submitting))
    return !1; let n = e === void 0 ? t.structure.root.fieldProxy : r, i = { root: t.structure.root.fieldProxy, submitted: r }; e = typeof e == "function" ? { action: e } : e ?? t.structure.fieldManager.submitOptions; let s = e?.action; if (!s)
    throw new l(1915, !1); let o = e?.onInvalid, d = e?.ignoreValidators ?? "pending", c = !0; u(() => { ge(t), d === "none" ? c = t.valid() : d === "pending" && (c = !t.invalid()); }); try {
    if (c) {
        t.submitState.selfSubmitting.set(!0);
        let h = yield u(() => s?.(n, i));
        return h && Xe(t, h), !h || f(h) && h.length === 0;
    }
    else
        u(() => o?.(n, i));
    return !1;
}
finally {
    t.submitState.selfSubmitting.set(!1);
} }); }
function dt(r) { return S.create(r); }
function ge(r) { if (!r.validationState.shouldSkipValidation()) {
    r.markAsTouched();
    for (let e of r.structure.children())
        ge(e);
} }
function Xe(r, e) { f(e) || (e = [e]); let t = new Map; for (let n of e) {
    let i = Oe(n, r.fieldTree), s = i.fieldTree(), o = t.get(s);
    o || (o = [], t.set(s, o)), o.push(i);
} for (let [n, i] of t)
    n.submitState.submissionErrors.set(i); }
var j = class {
    kind = "compat";
    control;
    fieldTree;
    context;
    message;
    constructor({ context: e, kind: t, control: n }) { this.context = e, this.kind = t, this.control = n; }
};
function ut(r) { if (r.length === 0)
    return null; let e = {}; for (let t of r)
    e[t.kind] = t instanceof j ? t.context : t; return e; }
function qe(r, e) { return r === null ? [] : Object.entries(r).map(([t, n]) => new j({ context: n, kind: t, control: e })); }
function Qe(r) { let e = []; if (r.errors && e.push(...qe(r.errors, r)), r instanceof Se || r instanceof ve)
    for (let t of Object.values(r.controls))
        e.push(...Qe(t)); return e; }
export { tt as a, m as b, _ as c, rt as d, b as e, O as f, v as g, nt as h, Re as i, Te as j, ke as k, Ie as l, Ce as m, Ae as n, xe as o, Oe as p, ae as q, F as r, T as s, ee as t, te as u, Ge as v, it as w, st as x, ze as y, We as z, ot as A, at as B, dt as C, j as D, ut as E, Qe as F };
/*! Bundled license information:

@angular/forms/fesm2022/_validation_errors-chunk.mjs:
  (**
   * @license Angular v21.2.18
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
