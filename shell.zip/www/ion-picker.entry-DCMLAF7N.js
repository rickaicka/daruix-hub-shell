import { h as u } from "@nf-internal/chunk-NTOTMM2V";
import { i as d, m as l, n as h, q as b, r as p } from "@nf-internal/chunk-DPCBKAOC";
import { h as g } from "@nf-internal/chunk-C4FLJMU7";
var k = () => ":host{display:-ms-flexbox;display:flex;position:relative;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;width:100%;height:200px;direction:ltr;z-index:0}:host .picker-before,:host .picker-after{position:absolute;width:100%;-webkit-transform:translateZ(0);transform:translateZ(0);z-index:1;pointer-events:none}:host .picker-before{top:0;height:83px}:host .picker-before{inset-inline-start:0}:host .picker-after{top:116px;height:84px}:host .picker-after{inset-inline-start:0}:host .picker-highlight{border-radius:var(--highlight-border-radius, 8px);left:0;right:0;top:50%;bottom:0;-webkit-margin-start:auto;margin-inline-start:auto;-webkit-margin-end:auto;margin-inline-end:auto;margin-top:0;margin-bottom:0;position:absolute;width:calc(100% - 16px);height:34px;-webkit-transform:translateY(-50%);transform:translateY(-50%);background:var(--highlight-background);z-index:-1}:host input{position:absolute;top:0;left:0;right:0;bottom:0;width:100%;height:100%;margin:0;padding:0;border:0;outline:0;clip:rect(0 0 0 0);opacity:0;overflow:hidden;-webkit-appearance:none;-moz-appearance:none}:host ::slotted(ion-picker-column:first-of-type){text-align:start}:host ::slotted(ion-picker-column:last-of-type){text-align:end}:host ::slotted(ion-picker-column:only-child){text-align:center}:host .picker-before{background:-webkit-gradient(linear, left top, left bottom, color-stop(20%, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 1)), to(rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 0.8)));background:linear-gradient(to bottom, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 1) 20%, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 0.8) 100%)}:host .picker-after{background:-webkit-gradient(linear, left bottom, left top, color-stop(20%, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 1)), to(rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 0.8)));background:linear-gradient(to top, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 1) 20%, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 0.8) 100%)}:host .picker-highlight{background:var(--highlight-background, var(--ion-color-step-150, var(--ion-background-color-step-150, #eeeeef)))}", m = () => ":host{display:-ms-flexbox;display:flex;position:relative;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;width:100%;height:200px;direction:ltr;z-index:0}:host .picker-before,:host .picker-after{position:absolute;width:100%;-webkit-transform:translateZ(0);transform:translateZ(0);z-index:1;pointer-events:none}:host .picker-before{top:0;height:83px}:host .picker-before{inset-inline-start:0}:host .picker-after{top:116px;height:84px}:host .picker-after{inset-inline-start:0}:host .picker-highlight{border-radius:var(--highlight-border-radius, 8px);left:0;right:0;top:50%;bottom:0;-webkit-margin-start:auto;margin-inline-start:auto;-webkit-margin-end:auto;margin-inline-end:auto;margin-top:0;margin-bottom:0;position:absolute;width:calc(100% - 16px);height:34px;-webkit-transform:translateY(-50%);transform:translateY(-50%);background:var(--highlight-background);z-index:-1}:host input{position:absolute;top:0;left:0;right:0;bottom:0;width:100%;height:100%;margin:0;padding:0;border:0;outline:0;clip:rect(0 0 0 0);opacity:0;overflow:hidden;-webkit-appearance:none;-moz-appearance:none}:host ::slotted(ion-picker-column:first-of-type){text-align:start}:host ::slotted(ion-picker-column:last-of-type){text-align:end}:host ::slotted(ion-picker-column:only-child){text-align:center}:host .picker-before{background:-webkit-gradient(linear, left top, left bottom, color-stop(20%, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 1)), color-stop(90%, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 0)));background:linear-gradient(to bottom, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 1) 20%, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 0) 90%)}:host .picker-after{background:-webkit-gradient(linear, left bottom, left top, color-stop(30%, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 1)), color-stop(90%, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 0)));background:linear-gradient(to top, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 1) 30%, rgba(var(--fade-background-rgb, var(--background-rgb, var(--ion-background-color-rgb, 255, 255, 255))), 0) 90%)}", v = class {
    constructor(i) { d(this, i), this.ionInputModeChange = p(this, "ionInputModeChange", 7), this.useInputMode = !1, this.isInHighlightBounds = t => { let { highlightEl: e } = this; if (!e)
        return !1; let n = e.getBoundingClientRect(), r = t.clientX < n.left || t.clientX > n.right, a = t.clientY < n.top || t.clientY > n.bottom; return !(r || a); }, this.onFocusOut = t => { let { relatedTarget: e } = t; (!e || e.tagName !== "ION-PICKER-COLUMN" && e !== this.inputEl) && this.exitInputMode(); }, this.onFocusIn = t => { let { target: e } = t; if (e.tagName === "ION-PICKER-COLUMN" && !this.actionOnClick) {
        let n = e;
        n.numericInput ? this.enterInputMode(n, !1) : this.exitInputMode();
    } }, this.onClick = () => { let { actionOnClick: t } = this; t && (t(), this.actionOnClick = void 0); }, this.onPointerDown = t => { let { useInputMode: e, inputModeColumn: n, el: r } = this; if (this.isInHighlightBounds(t)) {
        if (e)
            t.target.tagName === "ION-PICKER-COLUMN" ? n && n === t.target ? this.actionOnClick = () => { this.enterInputMode(); } : this.actionOnClick = () => { this.enterInputMode(t.target); } : this.actionOnClick = () => { this.exitInputMode(); };
        else {
            let o = r.querySelectorAll("ion-picker-column.picker-column-numeric-input").length === 1 ? t.target : void 0;
            this.actionOnClick = () => { this.enterInputMode(o); };
        }
        return;
    } this.actionOnClick = () => { this.exitInputMode(); }; }, this.enterInputMode = (t, e = !0) => { let { inputEl: n, el: r } = this; !n || !r.querySelector("ion-picker-column.picker-column-numeric-input") || (this.useInputMode = !0, this.inputModeColumn = t, e ? (this.destroyKeypressListener && (this.destroyKeypressListener(), this.destroyKeypressListener = void 0), n.focus()) : (r.addEventListener("keypress", this.onKeyPress), this.destroyKeypressListener = () => { r.removeEventListener("keypress", this.onKeyPress); }), this.emitInputModeChange()); }, this.onKeyPress = t => { let { inputEl: e } = this; if (!e)
        return; let n = parseInt(t.key, 10); Number.isNaN(n) || (e.value += t.key, this.onInputChange()); }, this.selectSingleColumn = () => { let { inputEl: t, inputModeColumn: e, singleColumnSearchTimeout: n } = this; if (!t || !e)
        return; let r = Array.from(e.querySelectorAll("ion-picker-column-option")).filter(o => o.disabled !== !0); if (n && clearTimeout(n), this.singleColumnSearchTimeout = setTimeout(() => { t.value = "", this.singleColumnSearchTimeout = void 0; }, 1e3), t.value.length >= 3) {
        let o = t.value.length - 2, s = t.value.substring(o);
        t.value = s, this.selectSingleColumn();
        return;
    } let a = r.find(({ textContent: o }) => o.replace(/^0+(?=[1-9])|0+(?=0$)/, "") === t.value); if (a) {
        e.setValue(a.value);
        return;
    } if (t.value.length === 2) {
        let o = t.value.substring(t.value.length - 1);
        t.value = o, this.selectSingleColumn();
    } }, this.searchColumn = (t, e, n = "start") => { if (!e)
        return !1; let r = n === "start" ? /^0+/ : /0$/; e = e.replace(r, ""); let a = Array.from(t.querySelectorAll("ion-picker-column-option")).find(o => o.disabled !== !0 && o.textContent.replace(r, "") === e); return a && t.setValue(a.value), !!a; }, this.multiColumnSearch = (t, e, n) => { if (n.length === 0)
        return; let r = n.split(""), a = r.slice(0, 2).join(""), o = this.searchColumn(t, a); if (r.length > 2 && o) {
        let s = r.slice(2, 4).join("");
        this.searchColumn(e, s);
    }
    else if (!o && r.length >= 1) {
        let s = r[0], c = this.searchColumn(t, s);
        if (c || (r.shift(), s = r[0], c = this.searchColumn(t, s)), c && r.length > 1) {
            let f = r.slice(1, 3).join("");
            this.searchColumn(e, f);
        }
    } }, this.selectMultiColumn = () => { let { inputEl: t, el: e } = this; if (!t)
        return; let n = Array.from(e.querySelectorAll("ion-picker-column")).filter(s => s.numericInput), r = n[0], a = n[1], o = t.value; if (o.length > 4) {
        let s = t.value.length - 4, c = t.value.substring(s);
        t.value = c, o = c;
    } this.multiColumnSearch(r, a, o); }, this.onInputChange = () => { let { useInputMode: t, inputEl: e, inputModeColumn: n } = this; !t || !e || (n ? this.selectSingleColumn() : this.selectMultiColumn()); }, this.emitInputModeChange = () => { let { useInputMode: t, inputModeColumn: e } = this; this.ionInputModeChange.emit({ useInputMode: t, inputModeColumn: e }); }; }
    preventTouchStartPropagation(i) { i.stopPropagation(); }
    componentWillLoad() { u(this.el).addEventListener("focusin", this.onFocusIn), u(this.el).addEventListener("focusout", this.onFocusOut); }
    exitInputMode() { return g(this, null, function* () { let { inputEl: i, useInputMode: t } = this; !t || !i || (this.useInputMode = !1, this.inputModeColumn = void 0, i.blur(), i.value = "", this.destroyKeypressListener && (this.destroyKeypressListener(), this.destroyKeypressListener = void 0), this.emitInputModeChange()); }); }
    render() { return l(h, { key: "28f81e4ed44a633178561757c5199c2c98f94b74", onPointerDown: i => this.onPointerDown(i), onClick: () => this.onClick() }, l("input", { key: "abb3d1ad25ef63856af7804111175a4d50008bc0", "aria-hidden": "true", tabindex: -1, inputmode: "numeric", type: "number", onKeyDown: i => { var t; i.key === "Enter" && ((t = this.inputEl) === null || t === void 0 || t.blur()); }, ref: i => this.inputEl = i, onInput: () => this.onInputChange(), onBlur: () => this.exitInputMode() }), l("div", { key: "334a5abdc02e6b127c57177f626d7e4ff5526183", class: "picker-before" }), l("div", { key: "ffd6271931129e88fc7c820e919d684899e420c5", class: "picker-after" }), l("div", { key: "78d1d95fd09e04f154ea59f24a1cece72c47ed7b", class: "picker-highlight", ref: i => this.highlightEl = i }), l("slot", { key: "0bd5b9f875d3c71f6cbbde2054baeb1b0a2e8cd5" })); }
    get el() { return b(this); }
};
v.style = { ios: k(), md: m() };
export { v as ion_picker };
/*! Bundled license information:

@ionic/core/dist/esm/ion-picker.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
