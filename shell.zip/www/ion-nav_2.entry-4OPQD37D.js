import { a as E } from "@nf-internal/chunk-B5XQ7TKQ";
import { a as V } from "@nf-internal/chunk-56RDUDAP";
import { a as B, b as L, c as p, d as P, e as m, h as _ } from "@nf-internal/chunk-3EH34PB5";
import { c as T } from "@nf-internal/chunk-DBOLI3CQ";
import { n as h, s as A } from "@nf-internal/chunk-NTOTMM2V";
import { a as b, e as R, i as I, m as k, n as O, q as C, r as y } from "@nf-internal/chunk-DPCBKAOC";
import { h as f } from "@nf-internal/chunk-C4FLJMU7";
var G = 1, N = 2, S = 3, g = class {
    constructor(t, s) { this.component = t, this.params = s, this.state = G; }
    init(t) { return f(this, null, function* () { if (this.state = N, !this.element) {
        let s = this.component;
        this.element = yield V(this.delegate, t, s, ["ion-page", "ion-page-invisible"], this.params);
    } }); }
    _destroy() { h(this.state !== S, "view state must be ATTACHED"); let t = this.element; t && (this.delegate ? this.delegate.removeViewFromDom(t.parentElement, t) : t.remove()), this.nav = void 0, this.state = S; }
}, q = (e, t, s) => !e || e.component !== t ? !1 : A(e.params, s), x = (e, t) => e ? e instanceof g ? e : new g(e, t) : null, j = e => e.map(t => t instanceof g ? t : "component" in t ? x(t.component, t.componentProps === null ? void 0 : t.componentProps) : x(t, void 0)).filter(t => t !== null), D = () => ":host{left:0;right:0;top:0;bottom:0;position:absolute;contain:layout size style;z-index:0}", W = class {
    constructor(e) { I(this, e), this.ionNavWillLoad = y(this, "ionNavWillLoad", 7), this.ionNavWillChange = y(this, "ionNavWillChange", 3), this.ionNavDidChange = y(this, "ionNavDidChange", 3), this.transInstr = [], this.gestureOrAnimationInProgress = !1, this.useRouter = !1, this.isTransitioning = !1, this.destroyed = !1, this.views = [], this.didLoad = !1, this.animated = !0; }
    swipeGestureChanged() { this.gesture && this.gesture.enable(this.swipeGesture === !0); }
    rootChanged() { this.root !== void 0 && this.didLoad !== !1 && (this.useRouter || this.root !== void 0 && this.setRoot(this.root, this.rootParams)); }
    componentWillLoad() { if (this.useRouter = document.querySelector("ion-router") !== null && this.el.closest("[no-router]") === null, this.swipeGesture === void 0) {
        let e = T(this);
        this.swipeGesture = b.getBoolean("swipeBackEnabled", e === "ios");
    } this.ionNavWillLoad.emit(); }
    componentDidLoad() { return f(this, null, function* () { this.didLoad = !0, this.rootChanged(), this.gesture = (yield import("@nf-internal/swipe-back-DQ1q5MgD-Y5ZQNMV3")).createSwipeBackGesture(this.el, this.canStart.bind(this), this.onStart.bind(this), this.onMove.bind(this), this.onEnd.bind(this)), this.swipeGestureChanged(); }); }
    connectedCallback() { this.destroyed = !1; }
    disconnectedCallback() { for (let e of this.views)
        m(e.element, p), e._destroy(); this.gesture && (this.gesture.destroy(), this.gesture = void 0), this.transInstr.length = 0, this.views.length = 0, this.destroyed = !0; }
    push(e, t, s, n) { return this.insert(-1, e, t, s, n); }
    insert(e, t, s, n, i) { return this.insertPages(e, [{ component: t, componentProps: s }], n, i); }
    insertPages(e, t, s, n) { return this.queueTrns({ insertStart: e, insertViews: t, opts: s }, n); }
    pop(e, t) { return this.removeIndex(-1, 1, e, t); }
    popTo(e, t, s) { let n = { removeStart: -1, removeCount: -1, opts: t }; return typeof e == "object" && e.component ? (n.removeView = e, n.removeStart = 1) : typeof e == "number" && (n.removeStart = e + 1), this.queueTrns(n, s); }
    popToRoot(e, t) { return this.removeIndex(1, -1, e, t); }
    removeIndex(e, t = 1, s, n) { return this.queueTrns({ removeStart: e, removeCount: t, opts: s }, n); }
    setRoot(e, t, s, n) { return this.setPages([{ component: e, componentProps: t }], s, n); }
    setPages(e, t, s) { return t ?? (t = {}), t.animated !== !0 && (t.animated = !1), this.queueTrns({ insertStart: 0, insertViews: e, removeStart: 0, removeCount: -1, opts: t }, s); }
    setRouteId(e, t, s, n) { let i = this.getActiveSync(); if (q(i, e, t))
        return Promise.resolve({ changed: !1, element: i.element }); let r, o = new Promise(u => r = u), a, l = { updateURL: !1, viewIsReady: u => { let c, w = new Promise(d => c = d); return r({ changed: !0, element: u, markVisible: () => f(this, null, function* () { c(), yield a; }) }), w; } }; if (s === "root")
        a = this.setRoot(e, t, l);
    else {
        let u = this.views.find(c => q(c, e, t));
        u ? a = this.popTo(u, Object.assign(Object.assign({}, l), { direction: "back", animationBuilder: n })) : s === "forward" ? a = this.push(e, t, Object.assign(Object.assign({}, l), { animationBuilder: n })) : s === "back" && (a = this.setRoot(e, t, Object.assign(Object.assign({}, l), { direction: "back", animated: !0, animationBuilder: n })));
    } return o; }
    getRouteId() { return f(this, null, function* () { let e = this.getActiveSync(); if (e)
        return { id: e.element.tagName, params: e.params, element: e.element }; }); }
    getActive() { return f(this, null, function* () { return this.getActiveSync(); }); }
    getByIndex(e) { return f(this, null, function* () { return this.views[e]; }); }
    canGoBack(e) { return f(this, null, function* () { return this.canGoBackSync(e); }); }
    getPrevious(e) { return f(this, null, function* () { return this.getPreviousSync(e); }); }
    getLength() { return f(this, null, function* () { return Promise.resolve(this.views.length); }); }
    getActiveSync() { return this.views[this.views.length - 1]; }
    canGoBackSync(e = this.getActiveSync()) { return !!(e && this.getPreviousSync(e)); }
    getPreviousSync(e = this.getActiveSync()) { if (!e)
        return; let t = this.views, s = t.indexOf(e); return s > 0 ? t[s - 1] : void 0; }
    queueTrns(e, t) { return f(this, null, function* () { var s, n; if (this.isTransitioning && (!((s = e.opts) === null || s === void 0) && s.skipIfBusy))
        return !1; let i = new Promise((r, o) => { e.resolve = r, e.reject = o; }); if (e.done = t, e.opts && e.opts.updateURL !== !1 && this.useRouter) {
        let r = document.querySelector("ion-router");
        if (r) {
            let o = yield r.canTransition();
            if (o === !1)
                return !1;
            if (typeof o == "string")
                return r.push(o, e.opts.direction || "back"), !1;
        }
    } return ((n = e.insertViews) === null || n === void 0 ? void 0 : n.length) === 0 && (e.insertViews = void 0), this.transInstr.push(e), this.nextTrns(), i; }); }
    success(e, t) { if (this.destroyed) {
        this.fireError("nav controller was destroyed", t);
        return;
    } if (t.done && t.done(e.hasCompleted, e.requiresTransition, e.enteringView, e.leavingView, e.direction), t.resolve(e.hasCompleted), t.opts.updateURL !== !1 && this.useRouter) {
        let s = document.querySelector("ion-router");
        if (s) {
            let n = e.direction === "back" ? "back" : "forward";
            s.navChanged(n);
        }
    } }
    failed(e, t) { if (this.destroyed) {
        this.fireError("nav controller was destroyed", t);
        return;
    } this.transInstr.length = 0, this.fireError(e, t); }
    fireError(e, t) { t.done && t.done(!1, !1, e), t.reject && !this.destroyed ? t.reject(e) : t.resolve(!1); }
    nextTrns() { if (this.isTransitioning)
        return !1; let e = this.transInstr.shift(); return e ? (this.runTransition(e), !0) : !1; }
    runTransition(e) { return f(this, null, function* () { try {
        this.ionNavWillChange.emit(), this.isTransitioning = !0, this.prepareTI(e);
        let t = this.getActiveSync(), s = this.getEnteringView(e, t);
        if (!t && !s)
            throw new Error("no views in the stack to be removed");
        s && s.state === G && (yield s.init(this.el)), this.postViewInit(s, t, e);
        let n = (e.enteringRequiresTransition || e.leavingRequiresTransition) && s !== t;
        n && e.opts && t && (e.opts.direction === "back" && (e.opts.animationBuilder = e.opts.animationBuilder || s?.animationBuilder), t.animationBuilder = e.opts.animationBuilder);
        let i;
        n ? i = yield this.transition(s, t, e) : i = { hasCompleted: !0, requiresTransition: !1 }, this.success(i, e), this.ionNavDidChange.emit();
    }
    catch (t) {
        this.failed(t, e);
    } this.isTransitioning = !1, this.nextTrns(); }); }
    prepareTI(e) { var t, s, n; let i = this.views.length; if ((t = e.opts) !== null && t !== void 0 || (e.opts = {}), (s = (n = e.opts).delegate) !== null && s !== void 0 || (n.delegate = this.delegate), e.removeView !== void 0) {
        h(e.removeStart !== void 0, "removeView needs removeStart"), h(e.removeCount !== void 0, "removeView needs removeCount");
        let a = this.views.indexOf(e.removeView);
        if (a < 0)
            throw new Error("removeView was not found");
        e.removeStart += a;
    } e.removeStart !== void 0 && (e.removeStart < 0 && (e.removeStart = i - 1), e.removeCount < 0 && (e.removeCount = i - e.removeStart), e.leavingRequiresTransition = e.removeCount > 0 && e.removeStart + e.removeCount === i), e.insertViews && ((e.insertStart < 0 || e.insertStart > i) && (e.insertStart = i), e.enteringRequiresTransition = e.insertStart === i); let r = e.insertViews; if (!r)
        return; h(r.length > 0, "length can not be zero"); let o = j(r); if (o.length === 0)
        throw new Error("invalid views to insert"); for (let a of o) {
        a.delegate = e.opts.delegate;
        let l = a.nav;
        if (l && l !== this)
            throw new Error("inserted view was already inserted");
        if (a.state === S)
            throw new Error("inserted view was already destroyed");
    } e.insertViews = o; }
    getEnteringView(e, t) { let s = e.insertViews; if (s !== void 0)
        return s[s.length - 1]; let n = e.removeStart; if (n !== void 0) {
        let i = this.views, r = n + e.removeCount;
        for (let o = i.length - 1; o >= 0; o--) {
            let a = i[o];
            if ((o < n || o >= r) && a !== t)
                return a;
        }
    } }
    postViewInit(e, t, s) { var n, i, r; h(t || e, "Both leavingView and enteringView are null"), h(s.resolve, "resolve must be valid"), h(s.reject, "reject must be valid"); let o = s.opts, { insertViews: a, removeStart: l, removeCount: u } = s, c; if (l !== void 0 && u !== void 0) {
        h(l >= 0, "removeStart can not be negative"), h(u >= 0, "removeCount can not be negative"), c = [];
        for (let d = l; d < l + u; d++) {
            let v = this.views[d];
            v !== void 0 && v !== e && v !== t && c.push(v);
        }
        (n = o.direction) !== null && n !== void 0 || (o.direction = "back");
    } let w = this.views.length + ((i = a?.length) !== null && i !== void 0 ? i : 0) - (u ?? 0); if (h(w >= 0, "final balance can not be negative"), w === 0)
        throw R("[ion-nav] - You can't remove all the pages in the navigation stack. nav.pop() is probably called too many times.", this, this.el), new Error("navigation stack needs at least one root page"); if (a) {
        let d = s.insertStart;
        for (let v of a)
            this.insertViewAt(v, d), d++;
        s.enteringRequiresTransition && ((r = o.direction) !== null && r !== void 0 || (o.direction = "forward"));
    } if (c && c.length > 0) {
        for (let d of c)
            m(d.element, B), m(d.element, L), m(d.element, p);
        for (let d of c)
            this.destroyView(d);
    } }
    transition(e, t, s) { return f(this, null, function* () { let n = s.opts, i = n.progressAnimation ? c => { c !== void 0 && !this.gestureOrAnimationInProgress ? (this.gestureOrAnimationInProgress = !0, c.onFinish(() => { this.gestureOrAnimationInProgress = !1; }, { oneTimeCallback: !0 }), c.progressEnd(0, 0, 0)) : this.sbAni = c; } : void 0, r = T(this), o = e.element, a = t && t.element, l = Object.assign(Object.assign({ mode: r, showGoBack: this.canGoBackSync(e), baseEl: this.el, progressCallback: i, animated: this.animated && b.getBoolean("animated", !0), enteringEl: o, leavingEl: a }, n), { animationBuilder: n.animationBuilder || this.animation || b.get("navAnimation") }), { hasCompleted: u } = yield P(l); return this.transitionFinish(u, e, t, n); }); }
    transitionFinish(e, t, s, n) { let i = e ? t : s; return i && this.unmountInactiveViews(i), { hasCompleted: e, requiresTransition: !0, enteringView: t, leavingView: s, direction: n.direction }; }
    insertViewAt(e, t) { let s = this.views, n = s.indexOf(e); n > -1 ? (h(e.nav === this, "view is not part of the nav"), s.splice(n, 1), s.splice(t, 0, e)) : (h(!e.nav, "nav is used"), e.nav = this, s.splice(t, 0, e)); }
    removeView(e) { h(e.state === N || e.state === S, "view state should be loaded or destroyed"); let t = this.views, s = t.indexOf(e); h(s > -1, "view must be part of the stack"), s >= 0 && t.splice(s, 1); }
    destroyView(e) { e._destroy(), this.removeView(e); }
    unmountInactiveViews(e) { if (this.destroyed)
        return; let t = this.views, s = t.indexOf(e); for (let n = t.length - 1; n >= 0; n--) {
        let i = t[n], r = i.element;
        r && (n > s ? (m(r, p), this.destroyView(i)) : n < s && _(r, !0));
    } }
    canStart() { return !this.gestureOrAnimationInProgress && !!this.swipeGesture && !this.isTransitioning && this.transInstr.length === 0 && this.canGoBackSync(); }
    onStart() { this.gestureOrAnimationInProgress = !0, this.pop({ direction: "back", progressAnimation: !0 }); }
    onMove(e) { this.sbAni && this.sbAni.progressStep(e); }
    onEnd(e, t, s) { if (this.sbAni) {
        this.sbAni.onFinish(() => { this.gestureOrAnimationInProgress = !1; }, { oneTimeCallback: !0 });
        let n = e ? -.001 : .001;
        e ? n += E([0, 0], [.32, .72], [0, 1], [1, 1], t)[0] : (this.sbAni.easing("cubic-bezier(1, 0, 0.68, 0.28)"), n += E([0, 0], [1, 0], [.68, .28], [1, 1], t)[0]), this.sbAni.progressEnd(e ? 1 : 0, n, s);
    }
    else
        this.gestureOrAnimationInProgress = !1; }
    render() { return k("slot", { key: "a549286b51b1bb23c9ef51f71148452228d0ab14" }); }
    get el() { return C(this); }
    static get watchers() { return { swipeGesture: [{ swipeGestureChanged: 0 }], root: [{ rootChanged: 0 }] }; }
};
W.style = D();
var F = (e, t, s, n, i) => { let r = e.closest("ion-nav"); if (r) {
    if (t === "forward") {
        if (s !== void 0)
            return r.push(s, n, { skipIfBusy: !0, animationBuilder: i });
    }
    else if (t === "root") {
        if (s !== void 0)
            return r.setRoot(s, n, { skipIfBusy: !0, animationBuilder: i });
    }
    else if (t === "back")
        return r.pop({ skipIfBusy: !0, animationBuilder: i });
} return Promise.resolve(!1); }, J = class {
    constructor(e) { I(this, e), this.routerDirection = "forward", this.onClick = () => F(this.el, this.routerDirection, this.component, this.componentProps, this.routerAnimation); }
    render() { return k(O, { key: "d4d80feb51c0d92b0bedf6952c892f9df3002046", onClick: this.onClick }); }
    get el() { return C(this); }
};
export { W as ion_nav, J as ion_nav_link };
/*! Bundled license information:

@ionic/core/dist/esm/ion-nav_2.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
