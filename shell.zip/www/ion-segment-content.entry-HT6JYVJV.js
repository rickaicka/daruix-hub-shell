import { i as s, m as e, n as t } from "@nf-internal/chunk-DPCBKAOC";
import "@nf-internal/chunk-C4FLJMU7";
var o = () => ":host{scroll-snap-align:center;scroll-snap-stop:always;-ms-flex-negative:0;flex-shrink:0;width:100%;min-height:1px;overflow-y:scroll;scrollbar-width:none;-ms-overflow-style:none;}:host::-webkit-scrollbar{display:none}", r = class {
    constructor(n) { s(this, n); }
    render() { return e(t, { key: "665f41a854621f898eaf7ba9a49e77cc9326501e" }, e("slot", { key: "635aa57fbf6167dcd36fe8dc5dfc1c313637ac04" })); }
};
r.style = o();
export { r as ion_segment_content };
/*! Bundled license information:

@ionic/core/dist/esm/ion-segment-content.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
