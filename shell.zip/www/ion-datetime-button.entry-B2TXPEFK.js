import { F as g, M as p, e as P, l as I } from "@nf-internal/chunk-BKBA3YWO";
import { b as D } from "@nf-internal/chunk-JIWXQZSC";
import { c as C } from "@nf-internal/chunk-DBOLI3CQ";
import { b as E, f } from "@nf-internal/chunk-NTOTMM2V";
import { f as b, i as O, m as d, n as B, q as A } from "@nf-internal/chunk-DPCBKAOC";
import { h as m } from "@nf-internal/chunk-C4FLJMU7";
var j = () => ":host{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center}:host button{border-radius:8px;-webkit-margin-start:2px;margin-inline-start:2px;-webkit-margin-end:2px;margin-inline-end:2px;margin-top:0px;margin-bottom:0px;position:relative;-webkit-transition:150ms color ease-in-out;transition:150ms color ease-in-out;border:none;background:var(--ion-color-step-300, var(--ion-background-color-step-300, #edeef0));color:var(--ion-text-color, #000);font-family:inherit;font-size:1rem;cursor:pointer;overflow:hidden;-webkit-appearance:none;-moz-appearance:none;appearance:none}:host(.time-active) #time-button,:host(.date-active) #date-button{color:var(--ion-color-base)}:host(.datetime-button-disabled){pointer-events:none}:host(.datetime-button-disabled) button{opacity:0.4}:host button{-webkit-padding-start:13px;padding-inline-start:13px;-webkit-padding-end:13px;padding-inline-end:13px;padding-top:7px;padding-bottom:7px}:host button.ion-activated{color:var(--ion-color-step-600, var(--ion-text-color-step-400, #666666))}", V = () => ":host{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center}:host button{border-radius:8px;-webkit-margin-start:2px;margin-inline-start:2px;-webkit-margin-end:2px;margin-inline-end:2px;margin-top:0px;margin-bottom:0px;position:relative;-webkit-transition:150ms color ease-in-out;transition:150ms color ease-in-out;border:none;background:var(--ion-color-step-300, var(--ion-background-color-step-300, #edeef0));color:var(--ion-text-color, #000);font-family:inherit;font-size:1rem;cursor:pointer;overflow:hidden;-webkit-appearance:none;-moz-appearance:none;appearance:none}:host(.time-active) #time-button,:host(.date-active) #date-button{color:var(--ion-color-base)}:host(.datetime-button-disabled){pointer-events:none}:host(.datetime-button-disabled) button{opacity:0.4}:host button{-webkit-padding-start:12px;padding-inline-start:12px;-webkit-padding-end:12px;padding-inline-end:12px;padding-top:6px;padding-bottom:6px}", F = class {
    constructor(s) { O(this, s), this.datetimeEl = null, this.overlayEl = null, this.datetimePresentation = "date-time", this.datetimeActive = !1, this.color = "primary", this.disabled = !1, this.getParsedDateValues = e => e == null ? [] : Array.isArray(e) ? e : [e], this.setDateTimeText = () => m(this, null, function* () { var e, i, n, t, o; let { datetimeEl: l, datetimePresentation: h } = this; if (!l)
        return; let { value: _, locale: r, formatOptions: a, hourCycle: $, preferWheel: z, multiple: L, titleSelectedDatesFormatter: x } = l, u = this.getParsedDateValues(_), v = u.length > 0 ? I(u) : [yield l.getDefaultPart()]; if (!v)
        return; let c = v[0], y = P(r, $); switch (this.dateText = this.timeText = void 0, h) {
        case "date-time":
        case "time-date":
            let k = p(r, c, (e = a?.date) !== null && e !== void 0 ? e : { month: "short", day: "numeric", year: "numeric" }), w = g(r, c, y, a?.time);
            z ? this.dateText = `${k} ${w}` : (this.dateText = k, this.timeText = w);
            break;
        case "date":
            if (L && u.length !== 1) {
                let T = `${u.length} days`;
                if (x !== void 0)
                    try {
                        T = x(u);
                    }
                    catch (N) {
                        b("[ion-datetime-button] - Exception in provided `titleSelectedDatesFormatter`:", N);
                    }
                this.dateText = T;
            }
            else
                this.dateText = p(r, c, (i = a?.date) !== null && i !== void 0 ? i : { month: "short", day: "numeric", year: "numeric" });
            break;
        case "time":
            this.timeText = g(r, c, y, a?.time);
            break;
        case "month-year":
            this.dateText = p(r, c, (n = a?.date) !== null && n !== void 0 ? n : { month: "long", year: "numeric" });
            break;
        case "month":
            this.dateText = p(r, c, (t = a?.time) !== null && t !== void 0 ? t : { month: "long" });
            break;
        case "year":
            this.dateText = p(r, c, (o = a?.time) !== null && o !== void 0 ? o : { year: "numeric" });
            break;
    } }), this.waitForDatetimeChanges = () => m(this, null, function* () { let { datetimeEl: e } = this; return e ? new Promise(i => { f(e, "ionRender", i, { once: !0 }); }) : Promise.resolve(); }), this.handleDateClick = e => m(this, null, function* () { let { datetimeEl: i, datetimePresentation: n } = this; if (!i)
        return; let t = !1; switch (n) {
        case "date-time":
        case "time-date":
            let o = i.presentation !== "date";
            !i.preferWheel && o && (i.presentation = "date", t = !0);
            break;
    } this.selectedButton = "date", this.presentOverlay(e, t, this.dateTargetEl); }), this.handleTimeClick = e => { let { datetimeEl: i, datetimePresentation: n } = this; if (!i)
        return; let t = !1; switch (n) {
        case "date-time":
        case "time-date":
            i.presentation !== "time" && (i.presentation = "time", t = !0);
            break;
    } this.selectedButton = "time", this.presentOverlay(e, t, this.timeTargetEl); }, this.presentOverlay = (e, i, n) => m(this, null, function* () { let { overlayEl: t } = this; t && (t.tagName === "ION-POPOVER" ? (i && (yield this.waitForDatetimeChanges()), t.present(Object.assign(Object.assign({}, e), { detail: { ionShadowTarget: n } }))) : t.present()); }); }
    componentWillLoad() { return m(this, null, function* () { let { datetime: s } = this; if (!s) {
        b("[ion-datetime-button] - An ID associated with an ion-datetime instance is required to function properly.", this.el);
        return;
    } let e = this.datetimeEl = document.getElementById(s); if (!e) {
        b(`[ion-datetime-button] - No ion-datetime instance found for ID '${s}'.`, this.el);
        return;
    } if (e.tagName !== "ION-DATETIME") {
        b(`[ion-datetime-button] - Expected an ion-datetime instance for ID '${s}' but received '${e.tagName.toLowerCase()}' instead.`, e);
        return;
    } new IntersectionObserver(t => { let o = t[0]; this.datetimeActive = o.isIntersecting; }, { threshold: .01 }).observe(e); let n = this.overlayEl = e.closest("ion-modal, ion-popover"); n && n.classList.add("ion-datetime-button-overlay"), E(e, () => { let t = this.datetimePresentation = e.presentation || "date-time"; switch (this.setDateTimeText(), f(e, "ionValueChange", this.setDateTimeText), t) {
        case "date-time":
        case "date":
        case "month-year":
        case "month":
        case "year":
            this.selectedButton = "date";
            break;
        case "time-date":
        case "time":
            this.selectedButton = "time";
            break;
    } }); }); }
    render() { let { color: s, dateText: e, timeText: i, selectedButton: n, datetimeActive: t, disabled: o } = this, l = C(this); return d(B, { key: "c28e5e428111f18eaceb030dca8aba5579867eaa", class: D(s, { [l]: !0, [`${n}-active`]: t, "datetime-button-disabled": o }) }, e && d("button", { key: "a08f41b3150ef7171d0f1d9b3d69b51be67b7b84", class: "ion-activatable", id: "date-button", "aria-expanded": t ? "true" : "false", onClick: this.handleDateClick, disabled: o, part: "native", ref: h => this.dateTargetEl = h }, d("slot", { key: "35ee68ca1cea59f03e1b59b72606e618141c8e1f", name: "date-target" }, e), l === "md" && d("ion-ripple-effect", { key: "4be53227aaf0acd20e8ebbff9f645140e8a96f33" })), i && d("button", { key: "ab500f9b78f8c194180073eaf7325041adbd02f7", class: "ion-activatable", id: "time-button", "aria-expanded": t ? "true" : "false", onClick: this.handleTimeClick, disabled: o, part: "native", ref: h => this.timeTargetEl = h }, d("slot", { key: "5822486dfdedba6c071a0f5233cc06f8321a1f5d", name: "time-target" }, i), l === "md" && d("ion-ripple-effect", { key: "054a4acb811a98cc6d9bb6a3cf51232a1f09b0ea" }))); }
    get el() { return A(this); }
};
F.style = { ios: j(), md: V() };
export { F as ion_datetime_button };
/*! Bundled license information:

@ionic/core/dist/esm/ion-datetime-button.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
