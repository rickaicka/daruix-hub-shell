import { a as u } from "@nf-internal/chunk-56RDUDAP";
import "@nf-internal/chunk-NTOTMM2V";
import { f as r, i as c, m as s, n as l, q as d, r as n } from "@nf-internal/chunk-DPCBKAOC";
import { h as a } from "@nf-internal/chunk-C4FLJMU7";
var f = () => ":host(.tab-hidden){display:none !important}", p = class {
    constructor(e) { c(this, e), this.loaded = !1, this.active = !1; }
    componentWillLoad() { return a(this, null, function* () { this.active && (yield this.setActive()); }); }
    setActive() { return a(this, null, function* () { yield this.prepareLazyLoaded(), this.active = !0; }); }
    changeActive(e) { e && this.prepareLazyLoaded(); }
    prepareLazyLoaded() { if (!this.loaded && this.component != null) {
        this.loaded = !0;
        try {
            return u(this.delegate, this.el, this.component, ["ion-page"]);
        }
        catch (e) {
            r("[ion-tab] - Exception in prepareLazyLoaded:", e);
        }
    } return Promise.resolve(void 0); }
    render() { let { tab: e, active: t, component: i } = this; return s(l, { key: "fbd837bad7a0632336d46a597ace23673b153e48", role: "tabpanel", "aria-hidden": t ? null : "true", "aria-labelledby": `tab-button-${e}`, class: { "ion-page": i === void 0, "tab-hidden": !t } }, s("slot", { key: "35c218169fda826c9c1337558e0278d0c7f5f26a" })); }
    get el() { return d(this); }
    static get watchers() { return { active: [{ changeActive: 0 }] }; }
};
p.style = f();
var g = () => ":host{left:0;right:0;top:0;bottom:0;display:-ms-flexbox;display:flex;position:absolute;-ms-flex-direction:column;flex-direction:column;width:100%;height:100%;contain:layout size style;z-index:0}.tabs-inner{position:relative;-ms-flex:1;flex:1;contain:layout size style}", m = class {
    constructor(e) { c(this, e), this.ionNavWillLoad = n(this, "ionNavWillLoad", 7), this.ionTabsWillChange = n(this, "ionTabsWillChange", 3), this.ionTabsDidChange = n(this, "ionTabsDidChange", 3), this.transitioning = !1, this.useRouter = !1, this.onTabClicked = t => { let { href: i, tab: o } = t.detail; if (this.useRouter && i !== void 0) {
        let b = document.querySelector("ion-router");
        b && b.push(i);
    }
    else
        this.select(o); }; }
    componentWillLoad() { return a(this, null, function* () { if (this.useRouter || (this.useRouter = (!!this.el.querySelector("ion-router-outlet") || !!document.querySelector("ion-router")) && !this.el.closest("[no-router]")), !this.useRouter) {
        let e = this.tabs;
        e.length > 0 && (yield this.select(e[0]));
    } this.ionNavWillLoad.emit(); }); }
    componentDidLoad() { this.updateTabBar(); }
    componentDidUpdate() { this.updateTabBar(); }
    updateTabBar() { let e = this.el.querySelector("ion-tab-bar"); if (!e)
        return; let t = this.selectedTab ? this.selectedTab.tab : void 0; t !== void 0 && e.selectedTab !== t && (e.selectedTab = t); }
    select(e) { return a(this, null, function* () { let t = h(this.tabs, e); return this.shouldSwitch(t) ? (yield this.setActive(t), yield this.notifyRouter(), this.tabSwitch(), !0) : !1; }); }
    getTab(e) { return a(this, null, function* () { return h(this.tabs, e); }); }
    getSelected() { return Promise.resolve(this.selectedTab ? this.selectedTab.tab : void 0); }
    setRouteId(e) { return a(this, null, function* () { let t = h(this.tabs, e); return this.shouldSwitch(t) ? (yield this.setActive(t), { changed: !0, element: this.selectedTab, markVisible: () => this.tabSwitch() }) : { changed: !1, element: this.selectedTab }; }); }
    getRouteId() { return a(this, null, function* () { var e; let t = (e = this.selectedTab) === null || e === void 0 ? void 0 : e.tab; return t !== void 0 ? { id: t, element: this.selectedTab } : void 0; }); }
    setActive(e) { return this.transitioning ? Promise.reject("transitioning already happening") : (this.transitioning = !0, this.leavingTab = this.selectedTab, this.selectedTab = e, this.ionTabsWillChange.emit({ tab: e.tab }), e.active = !0, this.updateTabBar(), Promise.resolve()); }
    tabSwitch() { let e = this.selectedTab, t = this.leavingTab; this.leavingTab = void 0, this.transitioning = !1, e && t !== e && (t && (t.active = !1), this.ionTabsDidChange.emit({ tab: e.tab })); }
    notifyRouter() { if (this.useRouter) {
        let e = document.querySelector("ion-router");
        if (e)
            return e.navChanged("forward");
    } return Promise.resolve(!1); }
    shouldSwitch(e) { let t = this.selectedTab; return e !== void 0 && e !== t && !this.transitioning; }
    get tabs() { return Array.from(this.el.querySelectorAll("ion-tab")); }
    render() { return s(l, { key: "c7131135b31aa312dc0207602561e1c0f4ac3e53", onIonTabButtonClick: this.onTabClicked }, s("slot", { key: "6c46e91c0389bbcea1f15f35cf3ea513a74ac545", name: "top" }), s("div", { key: "4f1b649d8bb60b61402b97359de204979c5eda52", class: "tabs-inner" }, s("slot", { key: "8d1ef4952be4fb33567376e1083ea4da697fcae0" })), s("slot", { key: "260b8da8031494e9cb4635b3d22c49a433042db1", name: "bottom" })); }
    get el() { return d(this); }
}, h = (e, t) => { let i = typeof t == "string" ? e.find(o => o.tab === t) : t; return i || r(`[ion-tabs] - Tab with id: "${i}" does not exist`), i; };
m.style = g();
export { p as ion_tab, m as ion_tabs };
/*! Bundled license information:

@ionic/core/dist/esm/ion-tab_2.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
