import { h as r } from "@nf-internal/chunk-C4FLJMU7";
var s = () => { let e; return { lock: () => r(null, null, function* () { let o = e, t; return e = new Promise(n => t = n), o !== void 0 && (yield o), t; }) }; };
export { s as a };
/*! Bundled license information:

@ionic/core/dist/esm/lock-controller-B-hirT0v.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
