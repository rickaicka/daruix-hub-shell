import { e as T } from "@nf-internal/chunk-V3JGNOV4";
var y = (e, n) => e.month === n.month && e.day === n.day && e.year === n.year, p = (e, n) => e.year < n.year || e.year === n.year && e.month < n.month || e.year === n.year && e.month === n.month && e.day !== null && e.day < n.day, v = (e, n) => e.year > n.year || e.year === n.year && e.month > n.month || e.year === n.year && e.month === n.month && e.day !== null && e.day > n.day, B = (e, n, t) => {
    let o = Array.isArray(e) ? e : [e];
    for (let u of o)
        if (n !== void 0 && p(u, n) || t !== void 0 && v(u, t)) {
            T(`[ion-datetime] - The value provided to ion-datetime is out of bounds.

Min: ${JSON.stringify(n)}
Max: ${JSON.stringify(t)}
Value: ${JSON.stringify(e)}`);
            break;
        }
}, S = e => e % 4 === 0 && e % 100 !== 0 || e % 400 === 0, X = (e, n) => { if (n !== void 0)
    return n; let t = new Intl.DateTimeFormat(e, { hour: "numeric" }), o = t.resolvedOptions(); if (o.hourCycle !== void 0)
    return o.hourCycle; let u = new Date("5/18/2021 00:00"), r = t.formatToParts(u).find(d => d.type === "hour"); if (!r)
    throw new Error("Hour value not found from DateTimeFormat"); switch (r.value) {
    case "0": return "h11";
    case "12": return "h12";
    case "00": return "h23";
    case "24": return "h24";
    default: throw new Error(`Invalid hour cycle "${n}"`);
} }, H = e => e === "h23" || e === "h24", c = (e, n) => e === 4 || e === 6 || e === 9 || e === 11 ? 30 : e === 2 ? S(n) ? 29 : 28 : 31, q = (e, n = { month: "numeric", year: "numeric" }) => new Intl.DateTimeFormat(e, n).formatToParts(new Date)[0].type === "month", K = e => new Intl.DateTimeFormat(e, { hour: "numeric" }).formatToParts(new Date)[0].type === "dayPeriod", L = /^(\d{4}|[+\-]\d{6})(?:-(\d{2})(?:-(\d{2}))?)?(?:T(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{3}))?)?(?:(Z)|([+\-])(\d{2})(?::(\d{2}))?)?)?$/, z = /^((\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{3}))?)?(?:(Z)|([+\-])(\d{2})(?::(\d{2}))?)?)?$/, Q = e => { if (e === void 0)
    return; let n = e; typeof e == "string" && (n = e.replace(/\[|\]|\s/g, "").split(",")); let t; return Array.isArray(n) ? t = n.map(o => parseInt(o, 10)).filter(isFinite) : t = [n], t; }, x = e => ({ month: parseInt(e.getAttribute("data-month"), 10), day: parseInt(e.getAttribute("data-day"), 10), year: parseInt(e.getAttribute("data-year"), 10), dayOfWeek: parseInt(e.getAttribute("data-day-of-week"), 10) });
function w(e) { if (Array.isArray(e)) {
    let t = [];
    for (let o of e) {
        let u = w(o);
        if (!u)
            return;
        t.push(u);
    }
    return t;
} let n = null; if (e != null && e !== "" && (n = z.exec(e), n ? (n.unshift(void 0, void 0), n[2] = n[3] = void 0) : n = L.exec(e)), n === null) {
    T(`[ion-datetime] - Unable to parse date string: ${e}. Please provide a valid ISO 8601 datetime string.`);
    return;
} for (let t = 1; t < 8; t++)
    n[t] = n[t] !== void 0 ? parseInt(n[t], 10) : void 0; return { year: n[1], month: n[2], day: n[3], hour: n[4], minute: n[5], ampm: n[4] < 12 ? "am" : "pm" }; }
var C = (e, n, t) => n && p(e, n) ? n : t && v(e, t) ? t : e, Z = e => e >= 12 ? "pm" : "am", P = (e, n) => { let t = w(e); if (t === void 0)
    return; let { month: o, day: u, year: i, hour: r, minute: d } = t, h = i ?? n.year, m = o ?? 12; return { month: m, day: u ?? c(m, h), year: h, hour: r ?? 23, minute: d ?? 59 }; }, ee = (e, n) => { let t = w(e); if (t === void 0)
    return; let { month: o, day: u, year: i, hour: r, minute: d } = t; return { month: o ?? 1, day: u ?? 1, year: i ?? n.year, hour: r ?? 0, minute: d ?? 0 }; }, l = e => ("0" + (e !== void 0 ? Math.abs(e) : "0")).slice(-2), W = e => ("000" + (e !== void 0 ? Math.abs(e) : "0")).slice(-4);
function A(e) { if (Array.isArray(e))
    return e.map(t => A(t)); let n = ""; return e.year !== void 0 ? (n = W(e.year), e.month !== void 0 && (n += "-" + l(e.month), e.day !== void 0 && (n += "-" + l(e.day), e.hour !== void 0 && (n += `T${l(e.hour)}:${l(e.minute)}:00`)))) : e.hour !== void 0 && (n = l(e.hour) + ":" + l(e.minute)), n; }
var b = (e, n) => n === void 0 ? e : n === "am" ? e === 12 ? 0 : e : e === 12 ? 12 : e + 12, ne = e => { let { dayOfWeek: n } = e; if (n == null)
    throw new Error("No day of week provided"); return I(e, n); }, te = e => { let { dayOfWeek: n } = e; if (n == null)
    throw new Error("No day of week provided"); return O(e, 6 - n); }, oe = e => O(e, 1), re = e => I(e, 1), ue = e => I(e, 7), ie = e => O(e, 7), I = (e, n) => { let { month: t, day: o, year: u } = e; if (o === null)
    throw new Error("No day provided"); let i = { month: t, day: o, year: u }; if (i.day = o - n, i.day < 1 && (i.month -= 1), i.month < 1 && (i.month = 12, i.year -= 1), i.day < 1) {
    let r = c(i.month, i.year);
    i.day = r + i.day;
} return i; }, O = (e, n) => { let { month: t, day: o, year: u } = e; if (o === null)
    throw new Error("No day provided"); let i = { month: t, day: o, year: u }, r = c(t, u); return i.day = o + n, i.day > r && (i.day -= r, i.month += 1), i.month > 12 && (i.month = 1, i.year += 1), i; }, de = e => { let n = e.month === 1 ? 12 : e.month - 1, t = e.month === 1 ? e.year - 1 : e.year, o = c(n, t), u = o < e.day ? o : e.day; return { month: n, year: t, day: u }; }, ae = e => { let n = e.month === 12 ? 1 : e.month + 1, t = e.month === 12 ? e.year + 1 : e.year, o = c(n, t), u = o < e.day ? o : e.day; return { month: n, year: t, day: u }; }, F = (e, n) => { let t = e.month, o = e.year + n, u = c(t, o), i = u < e.day ? u : e.day; return { month: t, year: o, day: i }; }, se = e => F(e, -1), fe = e => F(e, 1), ce = (e, n, t) => n ? e : b(e, t), le = (e, n) => { let { ampm: t, hour: o } = e, u = o; return t === "am" && n === "pm" ? u = b(u, "pm") : t === "pm" && n === "am" && (u = Math.abs(u - 12)), u; }, ye = (e, n, t) => { let { month: o, day: u, year: i } = e, r = C(Object.assign({}, e), n, t), d = c(o, i); return u !== null && d < u && (r.day = d), n !== void 0 && y(r, n) && r.hour !== void 0 && n.hour !== void 0 && (r.hour < n.hour ? (r.hour = n.hour, r.minute = n.minute) : r.hour === n.hour && r.minute !== void 0 && n.minute !== void 0 && r.minute < n.minute && (r.minute = n.minute)), t !== void 0 && y(e, t) && r.hour !== void 0 && t.hour !== void 0 && (r.hour > t.hour ? (r.hour = t.hour, r.minute = t.minute) : r.hour === t.hour && r.minute !== void 0 && t.minute !== void 0 && r.minute > t.minute && (r.minute = t.minute)), r; }, he = ({ refParts: e, monthValues: n, dayValues: t, yearValues: o, hourValues: u, minuteValues: i, minParts: r, maxParts: d }) => { let { hour: h, minute: m, day: M, month: E, year: N } = e, a = Object.assign(Object.assign({}, e), { dayOfWeek: void 0 }); if (o !== void 0) {
    let f = o.filter(s => !(r !== void 0 && s < r.year || d !== void 0 && s > d.year));
    a.year = g(N, f);
} if (n !== void 0) {
    let f = n.filter(s => !(r !== void 0 && a.year === r.year && s < r.month || d !== void 0 && a.year === d.year && s > d.month));
    a.month = g(E, f);
} if (M !== null && t !== void 0) {
    let f = t.filter(s => !(r !== void 0 && p(Object.assign(Object.assign({}, a), { day: s }), r) || d !== void 0 && v(Object.assign(Object.assign({}, a), { day: s }), d)));
    a.day = g(M, f);
} if (h !== void 0 && u !== void 0) {
    let f = u.filter(s => !(r?.hour !== void 0 && y(a, r) && s < r.hour || d?.hour !== void 0 && y(a, d) && s > d.hour));
    a.hour = g(h, f), a.ampm = Z(a.hour);
} if (m !== void 0 && i !== void 0) {
    let f = i.filter(s => !(r?.minute !== void 0 && y(a, r) && a.hour === r.hour && s < r.minute || d?.minute !== void 0 && y(a, d) && a.hour === d.hour && s > d.minute));
    a.minute = g(m, f);
} return a; }, g = (e, n) => { let t = n[0], o = Math.abs(t - e); for (let u = 1; u < n.length; u++) {
    let i = n[u], r = Math.abs(i - e);
    r < o && (t = i, o = r);
} return t; }, U = e => e === void 0 ? "" : e.toUpperCase(), k = e => Object.assign(Object.assign({}, e), { timeZone: "UTC", timeZoneName: void 0 }), me = (e, n, t, o = { hour: "numeric", minute: "numeric" }) => { let u = { hour: n.hour, minute: n.minute }; return u.hour === void 0 || u.minute === void 0 ? "Invalid Time" : new Intl.DateTimeFormat(e, Object.assign(Object.assign({}, k(o)), { hourCycle: t })).format(new Date(A(Object.assign({ year: 2023, day: 1, month: 1 }, u)) + "Z")); }, _ = e => { let n = e.toString(); return n.length > 1 ? n : `0${n}`; }, ge = (e, n) => { if (e === 0)
    switch (n) {
        case "h11": return "0";
        case "h12": return "12";
        case "h23": return "00";
        case "h24": return "24";
        default: throw new Error(`Invalid hour cycle "${n}"`);
    } return H(n) ? _(e) : e.toString(); }, De = (e, n, t) => { if (t.day === null)
    return null; let o = D(t), u = new Intl.DateTimeFormat(e, { weekday: "long", month: "long", day: "numeric", timeZone: "UTC" }).format(o); return n ? `Today, ${u}` : u; }, Te = (e, n) => { let t = D(n); return new Intl.DateTimeFormat(e, { month: "long", year: "numeric", timeZone: "UTC" }).format(t); }, pe = (e, n) => R(e, n, { day: "numeric" }).find(t => t.type === "day").value, ve = (e, n) => Y(e, n, { year: "numeric" }), D = e => { var n, t, o; let u = e.hour !== void 0 && e.minute !== void 0 ? ` ${e.hour}:${e.minute}` : ""; return new Date(`${(n = e.month) !== null && n !== void 0 ? n : 1}/${(t = e.day) !== null && t !== void 0 ? t : 1}/${(o = e.year) !== null && o !== void 0 ? o : 2023}${u} GMT+0000`); }, Y = (e, n, t) => { let o = D(n); return $(e, k(t)).format(o); }, R = (e, n, t) => { let o = D(n); return $(e, t).formatToParts(o); }, $ = (e, n) => new Intl.DateTimeFormat(e, Object.assign(Object.assign({}, n), { timeZone: "UTC" })), we = e => { if ("RelativeTimeFormat" in Intl) {
    let n = new Intl.RelativeTimeFormat(e, { numeric: "auto" }).format(0, "day");
    return n.charAt(0).toUpperCase() + n.slice(1);
}
else
    return "Today"; }, j = e => { let n = e.getTimezoneOffset(); return e.setMinutes(e.getMinutes() - n), e; }, V = j(new Date("2022T01:00")), G = j(new Date("2022T13:00")), Ie = (e, n) => { let t = n === "am" ? V : G, o = new Intl.DateTimeFormat(e, { hour: "numeric", timeZone: "UTC" }).formatToParts(t).find(u => u.type === "dayPeriod"); return o ? o.value : U(n); }, Oe = e => Array.isArray(e) ? e.join(",") : e;
export { y as a, p as b, v as c, B as d, X as e, H as f, c as g, q as h, K as i, Q as j, x as k, w as l, C as m, Z as n, P as o, ee as p, A as q, ne as r, te as s, oe as t, re as u, ue as v, ie as w, de as x, ae as y, se as z, fe as A, ce as B, le as C, ye as D, he as E, me as F, _ as G, ge as H, De as I, Te as J, pe as K, ve as L, Y as M, we as N, j as O, Ie as P, Oe as Q };
/*! Bundled license information:

@ionic/core/dist/esm/format-CAmvpAez.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
