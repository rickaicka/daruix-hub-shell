var k = class {
    constructor(t, s, a, n, i) { this.id = s, this.name = a, this.disableScroll = i, this.priority = 1e6 * n + s, this.ctrl = t; }
    canStart() { return !!this.ctrl && this.ctrl.canStart(this.name); }
    start() { return !!this.ctrl && this.ctrl.start(this.name, this.id, this.priority); }
    capture() { if (!this.ctrl)
        return !1; let t = this.ctrl.capture(this.name, this.id, this.priority); return t && this.disableScroll && this.ctrl.disableScroll(this.id), t; }
    release() { this.ctrl && (this.ctrl.release(this.id), this.disableScroll && this.ctrl.enableScroll(this.id)); }
    destroy() { this.release(), this.ctrl = void 0; }
}, C = class {
    constructor(t, s, a, n) { this.id = s, this.disable = a, this.disableScroll = n, this.ctrl = t; }
    block() { if (this.ctrl) {
        if (this.disable)
            for (let t of this.disable)
                this.ctrl.disableGesture(t, this.id);
        this.disableScroll && this.ctrl.disableScroll(this.id);
    } }
    unblock() { if (this.ctrl) {
        if (this.disable)
            for (let t of this.disable)
                this.ctrl.enableGesture(t, this.id);
        this.disableScroll && this.ctrl.enableScroll(this.id);
    } }
    destroy() { this.unblock(), this.ctrl = void 0; }
}, H = "backdrop-no-scroll", J = new class {
    constructor() { this.gestureId = 0, this.requestedStart = new Map, this.disabledGestures = new Map, this.disabledScroll = new Set; }
    createGesture(e) { var t; return new k(this, this.newID(), e.name, (t = e.priority) !== null && t !== void 0 ? t : 0, !!e.disableScroll); }
    createBlocker(e = {}) { return new C(this, this.newID(), e.disable, !!e.disableScroll); }
    start(e, t, s) { return this.canStart(e) ? (this.requestedStart.set(t, s), !0) : (this.requestedStart.delete(t), !1); }
    capture(e, t, s) { if (!this.start(e, t, s))
        return !1; let a = this.requestedStart, n = -1e4; if (a.forEach(i => { n = Math.max(n, i); }), n === s) {
        this.capturedId = t, a.clear();
        let i = new CustomEvent("ionGestureCaptured", { detail: { gestureName: e } });
        return document.dispatchEvent(i), !0;
    } return a.delete(t), !1; }
    release(e) { this.requestedStart.delete(e), this.capturedId === e && (this.capturedId = void 0); }
    disableGesture(e, t) { let s = this.disabledGestures.get(e); s === void 0 && (s = new Set, this.disabledGestures.set(e, s)), s.add(t); }
    enableGesture(e, t) { let s = this.disabledGestures.get(e); s !== void 0 && s.delete(t); }
    disableScroll(e) { this.disabledScroll.add(e), this.disabledScroll.size === 1 && document.body.classList.add(H); }
    enableScroll(e) { this.disabledScroll.delete(e), this.disabledScroll.size === 0 && document.body.classList.remove(H); }
    canStart(e) { return this.capturedId === void 0 && !this.isDisabled(e); }
    isCaptured() { return this.capturedId !== void 0; }
    isScrollDisabled() { return this.disabledScroll.size > 0; }
    isDisabled(e) { let t = this.disabledGestures.get(e); return !!(t && t.size > 0); }
    newID() { return this.gestureId++, this.gestureId; }
};
var Y = (e, t, s, a) => { let n = !!se(e) && { capture: !1, passive: !!a.passive }, i, u; return e.__zone_symbol__addEventListener ? (i = "__zone_symbol__addEventListener", u = "__zone_symbol__removeEventListener") : (i = "addEventListener", u = "removeEventListener"), e[i](t, s, n), () => { e[u](t, s, n); }; }, se = e => { if (x === void 0)
    try {
        let t = Object.defineProperty({}, "passive", { get: () => { x = !0; } });
        e.addEventListener("optsTest", () => { }, t);
    }
    catch {
        x = !1;
    } return !!x; }, x, K = e => e instanceof Document ? e : e.ownerDocument, ne = e => { let t = !1, s = !1, a = !0, n = !1, i = Object.assign({ disableScroll: !1, direction: "x", gesturePriority: 0, passive: !0, maxAngle: 40, threshold: 10 }, e), u = i.canStart, f = i.onWillStart, I = i.onStart, j = i.onEnd, L = i.notCaptured, A = i.onMove, Z = i.threshold, $ = i.passive, ee = i.blurOnStart, r = { type: "pan", startX: 0, startY: 0, startTime: 0, currentX: 0, currentY: 0, velocityX: 0, velocityY: 0, deltaX: 0, deltaY: 0, currentTime: 0, event: void 0, data: void 0 }, M = ((l, o, h) => { let g = h * (Math.PI / 180), b = l === "x", p = Math.cos(g), X = o * o, S = 0, y = 0, v = !1, d = 0; return { start(m, G) { S = m, y = G, d = 0, v = !0; }, detect(m, G) { if (!v)
        return !1; let w = m - S, E = G - y, D = w * w + E * E; if (D < X)
        return !1; let O = Math.sqrt(D), T = (b ? w : E) / O; return d = T > p ? 1 : T < -p ? -1 : 0, v = !1, !0; }, isGesture: () => d !== 0, getDirection: () => d }; })(i.direction, i.threshold, i.maxAngle), _ = J.createGesture({ name: e.gestureName, priority: e.gesturePriority, disableScroll: e.disableScroll }), te = () => { t && (n = !1, A && A(r)); }, N = () => !!_.capture() && (t = !0, a = !1, r.startX = r.currentX, r.startY = r.currentY, r.startTime = r.currentTime, f ? f(r).then(R) : R(), !0), R = () => { ee && (() => { if (typeof document < "u") {
    let l = document.activeElement;
    l?.blur && l.blur();
} })(), I && I(r), a = !0; }, q = () => { t = !1, s = !1, n = !1, a = !0, _.release(); }, B = l => { let o = t, h = a; q(), h && (P(r, l), o ? j && j(r) : L && L(r)); }, z = ((l, o, h, g, b) => { let p, X, S, y, v, d, m, G = 0, w = c => { G = Date.now() + 2e3, o(c) && (!X && h && (X = Y(l, "touchmove", h, b)), S || (S = Y(c.target, "touchend", D, b)), y || (y = Y(c.target, "touchcancel", D, b))); }, E = c => { G > Date.now() || o(c) && (!d && h && (d = Y(K(l), "mousemove", h, b)), m || (m = Y(K(l), "mouseup", O, b))); }, D = c => { T(), g && g(c); }, O = c => { F(), g && g(c); }, T = () => { X && X(), S && S(), y && y(), X = S = y = void 0; }, F = () => { d && d(), m && m(), d = m = void 0; }, U = () => { T(), F(); }, W = (c = !0) => { c ? (p || (p = Y(l, "touchstart", w, b)), v || (v = Y(l, "mousedown", E, b))) : (p && p(), v && v(), p = v = void 0, U()); }; return { enable: W, stop: U, destroy: () => { W(!1), g = h = o = void 0; } }; })(i.el, l => { let o = V(l); return !(s || !a) && (Q(l, r), r.startX = r.currentX, r.startY = r.currentY, r.startTime = r.currentTime = o, r.velocityX = r.velocityY = r.deltaX = r.deltaY = 0, r.event = l, (!u || u(r) !== !1) && (_.release(), !!_.start() && (s = !0, Z === 0 ? N() : (M.start(r.startX, r.startY), !0)))); }, l => { t ? !n && a && (n = !0, P(r, l), requestAnimationFrame(te)) : (P(r, l), M.detect(r.currentX, r.currentY) && (M.isGesture() && N() || re())); }, B, { passive: $ }), re = () => { q(), z.stop(), L && L(r); }; return { enable(l = !0) { l || (t && B(void 0), q()), z.enable(l); }, destroy() { _.destroy(), z.destroy(); } }; }, P = (e, t) => { if (!t)
    return; let s = e.currentX, a = e.currentY, n = e.currentTime; Q(t, e); let i = e.currentX, u = e.currentY, f = (e.currentTime = V(t)) - n; if (f > 0 && f < 100) {
    let I = (u - a) / f;
    e.velocityX = (i - s) / f * .7 + .3 * e.velocityX, e.velocityY = .7 * I + .3 * e.velocityY;
} e.deltaX = i - e.startX, e.deltaY = u - e.startY, e.event = t; }, Q = (e, t) => { let s = 0, a = 0; if (e) {
    let n = e.changedTouches;
    if (n && n.length > 0) {
        let i = n[0];
        s = i.clientX, a = i.clientY;
    }
    else
        e.pageX !== void 0 && (s = e.pageX, a = e.pageY);
} t.currentX = s, t.currentY = a; }, V = e => e.timeStamp || Date.now();
export { H as a, J as b, ne as c };
/*! Bundled license information:

@ionic/core/components/p-BTEOs1at.js:
@ionic/core/components/p-Cl0B-RWe.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
