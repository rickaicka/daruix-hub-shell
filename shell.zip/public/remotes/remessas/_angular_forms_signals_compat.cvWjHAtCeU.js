import { D as X, E as K, F as G, a as R, o as j, r as U, s as S, t as x, u as F, v as V, w as L } from "@nf-internal/chunk-EQKKOSBI";
import { a as A, b as C } from "@nf-internal/chunk-JHI3MBHO";
import { linkedSignal as Z, untracked as y, runInInjectionContext as ee, computed as d, signal as Q, \u0275RuntimeError as W, EventEmitter as Y, inject as te, Injector as re, effect as p } from "@angular/core";
import { AbstractControl as k, ValueChangeEvent as ne, StatusChangeEvent as ie, TouchedChangeEvent as ae, PristineChangeEvent as se, FormResetEvent as oe } from "@angular/forms";
import { toSignal as M } from "@angular/core/rxjs-interop";
import { ReplaySubject as B } from "rxjs";
import { map as T, takeUntil as N } from "rxjs/operators";
import "@angular/core/primitives/signals";
var P = class extends S {
    options;
    control;
    constructor(e) { super(e), this.options = e, this.control = this.options.control; }
};
function de() { let r = new B(1); return () => (r.next(), r.complete(), r = new B(1)); }
function O(r, e) { let t = R(r), n = de(), i = Z({ source: r.control, computation: l => y(() => ee(t, () => e(l, n()))) }); return d(() => i()()); }
var f = (r, e) => O(r, (t, n) => M(t.statusChanges.pipe(T(() => e(t)), N(n)), { initialValue: e(t) })), z = (r, e) => O(r, (t, n) => M(t.events.pipe(T(() => e(t)), N(n)), { initialValue: e(t) })), D = class extends x {
    compatNode;
    touched;
    dirty;
    disabled;
    control;
    constructor(e, t) { super(e), this.compatNode = e, this.control = t.control, this.touched = z(t, i => i.touched), this.dirty = z(t, i => i.dirty); let n = f(t, i => i.disabled); this.disabled = d(() => n() || this.disabledReasons().length > 0); }
    markAsDirty() { this.control().markAsDirty(); }
    markAsTouched() { this.control().markAsTouched(); }
    markAsPristine() { this.control().markAsPristine(); }
    markAsUntouched() { this.control().markAsUntouched(); }
};
function le(r) { if (r.kind !== "root")
    return r.parent; }
function ue(r) { return r.kind === "root" ? r.fieldManager : r.parent.structure.root.structure.fieldManager; }
function ce(r) { let e = O(r, (t, n) => M(t.valueChanges.pipe(T(() => t.getRawValue()), N(n)), { initialValue: t.getRawValue() })); return e.set = t => { r.control().setValue(t); }, e.update = t => { e.set(t(e())); }, e; }
var E = class extends U {
    value;
    keyInParent;
    root;
    pathKeys;
    children = Q([]);
    childrenMap = d(() => { });
    parent;
    fieldManager;
    constructor(e, t) { super(t.logic, e, () => { throw new W(1911, !1); }), this.value = ce(t), this.parent = le(t), this.root = this.parent?.structure.root ?? e, this.fieldManager = ue(t); let n = t.kind === "child" ? t.identityInParent : void 0, i = t.kind === "child" ? t.initialKeyInParent : void 0; this.keyInParent = this.createKeyInParent(t, n, i), this.pathKeys = d(() => this.parent ? [...this.parent.structure.pathKeys(), this.keyInParent()] : []); }
    getChild() { }
}, m = d(() => []), he = d(() => !0), _ = class {
    syncValid;
    errors;
    pending;
    invalid;
    valid;
    parseErrors = d(() => []);
    constructor(e) { this.syncValid = f(e, t => t.status === "VALID"), this.errors = f(e, G), this.pending = f(e, t => t.pending), this.valid = f(e, t => t.valid), this.invalid = f(e, t => t.invalid); }
    asyncErrors = m;
    errorSummary = m;
    rawSyncTreeErrors = m;
    syncErrors = m;
    rawAsyncErrors = m;
    shouldSkipValidation = he;
    status = d(() => j(this));
}, I = class {
    basicAdapter = new F;
    newRoot(e, t, n, i) { return t() instanceof k ? $({ kind: "root", fieldManager: e, value: t, pathNode: n, logic: n.builder.build(), fieldAdapter: i }) : this.basicAdapter.newRoot(e, t, n, i); }
    createNodeState(e, t) { return t.control ? new D(e, t) : this.basicAdapter.createNodeState(e); }
    createStructure(e, t) { return t.control ? new E(e, t) : this.basicAdapter.createStructure(e, t); }
    createValidationState(e, t) { return t.control ? new _(t) : this.basicAdapter.createValidationState(e); }
    newChild(e) { return e.parent.value()[e.initialKeyInParent] instanceof k ? $(e) : new S(e); }
};
function $(r) { let e = r.kind === "root" ? r.value : d(() => r.parent.value()[r.initialKeyInParent]); return new P(C(A({}, r), { control: e })); }
function q(...r) { let [e, t, n] = V(r), i = C(A({}, n), { adapter: new I }); return L(e, t || (() => { }), i); }
var Se = { "ng-touched": ({ state: r }) => r().touched(), "ng-untouched": ({ state: r }) => !r().touched(), "ng-dirty": ({ state: r }) => r().dirty(), "ng-pristine": ({ state: r }) => !r().dirty(), "ng-valid": ({ state: r }) => r().valid(), "ng-invalid": ({ state: r }) => r().invalid(), "ng-pending": ({ state: r }) => r().pending() }, H = class extends k {
    fieldTree;
    sourceValue;
    fieldState;
    initialValue;
    pendingParentNotifications = 0;
    onChangeCallbacks = [];
    onDisabledChangeCallbacks = [];
    valueChanges = new Y;
    statusChanges = new Y;
    constructor(e, t, n) { super(null, null); let [i, l, h] = V([Q(e), t, n]); this.sourceValue = i, this.initialValue = e; let o = h?.injector ?? te(re), g = l ? q(this.sourceValue, l, { injector: o }) : q(this.sourceValue, { injector: o }); this.fieldTree = ge(g, () => this.parent?.updateValueAndValidity({ sourceControl: this })), this.fieldState = this.fieldTree(), this.defineCompatProperties(), p(() => { let a = this.sourceValue(); y(() => { this.notifyParentUnlessPending(), this.valueChanges.emit(a), this.emitControlEvent(new ne(a, this)); }); }, { injector: o }), p(() => { let a = this.status; y(() => { this.statusChanges.emit(a); }), this.emitControlEvent(new ie(a, this)); }, { injector: o }), p(() => { let a = this.disabled; y(() => { for (let s of this.onDisabledChangeCallbacks)
        s(a); }); }, { injector: o }), p(() => { let a = this.fieldState.touched(); this.emitControlEvent(new ae(a, this)); let s = this.parent; s && (a ? s.markAsTouched() : s.markAsUntouched()); }, { injector: o }), p(() => { let a = this.fieldState.dirty(); this.emitControlEvent(new se(!a, this)); let s = this.parent; s && (a ? s.markAsDirty() : s.markAsPristine()); }, { injector: o }); }
    defineCompatProperties() { let e = v({ value: v }); Object.defineProperty(this, e, { get: () => this.sourceValue() }); let t = v({ errors: v }); Object.defineProperty(this, t, { get: () => K(this.fieldState.errors()) }); }
    emitControlEvent(e) { y(() => { this._events.next(e); }); }
    setValue(e, t) { this.updateValue(e, t); }
    patchValue(e, t) { this.updateValue(e, t); }
    updateValue(e, t) { let n = this.scheduleParentUpdate(t); if (this.sourceValue.set(e), n && this.updateParentValueAndValidity(n, t?.emitEvent), t?.emitModelToViewChange !== !1)
        for (let i of this.onChangeCallbacks)
            i(e, !0); }
    registerOnChange(e) { this.onChangeCallbacks.push(e); }
    _unregisterOnChange(e) { J(this.onChangeCallbacks, e); }
    registerOnDisabledChange(e) { this.onDisabledChangeCallbacks.push(e); }
    _unregisterOnDisabledChange(e) { J(this.onDisabledChangeCallbacks, e); }
    getRawValue() { return this.value; }
    reset(e, t) { if (fe(e))
        throw w(); let n = e ?? this.initialValue; if (this.fieldState.reset(n), e !== void 0)
        this.updateValue(e, t);
    else if (!t?.onlySelf) {
        let i = this.parent;
        i && this.updateParentValueAndValidity(i, t?.emitEvent);
    } t?.emitEvent !== !1 && this.emitControlEvent(new oe(this)); }
    scheduleParentUpdate(e) { let t = e?.onlySelf ? null : this.parent; return (e?.onlySelf || t) && this.pendingParentNotifications++, t; }
    notifyParentUnlessPending() { if (this.pendingParentNotifications > 0) {
        this.pendingParentNotifications--;
        return;
    } let e = this.parent; e && this.updateParentValueAndValidity(e); }
    updateParentValueAndValidity(e, t) { e.updateValueAndValidity({ emitEvent: t, sourceControl: this }); }
    propagateToParent(e, t) { let n = this.parent; n && !e?.onlySelf && t(n); }
    get status() { return this.fieldState.disabled() ? "DISABLED" : this.fieldState.valid() ? "VALID" : this.fieldState.invalid() ? "INVALID" : "PENDING"; }
    get valid() { return this.fieldState.valid(); }
    get invalid() { return this.fieldState.invalid(); }
    get pending() { return this.fieldState.pending(); }
    get disabled() { return this.fieldState.disabled(); }
    get enabled() { return !this.disabled; }
    get dirty() { return this.fieldState.dirty(); }
    set dirty(e) { throw c(!1); }
    get pristine() { return !this.dirty; }
    set pristine(e) { throw c(!1); }
    get touched() { return this.fieldState.touched(); }
    set touched(e) { throw c(!1); }
    get untouched() { return !this.touched; }
    set untouched(e) { throw c(!1); }
    markAsTouched(e) { this.fieldState.markAsTouched(), this.propagateToParent(e, t => t.markAsTouched(e)); }
    markAsDirty(e) { this.fieldState.markAsDirty(), this.propagateToParent(e, t => t.markAsDirty(e)); }
    markAsPristine(e) { this.fieldState.markAsPristine(), this.propagateToParent(e, t => t.markAsPristine(e)); }
    markAsUntouched(e) { this.fieldState.markAsUntouched(), this.propagateToParent(e, t => t.markAsUntouched(e)); }
    updateValueAndValidity(e) { }
    _updateValue() { }
    _forEachChild(e) { }
    _anyControls(e) { return !1; }
    _allControlsDisabled() { return this.disabled; }
    _syncPendingControls() { return !1; }
    disable(e) { throw w(); }
    enable(e) { throw w(); }
    setValidators(e) { throw u(); }
    setAsyncValidators(e) { throw u(); }
    addValidators(e) { throw u(); }
    addAsyncValidators(e) { throw u(); }
    removeValidators(e) { throw u(); }
    removeAsyncValidators(e) { throw u(); }
    clearValidators() { throw u(); }
    clearAsyncValidators() { throw u(); }
    setErrors(e, t) { throw c(!1); }
    markAsPending(e) { throw c(!1); }
}, b = class {
    map = new WeakMap;
    getOrCreate(e, t) { let n = this.map.get(e); if (n)
        return n; let i = t(); return this.map.set(e, i), i; }
};
function ge(r, e) { let t = new b, n = new b, i = h => { let { value: o } = h, g = Object.assign((...a) => o(...a), { set: a => { o.set(a), e(); }, update: a => { o.update(a), e(); } }); return Object.create(h, { value: { get: () => g } }); }, l = h => t.getOrCreate(h, () => new Proxy(h, { get(o, g, a) { let s = Reflect.get(o, g, a); return typeof s == "function" && typeof g == "string" ? l(s) : s; }, apply(o, g, a) { let s = o(...a); return n.getOrCreate(s, () => i(s)); } })); return l(r); }
function fe(r) { return typeof r == "object" && r !== null && Object.keys(r).length === 2 && "value" in r && "disabled" in r; }
function c(r) { return new W(1920, r ?? !1); }
function w() { return c(!1); }
function u() { return c(!1); }
function J(r, e) { let t = r.indexOf(e); t > -1 && r.splice(t, 1); }
function v(r) { for (let e in r)
    if (r[e] === v)
        return e; throw Error(""); }
export { X as CompatValidationError, Se as NG_STATUS_CLASSES, H as SignalFormControl, q as compatForm };
/*! Bundled license information:

@angular/forms/fesm2022/signals-compat.mjs:
  (**
   * @license Angular v21.2.18
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
