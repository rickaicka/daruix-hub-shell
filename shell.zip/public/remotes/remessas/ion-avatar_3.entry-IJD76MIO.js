import { b as i } from "@nf-internal/chunk-C2WRTRKV";
import { c as t } from "@nf-internal/chunk-56EKAJ4H";
import { i as r, m as a, n as d } from "@nf-internal/chunk-V3JGNOV4";
import "@nf-internal/chunk-JHI3MBHO";
var n = () => ":host{border-radius:var(--border-radius);display:block}::slotted(ion-img),::slotted(img){border-radius:var(--border-radius);width:100%;height:100%;-o-object-fit:cover;object-fit:cover;overflow:hidden}:host{--border-radius:50%;width:48px;height:48px}", e = () => ":host{border-radius:var(--border-radius);display:block}::slotted(ion-img),::slotted(img){border-radius:var(--border-radius);width:100%;height:100%;-o-object-fit:cover;object-fit:cover;overflow:hidden}:host{--border-radius:50%;width:64px;height:64px}", s = class {
    constructor(o) { r(this, o); }
    render() { return a(d, { key: "998217066084f966bf5d356fed85bcbd451f675a", class: t(this) }, a("slot", { key: "1a6f7c9d4dc6a875f86b5b3cda6d59cb39587f22" })); }
};
s.style = { ios: n(), md: e() };
var c = () => ":host{--background:var(--ion-color-primary, #0054e9);--color:var(--ion-color-primary-contrast, #fff);--padding-top:3px;--padding-end:8px;--padding-bottom:3px;--padding-start:8px;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-webkit-padding-start:var(--padding-start);padding-inline-start:var(--padding-start);-webkit-padding-end:var(--padding-end);padding-inline-end:var(--padding-end);padding-top:var(--padding-top);padding-bottom:var(--padding-bottom);display:inline-block;min-width:10px;background:var(--background);color:var(--color);font-family:var(--ion-font-family, inherit);font-size:0.8125rem;font-weight:bold;line-height:1;text-align:center;white-space:nowrap;contain:content;vertical-align:baseline}:host(.ion-color){background:var(--ion-color-base);color:var(--ion-color-contrast)}:host(:empty){display:none}:host{border-radius:10px;font-size:max(13px, 0.8125rem)}", p = () => ":host{--background:var(--ion-color-primary, #0054e9);--color:var(--ion-color-primary-contrast, #fff);--padding-top:3px;--padding-end:8px;--padding-bottom:3px;--padding-start:8px;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-webkit-padding-start:var(--padding-start);padding-inline-start:var(--padding-start);-webkit-padding-end:var(--padding-end);padding-inline-end:var(--padding-end);padding-top:var(--padding-top);padding-bottom:var(--padding-bottom);display:inline-block;min-width:10px;background:var(--background);color:var(--color);font-family:var(--ion-font-family, inherit);font-size:0.8125rem;font-weight:bold;line-height:1;text-align:center;white-space:nowrap;contain:content;vertical-align:baseline}:host(.ion-color){background:var(--ion-color-base);color:var(--ion-color-contrast)}:host(:empty){display:none}:host{--padding-top:3px;--padding-end:4px;--padding-bottom:4px;--padding-start:4px;border-radius:4px}", l = class {
    constructor(o) { r(this, o); }
    render() { let o = t(this); return a(d, { key: "1a2d39c5deec771a2f2196447627b62a7d4c8389", class: i(this.color, { [o]: !0 }) }, a("slot", { key: "fc1b6587f1ed24715748eb6785e7fb7a57cdd5cd" })); }
};
l.style = { ios: c(), md: p() };
var b = () => ":host{--size:48px;--border-radius:0;border-radius:var(--border-radius);display:block;width:var(--size);height:var(--size)}::slotted(ion-img),::slotted(img){border-radius:var(--border-radius);width:100%;height:100%;-o-object-fit:cover;object-fit:cover;overflow:hidden}", g = class {
    constructor(o) { r(this, o); }
    render() { return a(d, { key: "b250e01664238f1dca8f9757b15bc3d5d9387ffa", class: t(this) }, a("slot", { key: "72cb568bccabc983c5186a7596ef6c6d4ebf5ad9" })); }
};
g.style = b();
export { s as ion_avatar, l as ion_badge, g as ion_thumbnail };
/*! Bundled license information:

@ionic/core/dist/esm/ion-avatar_3.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
