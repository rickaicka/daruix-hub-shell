import { d as _, f as O, h as N } from "@nf-internal/chunk-WTYIQXL5";
import { a as k, b as F } from "@nf-internal/chunk-GRQQPC7S";
import "@nf-internal/chunk-K4KGMBYV";
import { b as R, f as I, g as T } from "@nf-internal/chunk-EH7P5N2T";
import { a as S, b as A } from "@nf-internal/chunk-PJKO2XHO";
import "@nf-internal/chunk-V3JGNOV4";
import { e as L } from "@nf-internal/chunk-JHI3MBHO";
var C = new WeakMap, P = (e, t, o, s = 0, r = !1) => { C.has(e) !== o && (o ? q(e, t, s, r) : G(e, t)); }, Y = e => e === e.getRootNode().activeElement, q = (e, t, o, s = !1) => { let r = t.parentNode, n = t.cloneNode(!1); n.classList.add("cloned-input"), n.tabIndex = -1, s && (n.disabled = !0); let a = e.ownerDocument.dir === "rtl"; if (a) {
    let u = r.offsetWidth - t.offsetLeft - t.offsetWidth;
    n.style.insetInlineStart = `${u}px`;
}
else
    n.style.insetInlineStart = `${t.offsetLeft}px`; r.appendChild(n), C.set(e, n); let f = a ? 9999 : -9999; e.style.pointerEvents = "none", t.style.transform = `translate3d(${f}px,${o}px,0) scale(0)`; }, G = (e, t) => { let o = C.get(e); o && (C.delete(e), o.remove()), e.style.pointerEvents = "", t.style.transform = ""; }, U = 50, z = (e, t, o) => { if (!o || !t)
    return () => { }; let s = a => { Y(t) && P(e, t, a); }, r = () => P(e, t, !1), n = () => s(!0), c = () => s(!1); return I(o, "ionScrollStart", n), I(o, "ionScrollEnd", c), t.addEventListener("blur", r), () => { T(o, "ionScrollStart", n), T(o, "ionScrollEnd", c), t.removeEventListener("blur", r); }; }, B = "input, textarea, [no-blur], [contenteditable]", j = () => { let e = !0, t = !1, o = document, s = () => { t = !0; }, r = () => { e = !0; }, n = c => { if (t) {
    t = !1;
    return;
} let a = o.activeElement; if (!a || a.matches(B))
    return; let f = c.target; f !== a && (f.matches(B) || f.closest(B) || (e = !1, setTimeout(() => { e || a.blur(); }, 50))); }; return I(o, "ionScrollStart", s), o.addEventListener("focusin", r, !0), o.addEventListener("touchend", n, !1), () => { T(o, "ionScrollStart", s, !0), o.removeEventListener("focusin", r, !0), o.removeEventListener("touchend", n, !1); }; }, J = .3, Q = (e, t, o, s) => { var r; let n = (r = e.closest("ion-item,[ion-item]")) !== null && r !== void 0 ? r : e; return V(n.getBoundingClientRect(), t.getBoundingClientRect(), o, s); }, V = (e, t, o, s) => { let r = e.top, n = e.bottom, c = t.top, a = Math.min(t.bottom, s - o), f = c + 15, u = a - U - n, d = f - r, m = Math.round(u < 0 ? -u : d > 0 ? -d : 0), v = Math.min(m, r - c), i = Math.abs(v) / J, h = Math.min(400, Math.max(150, i)); return { scrollAmount: v, scrollDuration: h, scrollPadding: o, inputSafeY: -(r - f) + 4 }; }, H = "$ionPaddingTimer", K = (e, t, o) => { let s = e[H]; s && clearTimeout(s), t > 0 ? e.style.setProperty("--keyboard-offset", `${t}px`) : e[H] = setTimeout(() => { e.style.setProperty("--keyboard-offset", "0px"), o && o(); }, 120); }, $ = (e, t, o) => { let s = () => { t && K(t, 0, o); }; e.addEventListener("focusout", s, { once: !0 }); }, D = 0, p = "data-ionic-skip-scroll-assist", X = (e, t, o, s, r, n, c, a = !1) => { let f = n && (c === void 0 || c.mode === k.None), l = !1, u = S !== void 0 ? S.innerHeight : 0, d = y => { if (l === !1) {
    l = !0;
    return;
} W(e, t, o, s, y.detail.keyboardHeight, f, a, u, !1); }, m = () => { l = !1, S === null || S === void 0 || S.removeEventListener("ionKeyboardDidShow", d), e.removeEventListener("focusout", m); }, v = () => L(null, null, function* () { if (t.hasAttribute(p)) {
    t.removeAttribute(p);
    return;
} W(e, t, o, s, r, f, a, u), S === null || S === void 0 || S.addEventListener("ionKeyboardDidShow", d), e.addEventListener("focusout", m); }); return e.addEventListener("focusin", v), () => { e.removeEventListener("focusin", v), S === null || S === void 0 || S.removeEventListener("ionKeyboardDidShow", d), e.removeEventListener("focusout", m); }; }, M = e => { var t; if (document.activeElement === e)
    return; let o = e.getAttribute("id"), s = e.closest(`label[for="${o}"]`), r = (t = document.activeElement) === null || t === void 0 ? void 0 : t.closest(`label[for="${o}"]`); s !== null && s === r || (e.setAttribute(p, "true"), e.focus()); }, W = (e, t, o, s, r, n, c = !1, a = 0, f = !0) => L(null, null, function* () { if (!o && !s)
    return; let l = Q(e, o || s, r, a); if (o && Math.abs(l.scrollAmount) < 4) {
    M(t), n && o !== null && (K(o, D), $(t, o, () => D = 0));
    return;
} if (P(e, t, !0, l.inputSafeY, c), M(t), n && o && (D = l.scrollPadding, K(o, D)), typeof window < "u") {
    let u, d = () => L(null, null, function* () { u !== void 0 && clearTimeout(u), window.removeEventListener("ionKeyboardDidShow", m), window.removeEventListener("ionKeyboardDidShow", d), o && (yield N(o, 0, l.scrollAmount, l.scrollDuration)), P(e, t, !1, l.inputSafeY), document.activeElement === t && M(t), n && $(t, o, () => D = 0); }), m = () => { window.removeEventListener("ionKeyboardDidShow", m), window.addEventListener("ionKeyboardDidShow", d); };
    if (o) {
        let v = yield _(o), y = v.scrollHeight - v.clientHeight;
        if (f && l.scrollAmount > y - v.scrollTop) {
            t.type === "password" ? (l.scrollAmount += U, window.addEventListener("ionKeyboardDidShow", m)) : window.addEventListener("ionKeyboardDidShow", d), u = setTimeout(d, 1e3);
            return;
        }
    }
    d();
} }), Z = !0, ie = (e, t) => L(null, null, function* () { if (A === void 0)
    return; let o = t === "ios", s = t === "android", r = e.getNumber("keyboardHeight", 290), n = e.getBoolean("scrollAssist", !0), c = e.getBoolean("hideCaretOnScroll", o), a = e.getBoolean("inputBlurring", !1), f = e.getBoolean("scrollPadding", !0), l = Array.from(A.querySelectorAll("ion-input, ion-textarea")), u = new WeakMap, d = new WeakMap, m = yield F.getResizeMode(), v = i => L(null, null, function* () { yield new Promise(g => R(i, g)); let h = i.shadowRoot || i, b = h.querySelector("input") || h.querySelector("textarea"), w = O(i), x = w ? null : i.closest("ion-footer"); if (!b)
    return; if (w && c && !u.has(i)) {
    let g = z(i, b, w);
    u.set(i, g);
} if (!(b.type === "date" || b.type === "datetime-local") && (w || x) && n && !d.has(i)) {
    let g = X(i, b, w, x, r, f, m, s);
    d.set(i, g);
} }), y = i => { if (c) {
    let h = u.get(i);
    h && h(), u.delete(i);
} if (n) {
    let h = d.get(i);
    h && h(), d.delete(i);
} }; a && Z && j(); for (let i of l)
    v(i); A.addEventListener("ionInputDidLoad", i => { v(i.detail); }), A.addEventListener("ionInputDidUnload", i => { y(i.detail); }); });
export { ie as startInputShims };
/*! Bundled license information:

@ionic/core/dist/esm/input-shims-D10mwcw1.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
