import { a as ae } from "@nf-internal/chunk-ZN3FGH7Q";
import { f as we, g as xe } from "@nf-internal/chunk-62PG6E7C";
import { a as de, j as fe, k as he, m as ve, n as me, o as te, r as ue, w as ge } from "@nf-internal/chunk-ZLCREYPB";
import { a as pe, b as ce, c as le } from "@nf-internal/chunk-DMOCYLK5";
import { c as be } from "@nf-internal/chunk-C2WRTRKV";
import { a as u } from "@nf-internal/chunk-N5XCE53N";
import { b as se, c as ee } from "@nf-internal/chunk-56EKAJ4H";
import { c as ie, f as ne, h as $, i as Y } from "@nf-internal/chunk-EH7P5N2T";
import "@nf-internal/chunk-55MUSWHY";
import "@nf-internal/chunk-6V4UOETA";
import "@nf-internal/chunk-PJKO2XHO";
import { e as ye, i as ke, m as R, n as Pe, q as Ae, r as A } from "@nf-internal/chunk-V3JGNOV4";
import { e as L } from "@nf-internal/chunk-JHI3MBHO";
var K = null, oe = !1, Ie = t => { if (K !== null)
    return K; if (t.body === null)
    return { top: 0, bottom: 0, left: 0, right: 0 }; let e = t.createElement("div"); e.style.cssText = "position:fixed;visibility:hidden;pointer-events:none;top:0;left:0;padding-top:var(--ion-safe-area-top,0px);padding-bottom:var(--ion-safe-area-bottom,0px);padding-left:var(--ion-safe-area-left,0px);padding-right:var(--ion-safe-area-right,0px);", t.body.appendChild(e); let o = getComputedStyle(e), r = { top: parseFloat(o.paddingTop) || 0, bottom: parseFloat(o.paddingBottom) || 0, left: parseFloat(o.paddingLeft) || 0, right: parseFloat(o.paddingRight) || 0 }; return e.remove(), K = r, oe || (oe = !0, Y(() => { K = null, oe = !1; })), r; }, Le = t => { if (!t)
    return { arrowWidth: 0, arrowHeight: 0 }; let { width: e, height: o } = t.getBoundingClientRect(); return { arrowWidth: e, arrowHeight: o }; }, Te = (t, e, o) => { let r = e.getBoundingClientRect(), n = r.height, i = r.width; return t === "cover" && o && (i = o.getBoundingClientRect().width), { contentWidth: i, contentHeight: n }; }, $e = (t, e, o, r) => { let n = [], s = $(r).querySelector(".popover-content"); return e === "hover" ? n = [{ eventName: "mouseenter", callback: a => { document.elementFromPoint(a.clientX, a.clientY) !== t && o.dismiss(void 0, void 0, !1); } }] : n = [{ eventName: "click", callback: a => { if (a.target.closest("[data-ion-popover-trigger]") === t) {
            a.stopPropagation();
            return;
        } o.dismiss(void 0, void 0, !1); } }], n.forEach(({ eventName: a, callback: p }) => s.addEventListener(a, p)), () => { n.forEach(({ eventName: a, callback: p }) => s.removeEventListener(a, p)); }; }, Re = (t, e, o) => { let r = []; switch (e) {
    case "hover":
        let n;
        r = [{ eventName: "mouseenter", callback: i => L(null, null, function* () { i.stopPropagation(), n && clearTimeout(n), n = setTimeout(() => { Y(() => { o.presentFromTrigger(i), n = void 0; }); }, 100); }) }, { eventName: "mouseleave", callback: i => { n && clearTimeout(n); let s = i.relatedTarget; s && s.closest("ion-popover") !== o && o.dismiss(void 0, void 0, !1); } }, { eventName: "click", callback: i => i.stopPropagation() }, { eventName: "ionPopoverActivateTrigger", callback: i => o.presentFromTrigger(i, !0) }];
        break;
    case "context-menu":
        r = [{ eventName: "contextmenu", callback: i => { i.preventDefault(), o.presentFromTrigger(i); } }, { eventName: "click", callback: i => i.stopPropagation() }, { eventName: "ionPopoverActivateTrigger", callback: i => o.presentFromTrigger(i, !0) }];
        break;
    default:
        r = [{ eventName: "click", callback: i => o.presentFromTrigger(i) }, { eventName: "ionPopoverActivateTrigger", callback: i => o.presentFromTrigger(i, !0) }];
        break;
} return r.forEach(({ eventName: n, callback: i }) => t.addEventListener(n, i)), t.setAttribute("data-ion-popover-trigger", "true"), () => { r.forEach(({ eventName: n, callback: i }) => t.removeEventListener(n, i)), t.removeAttribute("data-ion-popover-trigger"); }; }, Se = (t, e) => !e || e.tagName !== "ION-ITEM" ? -1 : t.findIndex(o => o === e), ze = (t, e) => { let o = Se(t, e); return t[o + 1]; }, _e = (t, e) => { let o = Se(t, e); return t[o - 1]; }, G = t => { let o = $(t).querySelector("button"); o && Y(() => o.focus()); }, qe = t => t.hasAttribute("data-ion-popover-trigger"), Ne = t => { let e = o => L(null, null, function* () { var r; let n = document.activeElement, i = [], s = (r = o.target) === null || r === void 0 ? void 0 : r.tagName; if (!(s !== "ION-POPOVER" && s !== "ION-ITEM")) {
    try {
        i = Array.from(t.querySelectorAll("ion-item:not(ion-popover ion-popover *):not([disabled])"));
    }
    catch { }
    switch (o.key) {
        case "ArrowLeft":
            (yield t.getParentPopover()) && t.dismiss(void 0, void 0, !1);
            break;
        case "ArrowDown":
            o.preventDefault();
            let p = ze(i, n);
            p !== void 0 && G(p);
            break;
        case "ArrowUp":
            o.preventDefault();
            let c = _e(i, n);
            c !== void 0 && G(c);
            break;
        case "Home":
            o.preventDefault();
            let g = i[0];
            g !== void 0 && G(g);
            break;
        case "End":
            o.preventDefault();
            let d = i[i.length - 1];
            d !== void 0 && G(d);
            break;
        case "ArrowRight":
        case " ":
        case "Enter":
            if (n && qe(n)) {
                let h = new CustomEvent("ionPopoverActivateTrigger");
                n.dispatchEvent(h);
            }
            break;
    }
} }); return t.addEventListener("keydown", e), () => t.removeEventListener("keydown", e); }, Ce = (t, e, o, r, n, i, s, a, p, c, g) => { var d; let h = { top: 0, left: 0, width: 0, height: 0 }; switch (i) {
    case "event":
        if (!g)
            return p;
        let D = g;
        h = { top: D.clientY, left: D.clientX, width: 1, height: 1 };
        break;
    default:
        let l = g, I = c || ((d = l?.detail) === null || d === void 0 ? void 0 : d.ionShadowTarget) || l?.target;
        if (!I)
            return p;
        let m = I.getBoundingClientRect();
        h = { top: m.top, left: m.left, width: m.width, height: m.height };
        break;
} let v = Fe(s, h, e, o, r, n, t), b = Xe(a, s, h, e, o), w = v.top + b.top, k = v.left + b.left, { arrowTop: f, arrowLeft: x } = Ye(s, r, n, w, k, e, o, t), { originX: y, originY: P } = Me(s, a, t); return { top: w, left: k, referenceCoordinates: h, arrowTop: f, arrowLeft: x, originX: y, originY: P }; }, Me = (t, e, o) => { switch (t) {
    case "top": return { originX: De(e), originY: "bottom" };
    case "bottom": return { originX: De(e), originY: "top" };
    case "left": return { originX: "right", originY: H(e) };
    case "right": return { originX: "left", originY: H(e) };
    case "start": return { originX: o ? "left" : "right", originY: H(e) };
    case "end": return { originX: o ? "right" : "left", originY: H(e) };
} }, De = t => { switch (t) {
    case "start": return "left";
    case "center": return "center";
    case "end": return "right";
} }, H = t => { switch (t) {
    case "start": return "top";
    case "center": return "center";
    case "end": return "bottom";
} }, Ye = (t, e, o, r, n, i, s, a) => { let p = { arrowTop: r + s / 2 - e / 2, arrowLeft: n + i - e / 2 }, c = { arrowTop: r + s / 2 - e / 2, arrowLeft: n - e * 1.5 }; switch (t) {
    case "top": return { arrowTop: r + s, arrowLeft: n + i / 2 - e / 2 };
    case "bottom": return { arrowTop: r - o, arrowLeft: n + i / 2 - e / 2 };
    case "left": return p;
    case "right": return c;
    case "start": return a ? c : p;
    case "end": return a ? p : c;
    default: return { arrowTop: 0, arrowLeft: 0 };
} }, Fe = (t, e, o, r, n, i, s) => { let a = { top: e.top, left: e.left - o - n }, p = { top: e.top, left: e.left + e.width + n }; switch (t) {
    case "top": return { top: e.top - r - i, left: e.left };
    case "right": return p;
    case "bottom": return { top: e.top + e.height + i, left: e.left };
    case "left": return a;
    case "start": return s ? p : a;
    case "end": return s ? a : p;
} }, Xe = (t, e, o, r, n) => { switch (t) {
    case "center": return We(e, o, r, n);
    case "end": return Ve(e, o, r, n);
    default: return { top: 0, left: 0 };
} }, Ve = (t, e, o, r) => { switch (t) {
    case "start":
    case "end":
    case "left":
    case "right": return { top: -(r - e.height), left: 0 };
    default: return { top: 0, left: -(o - e.width) };
} }, We = (t, e, o, r) => { switch (t) {
    case "start":
    case "end":
    case "left":
    case "right": return { top: -(r / 2 - e.height / 2), left: 0 };
    default: return { top: 0, left: -(o / 2 - e.width / 2) };
} }, Ee = (t, e, o, r, n, i, s, a, p, c, g, d, h = 0, v = 0, b = 0) => { let w = h, k = v, f = o, x = e, y, P = c, D = g, l = !1, I = !1, m = !1, T = !1, S = d ? d.top + d.height : i / 2 - a / 2, z = d ? d.height : 0, C = !1, E = !1; if (f < r + p.left ? (f = r, l = !0, P = "left") : s + r + f + p.right > n && (I = !0, f = n - s - r, P = "right"), S + z + a > i - p.bottom && (t === "top" || t === "bottom")) {
    let O = S - a - z - (b - 1);
    if (O >= p.top + r)
        x = O, w = x + a, D = "bottom", C = !0;
    else {
        y = r, T = !0;
        let _ = i - p.bottom - r;
        x >= _ && (x = p.top + r, m = !0);
    }
} return { top: x, left: f, bottom: y, originX: P, originY: D, checkSafeAreaLeft: l, checkSafeAreaRight: I, checkSafeAreaTop: m, checkSafeAreaBottom: T, arrowTop: w, arrowLeft: k, addPopoverBottomClass: C, hideArrow: E }; }, je = (t, e = !1, o, r) => !(!o && !r || t !== "top" && t !== "bottom" && e), Ke = 5, B = 25, Ge = (t, e) => { var o; let { event: r, size: n, trigger: i, reference: s, side: a, align: p } = e, c = t.ownerDocument, g = c.dir === "rtl", d = c.defaultView.innerWidth, h = c.defaultView.innerHeight, v = $(t), b = v.querySelector(".popover-content"), w = v.querySelector(".popover-arrow"), k = i || ((o = r?.detail) === null || o === void 0 ? void 0 : o.ionShadowTarget) || r?.target, { contentWidth: f, contentHeight: x } = Te(n, b, k), { arrowWidth: y, arrowHeight: P } = Le(w), D = { top: h / 2 - x / 2, left: d / 2 - f / 2, originX: g ? "right" : "left", originY: "top" }, l = Ce(g, f, x, y, P, s, a, p, D, i, r), I = n === "cover" ? 0 : Ke, m = Ie(c), T = n === "cover" ? { top: 0, bottom: 0, left: 0, right: 0 } : { top: Math.max(m.top, B), bottom: Math.max(m.bottom, B), left: Math.max(m.left, B), right: Math.max(m.right, B) }, { originX: S, originY: z, top: C, left: E, bottom: O, checkSafeAreaLeft: _, checkSafeAreaRight: U, checkSafeAreaTop: J, checkSafeAreaBottom: q, arrowTop: F, arrowLeft: Q, addPopoverBottomClass: X } = Ee(a, l.top, l.left, I, d, h, f, x, T, l.originX, l.originY, l.referenceCoordinates, l.arrowTop, l.arrowLeft, P), V = u(), N = u(), M = u(); return N.addElement(v.querySelector("ion-backdrop")).fromTo("opacity", .01, "var(--backdrop-opacity)").beforeStyles({ "pointer-events": "none" }).afterClearStyles(["pointer-events"]), M.addElement(v.querySelector(".popover-arrow")).addElement(v.querySelector(".popover-content")).fromTo("opacity", .01, 1), V.easing("ease").duration(100).beforeAddWrite(() => { if (n === "cover" && t.style.setProperty("--width", `${f}px`), X && t.classList.add("popover-bottom"), O !== void 0) {
    let j = `${O}px`;
    q && (j = `${O}px + var(--ion-safe-area-bottom, 0px)`), b.style.setProperty("bottom", `calc(${j})`);
} let W = " + var(--ion-safe-area-left, 0px)", Oe = " - var(--ion-safe-area-right, 0px)", Z = `${E}px`; _ && (Z = `${E}px${W}`), U && (Z = `${E}px${Oe}`); let re = `${C}px`; if (J && (re = `${C}px + var(--ion-safe-area-top, 0px)`), b.style.setProperty("top", `calc(${re} + var(--offset-y, 0))`), b.style.setProperty("left", `calc(${Z} + var(--offset-x, 0))`), b.style.setProperty("transform-origin", `${z} ${S}`), w !== null) {
    let j = l.top !== C || l.left !== E;
    je(a, j, r, i) ? (w.style.setProperty("top", `calc(${F}px + var(--offset-y, 0))`), w.style.setProperty("left", `calc(${Q}px + var(--offset-x, 0))`)) : w.style.setProperty("display", "none");
} }).addAnimation([N, M]); }, He = t => { let e = $(t), o = e.querySelector(".popover-content"), r = e.querySelector(".popover-arrow"), n = u(), i = u(), s = u(); return i.addElement(e.querySelector("ion-backdrop")).fromTo("opacity", "var(--backdrop-opacity)", 0), s.addElement(e.querySelector(".popover-arrow")).addElement(e.querySelector(".popover-content")).fromTo("opacity", .99, 0), n.easing("ease").afterAddWrite(() => { t.style.removeProperty("--width"), t.classList.remove("popover-bottom"), o.style.removeProperty("top"), o.style.removeProperty("left"), o.style.removeProperty("bottom"), o.style.removeProperty("transform-origin"), r && (r.style.removeProperty("top"), r.style.removeProperty("left"), r.style.removeProperty("display")); }).duration(300).addAnimation([i, s]); }, Be = 12, Ue = (t, e) => { var o; let { event: r, size: n, trigger: i, reference: s, side: a, align: p } = e, c = t.ownerDocument, g = c.dir === "rtl", d = c.defaultView.innerWidth, h = c.defaultView.innerHeight, v = $(t), b = v.querySelector(".popover-content"), w = i || ((o = r?.detail) === null || o === void 0 ? void 0 : o.ionShadowTarget) || r?.target, { contentWidth: k, contentHeight: f } = Te(n, b, w), x = { top: h / 2 - f / 2, left: d / 2 - k / 2, originX: g ? "right" : "left", originY: "top" }, y = Ce(g, k, f, 0, 0, s, a, p, x, i, r), P = n === "cover" ? 0 : Be, D = n === "cover" ? { top: 0, bottom: 0, left: 0, right: 0 } : Ie(c), { originX: l, originY: I, top: m, left: T, bottom: S, checkSafeAreaLeft: z, checkSafeAreaRight: C, checkSafeAreaTop: E, checkSafeAreaBottom: O, addPopoverBottomClass: _ } = Ee(a, y.top, y.left, P, d, h, k, f, D, y.originX, y.originY, y.referenceCoordinates), U = " + var(--ion-safe-area-left, 0px)", J = " - var(--ion-safe-area-right, 0px)", q = `${T}px`; z && (q = `${T}px${U}`), C && (q = `${T}px${J}`); let F = `${m}px`; E && (F = `${m}px + var(--ion-safe-area-top, 0px)`); let Q = u(), X = u(), V = u(), N = u(), M = u(); return X.addElement(v.querySelector("ion-backdrop")).fromTo("opacity", .01, "var(--backdrop-opacity)").beforeStyles({ "pointer-events": "none" }).afterClearStyles(["pointer-events"]), V.addElement(v.querySelector(".popover-wrapper")).duration(150).fromTo("opacity", .01, 1), N.addElement(b).beforeStyles({ top: `calc(${F} + var(--offset-y, 0px))`, left: `calc(${q} + var(--offset-x, 0px))`, "transform-origin": `${I} ${l}` }).beforeAddWrite(() => { if (S !== void 0) {
    let W = `${S}px`;
    O && (W = `${S}px + var(--ion-safe-area-bottom, 0px)`), b.style.setProperty("bottom", `calc(${W})`);
} }).fromTo("transform", "scale(0.8)", "scale(1)"), M.addElement(v.querySelector(".popover-viewport")).fromTo("opacity", .01, 1), Q.easing("cubic-bezier(0.36,0.66,0.04,1)").duration(300).beforeAddWrite(() => { n === "cover" && t.style.setProperty("--width", `${k}px`), _ && t.classList.add("popover-bottom"); }).addAnimation([X, V, N, M]); }, Je = t => { let e = $(t), o = e.querySelector(".popover-content"), r = u(), n = u(), i = u(); return n.addElement(e.querySelector("ion-backdrop")).fromTo("opacity", "var(--backdrop-opacity)", 0), i.addElement(e.querySelector(".popover-wrapper")).fromTo("opacity", .99, 0), r.easing("ease").afterAddWrite(() => { t.style.removeProperty("--width"), t.classList.remove("popover-bottom"), o.style.removeProperty("top"), o.style.removeProperty("left"), o.style.removeProperty("bottom"), o.style.removeProperty("transform-origin"); }).duration(150).addAnimation([n, i]); }, Qe = () => ':host{--background:var(--ion-background-color, #fff);--min-width:0;--min-height:0;--max-width:auto;--height:auto;--offset-x:0px;--offset-y:0px;left:0;right:0;top:0;bottom:0;display:-ms-flexbox;display:flex;position:fixed;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;outline:none;color:var(--ion-text-color, #000);z-index:1001}:host(.popover-nested){pointer-events:none}:host(.popover-nested) .popover-wrapper{pointer-events:auto}:host(.overlay-hidden){display:none}.popover-wrapper{z-index:10}.popover-content{display:-ms-flexbox;display:flex;position:absolute;-ms-flex-direction:column;flex-direction:column;width:var(--width);min-width:var(--min-width);max-width:var(--max-width);height:var(--height);min-height:var(--min-height);max-height:var(--max-height);background:var(--background);-webkit-box-shadow:var(--box-shadow);box-shadow:var(--box-shadow);overflow:auto;z-index:10}::slotted(.popover-viewport){--ion-safe-area-top:0px;--ion-safe-area-right:0px;--ion-safe-area-bottom:0px;--ion-safe-area-left:0px;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column}:host(.popover-nested.popover-side-left){--offset-x:5px}:host(.popover-nested.popover-side-right){--offset-x:-5px}:host(.popover-nested.popover-side-start){--offset-x:5px}:host-context([dir=rtl]):host(.popover-nested.popover-side-start),:host-context([dir=rtl]).popover-nested.popover-side-start{--offset-x:-5px}@supports selector(:dir(rtl)){:host(.popover-nested.popover-side-start:dir(rtl)){--offset-x:-5px}}:host(.popover-nested.popover-side-end){--offset-x:-5px}:host-context([dir=rtl]):host(.popover-nested.popover-side-end),:host-context([dir=rtl]).popover-nested.popover-side-end{--offset-x:5px}@supports selector(:dir(rtl)){:host(.popover-nested.popover-side-end:dir(rtl)){--offset-x:5px}}:host{--width:200px;--max-height:90%;--box-shadow:none;--backdrop-opacity:var(--ion-backdrop-opacity, 0.08)}:host(.popover-desktop){--box-shadow:0px 4px 16px 0px rgba(0, 0, 0, 0.12)}.popover-content{border-radius:10px}:host(.popover-desktop) .popover-content{border:0.5px solid var(--ion-color-step-100, var(--ion-background-color-step-100, #e6e6e6))}.popover-arrow{display:block;position:absolute;width:20px;height:10px;overflow:hidden;z-index:11}.popover-arrow::after{top:3px;border-radius:3px;position:absolute;width:14px;height:14px;-webkit-transform:rotate(45deg);transform:rotate(45deg);background:var(--background);content:"";z-index:10}.popover-arrow::after{inset-inline-start:3px}:host(.popover-bottom) .popover-arrow{top:auto;bottom:-10px}:host(.popover-bottom) .popover-arrow::after{top:-6px}:host(.popover-side-left) .popover-arrow{-webkit-transform:rotate(90deg);transform:rotate(90deg)}:host(.popover-side-right) .popover-arrow{-webkit-transform:rotate(-90deg);transform:rotate(-90deg)}:host(.popover-side-top) .popover-arrow{-webkit-transform:rotate(180deg);transform:rotate(180deg)}:host(.popover-side-start) .popover-arrow{-webkit-transform:rotate(90deg);transform:rotate(90deg)}:host-context([dir=rtl]):host(.popover-side-start) .popover-arrow,:host-context([dir=rtl]).popover-side-start .popover-arrow{-webkit-transform:rotate(-90deg);transform:rotate(-90deg)}@supports selector(:dir(rtl)){:host(.popover-side-start:dir(rtl)) .popover-arrow{-webkit-transform:rotate(-90deg);transform:rotate(-90deg)}}:host(.popover-side-end) .popover-arrow{-webkit-transform:rotate(-90deg);transform:rotate(-90deg)}:host-context([dir=rtl]):host(.popover-side-end) .popover-arrow,:host-context([dir=rtl]).popover-side-end .popover-arrow{-webkit-transform:rotate(90deg);transform:rotate(90deg)}@supports selector(:dir(rtl)){:host(.popover-side-end:dir(rtl)) .popover-arrow{-webkit-transform:rotate(90deg);transform:rotate(90deg)}}.popover-arrow,.popover-content{opacity:0}@supports ((-webkit-backdrop-filter: blur(0)) or (backdrop-filter: blur(0))){:host(.popover-translucent) .popover-content,:host(.popover-translucent) .popover-arrow::after{background:rgba(var(--ion-background-color-rgb, 255, 255, 255), 0.8);-webkit-backdrop-filter:saturate(180%) blur(20px);backdrop-filter:saturate(180%) blur(20px)}}', Ze = () => ":host{--background:var(--ion-background-color, #fff);--min-width:0;--min-height:0;--max-width:auto;--height:auto;--offset-x:0px;--offset-y:0px;left:0;right:0;top:0;bottom:0;display:-ms-flexbox;display:flex;position:fixed;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;outline:none;color:var(--ion-text-color, #000);z-index:1001}:host(.popover-nested){pointer-events:none}:host(.popover-nested) .popover-wrapper{pointer-events:auto}:host(.overlay-hidden){display:none}.popover-wrapper{z-index:10}.popover-content{display:-ms-flexbox;display:flex;position:absolute;-ms-flex-direction:column;flex-direction:column;width:var(--width);min-width:var(--min-width);max-width:var(--max-width);height:var(--height);min-height:var(--min-height);max-height:var(--max-height);background:var(--background);-webkit-box-shadow:var(--box-shadow);box-shadow:var(--box-shadow);overflow:auto;z-index:10}::slotted(.popover-viewport){--ion-safe-area-top:0px;--ion-safe-area-right:0px;--ion-safe-area-bottom:0px;--ion-safe-area-left:0px;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column}:host(.popover-nested.popover-side-left){--offset-x:5px}:host(.popover-nested.popover-side-right){--offset-x:-5px}:host(.popover-nested.popover-side-start){--offset-x:5px}:host-context([dir=rtl]):host(.popover-nested.popover-side-start),:host-context([dir=rtl]).popover-nested.popover-side-start{--offset-x:-5px}@supports selector(:dir(rtl)){:host(.popover-nested.popover-side-start:dir(rtl)){--offset-x:-5px}}:host(.popover-nested.popover-side-end){--offset-x:-5px}:host-context([dir=rtl]):host(.popover-nested.popover-side-end),:host-context([dir=rtl]).popover-nested.popover-side-end{--offset-x:5px}@supports selector(:dir(rtl)){:host(.popover-nested.popover-side-end:dir(rtl)){--offset-x:5px}}:host{--width:250px;--max-height:90%;--box-shadow:0 5px 5px -3px rgba(0, 0, 0, 0.2), 0 8px 10px 1px rgba(0, 0, 0, 0.14), 0 3px 14px 2px rgba(0, 0, 0, 0.12);--backdrop-opacity:var(--ion-backdrop-opacity, 0.32)}.popover-content{border-radius:4px;-webkit-transform-origin:left top;transform-origin:left top}:host-context([dir=rtl]) .popover-content{-webkit-transform-origin:right top;transform-origin:right top}[dir=rtl] .popover-content{-webkit-transform-origin:right top;transform-origin:right top}@supports selector(:dir(rtl)){.popover-content:dir(rtl){-webkit-transform-origin:right top;transform-origin:right top}}.popover-viewport{-webkit-transition-delay:100ms;transition-delay:100ms}.popover-wrapper{opacity:0}", et = class {
    constructor(t) { ke(this, t), this.didPresent = A(this, "ionPopoverDidPresent", 7), this.willPresent = A(this, "ionPopoverWillPresent", 7), this.willDismiss = A(this, "ionPopoverWillDismiss", 7), this.didDismiss = A(this, "ionPopoverDidDismiss", 7), this.didPresentShorthand = A(this, "didPresent", 7), this.willPresentShorthand = A(this, "willPresent", 7), this.willDismissShorthand = A(this, "willDismiss", 7), this.didDismissShorthand = A(this, "didDismiss", 7), this.ionMount = A(this, "ionMount", 7), this.parentPopover = null, this.coreDelegate = le(), this.lockController = ae(), this.inline = !1, this.focusDescendantOnPresent = !1, this.presented = !1, this.hasController = !1, this.keyboardClose = !0, this.backdropDismiss = !0, this.showBackdrop = !0, this.translucent = !1, this.animated = !0, this.triggerAction = "click", this.size = "auto", this.dismissOnSelect = !1, this.reference = "trigger", this.side = "bottom", this.arrow = !0, this.isOpen = !1, this.keyboardEvents = !1, this.focusTrap = !0, this.keepContentsMounted = !1, this.onBackdropTap = () => { this.dismiss(void 0, ue); }, this.onLifecycle = e => { let o = this.usersElement, r = tt[e.type]; if (o && r) {
        let n = new CustomEvent(r, { bubbles: !1, cancelable: !1, detail: e.detail });
        o.dispatchEvent(n);
    } }, this.configureTriggerInteraction = () => { let { trigger: e, triggerAction: o, el: r, destroyTriggerInteraction: n } = this; if (n && n(), e === void 0)
        return; let i = this.triggerEl = e !== void 0 ? document.getElementById(e) : null; if (!i) {
        ye(`[ion-popover] - A trigger element with the ID "${e}" was not found in the DOM. The trigger element must be in the DOM when the "trigger" property is set on ion-popover.`, this.el);
        return;
    } this.destroyTriggerInteraction = Re(i, o, r); }, this.configureKeyboardInteraction = () => { let { destroyKeyboardInteraction: e, el: o } = this; e && e(), this.destroyKeyboardInteraction = Ne(o); }, this.configureDismissInteraction = () => { let { destroyDismissInteraction: e, parentPopover: o, triggerAction: r, triggerEl: n, el: i } = this; !o || !n || (e && e(), this.destroyDismissInteraction = $e(n, r, i, o)); }; }
    onTriggerChange() { this.configureTriggerInteraction(); }
    onIsOpenChange(t, e) { t === !0 && e === !1 ? this.present() : t === !1 && e === !0 && this.dismiss(); }
    connectedCallback() { let { configureTriggerInteraction: t, el: e } = this; fe(e), t(); }
    disconnectedCallback() { let { destroyTriggerInteraction: t } = this; t && t(), this.headerResizeObserver && (this.headerResizeObserver.disconnect(), this.headerResizeObserver = void 0); }
    componentWillLoad() { var t, e; let { el: o } = this, r = (e = (t = this.htmlAttributes) === null || t === void 0 ? void 0 : t.id) !== null && e !== void 0 ? e : he(o); this.parentPopover = o.closest(`ion-popover:not(#${r})`), this.alignment === void 0 && (this.alignment = ee(this) === "ios" ? "center" : "start"); }
    componentDidLoad() { let { parentPopover: t, isOpen: e } = this; e === !0 && Y(() => this.present()), t && ne(t, "ionPopoverWillDismiss", () => { this.dismiss(void 0, void 0, !1); }), this.configureTriggerInteraction(); }
    presentFromTrigger(t, e = !1) { return L(this, null, function* () { this.focusDescendantOnPresent = e, yield this.present(t), this.focusDescendantOnPresent = !1; }); }
    getDelegate(t = !1) { if (this.workingDelegate && !t)
        return { delegate: this.workingDelegate, inline: this.inline }; let e = this.el.parentNode, o = this.inline = e !== null && !this.hasController, r = this.workingDelegate = o ? this.delegate || this.coreDelegate : this.delegate; return { inline: o, delegate: r }; }
    present(t) { return L(this, null, function* () { let e = yield this.lockController.lock(); if (this.presented) {
        e();
        return;
    } let { el: o } = this, { inline: r, delegate: n } = this.getDelegate(!0); this.ionMount.emit(), this.usersElement = yield pe(n, o, this.component, ["popover-viewport"], this.componentProps, r), this.recalculateContentOnHeaderReady(), this.keyboardEvents || this.configureKeyboardInteraction(), this.configureDismissInteraction(), ie(o) ? yield xe(this.usersElement) : this.keepContentsMounted || (yield we()), yield ve(this, "popoverEnter", Ge, Ue, { event: t || this.event, size: this.size, trigger: this.triggerEl, reference: this.reference, side: this.side, align: this.alignment }), this.focusDescendantOnPresent && de(o), e(); }); }
    recalculateContentOnHeaderReady() { var t; let e = (t = this.el.shadowRoot) === null || t === void 0 ? void 0 : t.querySelector(".popover-content"); if (!e)
        return; let o = this.usersElement || e, r = o.querySelector("ion-header"), n = o.querySelectorAll("ion-content"); !r || n.length === 0 || (this.headerResizeObserver = new ResizeObserver(() => L(this, null, function* () { var i; if (r.offsetHeight > 0) {
        (i = this.headerResizeObserver) === null || i === void 0 || i.disconnect(), this.headerResizeObserver = void 0;
        for (let s of n)
            yield s.recalculateDimensions();
    } })), this.headerResizeObserver.observe(r)); }
    dismiss(t, e, o = !0) { return L(this, null, function* () { let r = yield this.lockController.lock(), { destroyKeyboardInteraction: n, destroyDismissInteraction: i } = this; o && this.parentPopover && this.parentPopover.dismiss(t, e, o); let s = yield me(this, t, e, "popoverLeave", He, Je, this.event); if (s) {
        n && (n(), this.destroyKeyboardInteraction = void 0), i && (i(), this.destroyDismissInteraction = void 0);
        let { delegate: a } = this.getDelegate();
        yield ce(a, this.usersElement);
    } return r(), s; }); }
    getParentPopover() { return L(this, null, function* () { return this.parentPopover; }); }
    onDidDismiss() { return te(this.el, "ionPopoverDidDismiss"); }
    onWillDismiss() { return te(this.el, "ionPopoverWillDismiss"); }
    render() { let t = ee(this), { onLifecycle: e, parentPopover: o, dismissOnSelect: r, side: n, arrow: i, htmlAttributes: s, focusTrap: a } = this, p = se("desktop"), c = i && !o; return R(Pe, Object.assign({ key: "2edd8333c630efbce59071f8a383e4326e928dbc", "aria-modal": "true", "no-router": !0, tabindex: "-1" }, s, { style: { zIndex: `${2e4 + this.overlayIndex}` }, class: Object.assign(Object.assign({}, be(this.cssClass)), { [t]: !0, "popover-translucent": this.translucent, "overlay-hidden": !0, "popover-desktop": p, [`popover-side-${n}`]: !0, [ge]: a === !1, "popover-nested": !!o }), onIonPopoverDidPresent: e, onIonPopoverWillPresent: e, onIonPopoverWillDismiss: e, onIonPopoverDidDismiss: e, onIonBackdropTap: this.onBackdropTap }), !o && R("ion-backdrop", { key: "aac4e68b08197534375e8ea3f8c9ea0c10ab2af4", tappable: this.backdropDismiss, visible: this.showBackdrop, part: "backdrop" }), R("div", { key: "b7f4ebf57d4148b32856b0075d286f454be8de5d", class: "popover-wrapper ion-overlay-wrapper", onClick: r ? () => this.dismiss() : void 0 }, c && R("div", { key: "607d94c28d73e8e957175a7c0f6e8a99ec4dcd53", class: "popover-arrow", part: "arrow" }), R("div", { key: "4366a5a5de550c09895e923f345583508e1ec30c", class: "popover-content", part: "content" }, R("slot", { key: "eb7886fbc99c15b667b7d825d24f1c12d9380f03" })))); }
    get el() { return Ae(this); }
    static get watchers() { return { trigger: [{ onTriggerChange: 0 }], triggerAction: [{ onTriggerChange: 0 }], isOpen: [{ onIsOpenChange: 0 }] }; }
}, tt = { ionPopoverDidPresent: "ionViewDidEnter", ionPopoverWillPresent: "ionViewWillEnter", ionPopoverWillDismiss: "ionViewWillLeave", ionPopoverDidDismiss: "ionViewDidLeave" };
et.style = { ios: Qe(), md: Ze() };
export { et as ion_popover };
/*! Bundled license information:

@ionic/core/dist/esm/ion-popover.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
