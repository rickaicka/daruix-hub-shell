import { q as s } from "@nf-internal/chunk-ZLCREYPB";
import "@nf-internal/chunk-DMOCYLK5";
import { c as a } from "@nf-internal/chunk-C2WRTRKV";
import { c as r } from "@nf-internal/chunk-56EKAJ4H";
import "@nf-internal/chunk-EH7P5N2T";
import "@nf-internal/chunk-55MUSWHY";
import "@nf-internal/chunk-6V4UOETA";
import "@nf-internal/chunk-PJKO2XHO";
import { i as l, m as t, n as d, q as m, s as h } from "@nf-internal/chunk-V3JGNOV4";
import "@nf-internal/chunk-JHI3MBHO";
var b = () => '.sc-ion-select-modal-ionic-h{height:100%}ion-list.sc-ion-select-modal-ionic ion-radio.sc-ion-select-modal-ionic::part(container),ion-list.sc-ion-select-modal-ionic ion-radio.sc-ion-select-modal-ionic [part~="container"]{display:none}ion-list.sc-ion-select-modal-ionic ion-radio.sc-ion-select-modal-ionic::part(label),ion-list.sc-ion-select-modal-ionic ion-radio.sc-ion-select-modal-ionic [part~="label"]{margin-left:0;margin-right:0;margin-top:0;margin-bottom:0}ion-item.sc-ion-select-modal-ionic{--inner-border-width:0}.item-radio-checked.sc-ion-select-modal-ionic{--background:rgba(var(--ion-color-primary-rgb, 0, 84, 233), 0.08);--background-focused:var(--ion-color-primary, #0054e9);--background-focused-opacity:0.2;--background-hover:var(--ion-color-primary, #0054e9);--background-hover-opacity:0.12}.item-checkbox-checked.sc-ion-select-modal-ionic{--background-activated:var(--ion-item-color, var(--ion-text-color, #000));--background-focused:var(--ion-item-color, var(--ion-text-color, #000));--background-hover:var(--ion-item-color, var(--ion-text-color, #000));--color:var(--ion-color-primary, #0054e9)}', p = () => '.sc-ion-select-modal-ios-h{height:100%}ion-item.sc-ion-select-modal-ios{--inner-padding-end:0}ion-radio.sc-ion-select-modal-ios::after{bottom:0;position:absolute;width:calc(100% - 0.9375rem - 16px);border-width:0px 0px 0.55px 0px;border-style:solid;border-color:var(--ion-item-border-color, var(--ion-border-color, var(--ion-color-step-250, var(--ion-background-color-step-250, #c8c7cc))));content:""}ion-radio.sc-ion-select-modal-ios::after{inset-inline-start:calc(0.9375rem + 16px)}', u = () => '.sc-ion-select-modal-md-h{height:100%}ion-list.sc-ion-select-modal-md ion-radio.sc-ion-select-modal-md::part(container),ion-list.sc-ion-select-modal-md ion-radio.sc-ion-select-modal-md [part~="container"]{display:none}ion-list.sc-ion-select-modal-md ion-radio.sc-ion-select-modal-md::part(label),ion-list.sc-ion-select-modal-md ion-radio.sc-ion-select-modal-md [part~="label"]{margin-left:0;margin-right:0;margin-top:0;margin-bottom:0}ion-item.sc-ion-select-modal-md{--inner-border-width:0}.item-radio-checked.sc-ion-select-modal-md{--background:rgba(var(--ion-color-primary-rgb, 0, 84, 233), 0.08);--background-focused:var(--ion-color-primary, #0054e9);--background-focused-opacity:0.2;--background-hover:var(--ion-color-primary, #0054e9);--background-hover-opacity:0.12}.item-checkbox-checked.sc-ion-select-modal-md{--background-activated:var(--ion-item-color, var(--ion-text-color, #000));--background-focused:var(--ion-item-color, var(--ion-text-color, #000));--background-hover:var(--ion-item-color, var(--ion-text-color, #000));--color:var(--ion-color-primary, #0054e9)}', f = class {
    constructor(o) { l(this, o), this.pendingEnterTarget = null, this.cancelText = "Close", this.options = []; }
    closeModal() { let o = this.el.closest("ion-modal"); o && o.dismiss(); }
    findOptionFromEvent(o) { let { options: e } = this; return e.find(i => i.value === o.target.value); }
    getValues(o) { let { multiple: e, options: i } = this; if (e)
        return i.filter(c => c.checked).map(c => c.value); let n = o ? this.findOptionFromEvent(o) : null; return n ? n.value : void 0; }
    callOptionHandler(o) { let e = this.findOptionFromEvent(o), i = this.getValues(o); e?.handler && s(e.handler, i); }
    setChecked(o) { let { multiple: e } = this, i = this.findOptionFromEvent(o); e && i && (i.checked = o.detail.checked); }
    renderRadioOptions() { let o = this.options.filter(e => e.checked).map(e => e.value)[0]; return t("ion-radio-group", { value: o, onIonChange: e => this.callOptionHandler(e) }, this.options.map(e => t("ion-item", { lines: "none", class: Object.assign({ "item-radio-checked": e.value === o }, a(e.cssClass)) }, t("ion-radio", { value: e.value, disabled: e.disabled, justify: "start", labelPlacement: "end", onClick: () => this.closeModal(), onKeyDown: i => { i.key === "Enter" && !i.repeat && (this.pendingEnterTarget = i.currentTarget); }, onKeyUp: i => { if (i.key === " ")
            this.closeModal();
        else if (i.key === "Enter") {
            let n = this.pendingEnterTarget === i.currentTarget;
            this.pendingEnterTarget = null, n && this.closeModal();
        } } }, e.text)))); }
    renderCheckboxOptions() { return this.options.map(o => t("ion-item", { class: Object.assign({ "item-checkbox-checked": o.checked }, a(o.cssClass)) }, t("ion-checkbox", { value: o.value, disabled: o.disabled, checked: o.checked, justify: "start", labelPlacement: "end", onIonChange: e => { this.setChecked(e), this.callOptionHandler(e), h(this); } }, o.text))); }
    render() { return t(d, { key: "fda0bf6f93cd5ec9f3c64f88a52de849e0e140a2", class: r(this) }, t("ion-header", { key: "27c0b17175a53db9ff159feeeb96451a3f011dab" }, t("ion-toolbar", { key: "91a4155ebc317fbc9f1bb3e26a7e94754b953c9b" }, this.header !== void 0 && t("ion-title", { key: "f6dae8e4e381f322cc90efefd9bb6ef81d4d2f3e" }, this.header), t("ion-buttons", { key: "e7760532fb2e7e7385ed6e62097d92d96ff20148", slot: "end" }, t("ion-button", { key: "4999b6fc46cba138186546dca67b7950855e6fb7", onClick: () => this.closeModal() }, this.cancelText)))), t("ion-content", { key: "c73f80a4bc25b9061ea65cf11e5d811c1a4d8704" }, t("ion-list", { key: "b21905d15b36ad5eb45845e768918d2763cf48b1" }, this.multiple === !0 ? this.renderCheckboxOptions() : this.renderRadioOptions()))); }
    get el() { return m(this); }
};
f.style = { ionic: b(), ios: p(), md: u() };
export { f as ion_select_modal };
/*! Bundled license information:

@ionic/core/dist/esm/ion-select-modal.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
