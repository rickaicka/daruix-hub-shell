import { a as r } from "@nf-internal/chunk-5F7RQEA2";
import { i as d, m as a, n as h, q as m, r as u } from "@nf-internal/chunk-V3JGNOV4";
import { e as c } from "@nf-internal/chunk-JHI3MBHO";
var f = () => ":host{display:-ms-flexbox;display:flex;height:100%;overflow-x:scroll;-webkit-scroll-snap-type:x mandatory;-ms-scroll-snap-type:x mandatory;scroll-snap-type:x mandatory;scrollbar-width:none;-ms-overflow-style:none}:host::-webkit-scrollbar{display:none}:host(.segment-view-disabled),:host(.segment-view-swipe-disabled){-ms-touch-action:none;touch-action:none;overflow-x:hidden}:host(.segment-view-scroll-disabled){pointer-events:none}:host(.segment-view-disabled){opacity:0.3}", w = () => ":host{display:-ms-flexbox;display:flex;height:100%;overflow-x:scroll;-webkit-scroll-snap-type:x mandatory;-ms-scroll-snap-type:x mandatory;scroll-snap-type:x mandatory;scrollbar-width:none;-ms-overflow-style:none}:host::-webkit-scrollbar{display:none}:host(.segment-view-disabled),:host(.segment-view-swipe-disabled){-ms-touch-action:none;touch-action:none;overflow-x:hidden}:host(.segment-view-scroll-disabled){pointer-events:none}:host(.segment-view-disabled){opacity:0.3}", g = class {
    constructor(e) { d(this, e), this.ionSegmentViewScroll = u(this, "ionSegmentViewScroll", 7), this.scrollEndTimeout = null, this.isTouching = !1, this.disabled = !1, this.swipeGesture = !0; }
    handleScroll(e) { var s; let { scrollLeft: t, scrollWidth: o, clientWidth: l } = e.target, i = o - l, n = (r(this.el) ? -1 : 1) * (t / i); this.ionSegmentViewScroll.emit({ scrollRatio: n, isManualScroll: (s = this.isManualScroll) !== null && s !== void 0 ? s : !0 }), this.resetScrollEndTimeout(); }
    handleScrollStart() { this.scrollEndTimeout && (clearTimeout(this.scrollEndTimeout), this.scrollEndTimeout = null), this.isTouching = !0; }
    handleTouchEnd() { this.isTouching = !1; }
    resetScrollEndTimeout() { this.scrollEndTimeout && (clearTimeout(this.scrollEndTimeout), this.scrollEndTimeout = null), this.scrollEndTimeout = setTimeout(() => { this.checkForScrollEnd(); }, 100); }
    checkForScrollEnd() { this.isTouching || (this.isManualScroll = void 0); }
    setContent(e, s = !0) { return c(this, null, function* () { let o = this.getSegmentContents().findIndex(n => n.id === e); if (o === -1)
        return; this.isManualScroll = !1, this.resetScrollEndTimeout(); let l = this.el.offsetWidth, i = o * l; this.el.scrollTo({ top: 0, left: (r(this.el) ? -1 : 1) * i, behavior: s ? "smooth" : "instant" }); }); }
    getSegmentContents() { return Array.from(this.el.querySelectorAll("ion-segment-content")); }
    render() { let { disabled: e, isManualScroll: s, swipeGesture: t } = this; return a(h, { key: "2a6e0a1046af75b1fa0eed20a5fbbb4634480297", class: { "segment-view-disabled": e, "segment-view-scroll-disabled": s === !1, "segment-view-swipe-disabled": t === !1 } }, a("slot", { key: "644b60d179d0de3fa204e3bef26a3503ceeaf1d6" })); }
    get el() { return m(this); }
};
g.style = { ios: f(), md: w() };
export { g as ion_segment_view };
/*! Bundled license information:

@ionic/core/dist/esm/ion-segment-view.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
