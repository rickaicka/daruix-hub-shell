import { a, b, c, d, e } from "@nf-internal/chunk-6V4UOETA";
import "@nf-internal/chunk-PJKO2XHO";
import "@nf-internal/chunk-V3JGNOV4";
import "@nf-internal/chunk-JHI3MBHO";
export { e as MENU_BACK_BUTTON_PRIORITY, d as OVERLAY_BACK_BUTTON_PRIORITY, b as blockHardwareBackButton, a as shouldUseCloseWatcher, c as startHardwareBackButton };
