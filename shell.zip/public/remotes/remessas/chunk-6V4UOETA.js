import { a as r } from "@nf-internal/chunk-PJKO2XHO";
import { a as d, f as u } from "@nf-internal/chunk-V3JGNOV4";
import { e as l } from "@nf-internal/chunk-JHI3MBHO";
var h = () => d.get("experimentalCloseWatcher", !1) && r !== void 0 && "CloseWatcher" in r, E = () => { document.addEventListener("backbutton", () => { }); }, k = () => { let c = document, a = !1, s = () => { if (a)
    return; let o = 0, n = [], f = new CustomEvent("ionBackButton", { bubbles: !1, detail: { register(t, e) { n.push({ priority: t, handler: e, id: o++ }); } } }); c.dispatchEvent(f); let p = t => l(null, null, function* () { try {
    if (t?.handler) {
        let e = t.handler(i);
        e != null && (yield e);
    }
}
catch (e) {
    u("[ion-app] - Exception in startHardwareBackButton:", e);
} }), i = () => { if (n.length > 0) {
    let t = { priority: Number.MIN_SAFE_INTEGER, handler: () => { }, id: -1 };
    n.forEach(e => { e.priority >= t.priority && (t = e); }), a = !0, n = n.filter(e => e.id !== t.id), p(t).then(() => a = !1);
} }; i(); }; if (h()) {
    let o, n = () => { o?.destroy(), o = new r.CloseWatcher, o.onclose = () => { s(), n(); }; };
    n();
}
else
    c.addEventListener("backbutton", s); }, m = 100, v = 99;
export { h as a, E as b, k as c, m as d, v as e };
/*! Bundled license information:

@ionic/core/dist/esm/hardware-back-button-B93Gru0Y.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
