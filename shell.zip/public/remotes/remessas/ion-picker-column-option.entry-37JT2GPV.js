import { b as n } from "@nf-internal/chunk-C2WRTRKV";
import { c as e } from "@nf-internal/chunk-56EKAJ4H";
import { d as o } from "@nf-internal/chunk-EH7P5N2T";
import { i as r, m as i, n as a, q as l } from "@nf-internal/chunk-V3JGNOV4";
import "@nf-internal/chunk-JHI3MBHO";
var d = () => ".picker-column-option-button{padding-left:0;padding-right:0;padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;margin-top:0;margin-bottom:0;width:100%;height:34px;border:0px;outline:none;background:transparent;color:inherit;font-family:var(--ion-font-family, inherit);font-size:inherit;line-height:34px;text-align:inherit;text-overflow:ellipsis;white-space:nowrap;cursor:pointer;overflow:hidden}:host(.option-disabled){opacity:0.4}:host(.option-disabled) .picker-column-option-button{cursor:default}", h = () => ".picker-column-option-button{padding-left:0;padding-right:0;padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;margin-top:0;margin-bottom:0;width:100%;height:34px;border:0px;outline:none;background:transparent;color:inherit;font-family:var(--ion-font-family, inherit);font-size:inherit;line-height:34px;text-align:inherit;text-overflow:ellipsis;white-space:nowrap;cursor:pointer;overflow:hidden}:host(.option-disabled){opacity:0.4}:host(.option-disabled) .picker-column-option-button{cursor:default}:host(.option-active),:host([part~=active]){color:var(--ion-color-base)}", b = class {
    constructor(t) { r(this, t), this.pickerColumn = null, this.ariaLabel = null, this.disabled = !1, this.color = "primary"; }
    onAriaLabelChange(t) { this.ariaLabel = t; }
    componentWillLoad() { let t = o(this.el, ["aria-label"]); this.ariaLabel = t["aria-label"] || null; }
    connectedCallback() { this.pickerColumn = this.el.closest("ion-picker-column"); }
    disconnectedCallback() { this.pickerColumn = null; }
    componentDidLoad() { let { pickerColumn: t } = this; t !== null && t.scrollActiveItemIntoView(); }
    onClick() { let { pickerColumn: t } = this; t !== null && t.setValue(this.value); }
    render() { let { color: t, disabled: s, ariaLabel: c } = this, p = e(this); return i(a, { key: "c45a1c14a351bf57d7113671164852349be5aa8a", class: n(t, { [p]: !0, "option-disabled": s }) }, i("div", { key: "824930b658c6e3fb493ac4c6c2451d38c6bc4829", class: "picker-column-option-button", role: "button", "aria-label": c, onClick: () => this.onClick() }, i("slot", { key: "019df4dcf46e629bdbebcd46ed3ab29669feab27" }))); }
    get el() { return l(this); }
    static get watchers() { return { "aria-label": [{ onAriaLabelChange: 0 }] }; }
};
b.style = { ios: d(), md: h() };
export { b as ion_picker_column_option };
/*! Bundled license information:

@ionic/core/dist/esm/ion-picker-column-option.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
