import { f as d } from "@nf-internal/chunk-CQE4ZXWS";
var h = (e, a = 0) => new Promise(r => { c(e, a, r); }), c = (e, a = 0, r) => { let t, n, i = { passive: !0 }, l = () => { t && t(); }, o = s => { s !== void 0 && e !== s.target || (l(), r(s)); }; return e && (e.addEventListener("webkitTransitionEnd", o, i), e.addEventListener("transitionend", o, i), n = setTimeout(o, a + 500), t = () => { n !== void 0 && (clearTimeout(n), n = void 0), e.removeEventListener("webkitTransitionEnd", o, i), e.removeEventListener("transitionend", o, i); }), l; }, f = (e, a) => { e.componentOnReady ? e.componentOnReady().then(r => a(r)) : p(() => a(e)); }, y = e => e.componentOnReady !== void 0, u = (e, a = []) => { let r = {}; return a.forEach(t => { e.hasAttribute(t) && (e.getAttribute(t) !== null && (r[t] = e.getAttribute(t)), e.removeAttribute(t)); }), r; }, m = ["role", "aria-activedescendant", "aria-atomic", "aria-autocomplete", "aria-braillelabel", "aria-brailleroledescription", "aria-busy", "aria-checked", "aria-colcount", "aria-colindex", "aria-colindextext", "aria-colspan", "aria-controls", "aria-current", "aria-describedby", "aria-description", "aria-details", "aria-disabled", "aria-errormessage", "aria-expanded", "aria-flowto", "aria-haspopup", "aria-hidden", "aria-invalid", "aria-keyshortcuts", "aria-label", "aria-labelledby", "aria-level", "aria-live", "aria-multiline", "aria-multiselectable", "aria-orientation", "aria-owns", "aria-placeholder", "aria-posinset", "aria-pressed", "aria-readonly", "aria-relevant", "aria-required", "aria-roledescription", "aria-rowcount", "aria-rowindex", "aria-rowindextext", "aria-rowspan", "aria-selected", "aria-setsize", "aria-sort", "aria-valuemax", "aria-valuemin", "aria-valuenow", "aria-valuetext"], w = e => u(e, m), x = (e, a, r, t) => e.addEventListener(a, r, t), g = (e, a, r, t) => e.removeEventListener(a, r, t), E = (e, a = e) => e.shadowRoot || a, p = e => typeof __zone_symbol__requestAnimationFrame == "function" ? __zone_symbol__requestAnimationFrame(e) : typeof requestAnimationFrame == "function" ? requestAnimationFrame(e) : setTimeout(e), _ = e => !!e.shadowRoot && !!e.attachShadow, T = e => { if (e.focus(), e.classList.contains("ion-focusable")) {
    let a = e.closest("ion-app");
    a && a.setFocus([e]);
} }, A = (e, a, r, t, n) => { {
    let i = a.querySelector("input.aux-input");
    i || (i = a.ownerDocument.createElement("input"), i.type = "hidden", i.classList.add("aux-input"), a.appendChild(i)), i.disabled = n, i.name = r, i.value = t || "";
} }, L = (e, a, r) => Math.max(e, Math.min(a, r)), k = (e, a) => { if (!e) {
    let r = "ASSERT: " + a;
    throw d(r), new Error(r);
} }, q = e => { if (e) {
    let a = e.changedTouches;
    if (a && a.length > 0) {
        let r = a[0];
        return { x: r.clientX, y: r.clientY };
    }
    if (e.pageX !== void 0)
        return { x: e.pageX, y: e.pageY };
} return { x: 0, y: 0 }; }, F = e => { let a = document.dir === "rtl"; switch (e) {
    case "start": return a;
    case "end": return !a;
    default: throw new Error(`"${e}" is not a valid value for [side]. Use "start" or "end" instead.`);
} }, R = (e, a) => { let r = e._original || e; return { _original: e, emit: v(r.emit.bind(r), a) }; }, v = (e, a = 0) => { let r; return (...t) => { clearTimeout(r), r = setTimeout(e, a, ...t); }; }, O = (e, a) => { if (e != null || (e = {}), a != null || (a = {}), e === a)
    return !0; let r = Object.keys(e); if (r.length !== Object.keys(a).length)
    return !1; for (let t of r)
    if (!(t in a) || e[t] !== a[t])
        return !1; return !0; }, j = e => typeof e == "number" && !isNaN(e) && isFinite(e);
export { h as a, f as b, y as c, u as d, w as e, x as f, g, E as h, p as i, _ as j, T as k, A as l, L as m, k as n, q as o, F as p, R as q, O as r, j as s };
/*! Bundled license information:

@ionic/core/components/p-Baq1XyAy.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
