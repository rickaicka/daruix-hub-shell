import { o as T } from "@nf-internal/chunk-6V6Z65ZI";
import "@nf-internal/chunk-CQE4ZXWS";
import { b as c } from "@nf-internal/chunk-JYWXGWOM";
import "@nf-internal/chunk-JHI3MBHO";
var x = o => { if (c === void 0)
    return; let t, s, i, f = 0, g = o.getBoolean("animated", !0) && o.getBoolean("rippleEffect", !0), d = new WeakMap, p = () => { i && clearTimeout(i), i = void 0, t && (L(!1), t = void 0); }, u = (e, n) => { if (e && e === t)
    return; i && clearTimeout(i), i = void 0; let { x: r, y: a } = T(n); if (t) {
    if (d.has(t))
        throw new Error("internal error");
    t.classList.contains(l) || v(t, r, a), L(!0);
} if (e) {
    let w = d.get(e);
    w && (clearTimeout(w), d.delete(e)), e.classList.remove(l);
    let h = () => { v(e, r, a), i = void 0; };
    E(e) ? h() : i = setTimeout(h, y);
} t = e; }, v = (e, n, r) => { if (f = Date.now(), e.classList.add(l), !g)
    return; let a = q(e); a !== null && (m(), s = a.addRipple(n, r)); }, m = () => { s !== void 0 && (s.then(e => e()), s = void 0); }, L = e => { m(); let n = t; if (!n)
    return; let r = b - Date.now() + f; if (e && r > 0 && !E(n)) {
    let a = setTimeout(() => { n.classList.remove(l), d.delete(n); }, b);
    d.set(n, a);
}
else
    n.classList.remove(l); }; c.addEventListener("ionGestureCaptured", p), c.addEventListener("pointerdown", e => { t || e.button === 2 || u(R(e), e); }, !0), c.addEventListener("pointerup", e => { u(void 0, e); }, !0), c.addEventListener("pointercancel", p, !0); }, R = o => { if (o.composedPath === void 0)
    return o.target.closest(".ion-activatable"); {
    let t = o.composedPath();
    for (let s = 0; s < t.length - 2; s++) {
        let i = t[s];
        if (!(i instanceof ShadowRoot) && i.classList.contains("ion-activatable"))
            return i;
    }
} }, E = o => o.classList.contains("ion-activatable-instant"), q = o => { if (o.shadowRoot) {
    let t = o.shadowRoot.querySelector("ion-ripple-effect");
    if (t)
        return t;
} return o.querySelector("ion-ripple-effect"); }, l = "ion-activated", y = 100, b = 150;
export { x as startTapClick };
/*! Bundled license information:

@ionic/core/components/p-C4t5ymfq.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
