import { g as h } from "@nf-internal/chunk-54RDICHU";
import "@nf-internal/chunk-JHI3MBHO";
import { DOCUMENT as u } from "@angular/common";
import * as l from "@angular/core";
import { InjectionToken as g, inject as a, Injector as p, \u0275RuntimeError as m, \u0275ChangeDetectionScheduler as y, \u0275performanceMarkFeature as f, makeEnvironmentProviders as _, RendererFactory2 as A, ANIMATION_MODULE_TYPE as v, NgZone as F } from "@angular/core";
var R = "@", I = (() => { class i {
    doc;
    delegate;
    zone;
    animationType;
    moduleImpl;
    _rendererFactoryPromise = null;
    scheduler = null;
    injector = a(p);
    loadingSchedulerFn = a(S, { optional: !0 });
    _engine;
    constructor(t, n, r, o, s) { this.doc = t, this.delegate = n, this.zone = r, this.animationType = o, this.moduleImpl = s; }
    ngOnDestroy() { this._engine?.flush(); }
    loadImpl() { let t = () => this.moduleImpl ?? import("@angular/animations/browser").then(r => r), n; return this.loadingSchedulerFn ? n = this.loadingSchedulerFn(t) : n = t(), n.catch(r => { throw new m(5300, !1); }).then(({ \u0275createEngine: r, \u0275AnimationRendererFactory: o }) => { this._engine = r(this.animationType, this.doc); let s = new o(this.delegate, this._engine, this.zone); return this.delegate = s, s; }); }
    createRenderer(t, n) { let r = this.delegate.createRenderer(t, n); if (r.\u0275type === 0)
        return r; typeof r.throwOnSyntheticProps == "boolean" && (r.throwOnSyntheticProps = !1); let o = new d(r); return n?.data?.animation && !this._rendererFactoryPromise && (this._rendererFactoryPromise = this.loadImpl()), this._rendererFactoryPromise?.then(s => { let c = s.createRenderer(t, n); o.use(c), this.scheduler ??= this.injector.get(y, null, { optional: !0 }), this.scheduler?.notify(10); }).catch(s => { o.use(r); }), o; }
    begin() { this.delegate.begin?.(); }
    end() { this.delegate.end?.(); }
    whenRenderingDone() { return this.delegate.whenRenderingDone?.() ?? Promise.resolve(); }
    componentReplaced(t) { this._engine?.flush(), this.delegate.componentReplaced?.(t); }
    static \u0275fac = function (n) { l.\u0275\u0275invalidFactory(); };
    static \u0275prov = l.\u0275\u0275defineInjectable({ token: i, factory: i.\u0275fac });
} return i; })(), d = class {
    delegate;
    replay = [];
    \u0275type = 1;
    constructor(e) { this.delegate = e; }
    use(e) { if (this.delegate = e, this.replay !== null) {
        for (let t of this.replay)
            t(e);
        this.replay = null;
    } }
    get data() { return this.delegate.data; }
    destroy() { this.replay = null, this.delegate.destroy(); }
    createElement(e, t) { return this.delegate.createElement(e, t); }
    createComment(e) { return this.delegate.createComment(e); }
    createText(e) { return this.delegate.createText(e); }
    get destroyNode() { return this.delegate.destroyNode; }
    appendChild(e, t) { this.delegate.appendChild(e, t); }
    insertBefore(e, t, n, r) { this.delegate.insertBefore(e, t, n, r); }
    removeChild(e, t, n, r) { this.delegate.removeChild(e, t, n, r); }
    selectRootElement(e, t) { return this.delegate.selectRootElement(e, t); }
    parentNode(e) { return this.delegate.parentNode(e); }
    nextSibling(e) { return this.delegate.nextSibling(e); }
    setAttribute(e, t, n, r) { this.delegate.setAttribute(e, t, n, r); }
    removeAttribute(e, t, n) { this.delegate.removeAttribute(e, t, n); }
    addClass(e, t) { this.delegate.addClass(e, t); }
    removeClass(e, t) { this.delegate.removeClass(e, t); }
    setStyle(e, t, n, r) { this.delegate.setStyle(e, t, n, r); }
    removeStyle(e, t, n) { this.delegate.removeStyle(e, t, n); }
    setProperty(e, t, n) { this.shouldReplay(t) && this.replay.push(r => r.setProperty(e, t, n)), this.delegate.setProperty(e, t, n); }
    setValue(e, t) { this.delegate.setValue(e, t); }
    listen(e, t, n, r) { return this.shouldReplay(t) && this.replay.push(o => o.listen(e, t, n, r)), this.delegate.listen(e, t, n, r); }
    shouldReplay(e) { return this.replay !== null && e.startsWith(R); }
}, S = new g("");
function w(i = "animations") { return f("NgAsyncAnimations"), typeof ngServerMode < "u" && ngServerMode && (i = "noop"), _([{ provide: A, useFactory: () => new I(a(u), a(h), a(F), i) }, { provide: v, useValue: i === "noop" ? "NoopAnimations" : "BrowserAnimations" }]); }
export { w as provideAnimationsAsync, S as \u0275ASYNC_ANIMATION_LOADING_SCHEDULER_FN, I as \u0275AsyncAnimationRendererFactory };
/*! Bundled license information:

@angular/platform-browser/fesm2022/animations-async.mjs:
  (**
   * @license Angular v21.2.18
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
