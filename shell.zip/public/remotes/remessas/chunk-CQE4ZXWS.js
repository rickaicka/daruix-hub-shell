import { a as K, e as se } from "@nf-internal/chunk-JHI3MBHO";
var _e = class {
    constructor() { this.m = new Map; }
    reset(t) { this.m = new Map(Object.entries(t)); }
    get(t, n) { let s = this.m.get(t); return s !== void 0 ? s : n; }
    getBoolean(t, n = !1) { let s = this.m.get(t); return s === void 0 ? n : typeof s == "string" ? s === "true" : !!s; }
    getNumber(t, n) { let s = parseFloat(this.m.get(t)); return isNaN(s) ? n !== void 0 ? n : NaN : s; }
    set(t, n) { this.m.set(t, n); }
}, rt = new _e, vn = e => { try {
    let t = e.sessionStorage.getItem(it);
    return t !== null ? JSON.parse(t) : {};
}
catch {
    return {};
} }, bn = (e, t) => { try {
    e.sessionStorage.setItem(it, JSON.stringify(t));
}
catch {
    return;
} }, Nn = e => { let t = {}; return e.location.search.slice(1).split("&").map(n => n.split("=")).map(([n, s]) => { try {
    return [decodeURIComponent(n), decodeURIComponent(s)];
}
catch {
    return ["", ""];
} }).filter(([n]) => xt(n, We)).map(([n, s]) => [n.slice(We.length), s]).forEach(([n, s]) => { t[n] = s; }), t; }, xt = (e, t) => e.substr(0, t.length) === t, We = "ionic:", it = "ionic-persist-config", H;
(function (e) { e.OFF = "OFF", e.ERROR = "ERROR", e.WARN = "WARN"; })(H || (H = {}));
var Sn = (e, ...t) => { let n = rt.get("logLevel", H.WARN); if ([H.WARN].includes(n))
    return console.warn(`[Ionic Warning]: ${e}`, ...t); }, _n = (e, ...t) => { let n = rt.get("logLevel", H.ERROR); if ([H.ERROR, H.WARN].includes(n))
    return console.error(`[Ionic Error]: ${e}`, ...t); }, wn = (e, ...t) => console.error(`<${e.tagName.toLowerCase()}> must be used inside ${t.join(" or ")}.`), kn = { isBrowser: !0 }, lt = (e => (e.Undefined = "undefined", e.Null = "null", e.String = "string", e.Number = "number", e.SpecialNumber = "number", e.Boolean = "boolean", e.BigInt = "bigint", e))(lt || {}), ct = (e => (e.Array = "array", e.Date = "date", e.Map = "map", e.Object = "object", e.RegularExpression = "regexp", e.Set = "set", e.Channel = "channel", e.Symbol = "symbol", e))(ct || {}), Ne = "type", Se = "value", De = "serialized:";
function dt(e, t, n) { let s = typeof HTMLElement < "u" ? HTMLElement.prototype : null; for (; e && e !== s;) {
    let o = Object.getOwnPropertyDescriptor(e, t);
    if (o && (!n || o.get))
        return o;
    e = Object.getPrototypeOf(e);
} }
var Y, Rt = (e, t) => { var n; Object.entries((n = t.o.t) != null ? n : {}).map(([s, [o]]) => { if (31 & o || 32 & o) {
    let r = e[s], i = dt(Object.getPrototypeOf(e), s, !0) || Object.getOwnPropertyDescriptor(e, s);
    i && Object.defineProperty(e, s, { get() { return i.get.call(this); }, set(l) { i.set.call(this, l); }, configurable: !0, enumerable: !0 }), t.l.has(s) ? e[s] = t.l.get(s) : r !== void 0 && (e[s] = r);
} }); }, P = e => { if (e.__stencil__getHostRef)
    return e.__stencil__getHostRef(); }, Ie = (e, t) => t in e, U = (e, t) => (0, console.error)(e, t), le = new Map, at = [], Z = "s-id", ce = "sty-id", He = "c-id", Fe = "http://www.w3.org/1999/xlink", g = typeof window < "u" ? window : {}, jn = g.HTMLElement || class {
}, N = { i: 0, u: "", jmp: e => e(), raf: e => requestAnimationFrame(e), ael: (e, t, n, s) => e.addEventListener(t, n, s), rel: (e, t, n, s) => e.removeEventListener(t, n, s), ce: (e, t) => new CustomEvent(e, t) }, $t = (() => { var e; let t = !1; try {
    (e = g.document) == null || e.addEventListener("e", null, Object.defineProperty({}, "passive", { get() { t = !0; } }));
}
catch { } return t; })(), $e = (() => { try {
    return !!g.document.adoptedStyleSheets && (new CSSStyleSheet, typeof new CSSStyleSheet().replaceSync == "function");
}
catch { } return !1; })(), we = !!$e && !!g.document && Object.getOwnPropertyDescriptor(g.document.adoptedStyleSheets, "length").writable, ke = !1, je = [], ut = [], ht = (e, t) => n => { e.push(n), ke || (ke = !0, t && 4 & N.i ? Te(Oe) : N.raf(Oe)); }, Ue = e => { for (let t = 0; t < e.length; t++)
    try {
        e[t](performance.now());
    }
    catch (n) {
        U(n);
    } e.length = 0; }, Oe = () => { Ue(je), Ue(ut), (ke = je.length > 0) && N.raf(Oe); }, Te = e => Promise.resolve(void 0).then(e), On = ht(je, !1), ft = ht(ut, !0), En = e => { let t = new URL(e, N.u); return t.origin !== g.location.origin ? t.href : t.pathname; };
function Tt(e) { let t = { mode: "open" }; t.delegatesFocus = !!(16 & e.i); let n = this.attachShadow(t); Y === void 0 && (Y = null), Y && (we ? n.adoptedStyleSheets.push(Y) : n.adoptedStyleSheets = [...n.adoptedStyleSheets, Y]); }
var fe = e => { let t = C(e, "childNodes"); e.tagName && e.tagName.includes("-") && e["s-cr"] && e.tagName !== "SLOT-FB" && te(t, e.tagName).forEach(s => { s.nodeType === 1 && s.tagName === "SLOT-FB" && (s.hidden = !!Le(s, J(s), !1).length); }); let n = 0; for (n = 0; n < t.length; n++) {
    let s = t[n];
    s.nodeType === 1 && C(s, "childNodes").length && fe(s);
} }, Q = e => { let t = []; for (let n = 0; n < e.length; n++) {
    let s = e[n]["s-nr"] || void 0;
    s && s.isConnected && t.push(s);
} return t; };
function te(e, t, n) { let s, o = 0, r = []; for (; o < e.length; o++) {
    if (s = e[o], s["s-sr"] && (!t || s["s-hn"] === t) && (n === void 0 || J(s) === n) && (r.push(s), n !== void 0))
        return r;
    r = [...r, ...te(s.childNodes, t, n)];
} return r; }
var Le = (e, t, n = !0) => { let s = []; (n && e["s-sr"] || !e["s-sr"]) && s.push(e); let o = e; for (; o = o.nextSibling;)
    J(o) !== t || !n && o["s-sr"] || s.push(o); return s; }, qe = (e, t) => e.nodeType === 1 ? e.getAttribute("slot") === null && t === "" || e.getAttribute("slot") === t : e["s-sn"] === t || t === "", pe = (e, t, n, s) => { if (e["s-ol"] && e["s-ol"].isConnected)
    return; let o = document.createTextNode(""); if (o["s-nr"] = e, !t["s-cr"] || !t["s-cr"].parentNode)
    return; let r = t["s-cr"].parentNode, i = C(r, n ? "prepend" : "appendChild"); if (s !== void 0) {
    o["s-oo"] = s;
    let l = C(r, "childNodes"), a = [o];
    l.forEach(c => { c["s-nr"] && a.push(c); }), a.sort((c, d) => !c["s-oo"] || c["s-oo"] < (d["s-oo"] || 0) ? -1 : !d["s-oo"] || d["s-oo"] < c["s-oo"] ? 1 : 0), a.forEach(c => i.call(r, c));
}
else
    i.call(r, o); e["s-ol"] = o, e["s-sh"] = t["s-hn"]; }, J = e => typeof e["s-sn"] == "string" ? e["s-sn"] : e.nodeType === 1 && e.getAttribute("slot") || void 0;
function pt(e) {
    if (e.assignedElements || e.assignedNodes || !e["s-sr"])
        return;
    let t = n => function (s) {
        let o = [], r = this["s-sn"];
        s?.flatten && console.error(`
          Flattening is not supported for Stencil non-shadow slots.
          You can use \`.childNodes\` to nested slot fallback content.
          If you have a particular use case, please open an issue on the Stencil repo.
        `);
        let i = this["s-cr"].parentElement;
        return (i.__childNodes ? i.childNodes : Q(i.childNodes)).forEach(l => { r === J(l) && o.push(l); }), n ? o.filter(l => l.nodeType === 1) : o;
    }.bind(e);
    e.assignedElements = t(!0), e.assignedNodes = t(!1);
}
function me(e) { e.dispatchEvent(new CustomEvent("slotchange", { bubbles: !1, cancelable: !1, composed: !1 })); }
function Pe(e, t) { var n; if (!(t = t || ((n = e["s-ol"]) == null ? void 0 : n.parentElement)))
    return { slotNode: null, slotName: "" }; let s = e["s-sn"] = J(e) || ""; return { slotNode: te(C(t, "childNodes"), t.tagName, s)[0], slotName: s }; }
var ze = e => { if (e.__cloneNode)
    return; let t = e.__cloneNode = e.cloneNode; e.cloneNode = function (n) { let s = this.shadowRoot && !0, o = t.call(this, !!s && n); if (!s && n) {
    let r, i, l = 0, a = ["s-id", "s-cr", "s-lr", "s-rc", "s-sc", "s-p", "s-cn", "s-sr", "s-sn", "s-hn", "s-ol", "s-nr", "s-si", "s-rf", "s-scs"], c = this.__childNodes || this.childNodes;
    for (; l < c.length; l++)
        r = c[l]["s-nr"], i = a.every(d => !c[l][d]), r && (o.__appendChild ? o.__appendChild(r.cloneNode(!0)) : o.appendChild(r.cloneNode(!0))), i && o.appendChild(c[l].cloneNode(!0));
} return o; }; }, Lt = e => { e.__appendChild || (e.__appendChild = e.appendChild, e.appendChild = function (t) { let { slotName: n, slotNode: s } = Pe(t, this); if (s) {
    pe(t, s);
    let o = Le(s, n), r = o[o.length - 1], i = C(r, "parentNode"), l = C(i, "insertBefore")(t, r.nextSibling);
    return me(s), fe(this), l;
} return this.__appendChild(t); }); }, Pt = e => { e.__removeChild || (e.__removeChild = e.removeChild, e.removeChild = function (t) { return t && t["s-sn"] !== void 0 && te(this.__childNodes || this.childNodes, this.tagName, t["s-sn"]) && t.isConnected ? (t.remove(), void fe(this)) : this.__removeChild(t); }); }, Vt = e => { e.__prepend || (e.__prepend = e.prepend, e.prepend = function (...t) { t.forEach(n => { typeof n == "string" && (n = this.ownerDocument.createTextNode(n)); let s = (n["s-sn"] = J(n)) || "", o = te(C(this, "childNodes"), this.tagName, s)[0]; if (o) {
    pe(n, o, !0);
    let r = Le(o, s)[0], i = C(r, "parentNode"), l = C(i, "insertBefore")(n, C(r, "nextSibling"));
    return me(o), l;
} return n.nodeType === 1 && n.getAttribute("slot") && (n.hidden = !0), e.__prepend(n); }); }); }, Bt = e => { e.__append || (e.__append = e.append, e.append = function (...t) { t.forEach(n => { typeof n == "string" && (n = this.ownerDocument.createTextNode(n)), this.appendChild(n); }); }); }, Mt = e => { if (e.__insertAdjacentHTML)
    return; let t = e.insertAdjacentHTML; e.insertAdjacentHTML = function (n, s) { if (n !== "afterbegin" && n !== "beforeend")
    return t.call(this, n, s); let o = this.ownerDocument.createElement("_"), r; if (o.innerHTML = s, n === "afterbegin")
    for (; r = o.firstChild;)
        this.prepend(r);
else if (n === "beforeend")
    for (; r = o.firstChild;)
        this.append(r); }; }, Wt = e => { e.insertAdjacentText = function (t, n) { this.insertAdjacentHTML(t, n); }; }, Dt = e => { e.__insertBefore || e.__insertBefore || (e.__insertBefore = e.insertBefore, e.insertBefore = function (t, n) { let { slotName: s, slotNode: o } = Pe(t, this), r = this.__childNodes ? this.childNodes : Q(this.childNodes); if (o) {
    let l = !1;
    if (r.forEach(a => { if (!(a !== n && n !== null)) {
        if (l = !0, n === null || s !== n["s-sn"])
            return void this.appendChild(t);
        if (s === n["s-sn"]) {
            pe(t, o);
            let c = C(n, "parentNode");
            C(c, "insertBefore")(t, n), me(o);
        }
    } }), l)
        return t;
} let i = n?.__parentNode; return i && !this.isSameNode(i) ? this.appendChild(t) : this.__insertBefore(t, n); }); }, It = e => { if (e.__insertAdjacentElement)
    return; let t = e.insertAdjacentElement; e.insertAdjacentElement = function (n, s) { return n !== "afterbegin" && n !== "beforeend" ? t.call(this, n, s) : n === "afterbegin" ? (this.prepend(s), s) : (n === "beforeend" && this.append(s), s); }; }, Ht = e => { V("textContent", e), Object.defineProperty(e, "textContent", { get: function () { let t = ""; return (this.__childNodes ? this.childNodes : Q(this.childNodes)).forEach(n => t += n.textContent || ""), t; }, set: function (t) { (this.__childNodes ? this.childNodes : Q(this.childNodes)).forEach(n => { n["s-ol"] && n["s-ol"].remove(), n.remove(); }), this.insertAdjacentHTML("beforeend", t); } }); }, Ft = e => { class t extends Array {
    item(s) { return this[s]; }
} V("children", e), Object.defineProperty(e, "children", { get() { return this.childNodes.filter(n => n.nodeType === 1); } }), Object.defineProperty(e, "childElementCount", { get() { return this.children.length; } }), V("firstChild", e), Object.defineProperty(e, "firstChild", { get() { return this.childNodes[0]; } }), V("lastChild", e), Object.defineProperty(e, "lastChild", { get() { return this.childNodes[this.childNodes.length - 1]; } }), V("childNodes", e), Object.defineProperty(e, "childNodes", { get() { let n = new t; return n.push(...Q(this.__childNodes)), n; } }); }, Ut = e => { e && !e.__nextSibling && (V("nextSibling", e), Object.defineProperty(e, "nextSibling", { get: function () { var t; let n = (t = this["s-ol"]) == null ? void 0 : t.parentNode.childNodes, s = n?.indexOf(this); return n && s > -1 ? n[s + 1] : this.__nextSibling; } })); }, qt = e => { e && !e.__nextElementSibling && (V("nextElementSibling", e), Object.defineProperty(e, "nextElementSibling", { get: function () { var t; let n = (t = this["s-ol"]) == null ? void 0 : t.parentNode.children, s = n?.indexOf(this); return n && s > -1 ? n[s + 1] : this.__nextElementSibling; } })); }, zt = e => { e && !e.__previousSibling && (V("previousSibling", e), Object.defineProperty(e, "previousSibling", { get: function () { var t; let n = (t = this["s-ol"]) == null ? void 0 : t.parentNode.childNodes, s = n?.indexOf(this); return n && s > -1 ? n[s - 1] : this.__previousSibling; } })); }, Jt = e => { e && !e.__previousElementSibling && (V("previousElementSibling", e), Object.defineProperty(e, "previousElementSibling", { get: function () { var t; let n = (t = this["s-ol"]) == null ? void 0 : t.parentNode.children, s = n?.indexOf(this); return n && s > -1 ? n[s - 1] : this.__previousElementSibling; } })); }, mt = e => { e && !e.__parentNode && (V("parentNode", e), Object.defineProperty(e, "parentNode", { get: function () { var t; return ((t = this["s-ol"]) == null ? void 0 : t.parentNode) || this.__parentNode; }, set: function (t) { this.__parentNode = t; } })); }, Kt = ["children", "nextElementSibling", "previousElementSibling"], Yt = ["childNodes", "firstChild", "lastChild", "nextSibling", "previousSibling", "textContent", "parentNode"];
function V(e, t) { if (!globalThis.Node || !globalThis.Element)
    return; let n; Kt.includes(e) ? n = Object.getOwnPropertyDescriptor(Element.prototype, e) : Yt.includes(e) && (n = Object.getOwnPropertyDescriptor(Node.prototype, e)), n || (n = Object.getOwnPropertyDescriptor(t, e)), n && Object.defineProperty(t, "__" + e, n); }
function C(e, t) { if ("__" + t in e) {
    let n = e["__" + t];
    return typeof n != "function" ? n : n.bind(e);
} return typeof e[t] != "function" ? e[t] : e[t].bind(e); }
var D = new WeakMap, gt = (e, t, n) => { let s = le.get(e); $e && n ? (s = s || new CSSStyleSheet, typeof s == "string" ? s = t : s.replaceSync(t)) : s = t, le.set(e, s); }, yt = (e, t, n) => { var s, o, r; let i = re(t, n), l = le.get(i); if (!g.document)
    return i; if (e = e.nodeType === 11 ? e : g.document, l)
    if (typeof l == "string") {
        let a, c = D.get(e = e.head || e);
        c || D.set(e, c = new Set);
        let d = e.querySelector(`[${ce}="${i}"]`);
        if (d)
            d.textContent = l;
        else if (!c.has(i)) {
            a = g.document.createElement("style"), a.textContent = l;
            let h = (s = N.h) != null ? s : (function () { var u, p, f; return (f = (p = (u = g.document.head) == null ? void 0 : u.querySelector('meta[name="csp-nonce"]')) == null ? void 0 : p.getAttribute("content")) != null ? f : void 0; })();
            if (h != null && a.setAttribute("nonce", h), !(1 & t.i))
                if (e.nodeName === "HEAD") {
                    let u = e.querySelectorAll("link[rel=preconnect]"), p = u.length > 0 ? u[u.length - 1].nextSibling : e.querySelector("style");
                    e.insertBefore(a, p?.parentNode === e ? p : null);
                }
                else if ("host" in e)
                    if ($e) {
                        let u = new ((o = e.defaultView) != null ? o : e.ownerDocument.defaultView).CSSStyleSheet;
                        u.replaceSync(l), we ? e.adoptedStyleSheets.unshift(u) : e.adoptedStyleSheets = [u, ...e.adoptedStyleSheets];
                    }
                    else {
                        let u = e.querySelector("style");
                        u ? u.textContent = l + u.textContent : e.prepend(a);
                    }
                else
                    e.append(a);
            1 & t.i && e.insertBefore(a, null), 4 & t.i && (a.textContent += "slot-fb{display:contents}slot-fb[hidden]{display:none}"), c && c.add(i);
        }
    }
    else {
        let a = D.get(e);
        if (a || D.set(e, a = new Set), !a.has(i)) {
            let c = (r = e.defaultView) != null ? r : e.ownerDocument.defaultView, d;
            if (l.constructor === c.CSSStyleSheet)
                d = l;
            else {
                d = new c.CSSStyleSheet;
                for (let h = 0; h < l.cssRules.length; h++)
                    d.insertRule(l.cssRules[h].cssText, h);
            }
            if (we ? e.adoptedStyleSheets.push(d) : e.adoptedStyleSheets = [...e.adoptedStyleSheets, d], a.add(i), "host" in e) {
                let h = e.querySelector(`[${ce}="${i}"]`);
                h && ft(() => h.remove());
            }
        }
    } return i; }, re = (e, t) => "sc-" + (t && 32 & e.i ? e.p + "-" + t : e.p), Ve = e => (e = typeof e) == "object" || e === "function", vt = (e, t, ...n) => { let s = null, o = null, r = null, i = !1, l = !1, a = [], c = h => { for (let u = 0; u < h.length; u++)
    s = h[u], Array.isArray(s) ? c(s) : s != null && typeof s != "boolean" && ((i = typeof e != "function" && !Ve(s)) && (s = String(s)), i && l ? a[a.length - 1].v += s : a.push(i ? z(null, s) : s), l = i); }; if (c(n), t) {
    t.key && (o = t.key), t.name && (r = t.name);
    {
        let h = t.className || t.class;
        h && (t.class = typeof h != "object" ? h : Object.keys(h).filter(u => h[u]).join(" "));
    }
} if (typeof e == "function")
    return e(t === null ? {} : t, a, Gt); let d = z(e, null); return d.$ = t, a.length > 0 && (d.j = a), d.O = o, d.N = r, d; }, z = (e, t) => ({ i: 0, S: e, v: t ?? null, k: null, j: null, $: null, O: null, N: null }), Zt = {}, Gt = { forEach: (e, t) => e.map(Je).forEach(t), map: (e, t) => e.map(Je).map(t).map(Qt) }, Je = e => ({ vattrs: e.$, vchildren: e.j, vkey: e.O, vname: e.N, vtag: e.S, vtext: e.v }), Qt = e => { if (typeof e.vtag == "function") {
    let n = K({}, e.vattrs);
    return e.vkey && (n.key = e.vkey), e.vname && (n.name = e.vname), vt(e.vtag, n, ...e.vchildren || []);
} let t = z(e.vtag, e.vtext); return t.$ = e.vattrs, t.j = e.vchildren, t.O = e.vkey, t.N = e.vname, t; }, Ee = (e, t, n, s, o, r, i, l = []) => { let a, c, d, h, u = o["s-sc"]; if (r.nodeType === 1) {
    if (a = r.getAttribute(He), a && (c = a.split("."), c[0] === i || c[0] === "0")) {
        d = Ke({ i: 0, C: c[0], M: c[1], I: c[2], L: c[3], S: r.tagName.toLowerCase(), k: r, $: { class: r.className || "" } }), t.push(d), r.removeAttribute(He), e.j || (e.j = []), u && c[0] === i && (r["s-si"] = u, d.$.class += " " + u);
        let f = d.k.getAttribute("s-sn");
        typeof f == "string" && (d.S === "slot-fb" && (Ye(f, c[2], d, r, e, t, n, s, l), u && r.classList.add(u)), d.k["s-sn"] = f, d.k.removeAttribute("s-sn")), d.L !== void 0 && (e.j[d.L] = d), e = d, s && d.I === "0" && (s[d.L] = d.k);
    }
    if (r.shadowRoot)
        for (h = r.shadowRoot.childNodes.length - 1; h >= 0; h--)
            Ee(e, t, n, s, o, r.shadowRoot.childNodes[h], i, l);
    let p = r.__childNodes || r.childNodes;
    for (h = p.length - 1; h >= 0; h--)
        Ee(e, t, n, s, o, p[h], i, l);
}
else if (r.nodeType === 8)
    c = r.nodeValue.split("."), (c[1] === i || c[1] === "0") && (a = c[0], d = Ke({ C: c[1], M: c[2], I: c[3], L: c[4] || "0", k: r, $: null, j: null, O: null, N: null, S: null, v: null }), a === "t" ? (d.k = Ge(r, 3), d.k && d.k.nodeType === 3 && (d.v = d.k.textContent, t.push(d), r.remove(), i === d.C && (e.j || (e.j = []), e.j[d.L] = d), s && d.I === "0" && (s[d.L] = d.k))) : a === "c" ? (d.k = Ge(r, 8), d.k && d.k.nodeType === 8 && (t.push(d), r.remove())) : d.C === i && (a === "s" ? Ye(r["s-sn"] = c[5] || "", c[2], d, r, e, t, n, s, l) : a === "r" && (s ? r.remove() : (o["s-cr"] = r, r["s-cn"] = !0))));
else if (e && e.S === "style") {
    let p = z(null, r.textContent);
    p.k = r, p.L = "0", e.j = [p];
} return e; }, Ce = (e, t) => { if (e.nodeType === 1) {
    let n = e[Z] || e.getAttribute(Z);
    n && t.set(n, e);
    let s = 0;
    if (e.shadowRoot)
        for (; s < e.shadowRoot.childNodes.length; s++)
            Ce(e.shadowRoot.childNodes[s], t);
    let o = e.__childNodes || e.childNodes;
    for (s = 0; s < o.length; s++)
        Ce(o[s], t);
}
else if (e.nodeType === 8) {
    let n = e.nodeValue.split(".");
    n[0] === "o" && (t.set(n[1] + "." + n[2], e), e.nodeValue = "", e["s-en"] = n[3]);
} }, Ke = e => K({ i: 0, C: null, M: null, I: null, L: "0", k: null, $: null, j: null, O: null, N: null, S: null, v: null }, e);
function Ye(e, t, n, s, o, r, i, l, a) { s["s-sr"] = !0, n.N = e || null, n.S = "slot"; let c = o?.k ? o.k["s-id"] || o.k.getAttribute("s-id") : ""; if (l && g.document) {
    let d = n.k = g.document.createElement(n.S);
    n.N && n.k.setAttribute("name", e), o.k.shadowRoot && c && c !== n.C ? C(o.k, "insertBefore")(d, C(o.k, "children")[0]) : C(C(s, "parentNode"), "insertBefore")(d, s), Ze(a, t, e, s, n.C), s.remove(), n.I === "0" && (l[n.L] = n.k);
}
else {
    let d = n.k, h = c && c !== n.C && o.k.shadowRoot;
    Ze(a, t, e, s, h ? c : n.C), pt(s), h && o.k.insertBefore(d, o.k.children[0]);
} r.push(n), i.push(n), o.j || (o.j = []), o.j[n.L] = n; }
var Ze = (e, t, n, s, o) => { var r, i; let l = s.nextSibling; if (e[t] = e[t] || [], l && !((r = l.nodeValue) != null && r.startsWith("s.")))
    do
        !l || (l.getAttribute && l.getAttribute("slot") || l["s-sn"]) !== n && (n !== "" || l["s-sn"] || l.getAttribute && l.getAttribute("slot") || l.nodeType !== 8 && l.nodeType !== 3) || (l["s-sn"] = n, e[t].push({ slot: s, node: l, hostId: o })), l = l?.nextSibling;
    while (l && !((i = l.nodeValue) != null && i.startsWith("s."))); }, Ge = (e, t) => { let n = e; do
    n = n.nextSibling;
while (n && (n.nodeType !== t || !n.nodeValue)); return n; }, Cn = e => at.push(e), An = e => { var t; return (t = P(e)) == null ? void 0 : t.R; }, bt = e => { if (!e)
    return; let t = Object.keys(e); if (t.length === 0)
    return; let n = !1; for (let o of t) {
    if (n)
        break;
    for (let r of e[o])
        if (typeof r == "string") {
            n = !0;
            break;
        }
} if (!n)
    return e; let s = {}; for (let o of t)
    s[o] = e[o].map(r => typeof r == "string" ? { [r]: 0 } : r); return s; }, Xt = class I {
    static fromLocalValue(t) { let n = t[Ne], s = Se in t ? t[Se] : void 0; switch (n) {
        case "string":
        case "boolean": return s;
        case "bigint": return BigInt(s);
        case "undefined": return;
        case "null": return null;
        case "number": return s === "NaN" ? NaN : s === "-0" ? -0 : s === "Infinity" ? 1 / 0 : s === "-Infinity" ? -1 / 0 : s;
        case "array": return s.map(c => I.fromLocalValue(c));
        case "date": return new Date(s);
        case "map":
            let o = new Map;
            for (let [c, d] of s) {
                let h = typeof c == "object" && c !== null ? I.fromLocalValue(c) : c, u = I.fromLocalValue(d);
                o.set(h, u);
            }
            return o;
        case "object":
            let r = {};
            for (let [c, d] of s)
                r[c] = I.fromLocalValue(d);
            return r;
        case "regexp":
            let { pattern: i, flags: l } = s;
            return new RegExp(i, l);
        case "set":
            let a = new Set;
            for (let c of s)
                a.add(I.fromLocalValue(c));
            return a;
        case "symbol": return Symbol(s);
        default: throw new Error(`Unsupported type: ${n}`);
    } }
    static fromLocalValueArray(t) { return t.map(n => I.fromLocalValue(n)); }
    static isLocalValueObject(t) { if (typeof t != "object" || t === null || !t.hasOwnProperty(Ne))
        return !1; let n = t[Ne]; return !!Object.values(K(K({}, lt), ct)).includes(n) && (n === "null" || n === "undefined" || t.hasOwnProperty(Se)); }
}, ie, de, F, Nt = (e, t) => { return typeof e == "string" && e.startsWith(De) ? e = typeof (n = e) == "string" && n.startsWith(De) ? Xt.fromLocalValue(JSON.parse((function (s) { let o = atob(s), r = new Uint8Array(o.length); for (let i = 0; i < o.length; i++)
    r[i] = o.charCodeAt(i); return new TextDecoder().decode(r); })(n.slice(11)))) : n : e == null || Ve(e) ? e : 4 & t ? e !== "false" && (e === "" || !!e) : 2 & t ? typeof e == "string" ? parseFloat(e) : typeof e == "number" ? e : NaN : 1 & t ? String(e) : e; var n; }, xn = (e, t, n) => { let s = e; return { emit: o => St(s, t, { bubbles: !!(4 & n), composed: !!(2 & n), cancelable: !!(1 & n), detail: o }) }; }, St = (e, t, n) => { let s = N.ce(t, n); return e.dispatchEvent(s), s; }, Qe = (e, t, n, s, o, r, i) => { if (n === s)
    return; let l = Ie(e, t), a = t.toLowerCase(); if (t === "class") {
    let c = e.classList, d = Xe(n), h = Xe(s);
    if ((e["s-si"] || e["s-sc"]) && i) {
        let u = e["s-sc"] || e["s-si"];
        h.push(u), d.forEach(p => { p.startsWith(u) && h.push(p); }), h = [...new Set(h)].filter(p => p), c.add(...h);
    }
    else
        c.remove(...d.filter(u => u && !h.includes(u))), c.add(...h.filter(u => u && !d.includes(u)));
}
else if (t === "style") {
    for (let c in n)
        s && s[c] != null || (c.includes("-") ? e.style.removeProperty(c) : e.style[c] = "");
    for (let c in s)
        n && s[c] === n[c] || (c.includes("-") ? e.style.setProperty(c, s[c]) : e.style[c] = s[c]);
}
else if (t !== "key") {
    if (t === "ref")
        s && nn(s, e);
    else if (e.__lookupSetter__(t) || t[0] !== "o" || t[1] !== "n") {
        if (t[0] === "a" && t.startsWith("attr:")) {
            let c = t.slice(5), d;
            {
                let h = P(e);
                if (h && h.o && h.o.t) {
                    let u = h.o.t[c];
                    u && u[1] && (d = u[1]);
                }
            }
            return d || (d = c.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase()), void (s == null || s === !1 ? s === !1 && e.getAttribute(d) !== "" || e.removeAttribute(d) : e.setAttribute(d, s === !0 ? "" : s));
        }
        if (t[0] === "p" && t.startsWith("prop:")) {
            let c = t.slice(5);
            try {
                e[c] = s;
            }
            catch { }
            return;
        }
        {
            let c = Ve(s);
            if ((l || c && s !== null) && !o)
                try {
                    if (e.tagName.includes("-"))
                        e[t] !== s && (e[t] = s);
                    else {
                        let h = s ?? "";
                        t === "list" ? l = !1 : n != null && e[t] === h || (typeof e.__lookupSetter__(t) == "function" ? e[t] = h : e.setAttribute(t, h));
                    }
                }
                catch { }
            let d = !1;
            a !== (a = a.replace(/^xlink\:?/, "")) && (t = a, d = !0), s == null || s === !1 ? s === !1 && e.getAttribute(t) !== "" || (d ? e.removeAttributeNS(Fe, t) : e.removeAttribute(t)) : (!l || 4 & r || o) && !c && e.nodeType === 1 && (s = s === !0 ? "" : s, d ? e.setAttributeNS(Fe, t, s) : e.setAttribute(t, s));
        }
    }
    else if (t = t[2] === "-" ? t.slice(3) : Ie(g, a) ? a.slice(2) : a[2] + t.slice(3), n || s) {
        let c = t.endsWith(_t);
        t = t.replace(tn, ""), n && N.rel(e, t, n, c), s && N.ael(e, t, s, c);
    }
} }, en = /\s/, Xe = e => (typeof e == "object" && e && "baseVal" in e && (e = e.baseVal), e && typeof e == "string" ? e.split(en) : []), _t = "Capture", tn = new RegExp(_t + "$"), Ae = (e, t, n, s) => { let o = t.k.nodeType === 11 && t.k.host ? t.k.host : t.k, r = e && e.$ || {}, i = t.$ || {}; for (let l of et(Object.keys(r)))
    l in i || Qe(o, l, r[l], void 0, n, t.i, s); for (let l of et(Object.keys(i)))
    Qe(o, l, r[l], i[l], n, t.i, s); };
function et(e) { return e.includes("ref") ? [...e.filter(t => t !== "ref"), "ref"] : e; }
var X = !1, ae = !1, ge = !1, $ = !1, xe = [], Re = [], ue = (e, t, n) => { var s; let o = t.j[n], r, i, l, a = 0; if (X || (ge = !0, o.S === "slot" && (o.i |= o.j ? 2 : 1)), o.v != null)
    r = o.k = g.document.createTextNode(o.v);
else if (1 & o.i)
    r = o.k = g.document.createTextNode(""), Ae(null, o, $);
else {
    if ($ || ($ = o.S === "svg"), !g.document)
        throw new Error("You are trying to render a Stencil component in an environment that doesn't support the DOM.");
    if (r = o.k = g.document.createElementNS($ ? "http://www.w3.org/2000/svg" : "http://www.w3.org/1999/xhtml", !X && 2 & o.i ? "slot-fb" : o.S), $ && o.S === "foreignObject" && ($ = !1), Ae(null, o, $), (c = ie) != null && c !== void 0 && r["s-si"] !== ie && r.classList.add(r["s-si"] = ie), o.j) {
        let d = o.S === "template" ? r.content : r;
        for (a = 0; a < o.j.length; ++a)
            i = ue(e, o, a), i && d.appendChild(i);
    }
    o.S === "svg" ? $ = !1 : r.tagName === "foreignObject" && ($ = !0);
} var c; return r["s-hn"] = F, 3 & o.i && (r["s-sr"] = !0, r["s-cr"] = de, r["s-sn"] = o.N || "", r["s-rf"] = (s = o.$) == null ? void 0 : s.ref, pt(r), l = e && e.j && e.j[n], l && l.S === o.S && e.k && wt(e.k), Ot(de, r, t.k, e?.k)), r; }, wt = e => { N.i |= 1; let t = e.closest(F.toLowerCase()); if (t != null) {
    let n = Array.from(t.__childNodes || t.childNodes).find(o => o["s-cr"]), s = Array.from(e.__childNodes || e.childNodes);
    for (let o of n ? s.reverse() : s)
        o["s-sh"] != null && (L(t, o, n ?? null), o["s-sh"] = void 0, ge = !0);
} N.i &= -2; }, he = (e, t) => { N.i |= 1; let n = Array.from(e.__childNodes || e.childNodes); if (e["s-sr"]) {
    let s = e;
    for (; s = s.nextSibling;)
        s && s["s-sn"] === e["s-sn"] && s["s-sh"] === F && n.push(s);
} for (let s = n.length - 1; s >= 0; s--) {
    let o = n[s];
    o["s-hn"] !== F && o["s-ol"] && (L(ee(o).parentNode, o, ee(o)), o["s-ol"].remove(), o["s-ol"] = void 0, o["s-sh"] = void 0, ge = !0), t && he(o, t);
} N.i &= -2; }, tt = (e, t, n, s, o, r) => { let i, l = e["s-cr"] && e["s-cr"].parentNode || e; for (l.shadowRoot && l.tagName === F && (l = l.shadowRoot), n.S === "template" && (l = l.content); o <= r; ++o)
    s[o] && (i = ue(null, n, o), i && (s[o].k = i, L(l, i, ee(t)))); }, nt = (e, t, n) => { for (let s = t; s <= n; ++s) {
    let o = e[s];
    if (o) {
        let r = o.k;
        jt(o), r && (ae = !0, r["s-ol"] ? r["s-ol"].remove() : he(r, !0), r.remove());
    }
} }, oe = (e, t, n = !1) => e.S === t.S && (e.S === "slot" ? e.N === t.N : n ? (n && !e.O && t.O && (e.O = t.O), !0) : e.O === t.O), ee = e => e && e["s-ol"] || e, q = (e, t, n = !1) => { let s = t.k = e.k, o = e.j, r = t.j, i = t.S, l = t.v, a; l == null ? ($ = i === "svg" || i !== "foreignObject" && $, i !== "slot" || X || e.N !== t.N && (t.k["s-sn"] = t.N || "", wt(t.k.parentElement)), Ae(e, t, $, n), o !== null && r !== null ? ((c, d, h, u, p = !1) => { let f, S, j = 0, v = 0, b = 0, y = 0, x = d.length - 1, k = d[0], m = d[x], R = u.length - 1, A = u[0], E = u[R], M = h.S === "template" ? c.content : c; for (; j <= x && v <= R;)
    if (k == null)
        k = d[++j];
    else if (m == null)
        m = d[--x];
    else if (A == null)
        A = u[++v];
    else if (E == null)
        E = u[--R];
    else if (oe(k, A, p))
        q(k, A, p), k = d[++j], A = u[++v];
    else if (oe(m, E, p))
        q(m, E, p), m = d[--x], E = u[--R];
    else if (oe(k, E, p))
        k.S !== "slot" && E.S !== "slot" || he(k.k.parentNode, !1), q(k, E, p), L(M, k.k, m.k.nextSibling), k = d[++j], E = u[--R];
    else if (oe(m, A, p))
        k.S !== "slot" && E.S !== "slot" || he(m.k.parentNode, !1), q(m, A, p), L(M, m.k, k.k), m = d[--x], A = u[++v];
    else {
        for (b = -1, y = j; y <= x; ++y)
            if (d[y] && d[y].O !== null && d[y].O === A.O) {
                b = y;
                break;
            }
        b >= 0 ? (S = d[b], S.S !== A.S ? f = ue(d && d[v], h, b) : (q(S, A, p), d[b] = void 0, f = S.k), A = u[++v]) : (f = ue(d && d[v], h, v), A = u[++v]), f && L(ee(k.k).parentNode, f, ee(k.k));
    } j > x ? tt(c, u[R + 1] == null ? null : u[R + 1].k, h, u, v, R) : v > R && nt(d, j, x); })(s, o, t, r, n) : r !== null ? (e.v !== null && (s.textContent = ""), tt(s, null, t, r, 0, r.length - 1)) : n || o === null ? n && o !== null && r === null && (t.j = o) : nt(o, 0, o.length - 1), $ && i === "svg" && ($ = !1)) : (a = s["s-cr"]) ? a.parentNode.textContent = l : e.v !== l && (s.data = l); }, B = [], kt = e => { let t, n, s, o = e.__childNodes || e.childNodes; for (let r of o) {
    if (r["s-sr"] && (t = r["s-cr"]) && t.parentNode) {
        n = t.parentNode.__childNodes || t.parentNode.childNodes;
        let i = r["s-sn"];
        for (s = n.length - 1; s >= 0; s--)
            if (t = n[s], !(t["s-cn"] || t["s-nr"] || t["s-hn"] === r["s-hn"] || t["s-sh"] && t["s-sh"] === r["s-hn"]))
                if (qe(t, i)) {
                    let l = B.find(a => a.A === t);
                    ae = !0, t["s-sn"] = t["s-sn"] || i, l ? (l.A["s-sh"] = r["s-hn"], l._ = r) : (t["s-sh"] = r["s-hn"], B.push({ _: r, A: t })), t["s-sr"] && B.map(a => { qe(a.A, t["s-sn"]) && (l = B.find(c => c.A === t), l && !a._ && (a._ = l._)); });
                }
                else
                    B.some(l => l.A === t) || B.push({ A: t });
    }
    r.nodeType === 1 && kt(r);
} }, jt = e => { e.$ && e.$.ref && xe.push(() => e.$.ref(null)), e.j && e.j.map(jt); }, nn = (e, t) => { Re.push(() => e(t)); }, L = (e, t, n, s) => { if (typeof t["s-sn"] == "string" && t["s-sr"] && t["s-cr"])
    Ot(t["s-cr"], t, e, t.parentElement);
else if (typeof t["s-sn"] == "string") {
    e.getRootNode().nodeType !== 11 && mt(t), e.insertBefore(t, n);
    let { slotNode: o } = Pe(t);
    return o && !s && me(o), t;
} return e.__insertBefore ? e.__insertBefore(t, n) : e?.insertBefore(t, n); };
function Ot(e, t, n, s) { var o, r; let i; if (e && typeof t["s-sn"] == "string" && t["s-sr"] && e.parentNode && e.parentNode["s-sc"] && (i = t["s-si"] || e.parentNode["s-sc"])) {
    let l = t["s-sn"], a = t["s-hn"];
    if ((o = n.classList) == null || o.add(i + "-s"), s && ((r = s.classList) == null ? void 0 : r.contains(i + "-s"))) {
        let c = (s.__childNodes || s.childNodes)[0], d = !1;
        for (; c;) {
            if (c["s-sn"] !== l && c["s-hn"] === a && c["s-sr"]) {
                d = !0;
                break;
            }
            c = c.nextSibling;
        }
        d || s.classList.remove(i + "-s");
    }
} }
var sn = (e, t, n = !1) => { var s, o, r, i, l; let a = e.$hostElement$, c = e.o, d = e.B || z(null, null); var h; let u = (h = t) && h.S === Zt ? t : vt(null, null, t); if (F = a.tagName, c.F && (u.$ = u.$ || {}, c.F.forEach(([p, f]) => { u.$[f] = a[p]; })), n && u.$)
    for (let p of Object.keys(u.$))
        a.hasAttribute(p) && !["key", "ref", "style", "class"].includes(p) && (u.$[p] = a[p]); if (u.S = null, u.i |= 4, e.B = u, u.k = d.k = a.shadowRoot || a, ie = a["s-sc"], X = !(!(1 & c.i) || 128 & c.i), de = a["s-cr"], ae = !1, q(d, u, n), N.i |= 1, ge) {
    kt(u.k);
    for (let p of B) {
        let f = p.A;
        if (!f["s-ol"] && g.document) {
            let S = g.document.createTextNode("");
            S["s-nr"] = f, L(f.parentNode, f["s-ol"] = S, f, n);
        }
    }
    for (let p of B) {
        let f = p.A, S = p._;
        if (f.nodeType === 1 && n && (f["s-ih"] = (s = f.hidden) != null && s), S) {
            let j = S.parentNode, v = S.nextSibling;
            if (v && v.nodeType === 1) {
                let b = (o = f["s-ol"]) == null ? void 0 : o.previousSibling;
                for (; b;) {
                    let y = (r = b["s-nr"]) != null ? r : null;
                    if (y && y["s-sn"] === f["s-sn"] && j === (y.__parentNode || y.parentNode)) {
                        for (y = y.nextSibling; y === f || y?.["s-sr"];)
                            y = y?.nextSibling;
                        if (!y || !y["s-nr"]) {
                            v = y;
                            break;
                        }
                    }
                    b = b.previousSibling;
                }
            }
            if ((!v && j !== (f.__parentNode || f.parentNode) || (f.__nextSibling || f.nextSibling) !== v) && f !== v) {
                if (L(j, f, v, n), f.nodeType === 8 && f.nodeValue.startsWith("s-nt-")) {
                    let b = g.document.createTextNode(f.nodeValue.replace(/^s-nt-/, ""));
                    b["s-hn"] = f["s-hn"], b["s-sn"] = f["s-sn"], b["s-sh"] = f["s-sh"], b["s-sr"] = f["s-sr"], b["s-ol"] = f["s-ol"], b["s-ol"]["s-nr"] = b, L(f.parentNode, b, f, n), f.parentNode.removeChild(f);
                }
                f.nodeType === 1 && f.tagName !== "SLOT-FB" && (f.hidden = (i = f["s-ih"]) != null && i);
            }
            f && typeof S["s-rf"] == "function" && S["s-rf"](S);
        }
        else
            f.nodeType === 1 && (f.hidden = !0);
    }
} if (ae && fe(u.k), N.i &= -2, B.length = 0, !X && !(1 & c.i) && a["s-cr"]) {
    let p = u.k.__childNodes || u.k.childNodes;
    for (let f of p)
        if (f["s-hn"] !== F && !f["s-sh"]) {
            if (n && f["s-ih"] == null && (f["s-ih"] = (l = f.hidden) != null && l), f.nodeType === 1)
                f.hidden = !0;
            else if (f.nodeType === 3 && f.nodeValue.trim()) {
                let S = g.document.createComment("s-nt-" + f.nodeValue);
                S["s-sn"] = f["s-sn"], L(f.parentNode, S, f, n), f.parentNode.removeChild(f);
            }
        }
} de = void 0, xe.forEach(p => p()), xe.length = 0, Re.forEach(p => p()), Re.length = 0; }, Et = (e, t) => { if (t && !e.T && t["s-p"]) {
    let n = t["s-p"].push(new Promise(s => e.T = () => { t["s-p"].splice(n - 1, 1), s(); }));
} }, ye = (e, t) => { if (e.i |= 16, 4 & e.i)
    return void (e.i |= 512); Et(e, e.U); let n = () => on(e, t); if (!t)
    return ft(n); queueMicrotask(() => { n(); }); }, on = (e, t) => { let n = e.$hostElement$, s = n; if (!s)
    throw new Error(`Can't render component <${n.tagName.toLowerCase()} /> with invalid Stencil runtime! Make sure this imported component is compiled with a \`externalRuntime: true\` flag. For more information, please refer to https://stenciljs.com/docs/custom-elements#externalruntime`); let o; return o = G(s, t ? "componentWillLoad" : "componentWillUpdate", void 0, n), o = st(o, () => G(s, "componentWillRender", void 0, n)), st(o, () => ln(e, s, t)); }, st = (e, t) => rn(e) ? e.then(t).catch(n => { console.error(n), t(); }) : t(), rn = e => e instanceof Promise || e && e.then && typeof e.then == "function", ln = (e, t, n) => se(null, null, function* () { var s; let o = e.$hostElement$, r = o["s-rc"]; n && (i => { let l = i.o, a = i.$hostElement$, c = l.i, d = yt(a.shadowRoot ? a.shadowRoot : a.getRootNode(), l, i.R); 10 & c && (a["s-sc"] = d, a.classList.add(d + "-h")); })(e), cn(e, t, o, n), r && (r.map(i => i()), o["s-rc"] = void 0); {
    let i = (s = o["s-p"]) != null ? s : [], l = () => dn(e);
    i.length === 0 ? l() : (Promise.all(i).then(l).catch(l), e.i |= 4, i.length = 0);
} }), cn = (e, t, n, s) => { try {
    t = t.render && t.render(), e.i &= -17, e.i |= 2, sn(e, t, s);
}
catch (o) {
    U(o, e.$hostElement$);
} return null; }, dn = e => { let t = e.$hostElement$, n = t, s = e.U; G(n, "componentDidRender", void 0, t), 64 & e.i ? G(n, "componentDidUpdate", void 0, t) : (e.i |= 64, un(t), G(n, "componentDidLoad", void 0, t), e.D(t), s || an()), e.T && (e.T(), e.T = void 0), 512 & e.i && Te(() => ye(e, !1)), e.i &= -517; }, Rn = e => { var t; {
    let n = P(e), s = (t = n?.$hostElement$) == null ? void 0 : t.isConnected;
    return s && (18 & n.i) == 2 && ye(n, !1), s;
} }, an = () => { var e; Te(() => St(g, "appload", { detail: { namespace: "ionic" } })), (e = N.W) != null && e.size && N.W.clear(); }, G = (e, t, n, s) => { if (e && e[t])
    try {
        return e[t](n);
    }
    catch (o) {
        U(o, s);
    } }, un = e => e.classList.add("hydrated"), ot = (e, t, n, s) => { let o = P(e); if (!o)
    return; let r = e, i = o.l.get(t), l = o.i, a = r; n = Nt(n, s.t[t][0]); let c = Number.isNaN(i) && Number.isNaN(n); if (n !== i && !c) {
    if (o.l.set(t, n), s.V) {
        let d = s.V[t];
        d && d.map(h => { try {
            let [[u, p]] = Object.entries(h);
            (128 & l || 1 & p) && (a ? a[u](n, i, t) : o.H.push(() => { o.P[u](n, i, t); }));
        }
        catch (u) {
            U(u, r);
        } });
    }
    if (2 & l) {
        if (a.componentShouldUpdate && a.componentShouldUpdate(n, i, t) === !1 && !(16 & l))
            return;
        16 & l || ye(o, !1);
    }
} }, hn = (e, t) => { var n, s; let o = e.prototype; {
    e.watchers && !t.V && (t.V = bt(e.watchers)), e.deserializers && !t.q && (t.q = e.deserializers), e.serializers && !t.J && (t.J = e.serializers);
    let r = Object.entries((n = t.t) != null ? n : {});
    r.map(([i, [l]]) => { if (31 & l || 32 & l) {
        let { get: a, set: c } = dt(o, i) || {};
        a && (t.t[i][0] |= 2048), c && (t.t[i][0] |= 4096), Object.defineProperty(o, i, { get() { return a ? a.apply(this) : (d = i, P(this).l.get(d)); var d; }, configurable: !0, enumerable: !0 }), Object.defineProperty(o, i, { set(d) { let h = P(this); if (h) {
                if (c)
                    return (32 & l ? this[i] : h.$hostElement$[i]) === void 0 && h.l.get(i) && (d = h.l.get(i)), c.apply(this, [Nt(d, l)]), void ot(this, i, d = 32 & l ? this[i] : h.$hostElement$[i], t);
                ot(this, i, d, t);
            } } });
    } });
    {
        let i = new Map;
        o.attributeChangedCallback = function (l, a, c) { N.jmp(() => { var d; let h = i.get(l), u = P(this); if (this.hasOwnProperty(h), o.hasOwnProperty(h) && typeof this[h] == "number" && this[h] == c)
            return; if (h == null) {
            let v = u?.i;
            if (u && v && !(8 & v) && c !== a) {
                let b = this, y = (d = t.V) == null ? void 0 : d[l];
                y?.forEach(x => { let [[k, m]] = Object.entries(x); b[k] != null && (128 & v || 1 & m) && b[k].call(b, c, a, l); });
            }
            return;
        } let p = r.find(([v]) => v === h), f = p && 4 & p[1][0], S = f && c === null && this[h] === void 0; f && (c = c !== null && c !== "false"); let j = Object.getOwnPropertyDescriptor(o, h); S || c == this[h] || j.get && !j.set || (this[h] = c); }); }, e.observedAttributes = Array.from(new Set([...Object.keys((s = t.V) != null ? s : {}), ...r.filter(([l, a]) => 31 & a[0]).map(([l, a]) => { var c; let d = a[1] || l; return i.set(d, l), 512 & a[0] && ((c = t.F) == null || c.push([l, d])), d; })]));
    }
} return e; }, fn = e => { if (!(1 & N.i)) {
    let t = P(e);
    if (!t)
        return;
    let n = t.o, s = () => { };
    if (1 & t.i)
        Ct(e, t, n.Y), t?.P || t?.Z && t.Z.then(() => { });
    else {
        let o;
        if (t.i |= 1, o = e.getAttribute(Z), o) {
            if (1 & n.i) {
                let r = yt(e.shadowRoot, n, e.getAttribute("s-mode"));
                e.classList.remove(r + "-h", r + "-s");
            }
            else if (2 & n.i) {
                let r = re(n, e.getAttribute("s-mode"));
                e["s-sc"] = r;
            }
            ((r, i, l, a) => { var c, d, h, u; let p = r.shadowRoot, f = [], S = [], j = [], v = p ? [] : null, b = z(i, null), y; b.k = r; {
                let w = a.o;
                w && 10 & w.i && r["s-sc"] ? (y = r["s-sc"], r.classList.add(y + "-h")) : r["s-sc"] && delete r["s-sc"];
            } !g.document || N.W && N.W.size || Ce(g.document.body, N.W = new Map), r[Z] = l, r.removeAttribute(Z), a.B = Ee(b, f, S, v, r, r, l, j); let x = 0, k = f.length, m; for (; x < k; x++) {
                m = f[x];
                let w = m.C + "." + m.M, T = N.W.get(w), O = m.k;
                if (p) {
                    if ((c = m.S) != null && c.toString().includes("-") && m.S !== "slot-fb" && !m.k.shadowRoot) {
                        let ne = P(m.k);
                        if (ne) {
                            let At = re(ne.o, m.k.getAttribute("s-mode")), Me = g.document.querySelector(`style[sty-id="${At}"]`);
                            Me && v.unshift(Me.cloneNode(!0));
                        }
                    }
                }
                else
                    O["s-hn"] = i.toUpperCase(), m.S === "slot" && (O["s-cr"] = r["s-cr"]);
                m.S === "slot" && (m.N = m.k["s-sn"] || m.k.name || null, m.j ? (m.i |= 2, m.k.childNodes.length || m.j.forEach(ne => { m.k.appendChild(ne.k); })) : m.i |= 1), T && T.isConnected && (T.parentElement.shadowRoot && T["s-en"] === "" && T.parentNode.insertBefore(O, T.nextSibling), T.parentNode.removeChild(T), p || (O["s-oo"] = parseInt(m.M))), T && !T["s-id"] && N.W.delete(w);
            } let R = [], A = j.length, E, M, Be, _, ve = 0, be = 0; for (; ve < A; ve++)
                if (E = j[ve], E && E.length)
                    for (Be = E.length, M = 0; M < Be; M++) {
                        if (_ = E[M], R[_.hostId] || (R[_.hostId] = N.W.get(_.hostId)), !R[_.hostId])
                            continue;
                        let w = R[_.hostId];
                        w.shadowRoot && _.node.parentElement !== w && w.insertBefore(_.node, (h = (d = E[M - 1]) == null ? void 0 : d.node) == null ? void 0 : h.nextSibling), w.shadowRoot && p || (_.slot["s-cr"] || (_.slot["s-cr"] = w["s-cr"], _.slot["s-cr"] = !_.slot["s-cr"] && w.shadowRoot ? w : (w.__childNodes || w.childNodes)[0]), pe(_.node, _.slot, !1, _.node["s-oo"] || be), (u = _.node.parentElement) != null && u.shadowRoot && _.node.getAttribute && _.node.getAttribute("slot") && _.node.removeAttribute("slot"), (W = _.node) && W.__nextSibling === void 0 && globalThis.Node && (Ut(W), zt(W), mt(W), W.nodeType === Node.ELEMENT_NODE && (qt(W), Jt(W)))), be = (_.node["s-oo"] || be) + 1;
                    } var W; if (y && S.length && S.forEach(w => { w.k.parentElement.classList.add(y + "-s"); }), p && !p.childNodes.length) {
                let w = 0, T = v.length;
                if (T) {
                    for (; w < T; w++) {
                        let O = v[w];
                        O && p.appendChild(O);
                    }
                    Array.from(r.childNodes).forEach(O => { typeof O["s-en"] != "string" && typeof O["s-sn"] != "string" && (O.nodeType === 1 && O.slot && O.hidden ? O.removeAttribute("hidden") : O.nodeType !== 8 || O.nodeValue || O.parentNode.removeChild(O)); });
                }
            } a.$hostElement$ = r; })(e, n.p, o, t);
        }
        o || 12 & n.i && pn(e);
        {
            let r = e;
            for (; r = r.parentNode || r.host;)
                if (r.nodeType === 1 && r.hasAttribute("s-id") && r["s-p"] || r["s-p"]) {
                    Et(t, t.U = r);
                    break;
                }
        }
        n.t && Object.entries(n.t).map(([r, [i]]) => { if (31 & i && Object.prototype.hasOwnProperty.call(e, r)) {
            let l = e[r];
            delete e[r], e[r] = l;
        } }), ((r, i, l) => se(null, null, function* () { let a; try {
            if (!(32 & i.i) && (i.i |= 32, a = r.constructor, customElements.whenDefined(r.localName).then(() => i.i |= 128), a && a.style)) {
                let h;
                typeof a.style == "string" ? h = a.style : typeof a.style != "string" && (i.R = (p => at.map(f => f(p)).find(f => !!f))(r), i.R && (h = a.style[i.R]));
                let u = re(l, i.R);
                if (!le.has(u)) {
                    let p = () => { };
                    gt(u, h, !!(1 & l.i)), p();
                }
            }
            let c = i.U, d = () => ye(i, !0);
            c && c["s-rc"] ? c["s-rc"].push(d) : d();
        }
        catch (c) {
            U(c, r), i.T && (i.T(), i.T = void 0), i.D && i.D(r);
        } }))(e, t, n);
    }
    s();
} }, pn = e => { if (!g.document)
    return; let t = e["s-cr"] = g.document.createComment(""); t["s-cn"] = !0, L(e, t, e.firstChild); }, $n = (e, t) => { let n = { i: t[0], p: t[1] }; try {
    n.t = t[2], n.Y = t[3], n.V = bt(e.V), n.q = e.q, n.J = e.J, n.F = [], !(1 & n.i) && 256 & n.i ? (ze(s = e.prototype), Lt(s), Bt(s), Vt(s), It(s), Mt(s), Wt(s), Dt(s), Ht(s), Ft(s), Pt(s)) : ze(e.prototype), (() => { if (!g.document)
        return; let i = g.document.querySelectorAll(`[${ce}]`), l = 0; for (; l < i.length; l++)
        gt(i[l].getAttribute(ce), i[l].innerHTML.replace(/\/\*!@([^\/]+)\*\/[^\{]+\{/g, "$1{"), !0); })();
    let o = e.prototype.connectedCallback, r = e.prototype.disconnectedCallback;
    return Object.assign(e.prototype, { __hasHostListenerAttached: !1, __registerHost() { ((i, l) => { let a = { i: 0, $hostElement$: i, o: l, l: new Map, G: new Map }; a.Z = new Promise(d => a.D = d), i["s-p"] = [], i["s-rc"] = []; let c = a; i.__stencil__getHostRef = () => c, 512 & l.i && Rt(i, a); })(this, n); }, connectedCallback() { if (!this.__hasHostListenerAttached) {
            let i = P(this);
            if (!i)
                return;
            Ct(this, i, n.Y), this.__hasHostListenerAttached = !0;
        } fn(this), o && o.call(this); }, disconnectedCallback() { (i => se(null, null, function* () { if (!(1 & N.i)) {
            let l = P(i);
            l?.K && (l.K.map(a => a()), l.K = void 0);
        } D.has(i) && D.delete(i), i.shadowRoot && D.has(i.shadowRoot) && D.delete(i.shadowRoot); }))(this), r && r.call(this); }, __attachShadow() { if (this.shadowRoot) {
            if (this.shadowRoot.mode !== "open")
                throw new Error(`Unable to re-use existing shadow root for ${n.p}! Mode is set to ${this.shadowRoot.mode} but Stencil only supports open shadow roots.`);
        }
        else
            Tt.call(this, n); } }), Object.defineProperty(e, "is", { value: n.p, configurable: !0 }), hn(e, n);
}
catch (o) {
    return U(o), e;
} var s; }, Tn = (e, t) => t, Ct = (e, t, n) => { n && g.document && n.map(([s, o, r]) => { let i = gn(g.document, e, s), l = mn(t, r), a = yn(s); N.ael(i, o, l, a), (t.K = t.K || []).push(() => N.rel(i, o, l, a)); }); }, mn = (e, t) => n => { try {
    e.$hostElement$[t](n);
}
catch (s) {
    U(s, e.$hostElement$);
} }, gn = (e, t, n) => 4 & n ? e : 8 & n ? g : 16 & n ? e.body : t, yn = e => $t ? { passive: !!(1 & e), capture: !!(2 & e) } : !!(2 & e);
export { rt as a, vn as b, bn as c, Nn as d, Sn as e, _n as f, wn as g, kn as h, jn as i, On as j, ft as k, En as l, vt as m, Zt as n, Cn as o, An as p, xn as q, Rn as r, $n as s, Tn as t };
/*! Bundled license information:

@ionic/core/components/p-CHqRYvYm.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
