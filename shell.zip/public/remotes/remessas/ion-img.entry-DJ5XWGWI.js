import { c as s } from "@nf-internal/chunk-56EKAJ4H";
import { d as o } from "@nf-internal/chunk-EH7P5N2T";
import { i as r, m as e, n, q as d, r as t } from "@nf-internal/chunk-V3JGNOV4";
import "@nf-internal/chunk-JHI3MBHO";
var g = () => ":host{display:block;-o-object-fit:contain;object-fit:contain}img{display:block;width:100%;height:100%;-o-object-fit:inherit;object-fit:inherit;-o-object-position:inherit;object-position:inherit}", b = class {
    constructor(i) { r(this, i), this.ionImgWillLoad = t(this, "ionImgWillLoad", 7), this.ionImgDidLoad = t(this, "ionImgDidLoad", 7), this.ionError = t(this, "ionError", 7), this.inheritedAttributes = {}, this.onLoad = () => { this.ionImgDidLoad.emit(); }, this.onError = () => { this.ionError.emit(); }; }
    srcChanged() { this.addIO(); }
    componentWillLoad() { this.inheritedAttributes = o(this.el, ["draggable"]); }
    componentDidLoad() { this.addIO(); }
    disconnectedCallback() { this.loadTimeout && clearTimeout(this.loadTimeout); }
    addIO() { this.loadTimeout && (clearTimeout(this.loadTimeout), this.loadTimeout = void 0), this.src !== void 0 && (typeof window < "u" && "IntersectionObserver" in window && "IntersectionObserverEntry" in window && "isIntersecting" in window.IntersectionObserverEntry.prototype ? (this.removeIO(), this.io = new IntersectionObserver(i => { i[i.length - 1].isIntersecting && (this.load(), this.removeIO()); }), this.io.observe(this.el)) : this.loadTimeout = setTimeout(() => this.load(), 200)); }
    load() { this.loadError = this.onError, this.loadSrc = this.src, this.ionImgWillLoad.emit(); }
    removeIO() { this.io && (this.io.disconnect(), this.io = void 0); }
    render() { let { loadSrc: i, alt: a, onLoad: h, loadError: c, inheritedAttributes: l } = this, { draggable: m } = l; return e(n, { key: "9bfaa659b0680189fd29f3acb2fdce7f70be6060", class: s(this) }, e("img", { key: "d484beae0d5cbe0406958bfad40cdd6c05625340", decoding: "async", src: i, alt: a, onLoad: h, onError: c, part: "image", draggable: u(m) })); }
    get el() { return d(this); }
    static get watchers() { return { src: [{ srcChanged: 0 }] }; }
}, u = i => { switch (i) {
    case "true": return !0;
    case "false": return !1;
    default: return;
} };
b.style = g();
export { b as ion_img };
/*! Bundled license information:

@ionic/core/dist/esm/ion-img.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
