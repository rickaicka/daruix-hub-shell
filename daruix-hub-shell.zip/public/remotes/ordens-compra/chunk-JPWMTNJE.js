var E="ion-focused",m=["Tab","ArrowDown","Space","Escape"," ","Shift","Enter","ArrowLeft","ArrowRight","ArrowUp","Home","End"],f=i=>{let c=[],n=!0,e=i?i.shadowRoot:document,L=i||document.body,s=t=>{c.forEach(o=>o.classList.remove(E)),t.forEach(o=>o.classList.add(E)),c=t},r=()=>{n=!1,s([])},d=t=>{n=m.includes(t.key),n||s([])},a=t=>{if(n&&t.composedPath!==void 0){let o=t.composedPath().filter(v=>!!v.classList&&v.classList.contains("ion-focusable"));s(o)}},u=()=>{e.activeElement===L&&s([])};return e.addEventListener("keydown",d),e.addEventListener("focusin",a),e.addEventListener("focusout",u),e.addEventListener("touchstart",r,{passive:!0}),e.addEventListener("mousedown",r),{destroy:()=>{e.removeEventListener("keydown",d),e.removeEventListener("focusin",a),e.removeEventListener("focusout",u),e.removeEventListener("touchstart",r),e.removeEventListener("mousedown",r)},setFocus:s}};export{f as a};
/*! Bundled license information:

@ionic/core/components/p-BmVRXR1y.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
