import{b as a,c as b}from"@nf-internal/chunk-3IHVGUEN";import"@nf-internal/chunk-4CLCTAJ7";export{a as GESTURE_CONTROLLER,b as createGesture};
