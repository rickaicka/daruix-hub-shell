import{f as i,g as m}from"@nf-internal/chunk-3QKIQXY3";import{b as a}from"@nf-internal/chunk-2A24GCGK";import{j as s,k as n}from"@nf-internal/chunk-DENXEOXI";import{d as r}from"@nf-internal/chunk-4CLCTAJ7";var f=()=>{let e=window;e.addEventListener("statusTap",()=>{s(()=>{let o=document.elementFromPoint(e.innerWidth/2,e.innerHeight/2);if(!o)return;let t=i(o);t&&new Promise(p=>a(t,p)).then(()=>{n(()=>r(null,null,function*(){t.style.setProperty("--overflow","hidden"),yield m(t,300),t.style.removeProperty("--overflow")}))})})})};export{f as startStatusTap};
/*! Bundled license information:

@ionic/core/components/p-D7bSXQD3.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
