var r={production:!0,apiUrl:"https://daruix-hub.com.br/api",ordersApiUrl:"https://api.daruix-engenharia.vps-kinghost.net/flask"};export{r as a};
