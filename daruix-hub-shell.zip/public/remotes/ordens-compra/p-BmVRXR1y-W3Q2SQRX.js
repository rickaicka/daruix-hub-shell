import{a}from"@nf-internal/chunk-JPWMTNJE";import"@nf-internal/chunk-4CLCTAJ7";export{a as startFocusVisible};
