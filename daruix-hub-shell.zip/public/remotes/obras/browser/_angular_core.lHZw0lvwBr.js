import { a as LT } from "@nf-internal/chunk-33B6ZBWA";
import { $ as To, $a as So, $b as w, $c as Wt, A as yn, Aa as q, Ab as gp, Ac as Dc, B as Xr, Ba as le, Bb as mp, Bc as yi, C as za, Ca as ue, Cb as yp, Cc as bp, D as vt, Da as se, Db as de, Dc as J, E as Lt, Ea as Ht, Eb as oc, Ec as Ze, F as vn, Fa as H, Fb as li, Fc as Ee, G as ei, Ga as O, Gb as vp, Gc as Cc, H as W, Ha as $e, Hb as Ro, Hc as Tc, I as Ne, Ia as T, Ib as ui, Ic as Mc, J as Ue, Ja as Dt, Jb as di, Jc as vi, K as Do, Ka as No, Kb as fi, Kc as xo, L as N, La as wo, Lb as rc, Lc as Ve, M as we, Ma as K, Mb as $t, Mc as TT, N as op, Na as Ct, Nb as Ep, Nc as Ap, O as Ga, Oa as In, Ob as Ip, Oc as Te, P as Ft, Pa as ze, Pb as Dp, Pc as zt, Q as rp, Qa as Se, Qb as Cp, Qc as Po, R as Le, Ra as Ka, Rb as Tp, Rc as Rp, S as ti, Sa as Ja, Sb as ic, Sc as Op, T as I, Ta as ci, Tb as pi, Tc as Gt, U as Wa, Ua as _o, Ub as Oo, Uc as MT, V as En, Va as be, Vb as sc, Vc as kp, W as ni, Wa as Vt, Wb as ac, Wc as xp, X as ip, Xa as Ge, Xb as Mp, Xc as Nc, Y as Fe, Ya as E, Yb as cc, Yc as U, Z as qa, Za as Ce, Zb as lc, Zc as wc, _ as Co, _a as He, _b as g, _c, a as fT, aa as Qa, ab as jt, ac as uc, ad as Sc, b as pT, ba as sp, bb as V, bc as dc, bd as NT, c as ja, ca as Mo, cb as re, cc as M, cd as wT, d as Qr, da as oi, db as ee, dc as Np, dd as bc, e as _, ea as ri, eb as Xa, ec as Cn, ed as Pp, f as ep, fa as _e, fb as me, fc as qe, fd as _T, g as De, ga as F, gb as Dn, gc as fc, gd as Ei, h as Ba, ha as Et, hb as Ae, hc as pc, hd as Nt, i as tp, ia as ET, ib as We, ic as hc, id as Tn, j as Yr, ja as nt, jb as ec, jc as gc, jd as ST, k as Zr, ka as IT, kb as dp, kc as mc, kd as Ii, l as hT, la as DT, lb as Tt, lc as fe, ld as Ac, m as Ua, ma as Ya, mb as ae, mc as Qe, md as Rc, n as G, na as ii, nb as tc, nc as yc, nd as bT, o as Kr, oa as ap, ob as fp, oc as he, od as Oc, p as np, pa as cp, pb as pp, pc as Ye, pd as AT, q as B, qa as si, qb as nc, qc as wp, qd as RT, r as Io, ra as It, rb as k, rc as vc, rd as qt, s as gT, sa as Za, sb as bo, sc as _p, sd as OT, t as mT, ta as lp, tb as Bt, tc as Sp, td as kT, u as Jr, ua as ai, ub as te, uc as Ec, ud as xT, v as $a, va as up, vb as hp, vc as hi, vd as PT, w as S, wa as CT, wb as Ut, wc as gi, wd as Lp, x as yT, xa as j, xb as Mt, xc as ko, y as vT, ya as m, yb as Ao, yc as Ic, z as yt, za as A, zb as pe, zc as mi } from "@nf-internal/chunk-6JHHKPZY";
import { b as dT } from "@nf-internal/chunk-74IHY5CB";
import { B as Ha, E as Va, a as tt, b as P, c as Kf, f as Fa, g as Gr, n as vo, p as Wr, r as qr, s as Eo, w as Jf, x as Xf } from "@nf-internal/chunk-WBZPGP5R";
import { a as Z, b as et, d as mt } from "@nf-internal/chunk-4CLCTAJ7";
import { setActiveConsumer as wn } from "@angular/core/primitives/signals";
import { Subject as Jh, Subscription as FT } from "rxjs";
import { map as HT } from "rxjs/operators";
var Mn = { JSACTION: "jsaction" };
function Je(e) { return { toString: e }.toString(); }
var _n = "__annotations__", Sn = "__parameters__", bn = "__prop__metadata__";
function yr(e, t, n, o, r) { return Je(() => { let i = su(t); function s(...a) { if (this instanceof s)
    return i.call(this, ...a), this; let c = new s(...a); return function (u) { return r && r(u, ...a), (u.hasOwnProperty(_n) ? u[_n] : Object.defineProperty(u, _n, { value: [] })[_n]).push(c), u; }; } return n && (s.prototype = Object.create(n.prototype)), s.prototype.ngMetadataName = e, s.annotationCls = s, s; }); }
function su(e) { return function (...n) { if (e) {
    let o = e(...n);
    for (let r in o)
        this[r] = o[r];
} }; }
function Zn(e, t, n) { return Je(() => { let o = su(t); function r(...i) { if (this instanceof r)
    return o.apply(this, i), this; let s = new r(...i); return a.annotation = s, a; function a(c, l, u) { let d = c.hasOwnProperty(Sn) ? c[Sn] : Object.defineProperty(c, Sn, { value: [] })[Sn]; for (; d.length <= u;)
    d.push(null); return (d[u] = d[u] || []).push(s), c; } } return r.prototype.ngMetadataName = e, r.annotationCls = r, r; }); }
function ct(e, t, n, o) { return Je(() => { let r = su(t); function i(...s) { if (this instanceof i)
    return r.apply(this, s), this; let a = new i(...s); function c(l, u) { if (l === void 0)
    throw new Error("Standard Angular field decorators are not supported in JIT mode."); let d = l.constructor, f = d.hasOwnProperty(bn) ? d[bn] : Object.defineProperty(d, bn, { value: {} })[bn]; f[u] = f.hasOwnProperty(u) && f[u] || [], f[u].unshift(a); } return c; } return n && (i.prototype = Object.create(n.prototype)), i.prototype.ngMetadataName = e, i.annotationCls = i, i; }); }
var Xh = En(Zn("Inject", e => ({ token: e })), -1), eg = En(Zn("Optional"), 8), tg = En(Zn("Self"), 2), ng = En(Zn("SkipSelf"), 4), og = En(Zn("Host"), 1);
function oe(e) { let t = De.ng; if (t && t.\u0275compilerFacade)
    return t.\u0275compilerFacade; throw new Error("JIT compiler unavailable"); }
var Fp = { \u0275\u0275defineInjectable: B, \u0275\u0275defineInjector: Io, \u0275\u0275inject: Le, \u0275\u0275invalidFactoryDep: ti, resolveForwardRef: G }, rg = Function;
function Ho(e) { return typeof e == "function"; }
var VT = /^function\s+\S+\(\)\s*{[\s\S]+\.apply\(this,\s*(arguments|(?:[^()]+\(\[\],)?[^()]+\(arguments\).*)\)/, jT = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{/, BT = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{[\s\S]*constructor\s*\(/, UT = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{[\s\S]*constructor\s*\(\)\s*{[^}]*super\(\.\.\.arguments\)/;
function $T(e) { return VT.test(e) || UT.test(e) || jT.test(e) && !BT.test(e); }
var Ui = class {
    _reflect;
    constructor(t) { this._reflect = t || De.Reflect; }
    factory(t) { return (...n) => new t(...n); }
    _zipTypesAndAnnotations(t, n) { let o; typeof t > "u" ? o = To(n.length) : o = To(t.length); for (let r = 0; r < o.length; r++)
        typeof t > "u" ? o[r] = [] : t[r] && t[r] != Object ? o[r] = [t[r]] : o[r] = [], n && n[r] != null && (o[r] = o[r].concat(n[r])); return o; }
    _ownParameters(t, n) { let o = t.toString(); if ($T(o))
        return null; if (t.parameters && t.parameters !== n.parameters)
        return t.parameters; let r = t.ctorParameters; if (r && r !== n.ctorParameters) {
        let a = typeof r == "function" ? r() : r, c = a.map(u => u && u.type), l = a.map(u => u && kc(u.decorators));
        return this._zipTypesAndAnnotations(c, l);
    } let i = t.hasOwnProperty(Sn) && t[Sn], s = this._reflect && this._reflect.getOwnMetadata && this._reflect.getOwnMetadata("design:paramtypes", t); return s || i ? this._zipTypesAndAnnotations(s, i) : To(t.length); }
    parameters(t) { if (!Ho(t))
        return []; let n = Di(t), o = this._ownParameters(t, n); return !o && n !== Object && (o = this.parameters(n)), o || []; }
    _ownAnnotations(t, n) { if (t.annotations && t.annotations !== n.annotations) {
        let o = t.annotations;
        return typeof o == "function" && o.annotations && (o = o.annotations), o;
    } return t.decorators && t.decorators !== n.decorators ? kc(t.decorators) : t.hasOwnProperty(_n) ? t[_n] : null; }
    annotations(t) { if (!Ho(t))
        return []; let n = Di(t), o = this._ownAnnotations(t, n) || []; return (n !== Object ? this.annotations(n) : []).concat(o); }
    _ownPropMetadata(t, n) { if (t.propMetadata && t.propMetadata !== n.propMetadata) {
        let o = t.propMetadata;
        return typeof o == "function" && o.propMetadata && (o = o.propMetadata), o;
    } if (t.propDecorators && t.propDecorators !== n.propDecorators) {
        let o = t.propDecorators, r = {};
        return Object.keys(o).forEach(i => { r[i] = kc(o[i]); }), r;
    } return t.hasOwnProperty(bn) ? t[bn] : null; }
    propMetadata(t) { if (!Ho(t))
        return {}; let n = Di(t), o = {}; if (n !== Object) {
        let i = this.propMetadata(n);
        Object.keys(i).forEach(s => { o[s] = i[s]; });
    } let r = this._ownPropMetadata(t, n); return r && Object.keys(r).forEach(i => { let s = []; o.hasOwnProperty(i) && s.push(...o[i]), s.push(...r[i]), o[i] = s; }), o; }
    ownPropMetadata(t) { return Ho(t) ? this._ownPropMetadata(t, Di(t)) || {} : {}; }
    hasLifecycleHook(t, n) { return t instanceof rg && n in t.prototype; }
};
function kc(e) { return e ? e.map(t => { let o = t.type.annotationCls, r = t.args ? t.args : []; return new o(...r); }) : []; }
function Di(e) { let t = e.prototype ? Object.getPrototypeOf(e.prototype) : null; return (t ? t.constructor : null) || Object; }
function ig(e, t, n, o) { t !== null ? t.applyValueToInputSignal(t, o) : e[n] = o; }
var $i = class {
    previousValue;
    currentValue;
    firstChange;
    constructor(t, n, o) { this.previousValue = t, this.currentValue = n, this.firstChange = o; }
    isFirstChange() { return this.firstChange; }
}, sg = (() => { let e = () => ag; return e.ngInherit = !0, e; })();
function ag(e) { return e.type.prototype.ngOnChanges && (e.setInput = GT), zT; }
function zT() { let e = lg(this), t = e?.current; if (t) {
    let n = e.previous;
    if (n === _e)
        e.previous = t;
    else
        for (let o in t)
            n[o] = t[o];
    e.current = null, this.ngOnChanges(t);
} }
function GT(e, t, n, o, r) { let i = this.declaredInputs[o], s = lg(e) || WT(e, { previous: _e, current: null }), a = s.current || (s.current = {}), c = s.previous, l = c[i]; a[i] = new $i(l && l.currentValue, n, c === _e), ig(e, t, r, n); }
var cg = "__ngSimpleChanges__";
function lg(e) { return e[cg] || null; }
function WT(e, t) { return e[cg] = t; }
var Hp = [];
var x = function (e, t = null, n) { for (let o = 0; o < Hp.length; o++) {
    let r = Hp[o];
    r(e, t, n);
} }, R = (function (e) { return e[e.TemplateCreateStart = 0] = "TemplateCreateStart", e[e.TemplateCreateEnd = 1] = "TemplateCreateEnd", e[e.TemplateUpdateStart = 2] = "TemplateUpdateStart", e[e.TemplateUpdateEnd = 3] = "TemplateUpdateEnd", e[e.LifecycleHookStart = 4] = "LifecycleHookStart", e[e.LifecycleHookEnd = 5] = "LifecycleHookEnd", e[e.OutputStart = 6] = "OutputStart", e[e.OutputEnd = 7] = "OutputEnd", e[e.BootstrapApplicationStart = 8] = "BootstrapApplicationStart", e[e.BootstrapApplicationEnd = 9] = "BootstrapApplicationEnd", e[e.BootstrapComponentStart = 10] = "BootstrapComponentStart", e[e.BootstrapComponentEnd = 11] = "BootstrapComponentEnd", e[e.ChangeDetectionStart = 12] = "ChangeDetectionStart", e[e.ChangeDetectionEnd = 13] = "ChangeDetectionEnd", e[e.ChangeDetectionSyncStart = 14] = "ChangeDetectionSyncStart", e[e.ChangeDetectionSyncEnd = 15] = "ChangeDetectionSyncEnd", e[e.AfterRenderHooksStart = 16] = "AfterRenderHooksStart", e[e.AfterRenderHooksEnd = 17] = "AfterRenderHooksEnd", e[e.ComponentStart = 18] = "ComponentStart", e[e.ComponentEnd = 19] = "ComponentEnd", e[e.DeferBlockStateStart = 20] = "DeferBlockStateStart", e[e.DeferBlockStateEnd = 21] = "DeferBlockStateEnd", e[e.DynamicComponentStart = 22] = "DynamicComponentStart", e[e.DynamicComponentEnd = 23] = "DynamicComponentEnd", e[e.HostBindingsUpdateStart = 24] = "HostBindingsUpdateStart", e[e.HostBindingsUpdateEnd = 25] = "HostBindingsUpdateEnd", e; })(R || {});
function qT(e, t, n) { let { ngOnChanges: o, ngOnInit: r, ngDoCheck: i } = t.type.prototype; if (o) {
    let s = ag(t);
    (n.preOrderHooks ??= []).push(e, s), (n.preOrderCheckHooks ??= []).push(e, s);
} r && (n.preOrderHooks ??= []).push(0 - e, r), i && ((n.preOrderHooks ??= []).push(e, i), (n.preOrderCheckHooks ??= []).push(e, i)); }
function ug(e, t) { for (let n = t.directiveStart, o = t.directiveEnd; n < o; n++) {
    let i = e.data[n].type.prototype, { ngAfterContentInit: s, ngAfterContentChecked: a, ngAfterViewInit: c, ngAfterViewChecked: l, ngOnDestroy: u } = i;
    s && (e.contentHooks ??= []).push(-n, s), a && ((e.contentHooks ??= []).push(n, a), (e.contentCheckHooks ??= []).push(n, a)), c && (e.viewHooks ??= []).push(-n, c), l && ((e.viewHooks ??= []).push(n, l), (e.viewCheckHooks ??= []).push(n, l)), u != null && (e.destroyHooks ??= []).push(n, u);
} }
function Oi(e, t, n) { dg(e, t, 3, n); }
function ki(e, t, n, o) { (e[A] & 3) === n && dg(e, t, n, o); }
function xc(e, t) { let n = e[A]; (n & 3) === t && (n &= 16383, n += 1, e[A] = n); }
function dg(e, t, n, o) { let r = o !== void 0 ? e[In] & 65535 : 0, i = o ?? -1, s = t.length - 1, a = 0; for (let c = r; c < s; c++)
    if (typeof t[c + 1] == "number") {
        if (a = t[c], o != null && a >= o)
            break;
    }
    else
        t[c] < 0 && (e[In] += 65536), (a < i || i == -1) && (QT(e, n, t, c), e[In] = (e[In] & 4294901760) + c + 2), c++; }
function Vp(e, t) { x(R.LifecycleHookStart, e, t); let n = P(null); try {
    t.call(e);
}
finally {
    P(n), x(R.LifecycleHookEnd, e, t);
} }
function QT(e, t, n, o) { let r = n[o] < 0, i = n[o + 1], s = r ? -n[o] : n[o], a = e[s]; r ? e[A] >> 14 < e[In] >> 16 && (e[A] & 3) === t && (e[A] += 16384, Vp(a, i)) : Vp(a, i); }
var kn = -1, en = class {
    factory;
    name;
    injectImpl;
    resolving = !1;
    canSeeViewProviders;
    multi;
    componentProviders;
    index;
    providerFactory;
    constructor(t, n, o, r) { this.factory = t, this.name = r, this.canSeeViewProviders = n, this.injectImpl = o; }
};
function ys(e) { return e != null && typeof e == "object" && (e.insertBeforeIndex === null || typeof e.insertBeforeIndex == "number" || Array.isArray(e.insertBeforeIndex)); }
function fg(e) { return !!(e.type & 128); }
function YT(e) { return (e.flags & 8) !== 0; }
function ZT(e) { return (e.flags & 16) !== 0; }
function KT(e, t, n) { let o = 0; for (; o < n.length;) {
    let r = n[o];
    if (typeof r == "number") {
        if (r !== 0)
            break;
        o++;
        let i = n[o++], s = n[o++], a = n[o++];
        e.setAttribute(t, s, a, i);
    }
    else {
        let i = r, s = n[++o];
        JT(i) ? e.setProperty(t, i, s) : e.setAttribute(t, i, s), o++;
    }
} return o; }
function pg(e) { return e === 3 || e === 4 || e === 6; }
function JT(e) { return e.charCodeAt(0) === 64; }
function Vn(e, t) { if (!(t === null || t.length === 0))
    if (e === null || e.length === 0)
        e = t.slice();
    else {
        let n = -1;
        for (let o = 0; o < t.length; o++) {
            let r = t[o];
            typeof r == "number" ? n = r : n === 0 || (n === -1 || n === 2 ? jp(e, n, r, null, t[++o]) : jp(e, n, r, null, null));
        }
    } return e; }
function jp(e, t, n, o, r) { let i = 0, s = e.length; if (t === -1)
    s = -1;
else
    for (; i < e.length;) {
        let a = e[i++];
        if (typeof a == "number") {
            if (a === t) {
                s = -1;
                break;
            }
            else if (a > t) {
                s = i - 1;
                break;
            }
        }
    } for (; i < e.length;) {
    let a = e[i];
    if (typeof a == "number")
        break;
    if (a === n) {
        r !== null && (e[i + 1] = r);
        return;
    }
    i++, r !== null && i++;
} s !== -1 && (e.splice(s, 0, t), i = s + 1), e.splice(i++, 0, n), r !== null && e.splice(i++, 0, r); }
function hg(e) { return e !== kn; }
function zi(e) { return e & 32767; }
function XT(e) { return e >> 16; }
function Gi(e, t) { let n = XT(e), o = t; for (; n > 0;)
    o = o[wo], n--; return o; }
var ol = !0;
function Wi(e) { let t = ol; return ol = e, t; }
var eM = 256, gg = eM - 1, mg = 5, tM = 0, Ke = {};
function nM(e, t, n) { let o; typeof n == "string" ? o = n.charCodeAt(0) || 0 : n.hasOwnProperty(Lt) && (o = n[Lt]), o == null && (o = n[Lt] = tM++); let r = o & gg, i = 1 << r; t.data[e + (r >> mg)] |= i; }
function qi(e, t) { let n = yg(e, t); if (n !== -1)
    return n; let o = t[m]; o.firstCreatePass && (e.injectorIndex = t.length, Pc(o.data, e), Pc(t, null), Pc(o.blueprint, null)); let r = au(e, t), i = e.injectorIndex; if (hg(r)) {
    let s = zi(r), a = Gi(r, t), c = a[m].data;
    for (let l = 0; l < 8; l++)
        t[i + l] = a[s + l] | c[s + l];
} return t[i + 8] = r, i; }
function Pc(e, t) { e.push(0, 0, 0, 0, 0, 0, 0, 0, t); }
function yg(e, t) { return e.injectorIndex === -1 || e.parent && e.parent.injectorIndex === e.injectorIndex || t[e.injectorIndex + 8] === null ? -1 : e.injectorIndex; }
function au(e, t) { if (e.parent && e.parent.injectorIndex !== -1)
    return e.parent.injectorIndex; let n = 0, o = null, r = t; for (; r !== null;) {
    if (o = Tg(r), o === null)
        return kn;
    if (n++, r = r[wo], o.injectorIndex !== -1)
        return o.injectorIndex | n << 16;
} return kn; }
function rl(e, t, n) { nM(e, t, n); }
function oM(e, t) { if (t === "class")
    return e.classes; if (t === "style")
    return e.styles; let n = e.attrs; if (n) {
    let o = n.length, r = 0;
    for (; r < o;) {
        let i = n[r];
        if (pg(i))
            break;
        if (i === 0)
            r = r + 2;
        else if (typeof i == "number")
            for (r++; r < o && typeof n[r] == "string";)
                r++;
        else {
            if (i === t)
                return n[r + 1];
            r = r + 2;
        }
    }
} return null; }
function vg(e, t, n) { if (n & 8 || e !== void 0)
    return e; Ga(t, "NodeInjector"); }
function Eg(e, t, n, o) { if (n & 8 && o === void 0 && (o = null), (n & 3) === 0) {
    let r = e[O], i = Ft(void 0);
    try {
        return r ? r.get(t, o, n & 8) : rp(t, o, n & 8);
    }
    finally {
        Ft(i);
    }
} return vg(o, t, n); }
function Ig(e, t, n, o = 0, r) { if (e !== null) {
    if (t[A] & 2048 && !(o & 2)) {
        let s = aM(e, t, n, o, Ke);
        if (s !== Ke)
            return s;
    }
    let i = Dg(e, t, n, o, Ke);
    if (i !== Ke)
        return i;
} return Eg(t, n, o, r); }
function Dg(e, t, n, o, r) { let i = iM(n); if (typeof i == "function") {
    if (!Ic(t, e, o))
        return o & 1 ? vg(r, n, o) : Eg(t, n, o, r);
    try {
        let s;
        if (s = i(o), s == null && !(o & 8))
            Ga(n);
        else
            return s;
    }
    finally {
        Dc();
    }
}
else if (typeof i == "number") {
    let s = null, a = yg(e, t), c = kn, l = o & 1 ? t[K][ue] : null;
    for ((a === -1 || o & 4) && (c = a === -1 ? au(e, t) : t[a + 8], c === kn || !Up(o, !1) ? a = -1 : (s = t[m], a = zi(c), t = Gi(c, t))); a !== -1;) {
        let u = t[m];
        if (Bp(i, a, u.data)) {
            let d = rM(a, t, n, s, o, l);
            if (d !== Ke)
                return d;
        }
        c = t[a + 8], c !== kn && Up(o, t[m].data[a + 8] === l) && Bp(i, a, t) ? (s = u, a = zi(c), t = Gi(c, t)) : a = -1;
    }
} return r; }
function rM(e, t, n, o, r, i) { let s = t[m], a = s.data[e + 8], c = o == null ? me(a) && ol : o != s && (a.type & 3) !== 0, l = r & 1 && i === a, u = xi(a, s, n, c, l); return u !== null ? Ko(t, s, u, a, r) : Ke; }
function xi(e, t, n, o, r) { let i = e.providerIndexes, s = t.data, a = i & 1048575, c = e.directiveStart, l = e.directiveEnd, u = i >> 20, d = o ? a : a + u, f = r ? a + u : l; for (let p = d; p < f; p++) {
    let h = s[p];
    if (p < c && n === h || p >= c && h.type === n)
        return p;
} if (r) {
    let p = s[c];
    if (p && Ae(p) && p.type === n)
        return c;
} return null; }
function Ko(e, t, n, o, r) { let i = e[n], s = t.data; if (i instanceof en) {
    let a = i;
    if (a.resolving)
        throw op("");
    let c = Wi(a.canSeeViewProviders);
    a.resolving = !0;
    let l = s[n].type || s[n], u, d = a.injectImpl ? Ft(a.injectImpl) : null, f = Ic(e, o, 0);
    try {
        i = e[n] = a.factory(void 0, r, s, e, o), t.firstCreatePass && n >= o.directiveStart && qT(n, s[n], t);
    }
    finally {
        d !== null && Ft(d), Wi(c), a.resolving = !1, Dc();
    }
} return i; }
function iM(e) { if (typeof e == "string")
    return e.charCodeAt(0) || 0; let t = e.hasOwnProperty(Lt) ? e[Lt] : void 0; return typeof t == "number" ? t >= 0 ? t & gg : sM : t; }
function Bp(e, t, n) { let o = 1 << e; return !!(n[t + (e >> mg)] & o); }
function Up(e, t) { return !(e & 2) && !(e & 1 && t); }
var St = class {
    _tNode;
    _lView;
    constructor(t, n) { this._tNode = t, this._lView = n; }
    get(t, n, o) { return Ig(this._tNode, this._lView, t, Wa(o), n); }
};
function sM() { return new St(M(), g()); }
function Cg(e) { return Je(() => { let t = e.prototype.constructor, n = t[vt] || il(t), o = Object.prototype, r = Object.getPrototypeOf(e.prototype).constructor; for (; r && r !== o;) {
    let i = r[vt] || il(r);
    if (i && i !== n)
        return i;
    r = Object.getPrototypeOf(r);
} return i => new i; }); }
function il(e) { return Kr(e) ? () => { let t = il(G(e)); return t && t(); } : ni(e); }
function aM(e, t, n, o, r) { let i = e, s = t; for (; i !== null && s !== null && s[A] & 2048 && !We(s);) {
    let a = Dg(i, s, n, o | 2, Ke);
    if (a !== Ke)
        return a;
    let c = i.parent;
    if (!c) {
        let l = s[Ka];
        if (l) {
            let u = l.get(n, Ke, o & -5);
            if (u !== Ke)
                return u;
        }
        c = Tg(s), s = s[wo];
    }
    i = c;
} return r; }
function Tg(e) { let t = e[m], n = t.type; return n === 2 ? t.declTNode : n === 1 ? e[ue] : null; }
function vs(e) { return oM(M(), e); }
var Mg = Zn("Attribute", e => ({ attributeName: e, __NG_ELEMENT_ID__: () => vs(e) })), $p = null;
function cu() { return $p = $p || new Ui; }
function Es(e) { return Ng(cu().parameters(e)); }
function Ng(e) { return e.map(t => cM(t)); }
function cM(e) { let t = { token: null, attribute: null, host: !1, optional: !1, self: !1, skipSelf: !1 }; if (Array.isArray(e) && e.length > 0)
    for (let n = 0; n < e.length; n++) {
        let o = e[n];
        if (o === void 0)
            continue;
        let r = Object.getPrototypeOf(o);
        if (o instanceof eg || r.ngMetadataName === "Optional")
            t.optional = !0;
        else if (o instanceof ng || r.ngMetadataName === "SkipSelf")
            t.skipSelf = !0;
        else if (o instanceof tg || r.ngMetadataName === "Self")
            t.self = !0;
        else if (o instanceof og || r.ngMetadataName === "Host")
            t.host = !0;
        else if (o instanceof Xh)
            t.token = o.token;
        else if (o instanceof Mg) {
            if (o.attributeName === void 0)
                throw new _(-204, !1);
            t.attribute = o.attributeName;
        }
        else
            t.token = o;
    }
else
    e === void 0 || Array.isArray(e) && e.length === 0 ? t.token = null : t.token = e; return t; }
function lM(e, t) { let n = null, o = null; e.hasOwnProperty(Jr) || Object.defineProperty(e, Jr, { get: () => (n === null && (n = oe({ usage: 0, kind: "injectable", type: e }).compileInjectable(Fp, `ng:///${e.name}/\u0275prov.js`, pM(e, t))), n) }), e.hasOwnProperty(vt) || Object.defineProperty(e, vt, { get: () => { if (o === null) {
        let r = oe({ usage: 0, kind: "injectable", type: e });
        o = r.compileFactory(Fp, `ng:///${e.name}/\u0275fac.js`, { name: e.name, type: e, typeArgumentCount: 0, deps: Es(e), target: r.FactoryTarget.Injectable });
    } return o; }, configurable: !0 }); }
var uM = Ba({ provide: String, useValue: Ba });
function zp(e) { return e.useClass !== void 0; }
function dM(e) { return uM in e; }
function Gp(e) { return e.useFactory !== void 0; }
function fM(e) { return e.useExisting !== void 0; }
function pM(e, t) { let n = t || { providedIn: null }, o = { name: e.name, type: e, typeArgumentCount: 0, providedIn: n.providedIn }; return (zp(n) || Gp(n)) && n.deps !== void 0 && (o.deps = Ng(n.deps)), zp(n) ? o.useClass = n.useClass : dM(n) ? o.useValue = n.useValue : Gp(n) ? o.useFactory = n.useFactory : fM(n) && (o.useExisting = n.useExisting), o; }
var hM = yr("Injectable", void 0, void 0, void 0, (e, t) => lM(e, t));
function gM() { return Kn(M(), g()); }
function Kn(e, t) { return new vr(te(e, t)); }
var vr = (() => { class e {
    nativeElement;
    constructor(n) { this.nativeElement = n; }
    static __NG_ELEMENT_ID__ = gM;
} return e; })();
function wg(e) { return e instanceof vr ? e.nativeElement : e; }
function mM() { return this._results[Symbol.iterator](); }
var Qi = class {
    _emitDistinctChangesOnly;
    dirty = !0;
    _onDirty = void 0;
    _results = [];
    _changesDetected = !1;
    _changes = void 0;
    length = 0;
    first = void 0;
    last = void 0;
    get changes() { return this._changes ??= new Jh; }
    constructor(t = !1) { this._emitDistinctChangesOnly = t; }
    get(t) { return this._results[t]; }
    map(t) { return this._results.map(t); }
    filter(t) { return this._results.filter(t); }
    find(t) { return this._results.find(t); }
    reduce(t, n) { return this._results.reduce(t, n); }
    forEach(t) { this._results.forEach(t); }
    some(t) { return this._results.some(t); }
    toArray() { return this._results.slice(); }
    toString() { return this._results.toString(); }
    reset(t, n) { this.dirty = !1; let o = Fe(t); (this._changesDetected = !ip(this._results, o, n)) && (this._results = o, this.length = o.length, this.last = o[this.length - 1], this.first = o[0]); }
    notifyOnChanges() { this._changes !== void 0 && (this._changesDetected || !this._emitDistinctChangesOnly) && this._changes.next(this); }
    onDirty(t) { this._onDirty = t; }
    setDirty() { this.dirty = !0, this._onDirty?.(); }
    destroy() { this._changes !== void 0 && (this._changes.complete(), this._changes.unsubscribe()); }
    [Symbol.iterator] = mM;
}, dn = "ngSkipHydration", yM = "ngskiphydration";
function lu(e) { let t = e.mergedAttrs; if (t === null)
    return !1; for (let n = 0; n < t.length; n += 2) {
    let o = t[n];
    if (typeof o == "number")
        return !1;
    if (typeof o == "string" && o.toLowerCase() === yM)
        return !0;
} return !1; }
function _g(e) { return e.hasAttribute(dn); }
function Jo(e) { return (e.flags & 128) === 128; }
function Jn(e) { if (Jo(e))
    return !0; let t = e.parent; for (; t;) {
    if (Jo(e) || lu(t))
        return !0;
    t = t.parent;
} return !1; }
function Sg(e) { return Jo(e) || lu(e) || Jn(e); }
var Is = (function (e) { return e[e.OnPush = 0] = "OnPush", e[e.Eager = 1] = "Eager", e[e.Default = 1] = "Default", e; })(Is || {}), Ds = new Map, vM = 0;
function EM() { return vM++; }
function IM(e) { Ds.set(e[Se], e); }
function bg(e) { return Ds.get(e) || null; }
function sl(e) { Ds.delete(e[Se]); }
function DM() { return Ds; }
var Yi = class {
    lViewId;
    nodeIndex;
    native;
    component;
    directives;
    localRefs;
    get lView() { return bg(this.lViewId); }
    constructor(t, n, o) { this.lViewId = t, this.nodeIndex = n, this.native = o; }
};
function Ie(e) { let t = Pi(e); if (t) {
    if (re(t)) {
        let n = t, o, r, i;
        if (Ag(e)) {
            if (o = NM(n, e), o == -1)
                throw new Error("The provided component was not found in the application");
            r = e;
        }
        else if (TM(e)) {
            if (o = wM(n, e), o == -1)
                throw new Error("The provided directive was not found in the application");
            i = Rg(o, n);
        }
        else if (o = qp(n, e), o == -1)
            return null;
        let s = k(n[o]), a = Pi(s), c = a && !Array.isArray(a) ? a : Wp(n, o, s);
        if (r && c.component === void 0 && (c.component = r, Re(c.component, c)), i && c.directives === void 0) {
            c.directives = i;
            for (let l = 0; l < i.length; l++)
                Re(i[l], c);
        }
        Re(c.native, c), t = c;
    }
}
else {
    let n = e, o = n;
    for (; o = o.parentNode;) {
        let r = Pi(o);
        if (r) {
            let i = Array.isArray(r) ? r : r.lView;
            if (!i)
                return null;
            let s = qp(i, n);
            if (s >= 0) {
                let a = k(i[s]), c = Wp(i, s, a);
                Re(a, c), t = c;
                break;
            }
        }
    }
} return t || null; }
function Wp(e, t, n) { return new Yi(e[Se], t, n); }
var al = "__ngContext__";
function Re(e, t) { re(t) ? (e[al] = t[Se], IM(t)) : e[al] = t; }
function Pi(e) { let t = e[al]; return typeof t == "number" ? bg(t) : t || null; }
function CM(e) { let t = Pi(e); return t ? re(t) ? t : t.lView : null; }
function Ag(e) { return e && e.constructor && e.constructor.\u0275cmp; }
function TM(e) { return e && e.constructor && e.constructor.\u0275dir; }
function qp(e, t) { let n = e[m]; for (let o = E; o < n.bindingStartIndex; o++)
    if (k(e[o]) === t)
        return o; return -1; }
function MM(e) { if (e.child)
    return e.child; if (e.next)
    return e.next; for (; e.parent && !e.parent.next;)
    e = e.parent; return e.parent && e.parent.next; }
function NM(e, t) { let n = e[m].components; if (n)
    for (let o = 0; o < n.length; o++) {
        let r = n[o];
        if (pe(r, e)[H] === t)
            return r;
    }
else if (pe(E, e)[H] === t)
    return E; return -1; }
function wM(e, t) { let n = e[m].firstChild; for (; n;) {
    let o = n.directiveStart, r = n.directiveEnd;
    for (let i = o; i < r; i++)
        if (e[i] === t)
            return n.index;
    n = MM(n);
} return -1; }
function Rg(e, t) { let n = t[m].data[e]; if (n.directiveStart === 0)
    return F; let o = []; for (let r = n.directiveStart; r < n.directiveEnd; r++) {
    let i = t[r];
    Ag(i) || o.push(i);
} return o; }
function _M(e, t) { let n = t[m].data[e]; return me(n) ? t[n.directiveStart + n.componentOffset] : null; }
function SM(e, t) { let n = e[m].data[t]; if (n && n.localNames) {
    let o = {}, r = n.index + 1;
    for (let i = 0; i < n.localNames.length; i += 2)
        o[n.localNames[i]] = e[r], r++;
    return o;
} return null; }
function Og(e) { return xg(e[Dt]); }
function kg(e) { return xg(e[le]); }
function xg(e) { for (; e !== null && !ee(e);)
    e = e[le]; return e; }
function Qp(e) { let t = Ie(e); if (t === null)
    return null; if (t.component === void 0) {
    let n = t.lView;
    if (n === null)
        return null;
    t.component = _M(t.nodeIndex, n);
} return t.component; }
function bM(e) { VM(e); let t = Ie(e), n = t ? t.lView : null; return n === null ? null : n[H]; }
function AM(e) { let t = Ie(e), n = t ? t.lView : null; if (n === null)
    return null; let o; for (; n[m].type === 2 && (o = $t(n));)
    n = o; return We(n) ? null : n[H]; }
function RM(e) { let t = Ie(e), n = t ? t.lView : null; if (n === null)
    return Te.NULL; let o = n[m].data[t.nodeIndex]; return new St(o, n); }
function OM(e) { let t = Ie(e), n = t ? t.lView : null; if (n === null)
    return []; let o = n[m], r = o.data[t.nodeIndex], i = [], s = r.providerIndexes & 1048575, a = r.directiveEnd; for (let c = s; c < a; c++) {
    let l = o.data[c];
    HM(l) && (l = l.type), i.push(l);
} return i; }
function kM(e) { if (e instanceof Text)
    return []; let t = Ie(e), n = t ? t.lView : null; if (n === null)
    return []; let o = n[m], r = t.nodeIndex; return o?.data[r] ? (t.directives === void 0 && (t.directives = Rg(r, n)), t.directives === null ? [] : [...t.directives]) : []; }
var Pg = (function (e) { return e[e.Default = 0] = "Default", e[e.OnPush = 1] = "OnPush", e; })(Pg || {}), Lg = (function (e) { return e[e.Emulated = 0] = "Emulated", e[e.None = 1] = "None", e; })(Lg || {});
function xM(e) { let t = Ie(e); if (t === null)
    return {}; if (t.localRefs === void 0) {
    let n = t.lView;
    if (n === null)
        return {};
    t.localRefs = SM(n, t.nodeIndex);
} return t.localRefs || {}; }
function PM(e) { return Ie(e).native; }
function LM(e) { let t = Ie(e), n = t === null ? null : t.lView; if (n === null)
    return []; let o = n[m], r = n[Ht], i = o.cleanup, s = []; if (i && r)
    for (let a = 0; a < i.length;) {
        let c = i[a++], l = i[a++];
        if (typeof c == "string") {
            let u = c, d = k(n[l]), f = r[i[a++]], p = i[a++], h = typeof p == "boolean" || p >= 0 ? "dom" : "output", y = typeof p == "boolean" ? p : !1;
            e == d && s.push({ element: e, name: u, callback: f, useCapture: y, type: h });
        }
    } return s.sort(FM), s; }
function FM(e, t) { return e.name == t.name ? 0 : e.name < t.name ? -1 : 1; }
function HM(e) { return e.type !== void 0 && e.declaredInputs !== void 0 && e.resolveHostDirectives !== void 0; }
function VM(e) { if (typeof Element < "u" && !(e instanceof Element))
    throw new Error("Expecting instance of DOM Element"); }
var cl;
function jM(e) { cl = e; }
function Cs() { if (cl !== void 0)
    return cl; if (typeof document < "u")
    return document; throw new _(210, !1); }
var lt = new S("", { factory: () => BM }), BM = "ng";
var uu = new S(""), UM = new S("", { providedIn: "platform", factory: () => "unknown" }), $M = new S(""), zM = new S("", { factory: () => I(zt).body?.querySelector("[ngCspNonce]")?.getAttribute("ngCspNonce") || null }), Fg = { breakpoints: [16, 32, 48, 64, 96, 128, 256, 384, 640, 750, 828, 1080, 1200, 1920, 2048, 3840], placeholderResolution: 30, disableImageSizeWarning: !1, disableImageLazyLoadWarning: !1 }, GM = new S("", { factory: () => Fg });
function WM(e) { return e; }
var Xn = (() => { class e {
    static \u0275prov = B({ token: e, providedIn: "root", factory: () => { let n = new e; return (typeof ngServerMode > "u" || !ngServerMode) && (n.store = Hg(I(zt), I(lt))), n; } });
    store = {};
    onSerializeCallbacks = {};
    get(n, o) { return this.store[n] !== void 0 ? this.store[n] : o; }
    set(n, o) { this.store[n] = o; }
    remove(n) { delete this.store[n]; }
    hasKey(n) { return this.store.hasOwnProperty(n); }
    get isEmpty() { return Object.keys(this.store).length === 0; }
    onSerialize(n, o) { this.onSerializeCallbacks[n] = o; }
    toJson() { for (let n in this.onSerializeCallbacks)
        if (this.onSerializeCallbacks.hasOwnProperty(n))
            try {
                this.store[n] = this.onSerializeCallbacks[n]();
            }
            catch (o) {
                console.warn("Exception in onSerialize callback: ", o);
            } return JSON.stringify(this.store).replace(/</g, "\\u003C").replace(/\//g, "\\u002F"); }
} return e; })();
function Hg(e, t) { let n = e.getElementById(t + "-state"); if (n?.tagName === "SCRIPT" && n.textContent)
    try {
        return JSON.parse(n.textContent);
    }
    catch (o) {
        console.warn("Exception while restoring TransferState for app " + t, o);
    } return {}; }
var du = "h", fu = "b", Vg = "f", jg = "n", Er = "e", Ts = "t", eo = "c", Ir = "x", st = "r", Ms = "i", Dr = "n", to = "d", Ns = "l", ws = "di", Cr = "s", pu = "p", Tr = "t", fn = new S(""), Bg = !1, hu = new S("", { factory: () => Bg }), gu = new S(""), _s = new S(""), mu = !1, Ug = new S("", { factory: () => [] }), yu = new S(""), Mr = new S("", { factory: () => new Map }), qM = new S(""), Zi = { passive: !0, capture: !0 }, Lc = new WeakMap, Fc = new WeakMap, _t = new WeakMap, Ki = ["click", "keydown"], Ji = ["mouseenter", "mouseover", "focusin"], Ci = new Map, Xo = class {
    callbacks = new Set;
    listener = () => { for (let t of this.callbacks)
        t(); };
};
function $g(e, t) { let n = Fc.get(e); if (!n) {
    n = new Xo, Fc.set(e, n);
    for (let o of Ki)
        e.addEventListener(o, n.listener, Zi);
} return n.callbacks.add(t), () => { let { callbacks: o, listener: r } = n; if (o.delete(t), o.size === 0) {
    Fc.delete(e);
    for (let i of Ki)
        e.removeEventListener(i, r, Zi);
} }; }
function zg(e, t) { let n = Lc.get(e); if (!n) {
    n = new Xo, Lc.set(e, n);
    for (let o of Ji)
        e.addEventListener(o, n.listener, Zi);
} return n.callbacks.add(t), () => { let { callbacks: o, listener: r } = n; if (o.delete(t), o.size === 0) {
    for (let i of Ji)
        e.removeEventListener(i, r, Zi);
    Lc.delete(e);
} }; }
function QM(e) { let t = Gg(e); return new IntersectionObserver(n => { for (let o of n)
    o.isIntersecting && _t.has(o.target) && _t.get(o.target)?.get(t)?.listener(); }, e); }
function YM(e, t, n, o) { let r = Gg(o), i = _t.get(e)?.get(r); Ci.has(r) || Ci.set(r, { observer: n(o), count: 0 }); let s = Ci.get(r); if (!i) {
    i = new Xo, s.observer.observe(e);
    let a = _t.get(e);
    a ? a.set(r, i) : (a = new Map, _t.set(e, a)), a.set(r, i), s.count++;
} return i.callbacks.add(t), () => { if (_t.get(e)?.has(r)) {
    if (i.callbacks.delete(t), i.callbacks.size === 0) {
        s.observer.unobserve(e), s.count--;
        let a = _t.get(e);
        a && (a.delete(r), a.size === 0 && _t.delete(e));
    }
    s.count === 0 && (s.observer.disconnect(), Ci.delete(r));
} }; }
function Gg(e) {
    return e ? `${e.rootMargin}/${typeof e.threshold == "number" ? e.threshold : e.threshold?.join(`
`)}` : "";
}
var no = "ngb";
function vu(e, t, n = null) { if (t.length === 0 || e.nodeType !== Node.ELEMENT_NODE)
    return; let o = e.getAttribute(Mn.JSACTION), r = t.reduce((s, a) => (o?.indexOf(a) ?? -1) === -1 ? s + a + ":;" : s, ""); e.setAttribute(Mn.JSACTION, `${o ?? ""}${r}`); let i = n ?? ""; i !== "" && r.length > 0 && e.setAttribute(no, i); }
var Wg = (e, t, n) => { let o = e, r = o.__jsaction_fns ?? new Map, i = r.get(t) ?? []; i.push(n), r.set(t, i), o.__jsaction_fns = r; }, Eu = (e, t) => { let n = e, o = n.getAttribute(no) ?? "", r = t.get(o) ?? new Set; r.has(n) || r.add(n), t.set(o, r); };
function ZM(e, t) { if (e.length > 0) {
    let n = [];
    for (let r of e)
        t.has(r) && (n = [...n, ...t.get(r)]);
    new Set(n).forEach(Iu);
} }
var Iu = e => { e.removeAttribute(Mn.JSACTION), e.removeAttribute(no), e.__jsaction_fns = void 0; }, Du = new S("", { factory: () => ({}) }), ll = new WeakMap;
function KM(e, t) { if (e == null || typeof e != "object")
    return; let n = ll.get(e); n || (n = new WeakSet, ll.set(e, n)), n.add(t); }
function Cu(e, t) { let n = t?.__jsaction_fns?.get(e.type); if (!(!n || !t?.isConnected) && !(t && ll.get(e)?.has(t)))
    for (let o of n)
        o(e); }
var ul = new Map;
function qg(e, t) { return ul.set(e, t), () => ul.delete(e); }
var Yp = !1, Qg = (e, t, n, o) => { };
function JM(e, t, n, o) { Qg(e, t, n, o); }
function Yg() { Yp || (Qg = (e, t, n, o) => { let r = e[O].get(lt); ul.get(r)?.(t, n, o); }, Yp = !0); }
var ut = new S(""), Zg = (() => { class e {
    registry = new Map;
    cleanupFns = new Map;
    jsActionMap = I(Mr);
    contract = I(Du);
    add(n, o) { if (this.registry.set(n, o), this.awaitingCallbacks.has(n)) {
        let r = this.awaitingCallbacks.get(n);
        for (let i of r)
            i();
    } }
    get(n) { return this.registry.get(n) ?? null; }
    has(n) { return this.registry.has(n); }
    cleanup(n) { ZM(n, this.jsActionMap); for (let o of n)
        this.registry.delete(o), this.jsActionMap.delete(o), this.invokeTriggerCleanupFns(o), this.hydrating.delete(o), this.awaitingCallbacks.delete(o); this.size === 0 && this.contract.instance?.cleanUp(); }
    get size() { return this.registry.size; }
    addCleanupFn(n, o) { let r = []; this.cleanupFns.has(n) && (r = this.cleanupFns.get(n)), r.push(o), this.cleanupFns.set(n, r); }
    invokeTriggerCleanupFns(n) { let o = this.cleanupFns.get(n) ?? []; for (let r of o)
        r(); this.cleanupFns.delete(n); }
    hydrating = new Map;
    awaitingCallbacks = new Map;
    awaitParentBlock(n, o) { let r = this.awaitingCallbacks.get(n) ?? []; r.push(o), this.awaitingCallbacks.set(n, r); }
    static \u0275prov = B({ token: e, providedIn: null, factory: () => new e });
} return e; })();
function oo(e) { return (e.flags & 32) === 32; }
var Kg = "__nghData__", Ss = Kg, Jg = "__nghDeferData__", bs = Jg;
function XM(e) { return e === Kg || e === Jg; }
var xn = "ngh", Xg = "nghm", em = () => null;
function eN(e, t, n = !1) { let o = e.getAttribute(xn); if (o == null)
    return null; let [r, i] = o.split("|"); if (o = n ? i : r, !o)
    return null; let s = i ? `|${i}` : "", a = n ? r : s, c = {}; if (o !== "") {
    let u = t.get(Xn, null, { optional: !0 });
    u !== null && (c = u.get(Ss, [])[Number(o)]);
} let l = { data: c, firstChild: e.firstChild ?? null }; return n && (l.firstChild = e, As(l, 0, e.nextSibling)), a ? e.setAttribute(xn, a) : e.removeAttribute(xn), l; }
function tm() { em = eN; }
function nm(e, t, n = !1) { return em(e, t, n); }
function Tu(e) { let t = e._lView; return t[m].type === 2 ? null : (We(t) && (t = t[E]), t); }
function tN(e) { return e.textContent?.replace(/\s/gm, ""); }
function nN(e) { let t = Cs(), n = t.createNodeIterator(e, NodeFilter.SHOW_COMMENT, { acceptNode(i) { let s = tN(i); return s === "ngetn" || s === "ngtns" ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; } }), o, r = []; for (; o = n.nextNode();)
    r.push(o); for (let i of r)
    i.textContent === "ngetn" ? i.replaceWith(t.createTextNode("")) : i.remove(); }
var om = (function (e) { return e.Hydrated = "hydrated", e.Skipped = "skipped", e.Mismatched = "mismatched", e; })(om || {}), oN = "__ngDebugHydrationInfo__";
function rN(e) { return e[oN] ?? null; }
function As(e, t, n) { e.segmentHeads ??= {}, e.segmentHeads[t] = n; }
function dl(e, t) { return e.segmentHeads?.[t] ?? null; }
function Nr(e) { return e.get(yu, !1, { optional: !0 }); }
var iN = !1;
function sN() { iN = !1; }
function rm(e, t) { let n = e.data, o = n[Er]?.[t] ?? null; return o === null && n[eo]?.[t] && (o = Mu(e, t)), o; }
function aN(e, t) { return e.data[Er]?.[t] !== void 0; }
function im(e, t) { return e.data[eo]?.[t] ?? null; }
function Mu(e, t) { let n = im(e, t) ?? [], o = 0; for (let r of n)
    o += r[st] * (r[Ir] ?? 1); return o; }
function sm(e) { if (typeof e.disconnectedNodes > "u") {
    let t = e.data[to];
    e.disconnectedNodes = t ? new Set(t) : null;
} return e.disconnectedNodes; }
function Rs(e, t) { if (typeof e.disconnectedNodes > "u") {
    let n = e.data[to];
    e.disconnectedNodes = n ? new Set(n) : null;
} return !!sm(e)?.has(t); }
function Os(e, t) { let n = e[se]; return n !== null && !Oo() && !oo(t) && !Rs(n, t.index - E); }
function Nu(e, t) { let n = t, o = e.corruptedTextNodes; n.textContent === "" ? o.set(n, "ngetn") : n.nextSibling?.nodeType === Node.TEXT_NODE && o.set(n, "ngtns"); }
function am(e) { let t = []; return e !== null && (e.has(4) && t.push(...Ji), e.has(3) && t.push(...Ki)), t; }
function cN(e, t) { let n = t.get(ut), r = t.get(Xn).get(bs, {}), i = !1, s = e, a = null, c = []; for (; !i && s;) {
    i = n.has(s);
    let l = n.hydrating.get(s);
    if (a === null && l != null) {
        a = l.promise;
        break;
    }
    c.unshift(s), s = r[s][pu];
} return { parentBlockPromise: a, hydrationQueue: c }; }
function lN(e) { let t = e.body.querySelectorAll("[jsaction]"), n = new Set, o = [Ji.join(":;"), Ki.join(":;")].join("|"); for (let r of t) {
    let i = r.getAttribute("jsaction"), s = r.getAttribute("ngb");
    i?.match(o) && s !== null && n.add(r);
} return n; }
function cm(e, t) { let n = lN(e), o = t.get(Mr); for (let r of n)
    Eu(r, o); }
var lm = () => ({});
function uN(e) { let t = e.get(Xn, null, { optional: !0 }); return t !== null ? t.get(bs, {}) : {}; }
function um() { lm = uN; }
function dN(e) { return lm(e); }
function fN(e) { return typeof e == "object" && e.trigger === 5; }
function pN(e) { return e[Tr]?.find(n => fN(n))?.delay ?? null; }
function hN(e) { let t = e[Tr]; if (t)
    for (let n of t) {
        if (n === 2)
            return !0;
        if (typeof n == "object" && n.trigger === 2)
            return n.intersectionObserverOptions || !0;
    } return null; }
function Zp(e, t) { return e[Tr]?.includes(t) ?? !1; }
function gN(e) { return { data: e, hydrate: { idle: Zp(e, 0), immediate: Zp(e, 1), timer: pN(e), viewport: hN(e) } }; }
function dm(e) { let t = dN(e), n = new Map; for (let o in t)
    n.set(o, gN(t[o])); return n; }
function Hc(e) { return !!e && e.nodeType === Node.COMMENT_NODE && e.textContent?.trim() === Xg; }
function Kp(e) { for (; e && e.nodeType === Node.TEXT_NODE;)
    e = e.previousSibling; return e; }
function fm(e) { for (let o of e.body.childNodes)
    if (Hc(o))
        return; let t = Kp(e.body.previousSibling); if (Hc(t))
    return; let n = Kp(e.head.lastChild); if (!Hc(n))
    throw new _(-507, !1); }
function pm(e, t) { let n = e.contentQueries; if (n !== null) {
    let o = P(null);
    try {
        for (let r = 0; r < n.length; r += 2) {
            let i = n[r], s = n[r + 1];
            if (s !== -1) {
                let a = e.data[s];
                ko(i), a.contentQueries(2, t[s], s);
            }
        }
    }
    finally {
        P(o);
    }
} }
function fl(e, t, n) { ko(0); let o = P(null); try {
    t(e, n);
}
finally {
    P(o);
} }
function wu(e, t, n) { if (Xa(t)) {
    let o = P(null);
    try {
        let r = t.directiveStart, i = t.directiveEnd;
        for (let s = r; s < i; s++) {
            let a = e.data[s];
            if (a.contentQueries) {
                let c = n[s];
                a.contentQueries(1, c, s);
            }
        }
    }
    finally {
        P(o);
    }
} }
var Oe = (function (e) { return e[e.Emulated = 0] = "Emulated", e[e.None = 2] = "None", e[e.ShadowDom = 3] = "ShadowDom", e[e.ExperimentalIsolatedShadowDom = 4] = "ExperimentalIsolatedShadowDom", e; })(Oe || {}), mN = { name: "custom-elements" }, yN = { name: "no-errors-schema" }, hm = !1;
function vN(e) { hm = e; }
function EN() { return hm; }
var gm = !1;
function IN(e) { gm = e; }
function DN() { return gm; }
var mm = "svg", ym = "math", vm = { "http://www.w3.org/2000/svg": mm, "http://www.w3.org/1998/Math/MathML": ym }, Ti;
function Em() { if (Ti === void 0 && (Ti = null, De.trustedTypes))
    try {
        Ti = De.trustedTypes.createPolicy("angular", { createHTML: e => e, createScript: e => e, createScriptURL: e => e });
    }
    catch { } return Ti; }
function ro(e) { return Em()?.createHTML(e) || e; }
function CN(e) { return Em()?.createScriptURL(e) || e; }
var Mi;
function _u() { if (Mi === void 0 && (Mi = null, De.trustedTypes))
    try {
        Mi = De.trustedTypes.createPolicy("angular#unsafe-bypass", { createHTML: e => e, createScript: e => e, createScriptURL: e => e });
    }
    catch { } return Mi; }
function Jp(e) { return _u()?.createHTML(e) || e; }
function Xp(e) { return _u()?.createScript(e) || e; }
function eh(e) { return _u()?.createScriptURL(e) || e; }
var at = class {
    changingThisBreaksApplicationSecurity;
    constructor(t) { this.changingThisBreaksApplicationSecurity = t; }
    toString() { return `SafeValue must use [property]=binding: ${this.changingThisBreaksApplicationSecurity} (see ${Qr})`; }
}, pl = class extends at {
    getTypeName() { return "HTML"; }
}, hl = class extends at {
    getTypeName() { return "Style"; }
}, gl = class extends at {
    getTypeName() { return "Script"; }
}, ml = class extends at {
    getTypeName() { return "URL"; }
}, yl = class extends at {
    getTypeName() { return "ResourceURL"; }
};
function dt(e) { return e instanceof at ? e.changingThisBreaksApplicationSecurity : e; }
function io(e, t) { let n = Im(e); if (n != null && n !== t) {
    if (n === "ResourceURL" && t === "URL")
        return !0;
    throw new Error(`Required a safe ${t}, got a ${n} (see ${Qr})`);
} return n === t; }
function Im(e) { return e instanceof at && e.getTypeName() || null; }
function TN(e) { return new pl(e); }
function MN(e) { return new hl(e); }
function NN(e) { return new gl(e); }
function wN(e) { return new ml(e); }
function _N(e) { return new yl(e); }
function Dm(e) { let t = new El(e); return SN() ? new vl(t) : t; }
var vl = class {
    inertDocumentHelper;
    constructor(t) { this.inertDocumentHelper = t; }
    getInertBodyElement(t) { t = "<body><remove></remove>" + t; try {
        let n = new window.DOMParser().parseFromString(ro(t), "text/html").body;
        return n === null ? this.inertDocumentHelper.getInertBodyElement(t) : (n.firstChild?.remove(), n);
    }
    catch {
        return null;
    } }
}, El = class {
    defaultDoc;
    inertDocument;
    constructor(t) { this.defaultDoc = t, this.inertDocument = this.defaultDoc.implementation.createHTMLDocument("sanitization-inert"); }
    getInertBodyElement(t) { let n = this.inertDocument.createElement("template"); return n.innerHTML = ro(t), n; }
};
function SN() { try {
    return !!new window.DOMParser().parseFromString(ro(""), "text/html");
}
catch {
    return !1;
} }
var bN = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i;
function ks(e) { return e = String(e), e.match(bN) ? e : "unsafe:" + e; }
function ft(e) { let t = {}; for (let n of e.split(","))
    t[n] = !0; return t; }
function wr(...e) { let t = {}; for (let n of e)
    for (let o in n)
        n.hasOwnProperty(o) && (t[o] = !0); return t; }
var Cm = ft("area,br,col,hr,img,wbr"), Tm = ft("colgroup,dd,dt,li,p,tbody,td,tfoot,th,thead,tr"), Mm = ft("rp,rt"), AN = wr(Mm, Tm), RN = wr(Tm, ft("address,article,aside,blockquote,caption,center,del,details,dialog,dir,div,dl,figure,figcaption,footer,h1,h2,h3,h4,h5,h6,header,hgroup,hr,ins,main,map,menu,nav,ol,pre,section,summary,table,ul")), ON = wr(Mm, ft("a,abbr,acronym,audio,b,bdi,bdo,big,br,cite,code,del,dfn,em,font,i,img,ins,kbd,label,map,mark,picture,q,ruby,rp,rt,s,samp,small,source,span,strike,strong,sub,sup,time,track,tt,u,var,video")), Il = wr(Cm, RN, ON, AN), Nm = ft("background,cite,href,itemtype,longdesc,poster,src,xlink:href"), kN = ft("abbr,accesskey,align,alt,autoplay,axis,bgcolor,border,cellpadding,cellspacing,class,clear,color,cols,colspan,compact,controls,coords,datetime,default,dir,download,face,headers,height,hidden,hreflang,hspace,ismap,itemscope,itemprop,kind,label,lang,language,loop,media,muted,nohref,nowrap,open,preload,rel,rev,role,rows,rowspan,rules,scope,scrolling,shape,size,sizes,span,srclang,srcset,start,summary,tabindex,target,title,translate,type,usemap,valign,value,vspace,width"), xN = ft("aria-activedescendant,aria-atomic,aria-autocomplete,aria-busy,aria-checked,aria-colcount,aria-colindex,aria-colspan,aria-controls,aria-current,aria-describedby,aria-details,aria-disabled,aria-dropeffect,aria-errormessage,aria-expanded,aria-flowto,aria-grabbed,aria-haspopup,aria-hidden,aria-invalid,aria-keyshortcuts,aria-label,aria-labelledby,aria-level,aria-live,aria-modal,aria-multiline,aria-multiselectable,aria-orientation,aria-owns,aria-placeholder,aria-posinset,aria-pressed,aria-readonly,aria-relevant,aria-required,aria-roledescription,aria-rowcount,aria-rowindex,aria-rowspan,aria-selected,aria-setsize,aria-sort,aria-valuemax,aria-valuemin,aria-valuenow,aria-valuetext"), Dl = wr(Nm, kN, xN), PN = ft("script,style,template"), Cl = class {
    sanitizedSomething = !1;
    buf = [];
    sanitizeChildren(t) { let n = t.firstChild, o = !0, r = []; for (; n;) {
        if (n.nodeType === Node.ELEMENT_NODE ? o = this.startElement(n) : n.nodeType === Node.TEXT_NODE ? this.chars(n.nodeValue) : this.sanitizedSomething = !0, o && n.firstChild) {
            r.push(n), n = HN(n);
            continue;
        }
        for (; n;) {
            n.nodeType === Node.ELEMENT_NODE && this.endElement(n);
            let i = FN(n);
            if (i) {
                n = i;
                break;
            }
            n = r.pop();
        }
    } return this.buf.join(""); }
    startElement(t) { let n = th(t).toLowerCase(); if (!Il.hasOwnProperty(n))
        return this.sanitizedSomething = !0, !PN.hasOwnProperty(n); this.buf.push("<"), this.buf.push(n); let o = t.attributes; for (let r = 0; r < o.length; r++) {
        let i = o.item(r), s = i.name, a = s.toLowerCase();
        if (!Dl.hasOwnProperty(a)) {
            this.sanitizedSomething = !0;
            continue;
        }
        let c = i.value;
        Nm[a] && (c = ks(c)), this.buf.push(" ", s, '="', nh(c), '"');
    } return this.buf.push(">"), !0; }
    endElement(t) { let n = th(t).toLowerCase(); Il.hasOwnProperty(n) && !Cm.hasOwnProperty(n) && (this.buf.push("</"), this.buf.push(n), this.buf.push(">")); }
    chars(t) { this.buf.push(nh(t)); }
};
function LN(e, t) { return (e.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_CONTAINED_BY) !== Node.DOCUMENT_POSITION_CONTAINED_BY; }
function FN(e) { let t = e.nextSibling; if (t && e !== t.previousSibling)
    throw wm(t); return t; }
function HN(e) { let t = e.firstChild; if (t && LN(e, t))
    throw wm(t); return t; }
function th(e) { let t = e.nodeName; return typeof t == "string" ? t : "FORM"; }
function wm(e) { return new Error(`Failed to sanitize html because the element is clobbered: ${e.outerHTML}`); }
var VN = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g, jN = /([^\#-~ |!])/g;
function nh(e) { return e.replace(/&/g, "&amp;").replace(VN, function (t) { let n = t.charCodeAt(0), o = t.charCodeAt(1); return "&#" + ((n - 55296) * 1024 + (o - 56320) + 65536) + ";"; }).replace(jN, function (t) { return "&#" + t.charCodeAt(0) + ";"; }).replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
var Ni;
function _m(e, t) { let n = null; try {
    Ni = Ni || Dm(e);
    let o = t ? String(t) : "";
    n = Ni.getInertBodyElement(o);
    let r = 5, i = o;
    do {
        if (r === 0)
            throw new Error("Failed to sanitize html because the input is unstable");
        r--, o = i, i = n.innerHTML, n = Ni.getInertBodyElement(o);
    } while (o !== i);
    let a = new Cl().sanitizeChildren(Tl(n) || n);
    return ro(a);
}
finally {
    if (n) {
        let o = Tl(n) || n;
        for (; o.firstChild;)
            o.firstChild.remove();
    }
} }
function Tl(e) { return "content" in e && BN(e) ? e.content : null; }
function BN(e) { return e.nodeType === Node.ELEMENT_NODE && e.nodeName === "TEMPLATE"; }
var UN = /^>|^->|<!--|-->|--!>|<!-$/g, $N = /(<|>)/g, zN = "\u200B$1\u200B";
function GN(e) { return e.replace(UN, t => t.replace($N, zN)); }
function Su(e, t) { return e.createText(t); }
function Sm(e, t, n) { e.setValue(t, n); }
function bu(e, t) { return e.createComment(GN(t)); }
function xs(e, t, n) { return e.createElement(t, n); }
function tn(e, t, n, o, r) { e.insertBefore(t, n, o, r); }
function bm(e, t, n) { e.appendChild(t, n); }
function oh(e, t, n, o, r) { o !== null ? tn(e, t, n, o, r) : bm(e, t, n); }
function _r(e, t, n, o) { e.removeChild(null, t, n, o); }
function Am(e) { e.textContent = ""; }
function WN(e, t, n) { e.setAttribute(t, "style", n); }
function qN(e, t, n) { n === "" ? e.removeAttribute(t, "class") : e.setAttribute(t, "class", n); }
function Rm(e, t, n) { let { mergedAttrs: o, classes: r, styles: i } = n; o !== null && KT(e, t, o), r !== null && qN(e, t, r), i !== null && WN(e, t, i); }
function QN(e) { let t = g(); e.src = "", e.srcdoc = ro(""), _r(t[T], e); }
function Au(e, t = !0) { if (e[0] != ":")
    return [null, e]; let n = e.indexOf(":", 1); if (n === -1) {
    if (t)
        throw new Error(`Unsupported format "${e}" expecting ":namespace:name"`);
    return [null, e];
} return [e.slice(1, n), e.slice(n + 1)]; }
function Ru(e, t, n) { if (t !== void 0 && n !== void 0 && Pm(t, n) !== ae.HTML)
    return e; let o = Sr(); return o ? Jp(o.sanitize(ae.HTML, e) || "") : io(e, "HTML") ? Jp(dt(e)) : _m(Cs(), N(e)); }
function Ou(e) { let t = Sr(); return t ? t.sanitize(ae.STYLE, e) || "" : io(e, "Style") ? dt(e) : N(e); }
function ku(e) { let t = Sr(); return t ? t.sanitize(ae.URL, e) || "" : io(e, "URL") ? dt(e) : ks(N(e)); }
function Ps(e) { let t = Sr(); if (t)
    return eh(t.sanitize(ae.RESOURCE_URL, e) || ""); if (io(e, "ResourceURL"))
    return eh(dt(e)); throw new _(904, !1); }
function xu(e) { let t = Sr(); if (t)
    return Xp(t.sanitize(ae.SCRIPT, e) || ""); if (io(e, "Script"))
    return Xp(dt(e)); throw new _(905, !1); }
function Om(e) { return ro(e[0]); }
function km(e) { return CN(e[0]); }
function YN(e, t) { switch (Pm(e, t)) {
    case ae.RESOURCE_URL: return Ps;
    case ae.URL: return ku;
    default: return null;
} }
function xm(e, t, n) { return YN(t, n)?.(e) ?? e; }
function Sr() { let e = g(); return e && e[$e].sanitizer; }
function Pm(e, t) { let [n, o] = Lm(e); return nc(o, t, n); }
function Lm(e) { e = e.toLowerCase(); let t = Au(e, !1); if (t[0])
    return t; let o = J() === -1 ? null : Ee(), r = o?.namespace; if (e === "#host" && o?.type === 2) {
    let i = te(o, g());
    if (i.tagName && (e = i.tagName.toLowerCase()), r == null) {
        let s = i.namespaceURI;
        r = s && vm[s];
    }
} return [r, e]; }
var wi = new Set(["href", "xlink:href"]), ZN = { animate: { to: wi, values: wi, from: wi }, set: { to: wi } };
function Pu(e, t, n) { let r = J() === -1 ? null : Ee(); if (r && r.type !== 2)
    return e; let [i, s] = Lm(t); if (nc(s, n, i) !== ae.ATTRIBUTE_NO_BINDING)
    return e; let c = g(); if (r) {
    if (s === "iframe") {
        let u = te(r, c);
        QN(u);
    }
    else if (i === tc) {
        let u = ZN[s]?.[n.toLowerCase()];
        if (u) {
            let d = te(r, c);
            if (KN(d, u))
                throw new _(-910, !1);
            return e;
        }
    }
} let l = !1; throw new _(-910, l); }
function KN(e, t) { for (let n of e.getAttributeNames()) {
    if (n.toLowerCase() !== "attributename")
        continue;
    let o = e.getAttribute(n);
    if (o !== null && t.has(o.toLowerCase()))
        return o;
} return null; }
function JN() { return nt([]); }
function Fm(e) { return e.ownerDocument.defaultView; }
function Hm(e) { return e.ownerDocument; }
function Lu(e) { return e.ownerDocument.body; }
var XN = "\uFFFD";
function An(e) { return e instanceof Function ? e() : e; }
function ew(e, t, n) { let o = e.length; for (;;) {
    let r = e.indexOf(t, n);
    if (r === -1)
        return r;
    if (r === 0 || e.charCodeAt(r - 1) <= 32) {
        let i = t.length;
        if (r + i === o || e.charCodeAt(r + i) <= 32)
            return r;
    }
    n = r + 1;
} }
var Vm = "ng-template";
function tw(e, t, n, o) { let r = 0; if (o) {
    for (; r < t.length && typeof t[r] == "string"; r += 2)
        if (t[r] === "class" && ew(t[r + 1].toLowerCase(), n, 0) !== -1)
            return !0;
}
else if (Fu(e))
    return !1; if (r = t.indexOf(1, r), r > -1) {
    let i;
    for (; ++r < t.length && typeof (i = t[r]) == "string";)
        if (i.toLowerCase() === n)
            return !0;
} return !1; }
function Fu(e) { return e.type === 4 && e.value !== Vm; }
function nw(e, t, n) { let o = e.type === 4 && !n ? Vm : e.value; return t === o; }
function ow(e, t, n) { let o = 4, r = e.attrs, i = r !== null ? sw(r) : 0, s = !1; for (let a = 0; a < t.length; a++) {
    let c = t[a];
    if (typeof c == "number") {
        if (!s && !je(o) && !je(c))
            return !1;
        if (s && je(c))
            continue;
        s = !1, o = c | o & 1;
        continue;
    }
    if (!s)
        if (o & 4) {
            if (o = 2 | o & 1, c !== "" && !nw(e, c, n) || c === "" && t.length === 1) {
                if (je(o))
                    return !1;
                s = !0;
            }
        }
        else if (o & 8) {
            if (r === null || !tw(e, r, c, n)) {
                if (je(o))
                    return !1;
                s = !0;
            }
        }
        else {
            let l = t[++a], u = rw(c, r, Fu(e), n);
            if (u === -1) {
                if (je(o))
                    return !1;
                s = !0;
                continue;
            }
            if (l !== "") {
                let d;
                if (u > i ? d = "" : d = r[u + 1].toLowerCase(), o & 2 && l !== d) {
                    if (je(o))
                        return !1;
                    s = !0;
                }
            }
        }
} return je(o) || s; }
function je(e) { return (e & 1) === 0; }
function rw(e, t, n, o) { if (t === null)
    return -1; let r = 0; if (o || !n) {
    let i = !1;
    for (; r < t.length;) {
        let s = t[r];
        if (s === e)
            return r;
        if (s === 3 || s === 6)
            i = !0;
        else if (s === 1 || s === 2) {
            let a = t[++r];
            for (; typeof a == "string";)
                a = t[++r];
            continue;
        }
        else {
            if (s === 4)
                break;
            if (s === 0) {
                r += 4;
                continue;
            }
        }
        r += i ? 1 : 2;
    }
    return -1;
}
else
    return aw(t, e); }
function jm(e, t, n = !1) { for (let o = 0; o < t.length; o++)
    if (ow(e, t[o], n))
        return !0; return !1; }
function iw(e) { let t = e.attrs; if (t != null) {
    let n = t.indexOf(5);
    if ((n & 1) === 0)
        return t[n + 1];
} return null; }
function sw(e) { for (let t = 0; t < e.length; t++) {
    let n = e[t];
    if (pg(n))
        return t;
} return e.length; }
function aw(e, t) { let n = e.indexOf(4); if (n > -1)
    for (n++; n < e.length;) {
        let o = e[n];
        if (typeof o == "number")
            return -1;
        if (o === t)
            return n;
        n++;
    } return -1; }
function cw(e, t) { e: for (let n = 0; n < t.length; n++) {
    let o = t[n];
    if (e.length === o.length) {
        for (let r = 0; r < e.length; r++)
            if (e[r] !== o[r])
                continue e;
        return !0;
    }
} return !1; }
function rh(e, t) { return e ? ":not(" + t.trim() + ")" : t; }
function lw(e) { let t = e[0], n = 1, o = 2, r = "", i = !1; for (; n < e.length;) {
    let s = e[n];
    if (typeof s == "string")
        if (o & 2) {
            let a = e[++n];
            r += "[" + s + (a.length > 0 ? '="' + a + '"' : "") + "]";
        }
        else
            o & 8 ? r += "." + s : o & 4 && (r += " " + s);
    else
        r !== "" && !je(s) && (t += rh(i, r), r = ""), o = s, i = i || !je(o);
    n++;
} return r !== "" && (t += rh(i, r)), t; }
function uw(e) { return e.map(lw).join(","); }
function dw(e) { let t = [], n = [], o = 1, r = 2; for (; o < e.length;) {
    let i = e[o];
    if (typeof i == "string")
        r === 2 ? i !== "" && t.push(i, e[++o]) : r === 8 && n.push(i);
    else {
        if (!je(r))
            break;
        r = i;
    }
    o++;
} return n.length && t.push(1, ...n), t; }
var L = {};
function Hu(e, t, n, o, r, i, s, a, c, l, u) { let d = E + o, f = d + r, p = fw(d, f), h = typeof l == "function" ? l() : l; return p[m] = { type: e, blueprint: p, template: n, queries: null, viewQuery: a, declTNode: t, data: p.slice().fill(null, d), bindingStartIndex: d, expandoStartIndex: f, hostBindingOpCodes: null, firstCreatePass: !0, firstUpdatePass: !0, staticViewQueries: !1, staticContentQueries: !1, preOrderHooks: null, preOrderCheckHooks: null, contentHooks: null, contentCheckHooks: null, viewHooks: null, viewCheckHooks: null, destroyHooks: null, cleanup: null, contentQueries: null, components: null, directiveRegistry: typeof i == "function" ? i() : i, pipeRegistry: typeof s == "function" ? s() : s, firstChild: null, schemas: c, consts: h, incompleteFirstPass: !1, ssrId: u }; }
function fw(e, t) { let n = []; for (let o = 0; o < t; o++)
    n.push(o < e ? null : L); return n; }
function Bm(e) { let t = e.tView; return t === null || t.incompleteFirstPass ? e.tView = Hu(1, null, e.template, e.decls, e.vars, e.directiveDefs, e.pipeDefs, e.viewQuery, e.schemas, e.consts, e.id) : t; }
function Ls(e, t, n, o, r, i, s, a, c, l, u) { let d = t.blueprint.slice(); return d[j] = r, d[A] = o | 4 | 128 | 8 | 64 | 1024, (l !== null || e && e[A] & 2048) && (d[A] |= 2048), oc(d), d[q] = d[wo] = e, d[H] = n, d[$e] = s || e && e[$e], d[T] = a || e && e[T], d[O] = c || e && e[O] || null, d[ue] = i, d[Se] = EM(), d[se] = u, d[Ka] = l, d[K] = t.type == 2 ? e[K] : d, d; }
function pw(e, t, n) { let o = te(t, e), r = Bm(n), i = e[$e].rendererFactory, s = ju(e, Ls(e, r, null, Vu(n), o, t, null, i.createRenderer(o, n), null, null, null)); return e[t.index] = s; }
function Vu(e) { let t = 16; return e.signals ? t = 4096 : e.onPush && (t = 64), t; }
function br(e, t, n, o) { if (n === 0)
    return -1; let r = t.length; for (let i = 0; i < n; i++)
    t.push(o), e.blueprint.push(o), e.data.push(null); return r; }
function ju(e, t) { return e[Dt] ? e[No][le] = t : e[Dt] = t, e[No] = t, t; }
function Um(e = 1) { $m(w(), g(), J() + e, !1); }
function $m(e, t, n, o) { if (!o)
    if ((t[A] & 3) === 3) {
        let i = e.preOrderCheckHooks;
        i !== null && Oi(t, i, n);
    }
    else {
        let i = e.preOrderHooks;
        i !== null && ki(t, i, 0, n);
    } Ze(n); }
var Fs = (function (e) { return e[e.None = 0] = "None", e[e.SignalBased = 1] = "SignalBased", e[e.HasDecoratorInputTransform = 2] = "HasDecoratorInputTransform", e; })(Fs || {});
function bt(e, t, n, o) { let r = P(null); try {
    let [i, s, a] = e.inputs[n], c = null;
    (s & Fs.SignalBased) !== 0 && (c = t[i][tt]), c !== null && c.transformFn !== void 0 ? o = c.transformFn(o) : a !== null && (o = a.call(t, o)), e.setInput !== null ? e.setInput(t, c, o, n, i) : ig(t, c, i, o);
}
finally {
    P(r);
} }
var Xi = (function (e) { return e[e.Important = 1] = "Important", e[e.DashCase = 2] = "DashCase", e; })(Xi || {}), Ml;
function Bu(e, t) { return Ml(e, t); }
function hw(e) { Ml === void 0 && (Ml = e()); }
var zm = new S("", { factory: () => !1 }), Gm = new S("", { factory: () => gw }), gw = 4e3, mw = !1, pn = (typeof ngServerMode > "u" || !ngServerMode) && typeof document < "u" && typeof document?.documentElement?.getAnimations == "function";
function Hs(e) { return e[O].get(zm, mw); }
function yw(e, t, n) { let o = jn.get(e); if (o) {
    for (let r of t)
        o.classList.push(r);
    for (let r of n)
        o.cleanupFns.push(r);
}
else
    jn.set(e, { classList: t, cleanupFns: n }); }
function Uu(e) { let t = jn.get(e); if (t) {
    for (let n of t.cleanupFns)
        n();
    jn.delete(e);
} Xt.delete(e); }
var vw = () => { }, jn = new WeakMap, Xt = new WeakMap, er = new WeakMap, Vo = new WeakSet;
function Nl(e, t) { let n = er.get(e); if (n && n.length > 0) {
    let o = n.findIndex(r => r === t);
    o > -1 && n.splice(o, 1);
} n?.length === 0 && er.delete(e); }
function Ew(e, t) { let n = er.get(e); if (!n || n.length === 0)
    return; let o = t.parentNode, r = t.previousSibling; for (let i = n.length - 1; i >= 0; i--) {
    let s = n[i], a = s.parentNode;
    s === t ? (n.splice(i, 1), Vo.add(s), s.dispatchEvent(new CustomEvent("animationend", { detail: { cancel: !0 } }))) : (r && s === r || a && o && a !== o) && (n.splice(i, 1), s.dispatchEvent(new CustomEvent("animationend", { detail: { cancel: !0 } })), s.parentNode?.removeChild(s));
} }
function $u(e, t) { let n = er.get(e); n ? n.includes(t) || n.push(t) : er.set(e, [t]); }
function es(e) { let t = e[Ge] ??= {}; return t.enter ??= new Map; }
function nn(e) { let t = e[Ge] ??= {}; return t.leave ??= new Map; }
function Wm(e) { let t = typeof e == "function" ? e() : e, n = Array.isArray(t) ? t : null; return typeof t == "string" && (n = t.trim().split(/\s+/).filter(o => o)), n; }
function Iw(e, t) { if (!pn)
    return; let n = jn.get(e); if (n && n.classList.length > 0 && Dw(e, n.classList))
    for (let o of n.classList)
        t.removeClass(e, o); Uu(e); }
function Dw(e, t) { for (let n of t)
    if (e.classList.contains(n))
        return !0; return !1; }
function tr(e) { return e.composedPath ? e.composedPath()[0] : e.target; }
function zu(e, t) { let n = Xt.get(t); return n === void 0 ? !0 : t === tr(e) && (n.animationName !== void 0 && e.animationName === n.animationName || n.propertyName !== void 0 && (n.propertyName === "all" || e.propertyName === n.propertyName)); }
function Vs(e, t, n) { let o = e.get(t.index) ?? { animateFns: [] }; o.animateFns.push(n), e.set(t.index, o); }
function wl(e, t) { if (e)
    for (let n of e)
        n(); for (let n of t)
    n(); }
function _l(e, t) { let n = nn(e).get(t.index); n && (n.resolvers = void 0); }
function _i(e, t, n, o, r) { Nl(t, n), wl(o, r), _l(e, t); }
function ts(e) { if (!e)
    return 0; let t = e.toLowerCase().indexOf("ms") > -1 ? 1 : 1e3; return parseFloat(e) * t; }
function Kt(e, t) { return e.getPropertyValue(t).split(",").map(o => o.trim()); }
function Cw(e) { let t = Kt(e, "transition-property"), n = Kt(e, "transition-duration"), o = Kt(e, "transition-delay"), r = { propertyName: "", duration: 0, animationName: void 0 }; for (let i = 0; i < t.length; i++) {
    let s = ts(o[i]) + ts(n[i]);
    s > r.duration && (r.propertyName = t[i], r.duration = s);
} return r; }
function Tw(e) { let t = Kt(e, "animation-name"), n = Kt(e, "animation-delay"), o = Kt(e, "animation-duration"), r = Kt(e, "animation-iteration-count"), i = { animationName: "", propertyName: void 0, duration: 0 }; for (let s = 0; s < t.length; s++) {
    let a = ts(n[s]) + ts(o[s]), c = r[s];
    a > i.duration && c !== "infinite" && (i.animationName = t[s], i.duration = a);
} return i; }
function qm(e, t) { return e !== void 0 && e.duration > t.duration; }
function Qm(e) { return (e.animationName != null || e.propertyName != null) && e.duration > 0; }
function Mw(e, t) { let n = getComputedStyle(e), o = Tw(n), r = Cw(n), i = o.duration > r.duration ? o : r; qm(t.get(e), i) || Qm(i) && t.set(e, i); }
function Ym(e, t, n) { if (!n)
    return; let o = e.getAnimations(); return o.length === 0 ? Mw(e, t) : Nw(e, t, o); }
function Nw(e, t, n) { let o = { animationName: void 0, propertyName: void 0, duration: 0 }; for (let r of n) {
    let i = r.effect?.getTiming();
    if (i?.iterations === 1 / 0)
        continue;
    let s = typeof i?.duration == "number" ? i.duration : 0, a = (i?.delay ?? 0) + s, c = r.playbackRate;
    c !== void 0 && c !== 0 && c !== 1 && (a /= Math.abs(c));
    let l, u;
    r.animationName ? u = r.animationName : l = r.transitionProperty, a >= o.duration && (o = { animationName: u, propertyName: l, duration: a });
} qm(t.get(e), o) || Qm(o) && t.set(e, o); }
var on = new Set, js = (function (e) { return e[e.CHANGE_DETECTION = 0] = "CHANGE_DETECTION", e[e.AFTER_NEXT_RENDER = 1] = "AFTER_NEXT_RENDER", e; })(js || {}), hn = new S(""), ih = new Set;
function Q(e) { ih.has(e) || (ih.add(e), performance?.mark?.("mark_feature_usage", { detail: { feature: e } })); }
var Bs = (() => { class e {
    impl = null;
    execute() { this.impl?.execute(); }
    static \u0275prov = B({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), Gu = [0, 1, 2, 3], Wu = (() => { class e {
    ngZone = I(U);
    scheduler = I(Nt);
    errorHandler = I(_c, { optional: !0 });
    sequences = new Set;
    deferredRegistrations = new Set;
    executing = !1;
    constructor() { I(hn, { optional: !0 }); }
    execute() { let n = this.sequences.size > 0; n && x(R.AfterRenderHooksStart), this.executing = !0; for (let o of Gu)
        for (let r of this.sequences)
            if (!(r.erroredOrDestroyed || !r.hooks[o]))
                try {
                    r.pipelinedValue = this.ngZone.runOutsideAngular(() => this.maybeTrace(() => { let i = r.hooks[o]; return i(r.pipelinedValue); }, r.snapshot));
                }
                catch (i) {
                    r.erroredOrDestroyed = !0, this.errorHandler?.handleError(i);
                } this.executing = !1; for (let o of this.sequences)
        o.afterRun(), o.once && (this.sequences.delete(o), o.destroy()); for (let o of this.deferredRegistrations)
        this.sequences.add(o); this.deferredRegistrations.size > 0 && this.scheduler.notify(7), this.deferredRegistrations.clear(), n && x(R.AfterRenderHooksEnd); }
    register(n) { let { view: o } = n; o !== void 0 ? ((o[Vt] ??= []).push(n), di(o), o[A] |= 8192) : this.executing ? this.deferredRegistrations.add(n) : this.addSequence(n); }
    addSequence(n) { this.sequences.add(n), this.scheduler.notify(7); }
    unregister(n) { this.executing && this.sequences.has(n) ? (n.erroredOrDestroyed = !0, n.pipelinedValue = void 0, n.once = !0) : (this.sequences.delete(n), this.deferredRegistrations.delete(n)); }
    maybeTrace(n, o) { return o ? o.run(js.AFTER_NEXT_RENDER, n) : n(); }
    static \u0275prov = B({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), nr = class {
    impl;
    hooks;
    view;
    once;
    snapshot;
    erroredOrDestroyed = !1;
    pipelinedValue = void 0;
    unregisterOnDestroy;
    constructor(t, n, o, r, i, s = null) { this.impl = t, this.hooks = n, this.view = o, this.once = r, this.snapshot = s, this.unregisterOnDestroy = i?.onDestroy(() => this.destroy()); }
    afterRun() { this.erroredOrDestroyed = !1, this.pipelinedValue = void 0, this.snapshot?.dispose(), this.snapshot = null; }
    destroy() { this.impl.unregister(this), this.unregisterOnDestroy?.(); let t = this.view?.[Vt]; t && (this.view[Vt] = t.filter(n => n !== this)); }
};
function Zm(e, t) { let n = t?.injector ?? I(Te); return typeof ngServerMode < "u" && ngServerMode ? Us : (Q("NgAfterRender"), Km(e, n, t, !1)); }
function qu(e, t) { let n = t?.injector ?? I(Te); return typeof ngServerMode < "u" && ngServerMode ? Us : (Q("NgAfterNextRender"), Km(e, n, t, !0)); }
function ww(e) { return e instanceof Function ? [void 0, void 0, e, void 0] : [e.earlyRead, e.write, e.mixedReadWrite, e.read]; }
function Km(e, t, n, o) { let r = t.get(Bs); r.impl ??= t.get(Wu); let i = t.get(hn, null, { optional: !0 }), s = n?.manualCleanup !== !0 ? t.get(Po) : null, a = t.get(Ei, null, { optional: !0 }), c = new nr(r.impl, ww(e), a?.view, o, s, i?.snapshot(null)); return r.impl.register(c), c; }
var Us = { destroy() { } }, $s = new S("", { factory: () => ({ queue: new Set, isScheduled: !1, scheduler: null, injector: I(It) }) });
function Jm(e, t, n) { let o = e.get($s); if (Array.isArray(t))
    for (let r of t)
        o.queue.add(r), n?.detachedLeaveAnimationFns?.push(r);
else
    o.queue.add(t), n?.detachedLeaveAnimationFns?.push(t); o.scheduler && o.scheduler(e); }
function _w(e, t) { let n = e.get($s); if (t.detachedLeaveAnimationFns) {
    for (let o of t.detachedLeaveAnimationFns)
        n.queue.delete(o);
    t.detachedLeaveAnimationFns = void 0;
} }
function Sw(e) { let t = e.get($s); t.isScheduled || (qu(() => { t.isScheduled = !1; for (let n of t.queue)
    n(); t.queue.clear(); }, { injector: t.injector }), t.isScheduled = !0); }
function zs(e) { let t = e.get($s); t.scheduler = Sw, t.scheduler(e); }
function Qu(e, t) { for (let [n, o] of t)
    Jm(e, o.animateFns); }
function sh(e, t, n, o) { let r = e?.[Ge]?.enter; t !== null && r && r.has(n.index) && Qu(o, r); }
function Rn(e, t, n, o, r, i, s, a) { if (r != null) {
    let c, l = !1;
    ee(r) ? c = r : re(r) && (l = !0, r = r[j]);
    let u = k(r);
    e === 0 && o !== null ? (sh(a, o, i, n), s == null ? bm(t, o, u) : tn(t, o, u, s || null, !0)) : e === 1 && o !== null ? (sh(a, o, i, n), tn(t, o, u, s || null, !0), Ew(i, u)) : e === 2 ? (a?.[Ge]?.leave?.has(i.index) && $u(i, u), Vo.delete(u), ah(a, i, n, d => { if (Vo.has(u)) {
        Vo.delete(u);
        return;
    } _r(t, u, l, d); })) : e === 3 && (Vo.delete(u), ah(a, i, n, () => { t.destroyNode(u); })), c != null && Pw(t, e, n, c, i, o, s);
} }
function Xm(e, t) { ey(e, t), t[j] = null, t[ue] = null; }
function bw(e, t, n, o, r, i) { o[j] = r, o[ue] = t, Gs(e, o, n, 1, r, i); }
function ey(e, t) { t[$e].changeDetectionScheduler?.notify(9), Gs(e, t, t[T], 2, null, null); }
function Aw(e) { let t = e[Dt]; if (!t)
    return Vc(e[m], e); for (; t;) {
    let n = null;
    if (re(t))
        n = t[Dt];
    else {
        let o = t[V];
        o && (n = o);
    }
    if (!n) {
        for (; t && !t[le] && t !== e;)
            re(t) && Vc(t[m], t), t = t[q];
        t === null && (t = e), re(t) && Vc(t[m], t), n = t && t[le];
    }
    t = n;
} }
function Yu(e, t) { let n = e[jt], o = n.indexOf(t); n.splice(o, 1); }
function Ar(e, t) { if (Tt(t))
    return; let n = t[T]; n.destroyNode && Gs(e, t, n, 3, null, null), Aw(t); }
function Vc(e, t) { if (Tt(t))
    return; let n = P(null); try {
    t[A] &= -129, t[A] |= 256, t[be] && Eo(t[be]), kw(e, t), Ow(e, t), t[m].type === 1 && t[T].destroy();
    let o = t[Ct];
    if (o !== null && ee(t[q])) {
        o !== t[q] && Yu(o, t);
        let r = t[ze];
        r !== null && r.detachView(e);
    }
    sl(t);
}
finally {
    P(n);
} }
function ah(e, t, n, o) { let r = e?.[Ge]; if (r == null || r.leave == null || !r.leave.has(t.index))
    return o(!1); e && on.add(e[Se]), Jm(n, () => { if (r.leave && r.leave.has(t.index)) {
    let s = r.leave.get(t.index), a = [];
    if (s) {
        for (let c = 0; c < s.animateFns.length; c++) {
            let l = s.animateFns[c], { promise: u } = l();
            a.push(u);
        }
        r.detachedLeaveAnimationFns = void 0;
    }
    r.running = Promise.allSettled(a), Rw(e, o);
}
else
    e && on.delete(e[Se]), o(!1); }, r); }
function Rw(e, t) { let n = e[Ge]?.running; if (n) {
    n.then(() => { e[Ge].running = void 0, on.delete(e[Se]), t(!0); });
    return;
} t(!1); }
function Ow(e, t) { let n = e.cleanup, o = t[Ht]; if (n !== null)
    for (let s = 0; s < n.length - 1; s += 2)
        if (typeof n[s] == "string") {
            let a = n[s + 3];
            a >= 0 ? o[a]() : o[-a].unsubscribe(), s += 2;
        }
        else {
            let a = o[n[s + 1]];
            n[s].call(a);
        } o !== null && (t[Ht] = null); let r = t[Ja]; if (r !== null) {
    t[Ja] = null;
    for (let s = 0; s < r.length; s++) {
        let a = r[s];
        a();
    }
} let i = t[_o]; if (i !== null) {
    t[_o] = null;
    for (let s of i)
        s.destroy();
} }
function kw(e, t) { let n; if (e != null && (n = e.destroyHooks) != null)
    for (let o = 0; o < n.length; o += 2) {
        let r = t[n[o]];
        if (!(r instanceof en)) {
            let i = n[o + 1];
            if (Array.isArray(i))
                for (let s = 0; s < i.length; s += 2) {
                    let a = r[i[s]], c = i[s + 1];
                    x(R.LifecycleHookStart, a, c);
                    try {
                        c.call(a);
                    }
                    finally {
                        x(R.LifecycleHookEnd, a, c);
                    }
                }
            else {
                x(R.LifecycleHookStart, r, i);
                try {
                    i.call(r);
                }
                finally {
                    x(R.LifecycleHookEnd, r, i);
                }
            }
        }
    } }
function Zu(e, t, n) { return ty(e, t.parent, n); }
function ty(e, t, n) { let o = t; for (; o !== null && o.type & 168;)
    t = o, o = t.parent; if (o === null)
    return n[j]; if (me(o)) {
    let { encapsulation: r } = e.data[o.directiveStart + o.componentOffset];
    if (r === Oe.None || r === Oe.Emulated)
        return null;
} return te(o, n); }
function ny(e, t, n) { return ry(e, t, n); }
function oy(e, t, n) { return e.type & 40 ? te(e, n) : null; }
var ry = oy, Sl;
function iy(e, t) { ry = e, Sl = t; }
function Ku(e, t, n, o) { let r = Zu(e, o, t), i = t[T], s = o.parent || t[ue], a = ny(s, o, t); if (r != null)
    if (Array.isArray(n))
        for (let c = 0; c < n.length; c++)
            oh(i, r, n[c], a, !1);
    else
        oh(i, r, n, a, !1); Sl !== void 0 && Sl(i, o, t, n, r); }
function Jt(e, t) { if (t !== null) {
    let n = t.type;
    if (n & 3)
        return te(t, e);
    if (n & 4)
        return bl(-1, e[t.index]);
    if (n & 8) {
        let o = t.child;
        if (o !== null)
            return Jt(e, o);
        {
            let r = e[t.index];
            return ee(r) ? bl(-1, r) : k(r);
        }
    }
    else {
        if (n & 128)
            return Jt(e, t.next);
        if (n & 32)
            return Bu(t, e)() || k(e[t.index]);
        {
            let o = sy(e, t);
            if (o !== null) {
                if (Array.isArray(o))
                    return o[0];
                let r = $t(e[K]);
                return Jt(r, o);
            }
            else
                return Jt(e, t.next);
        }
    }
} return null; }
function sy(e, t) { if (t !== null) {
    let o = e[K][ue], r = t.projection;
    return o.projection[r];
} return null; }
function bl(e, t) { let n = V + e + 1; if (n < t.length) {
    let o = t[n], r = o[m].firstChild;
    if (r !== null)
        return Jt(o, r);
} return t[He]; }
function Ju(e, t, n, o, r, i, s) { for (; n != null;) {
    let a = o[O];
    if (n.type === 128) {
        n = n.next;
        continue;
    }
    let c = o[n.index], l = n.type;
    if (s && t === 0 && (c && Re(k(c), o), n.flags |= 2), !oo(n))
        if (l & 8)
            Ju(e, t, n.child, o, r, i, !1), Rn(t, e, a, r, c, n, i, o);
        else if (l & 32) {
            let u = Bu(n, o), d;
            for (; d = u();)
                Rn(t, e, a, r, d, n, i, o);
            Rn(t, e, a, r, c, n, i, o);
        }
        else
            l & 16 ? ay(e, t, o, n, r, i) : Rn(t, e, a, r, c, n, i, o);
    n = s ? n.projectionNext : n.next;
} }
function Gs(e, t, n, o, r, i) { Ju(n, o, e.firstChild, t, r, i, !1); }
function xw(e, t, n) { let o = t[T], r = Zu(e, n, t), i = n.parent || t[ue], s = ny(i, n, t); ay(o, 0, t, n, r, s); }
function ay(e, t, n, o, r, i) { let s = n[K], c = s[ue].projection[o.projection]; if (Array.isArray(c))
    for (let l = 0; l < c.length; l++) {
        let u = c[l];
        Rn(t, e, n[O], r, u, o, i, n);
    }
else {
    let l = c, u = s[q];
    Jo(o) && (l.flags |= 128), Ju(e, t, l, u, r, i, !0);
} }
function Pw(e, t, n, o, r, i, s) { let a = o[He], c = k(o); a !== c && Rn(t, e, n, i, a, r, s); for (let l = V; l < o.length; l++) {
    let u = o[l];
    Gs(u[m], u, e, t, i, a);
} }
function Lw(e, t, n, o, r) { if (t)
    r ? e.addClass(n, o) : e.removeClass(n, o);
else {
    let i = o.indexOf("-") === -1 ? void 0 : Xi.DashCase;
    r == null ? e.removeStyle(n, o, i) : (typeof r == "string" && r.endsWith("!important") && (r = r.slice(0, -10), i |= Xi.Important), e.setStyle(n, o, r, i));
} }
function cy(e, t, n, o, r) { let i = J(), s = o & 2; try {
    Ze(-1), s && t.length > E && $m(e, t, E, !1);
    let a = s ? R.TemplateUpdateStart : R.TemplateCreateStart;
    x(a, r, n), n(o, r);
}
finally {
    Ze(i);
    let a = s ? R.TemplateUpdateEnd : R.TemplateCreateEnd;
    x(a, r, n);
} }
function Ws(e, t, n) { Bw(e, t, n), (n.flags & 64) === 64 && Uw(e, t, n); }
function so(e, t, n = te) { let o = t.localNames; if (o !== null) {
    let r = t.index + 1;
    for (let i = 0; i < o.length; i += 2) {
        let s = o[i + 1], a = s === -1 ? n(t, e) : e[s];
        e[r++] = a;
    }
} }
function Fw(e, t, n, o) { let i = o.get(hu, Bg) || n === Oe.ShadowDom || n === Oe.ExperimentalIsolatedShadowDom, s = e.selectRootElement(t, i); return Hw(s), s; }
function Hw(e) { ly(e); }
var ly = () => null;
function Vw(e) { _g(e) ? Am(e) : nN(e); }
function uy() { ly = Vw; }
function jw(e) { return e === "class" ? "className" : e === "for" ? "htmlFor" : e === "formaction" ? "formAction" : e === "innerHtml" ? "innerHTML" : e === "readonly" ? "readOnly" : e === "tabindex" ? "tabIndex" : e; }
function Xu(e, t, n, o, r, i) { let s = t[m]; if (Zs(e, s, t, n, o)) {
    me(e) && dy(t, e.index);
    return;
} e.type & 3 && (n = jw(n)), ed(e, t, n, o, r, i); }
function ed(e, t, n, o, r, i) { if (e.type & 3) {
    let s = te(e, t);
    o = i != null ? i(o, e.value || "", n) : o, r.setProperty(s, n, o);
}
else
    e.type & 12; }
function dy(e, t) { let n = pe(t, e); n[A] & 16 || (n[A] |= 64); }
function Bw(e, t, n) { let o = n.directiveStart, r = n.directiveEnd; me(n) && pw(t, n, e.data[o + n.componentOffset]), e.firstCreatePass || qi(n, t); let i = n.initialInputs; for (let s = o; s < r; s++) {
    let a = e.data[s], c = Ko(t, e, s, n);
    if (Re(c, t), i !== null && Gw(t, s - o, c, a, n, i), Ae(a)) {
        let l = pe(n.index, t);
        l[H] = Ko(t, e, s, n);
    }
} }
function Uw(e, t, n) { let o = n.directiveStart, r = n.directiveEnd, i = n.index, s = Sp(); try {
    Ze(i);
    for (let a = o; a < r; a++) {
        let c = e.data[a], l = t[a];
        Ec(a), (c.hostBindings !== null || c.hostVars !== 0 || c.hostAttrs !== null) && $w(c, l);
    }
}
finally {
    Ze(-1), Ec(s);
} }
function $w(e, t) { e.hostBindings !== null && e.hostBindings(1, t); }
function td(e, t) { let n = e.directiveRegistry, o = null; if (n)
    for (let r = 0; r < n.length; r++) {
        let i = n[r];
        jm(t, i.selectors, !1) && (o ??= [], Ae(i) ? o.unshift(i) : o.push(i));
    } return o; }
function zw(e, t, n, o, r, i) { let s = te(e, t); qs(t[T], s, i, e.value, n, o, r); }
function qs(e, t, n, o, r, i, s) { if (i == null)
    e.removeAttribute(t, r, n);
else {
    let a = s == null ? N(i) : s(i, o || "", r);
    e.setAttribute(t, r, a, n);
} }
function Gw(e, t, n, o, r, i) { let s = i[t]; if (s !== null)
    for (let a = 0; a < s.length; a += 2) {
        let c = s[a], l = s[a + 1];
        bt(o, n, c, l);
    } }
function Qs(e, t, n, o, r) { let i = E + n, s = t[m], a = r(s, t, e, o, n); t[i] = a, qe(e, !0); let c = e.type === 2; return c ? (Rm(t[T], a, e), (Cp() === 0 || Dn(e)) && Re(a, t), Tp()) : Re(a, t), xo() && (!c || !oo(e)) && Ku(s, t, a, e), e; }
function Ys(e) { let t = e; return fc() ? pc() : (t = t.parent, qe(t, !1)), t; }
function fy(e, t, n) { return (e === null || Ae(e)) && (n = bo(n[t.index])), n[T]; }
function nd(e, t) { let n = e[O]; if (!n)
    return; let o; try {
    o = n.get(Wt, null);
}
catch {
    o = null;
} o?.(t); }
function Zs(e, t, n, o, r) { let i = e.inputs?.[o], s = e.hostDirectiveInputs?.[o], a = !1; if (s)
    for (let c = 0; c < s.length; c += 2) {
        let l = s[c], u = s[c + 1], d = t.data[l];
        bt(d, n[l], u, r), a = !0;
    } if (i)
    for (let c of i) {
        let l = n[c], u = t.data[c];
        bt(u, l, o, r), a = !0;
    } return a; }
function Ww(e, t, n, o, r, i) { let s = null, a = null, c = null, l = !1, u = e.directiveToIndex.get(o.type); if (typeof u == "number" ? s = u : [s, a, c] = u, a !== null && c !== null && e.hostDirectiveInputs?.hasOwnProperty(r)) {
    let d = e.hostDirectiveInputs[r];
    for (let f = 0; f < d.length; f += 2) {
        let p = d[f];
        if (p >= a && p <= c) {
            let h = t.data[p], y = d[f + 1];
            bt(h, n[p], y, i), l = !0;
        }
        else if (p > c)
            break;
    }
} return s !== null && o.inputs.hasOwnProperty(r) && (bt(o, n[s], r, i), l = !0), l; }
function qw(e, t) { let n = pe(t, e), o = n[m]; Qw(o, n); let r = n[j]; r !== null && n[se] === null && (n[se] = nm(r, n[O])), x(R.ComponentStart); try {
    Ks(o, n, n[H]);
}
finally {
    x(R.ComponentEnd, n[H]);
} }
function Qw(e, t) { for (let n = t.length; n < e.blueprint.length; n++)
    t.push(e.blueprint[n]); }
function Ks(e, t, n) { mi(t); try {
    let o = e.viewQuery;
    o !== null && fl(1, o, n);
    let r = e.template;
    r !== null && cy(e, t, r, 1, n), e.firstCreatePass && (e.firstCreatePass = !1), t[ze]?.finishViewCreation(e), e.staticContentQueries && pm(e, t), e.staticViewQueries && fl(2, e.viewQuery, n);
    let i = e.components;
    i !== null && Yw(t, i);
}
catch (o) {
    throw e.firstCreatePass && (e.incompleteFirstPass = !0, e.firstCreatePass = !1), o;
}
finally {
    t[A] &= -5, yi();
} }
function Yw(e, t) { for (let n = 0; n < t.length; n++)
    qw(e, t[n]); }
function ao(e, t, n, o) { let r = P(null); try {
    let i = t.tView, a = e[A] & 4096 ? 4096 : 16, c = Ls(e, i, n, a, null, t, null, null, o?.injector ?? null, o?.embeddedViewInjector ?? null, o?.dehydratedView ?? null), l = e[t.index];
    c[Ct] = l;
    let u = e[ze];
    return u !== null && (c[ze] = u.createEmbeddedView(i)), Ks(i, c, n), c;
}
finally {
    P(r);
} }
function rn(e, t) { return !t || t.firstChild === null || Jo(e); }
function Bn(e, t, n, o, r = !1) { for (; n !== null;) {
    if (n.type === 128) {
        n = r ? n.projectionNext : n.next;
        continue;
    }
    let i = t[n.index];
    i !== null && o.push(k(i)), ee(i) && Js(i, o);
    let s = n.type;
    if (s & 8)
        Bn(e, t, n.child, o);
    else if (s & 32) {
        let a = Bu(n, t), c;
        for (; c = a();)
            o.push(c);
    }
    else if (s & 16) {
        let a = sy(t, n);
        if (Array.isArray(a))
            o.push(...a);
        else {
            let c = $t(t[K]);
            Bn(c[m], c, a, o, !0);
        }
    }
    n = r ? n.projectionNext : n.next;
} return o; }
function Js(e, t) { for (let n = V; n < e.length; n++) {
    let o = e[n], r = o[m].firstChild;
    r !== null && Bn(o[m], o, r, t);
} e[He] !== e[j] && t.push(e[He]); }
function py(e) { if (e[Vt] !== null) {
    for (let t of e[Vt])
        t.impl.addSequence(t);
    e[Vt].length = 0;
} }
var hy = [];
function Zw(e) { return e[be] ?? Kw(e); }
function Kw(e) { let t = hy.pop() ?? Object.create(Xw); return t.lView = e, t; }
function Jw(e) { e.lView[be] !== e && (e.lView = null, hy.push(e)); }
var Xw = et(Z({}, Fa), { consumerIsAlwaysLive: !0, kind: "template", consumerMarkedDirty: e => { di(e.lView); }, consumerOnSignalRead() { this.lView[be] = this; } });
function e_(e) { let t = e[be] ?? Object.create(t_); return t.lView = e, t; }
var t_ = et(Z({}, Fa), { consumerIsAlwaysLive: !0, kind: "template", consumerMarkedDirty: e => { let t = $t(e.lView); for (; t && !gy(t[m]);)
        t = $t(t); t && li(t); }, consumerOnSignalRead() { this.lView[be] = this; } });
function gy(e) { return e.type !== 2; }
function my(e) { if (e[_o] === null)
    return; let t = !0; for (; t;) {
    let n = !1;
    for (let o of e[_o])
        o.dirty && (n = !0, o.zone === null || Zone.current === o.zone ? o.run() : o.zone.run(() => o.run()));
    t = n && !!(e[A] & 8192);
} }
var n_ = 100;
function yy(e, t = 0) { let o = e[$e].rendererFactory, r = !1; r || o.begin?.(); try {
    o_(e, t);
}
finally {
    r || o.end?.();
} }
function o_(e, t) { let n = gc(); try {
    mc(!0), Al(e, t);
    let o = 0;
    for (; Ro(e);) {
        if (o === n_)
            throw new _(103, !1);
        o++, Al(e, 1);
    }
}
finally {
    mc(n);
} }
function vy(e, t, n, o) { if (Tt(t))
    return; let r = t[A], i = !1, s = !1; mi(t); let a = !0, c = null, l = null; i || (gy(e) ? (l = Zw(t), c = vo(l)) : Kf() === null ? (a = !1, l = e_(t), c = vo(l)) : t[be] && (Eo(t[be]), t[be] = null)); try {
    oc(t), yc(e.bindingStartIndex), n !== null && cy(e, t, n, 2, o);
    let u = (r & 3) === 3;
    if (!i)
        if (u) {
            let p = e.preOrderCheckHooks;
            p !== null && Oi(t, p, null);
        }
        else {
            let p = e.preOrderHooks;
            p !== null && ki(t, p, 0, null), xc(t, 0);
        }
    if (s || r_(t), my(t), Ey(t, 0), e.contentQueries !== null && pm(e, t), !i)
        if (u) {
            let p = e.contentCheckHooks;
            p !== null && Oi(t, p);
        }
        else {
            let p = e.contentHooks;
            p !== null && ki(t, p, 1), xc(t, 1);
        }
    s_(e, t);
    let d = e.components;
    d !== null && Dy(t, d, 0);
    let f = e.viewQuery;
    if (f !== null && fl(2, f, o), !i)
        if (u) {
            let p = e.viewCheckHooks;
            p !== null && Oi(t, p);
        }
        else {
            let p = e.viewHooks;
            p !== null && ki(t, p, 2), xc(t, 2);
        }
    if (e.firstUpdatePass === !0 && (e.firstUpdatePass = !1), t[ci]) {
        for (let p of t[ci])
            p();
        t[ci] = null;
    }
    i || (py(t), t[A] &= -73);
}
catch (u) {
    throw i || di(t), u;
}
finally {
    l !== null && (Wr(l, c), a && Jw(l)), yi();
} }
function Ey(e, t) { for (let n = Og(e); n !== null; n = kg(n))
    for (let o = V; o < n.length; o++) {
        let r = n[o];
        Iy(r, t);
    } }
function r_(e) { for (let t = Og(e); t !== null; t = kg(t)) {
    if (!(t[A] & 2))
        continue;
    let n = t[jt];
    for (let o = 0; o < n.length; o++) {
        let r = n[o];
        li(r);
    }
} }
function i_(e, t, n) { x(R.ComponentStart); let o = pe(t, e); try {
    Iy(o, n);
}
finally {
    x(R.ComponentEnd, o[H]);
} }
function Iy(e, t) { mp(e) && Al(e, t); }
function Al(e, t) { let o = e[m], r = e[A], i = e[be], s = !!(t === 0 && r & 16); if (s ||= !!(r & 64 && t === 0), s ||= !!(r & 1024), s ||= !!(i?.dirty && qr(i)), s ||= !1, i && (i.dirty = !1), e[A] &= -9217, s)
    vy(o, e, o.template, e[H]);
else if (r & 8192) {
    let a = P(null);
    try {
        my(e), Ey(e, 1);
        let c = o.components;
        c !== null && Dy(e, c, 1), py(e);
    }
    finally {
        P(a);
    }
} }
function Dy(e, t, n) { for (let o = 0; o < t.length; o++)
    i_(e, t[o], n); }
function s_(e, t) { let n = e.hostBindingOpCodes; if (n !== null)
    try {
        for (let o = 0; o < n.length; o++) {
            let r = n[o];
            if (r < 0)
                Ze(~r);
            else {
                let i = r, s = n[++o], a = n[++o];
                _p(s, i);
                let c = t[i];
                x(R.HostBindingsUpdateStart, c);
                try {
                    a(2, c);
                }
                finally {
                    x(R.HostBindingsUpdateEnd, c);
                }
            }
        }
    }
    finally {
        Ze(-1);
    } }
function Rr(e, t) { let n = gc() ? 64 : 1088; for (e[$e].changeDetectionScheduler?.notify(t); e;) {
    e[A] |= n;
    let o = $t(e);
    if (We(e) && !o)
        return e;
    e = o;
} return null; }
function Cy(e, t, n, o) { return [e, !0, 0, t, null, o, null, n, null, null]; }
function Ty(e, t) { let n = V + t; if (n < e.length)
    return e[n]; }
function co(e, t, n, o = !0) { let r = t[m]; if (a_(r, t, e, n), o) {
    let s = bl(n, e), a = t[T], c = a.parentNode(e[He]);
    c !== null && bw(r, e[ue], a, t, c, s);
} let i = t[se]; i !== null && i.firstChild !== null && (i.firstChild = null); }
function od(e, t) { let n = or(e, t); return n !== void 0 && Ar(n[m], n), n; }
function or(e, t) { if (e.length <= V)
    return; let n = V + t, o = e[n]; if (o) {
    let r = o[Ct];
    r !== null && r !== e && Yu(r, o), t > 0 && (e[n - 1][le] = o[le]);
    let i = Co(e, V + t);
    Xm(o[m], o);
    let s = i[ze];
    s !== null && s.detachView(i[m]), o[q] = null, o[le] = null, o[A] &= -129;
} return o; }
function a_(e, t, n, o) { let r = V + o, i = n.length; o > 0 && (n[r - 1][le] = t), o < i - V ? (t[le] = n[r], qa(n, V + o, t)) : (n.push(t), t[le] = null), t[q] = n; let s = t[Ct]; s !== null && n !== s && My(s, t); let a = t[ze]; a !== null && a.insertView(e), ui(t), t[A] |= 128; }
function My(e, t) { let n = e[jt], o = t[q]; if (re(o))
    e[A] |= 2;
else {
    let r = o[q][K];
    t[K] !== r && (e[A] |= 2);
} n === null ? e[jt] = [t] : n.push(t); }
var Rt = class {
    _lView;
    _cdRefInjectingView;
    _appRef = null;
    _attachedToViewContainer = !1;
    exhaustive;
    get rootNodes() { let t = this._lView, n = t[m]; return Bn(n, t, n.firstChild, []); }
    constructor(t, n) { this._lView = t, this._cdRefInjectingView = n; }
    get context() { return this._lView[H]; }
    set context(t) { this._lView[H] = t; }
    get destroyed() { return Tt(this._lView); }
    destroy() { if (this._appRef)
        this._appRef.detachView(this);
    else if (this._attachedToViewContainer) {
        let t = this._lView[q];
        if (ee(t)) {
            let n = t[So], o = n ? n.indexOf(this) : -1;
            o > -1 && (or(t, o), Co(n, o));
        }
        this._attachedToViewContainer = !1;
    } Ar(this._lView[m], this._lView); }
    onDestroy(t) { fi(this._lView, t); }
    markForCheck() { Rr(this._cdRefInjectingView || this._lView, 4); }
    detach() { this._lView[A] &= -129; }
    reattach() { ui(this._lView), this._lView[A] |= 128; }
    detectChanges() { this._lView[A] |= 1024, yy(this._lView); }
    checkNoChanges() { }
    attachToViewContainerRef() { if (this._appRef)
        throw new _(902, !1); this._attachedToViewContainer = !0; }
    detachFromAppRef() { this._appRef = null; let t = We(this._lView), n = this._lView[Ct]; n !== null && !t && Yu(n, this._lView), ey(this._lView[m], this._lView); }
    attachToAppRef(t) { if (this._attachedToViewContainer)
        throw new _(902, !1); this._appRef = t; let n = We(this._lView), o = this._lView[Ct]; o !== null && !n && My(o, this._lView), ui(this._lView); }
};
function c_(e) { return Ro(e._lView) || !!(e._lView[A] & 64); }
function l_(e) { li(e._lView); }
var rr = (() => { class e {
    _declarationLView;
    _declarationTContainer;
    elementRef;
    static __NG_ELEMENT_ID__ = u_;
    constructor(n, o, r) { this._declarationLView = n, this._declarationTContainer = o, this.elementRef = r; }
    get ssrId() { return this._declarationTContainer.tView?.ssrId || null; }
    createEmbeddedView(n, o) { return this.createEmbeddedViewImpl(n, o); }
    createEmbeddedViewImpl(n, o, r) { let i = ao(this._declarationLView, this._declarationTContainer, n, { embeddedViewInjector: o, dehydratedView: r }); return new Rt(i); }
} return e; })();
function u_() { return Xs(M(), g()); }
function Xs(e, t) { return e.type & 4 ? new rr(t, e, Kn(e, t)) : null; }
var Rl = "<-- AT THIS LOCATION", d_ = "/guide/hydration#third-party-scripts-with-dom-manipulation";
function f_(e) { switch (e) {
    case 4: return "view container";
    case 2: return "element";
    case 8: return "ng-container";
    case 32: return "icu";
    case 64: return "i18n";
    case 16: return "projection";
    case 1: return "text";
    case 128: return "@let";
    default: return "<unknown>";
} }
function p_(e, t) {
    let n = `During serialization, Angular was unable to find an element in the DOM:

`, o = `${y_(e, t, !1)}

`, r = E_();
    throw new _(-502, n + o + r);
}
function Ny(e) {
    let t = "During serialization, Angular detected DOM nodes that were created outside of Angular context and provided as projectable nodes (likely via `ViewContainerRef.createComponent` or `createComponent` APIs). Hydration is not supported for such cases, consider refactoring the code to avoid this pattern or using `ngSkipHydration` on the host element of the component.\n\n", n = `${v_(e)}

`, o = t + n + I_();
    return new _(-503, o);
}
function h_(e) { let t = []; if (e.attrs)
    for (let n = 0; n < e.attrs.length;) {
        let o = e.attrs[n++];
        if (typeof o == "number")
            break;
        let r = e.attrs[n++];
        t.push(`${o}="${ns(r)}"`);
    } return t.join(" "); }
var g_ = new Set(["ngh", "ng-version", "ng-server-context"]);
function m_(e) { let t = []; for (let n = 0; n < e.attributes.length; n++) {
    let o = e.attributes[n];
    g_.has(o.name) || t.push(`${o.name}="${ns(o.value)}"`);
} return t.join(" "); }
function jc(e, t = "\u2026") { switch (e.type) {
    case 1: return `#text${e.value ? `(${e.value})` : ""}`;
    case 2:
        let o = h_(e), r = e.value.toLowerCase();
        return `<${r}${o ? " " + o : ""}>${t}</${r}>`;
    case 8: return "<!-- ng-container -->";
    case 4: return "<!-- container -->";
    default: return `#node(${f_(e.type)})`;
} }
function Li(e, t = "\u2026") { let n = e; switch (n.nodeType) {
    case Node.ELEMENT_NODE:
        let o = n.tagName.toLowerCase(), r = m_(n);
        return `<${o}${r ? " " + r : ""}>${t}</${o}>`;
    case Node.TEXT_NODE:
        let i = n.textContent ? ns(n.textContent) : "";
        return `#text${i ? `(${i})` : ""}`;
    case Node.COMMENT_NODE: return `<!-- ${ns(n.textContent ?? "")} -->`;
    default: return `#node(${n.nodeType})`;
} }
function y_(e, t, n) {
    let r = "";
    t.prev ? (r += `  \u2026
`, r += "  " + jc(t.prev) + `
`) : t.type && t.type & 12 && (r += `  \u2026
`), n ? (r += "  " + jc(t) + `
`, r += `  <!-- container -->  ${Rl}
`) : r += "  " + jc(t) + `  ${Rl}
`, r += `  \u2026
`;
    let i = t.type ? Zu(e[m], t, e) : null;
    return i && (r = Li(i, `
` + r)), r;
}
function v_(e) {
    let n = "", o = e;
    return o.previousSibling && (n += `  \u2026
`, n += "  " + Li(o.previousSibling) + `
`), n += "  " + Li(o) + `  ${Rl}
`, e.nextSibling && (n += `  \u2026
`), e.parentNode && (n = Li(o.parentNode, `
` + n)), n;
}
function E_(e) {
    return `To fix this problem:
  * check ${e ? `the "${e}"` : "corresponding"} component for hydration-related issues
  * check to see if your template has valid HTML structure
  * check if there are any third-party scripts that manipulate the DOM. More info: ${ja}${d_}
  * or skip hydration by adding the \`ngSkipHydration\` attribute to its host node in a template

`;
}
function I_() {
    return `Note: attributes are only displayed to better represent the DOM but have no effect on hydration mismatches.

`;
}
function D_(e) { return e.replace(/\s+/gm, ""); }
function ns(e, t = 50) { return e ? (e = D_(e), e.length > t ? `${e.substring(0, t - 1)}\u2026` : e) : ""; }
function wy(e, t, n) { let o = t.insertBeforeIndex, r = Array.isArray(o) ? o[0] : o; return r === null ? oy(e, t, n) : k(n[r]); }
function _y(e, t, n, o, r) { let i = t.insertBeforeIndex; if (Array.isArray(i)) {
    let s = o, a = null;
    if (t.type & 3 || (a = s, s = r), s !== null && t.componentOffset === -1)
        for (let c = 1; c < i.length; c++) {
            let l = n[i[c]];
            tn(e, s, l, a, !1);
        }
} }
function gn(e, t, n, o, r) { let i = e.data[t]; if (i === null)
    i = rd(e, t, n, o, r), wp() && (i.flags |= 32);
else if (i.type & 64) {
    i.type = n, i.value = o, i.attrs = r;
    let s = Cn();
    i.injectorIndex = s === null ? -1 : s.injectorIndex;
} return qe(i, !0), i; }
function rd(e, t, n, o, r) { let i = Np(), s = fc(), a = s ? i : i && i.parent, c = e.data[t] = T_(e, a, n, t, o, r); return C_(e, c, i, s), c; }
function C_(e, t, n, o) { e.firstChild === null && (e.firstChild = t), n !== null && (o ? n.child == null && t.parent !== null && (n.child = t) : n.next === null && (n.next = t, t.prev = n)); }
function T_(e, t, n, o, r, i) { let s = t ? t.injectorIndex : -1, a = 0; return Oo() && (a |= 128), { type: n, index: o, insertBeforeIndex: null, injectorIndex: s, directiveStart: -1, directiveEnd: -1, directiveStylingLast: -1, componentOffset: -1, controlDirectiveIndex: -1, customControlIndex: -1, propertyBindings: null, flags: a, providerIndexes: 0, value: r, namespace: vi(), attrs: i, mergedAttrs: null, localNames: null, initialInputs: null, inputs: null, hostDirectiveInputs: null, outputs: null, hostDirectiveOutputs: null, directiveToIndex: null, tView: null, next: null, prev: null, projectionNext: null, child: null, parent: t, projection: null, styles: null, stylesWithoutHost: null, residualStyles: void 0, classes: null, classesWithoutHost: null, residualClasses: void 0, classBindings: 0, styleBindings: 0 }; }
function Sy(e, t) { if (e.push(t), e.length > 1)
    for (let n = e.length - 2; n >= 0; n--) {
        let o = e[n];
        by(o) || M_(o, t) && N_(o) === null && w_(o, t.index);
    } }
function by(e) { return !(e.type & 64); }
function M_(e, t) { return by(t) || e.index > t.index; }
function N_(e) { let t = e.insertBeforeIndex; return Array.isArray(t) ? t[0] : t; }
function w_(e, t) { let n = e.insertBeforeIndex; Array.isArray(n) ? n[0] = t : (iy(wy, _y), e.insertBeforeIndex = t); }
function Bo(e, t) { let n = e.data[t]; return n === null || typeof n == "string" ? null : n.hasOwnProperty("currentCaseLViewIndex") ? n : n.value; }
function __(e, t, n) { let o = e.data[t]; o === null ? e.data[t] = n : o.value = n; }
function S_(e, t) { let n = e.insertBeforeIndex; n === null ? (iy(wy, _y), n = e.insertBeforeIndex = [null, t]) : (np(Array.isArray(n), !0, "Expecting array here"), n.push(t)); }
function b_(e, t, n) { let o = rd(e, n, 64, null, null); return Sy(t, o), o; }
function ea(e, t) { let n = t[e.currentCaseLViewIndex]; return n === null ? n : n < 0 ? ~n : n; }
function A_(e) { return e >>> 17; }
function R_(e) { return (e & 131070) >>> 1; }
function O_(e, t, n) { return e | t << 17 | n << 1; }
function Ay(e) { return e === -1; }
function id(e, t, n) { e.index = 0; let o = ea(t, n); o !== null ? e.removes = t.remove[o] : e.removes = F; }
function os(e) { if (e.index < e.removes.length) {
    let t = e.removes[e.index++];
    if (t > 0)
        return e.lView[t];
    {
        e.stack.push(e.index, e.removes);
        let n = ~t, o = e.lView[m].data[n];
        return id(e, o, e.lView), os(e);
    }
}
else
    return e.stack.length === 0 ? (e.lView = void 0, null) : (e.removes = e.stack.pop(), e.index = e.stack.pop(), os(e)); }
function k_() { let e = { stack: [], index: -1 }; function t(n, o) { for (e.lView = o; e.stack.length;)
    e.stack.pop(); return id(e, n.value, o), os.bind(null, e); } return t; }
function x_(e, t) { let n = { stack: [], index: -1, lView: t }; return id(n, e, t), os.bind(null, n); }
var P_ = new RegExp(`^(\\d+)*(${fu}|${du})*(.*)`);
function L_(e, t) { let n = [e]; for (let o of t) {
    let r = n.length - 1;
    if (r > 0 && n[r - 1] === o) {
        let i = n[r] || 1;
        n[r] = i + 1;
    }
    else
        n.push(o, "");
} return n.join(""); }
function F_(e) { let t = e.match(P_), [n, o, r, i] = t, s = o ? parseInt(o, 10) : r, a = []; for (let [c, l, u] of i.matchAll(/(f|n)(\d*)/g)) {
    let d = parseInt(u, 10) || 1;
    a.push(l, d);
} return [s, ...a]; }
function H_(e) { return !e.prev && e.parent?.type === 8; }
function Bc(e) { return e.index - E; }
function lo(e, t) { return !(e.type & 144) && !!t[e.index] && Ry(k(t[e.index])); }
function Ry(e) { return !!e && !e.isConnected; }
function Oy(e, t) { let n = e.i18nNodes; if (n)
    return n.get(t); }
function V_(e, t, n) { let r = e.data[Dr]?.[n]; return r ? ky(r, t) : null; }
function Or(e, t, n, o) { let r = Bc(o), i = Oy(e, r); if (i === void 0) {
    let s = e.data[Dr];
    if (s?.[r])
        i = ky(s[r], n);
    else if (t.firstChild === o)
        i = e.firstChild;
    else {
        let a = o.prev === null, c = o.prev ?? o.parent;
        if (H_(o)) {
            let l = Bc(o.parent);
            i = dl(e, l);
        }
        else {
            let l = te(c, n);
            if (a)
                i = l.firstChild;
            else {
                let u = Bc(c), d = dl(e, u);
                if (c.type === 2 && d) {
                    let p = Mu(e, u) + 1;
                    i = ta(p, d);
                }
                else
                    i = l.nextSibling;
            }
        }
    }
} return i; }
function ta(e, t) { let n = t; for (let o = 0; o < e; o++)
    n = n.nextSibling; return n; }
function j_(e, t) { let n = e; for (let o = 0; o < t.length; o += 2) {
    let r = t[o], i = t[o + 1];
    for (let s = 0; s < i; s++)
        switch (r) {
            case Vg:
                n = n.firstChild;
                break;
            case jg:
                n = n.nextSibling;
                break;
        }
} return n; }
function ky(e, t) { let [n, ...o] = F_(e), r; if (n === du)
    r = t[K][j];
else if (n === fu)
    r = Lu(t[K][j]);
else {
    let i = Number(n);
    r = k(t[i + E]);
} return j_(r, o); }
function Ol(e, t) { if (e === t)
    return []; if (e.parentElement == null || t.parentElement == null)
    return null; if (e.parentElement === t.parentElement)
    return B_(e, t); {
    let n = t.parentElement, o = Ol(e, n), r = Ol(n.firstChild, t);
    return !o || !r ? null : [...o, Vg, ...r];
} }
function B_(e, t) { let n = [], o = null; for (o = e; o != null && o !== t; o = o.nextSibling)
    n.push(jg); return o == null ? null : n; }
function ch(e, t, n) { let o = Ol(e, t); return o === null ? null : L_(n, o); }
function xy(e, t, n) { let o = e.parent, r, i, s; for (; o !== null && (lo(o, t) || n?.has(o.index));)
    o = o.parent; o === null || !(o.type & 3) ? (r = s = du, i = t[K][j]) : (r = o.index, i = k(t[r]), s = N(r - E)); let a = k(t[e.index]); if (e.type & 44) {
    let l = Jt(t, e);
    l && (a = l);
} let c = ch(i, a, s); if (c === null && i !== a) {
    let l = i.ownerDocument.body;
    if (c = ch(l, a, fu), c === null)
        throw p_(t, e);
} return c; }
function Py(e, t) { let n = e.createNodeIterator(t, NodeFilter.SHOW_COMMENT, { acceptNode: U_ }), o, r = new Map; for (; o = n.nextNode();) {
    let i = "ngh=", s = o?.textContent, a = s?.indexOf(i) ?? -1;
    if (a > -1) {
        let c = s.substring(a + i.length).trim();
        r.set(c, o);
    }
} return r; }
function U_(e) { return e.textContent?.trimStart().startsWith("ngh=") ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; }
var Ly = !1, Fy = () => { };
function sd(e) { Ly = e; }
function na() { return Ly; }
function $_(e, t, n, o) { Fy(e, t, n, o); }
function Hy() { Fy = Q_; }
function Vy(e) { return e = e ?? I(Te), e.get(gu, !1); }
function jy(e, t) { let n = t.i18nChildren.get(e); return n === void 0 && (n = z_(e), t.i18nChildren.set(e, n)), n; }
function z_(e) { let t = new Set; function n(o) { switch (t.add(o.index), o.kind) {
    case 1:
    case 2: {
        for (let r of o.children)
            n(r);
        break;
    }
    case 3: {
        for (let r of o.cases)
            for (let i of r)
                n(i);
        break;
    }
} } for (let o = E; o < e.bindingStartIndex; o++) {
    let r = e.data[o];
    if (!(!r || !r.ast))
        for (let i of r.ast)
            n(i);
} return t.size === 0 ? null : t; }
function By(e, t, n) { if (!n.isI18nHydrationEnabled)
    return null; let o = e[m], r = o.data[t]; if (!r || !r.ast)
    return null; let i = o.data[r.parentTNodeIndex]; if (i && Sg(i))
    return null; let s = { caseQueue: [], disconnectedNodes: new Set, disjointNodes: new Set }; return kl(e, s, n, r.ast), s.caseQueue.length === 0 && s.disconnectedNodes.size === 0 && s.disjointNodes.size === 0 ? null : s; }
function kl(e, t, n, o) { let r = null; for (let i of o) {
    let s = W_(e, t, n, i);
    s && (G_(r, s) && t.disjointNodes.add(i.index - E), r = s);
} return r; }
function G_(e, t) { return e && e.nextSibling !== t; }
function W_(e, t, n, o) { let r = k(e[o.index]); if (!r || Ry(r))
    return t.disconnectedNodes.add(o.index - E), null; let i = r; switch (o.kind) {
    case 0: {
        Nu(n, i);
        break;
    }
    case 1:
    case 2: {
        kl(e, t, n, o.children);
        break;
    }
    case 3: {
        let s = e[o.currentCaseLViewIndex];
        if (s != null) {
            let a = s < 0 ? ~s : s;
            t.caseQueue.push(a), kl(e, t, n, o.cases[a]);
        }
        break;
    }
} return q_(e, o); }
function q_(e, t) { let o = e[m].data[t.index]; return ys(o) ? Jt(e, o) : t.kind === 3 ? x_(o, e)() ?? k(e[t.index]) : k(e[t.index]) ?? null; }
function Qt(e, t) { e.currentNode = t; }
function Lo(e, t, n) { let o = n.index - E, { disconnectedNodes: r } = e, i = t.currentNode; return t.isConnected ? (e.i18nNodes.set(o, i), r.delete(o)) : r.add(o), i; }
function Uc(e, t) { let n = e.currentNode; for (let o = 0; o < t && n; o++)
    n = n?.nextSibling ?? null; return n; }
function $c(e, t) { return { currentNode: t, isConnected: e.isConnected }; }
function Q_(e, t, n, o) { let r = e[se]; if (!r || !na() || n && (Sg(n) || Rs(r, n.index - E)))
    return; let i = e[m], s = i.data[t]; function a() { if (Ay(o)) {
    let p = Or(r, i, e, n);
    return n.type & 8 ? p : p.firstChild;
} return r?.firstChild; } let c = a(), l = sm(r) ?? new Set, u = r.i18nNodes ??= new Map, d = r.data[Ns]?.[t - E] ?? [], f = r.dehydratedIcuData ??= new Map; Nn({ hydrationInfo: r, lView: e, i18nNodes: u, disconnectedNodes: l, caseQueue: d, dehydratedIcuData: f }, { currentNode: c, isConnected: !0 }, s.ast), r.disconnectedNodes = l.size === 0 ? null : l; }
function Nn(e, t, n) { if (Array.isArray(n)) {
    let o = t;
    for (let r of n) {
        let i = V_(e.hydrationInfo, e.lView, r.index - E);
        i && (o = $c(t, i)), Nn(e, o, r);
    }
}
else {
    if (e.disconnectedNodes.has(n.index - E))
        return;
    switch (n.kind) {
        case 0: {
            let o = Lo(e, t, n);
            Qt(t, o?.nextSibling ?? null);
            break;
        }
        case 1: {
            Nn(e, $c(t, t.currentNode?.firstChild ?? null), n.children);
            let o = Lo(e, t, n);
            Qt(t, o?.nextSibling ?? null);
            break;
        }
        case 2: {
            let o = n.index - E, { hydrationInfo: r } = e, i = rm(r, o);
            switch (n.type) {
                case 0: {
                    let s = Lo(e, t, n);
                    if (aN(r, o)) {
                        Nn(e, t, n.children);
                        let a = Uc(t, 1);
                        Qt(t, a);
                    }
                    else if (Nn(e, $c(t, t.currentNode?.firstChild ?? null), n.children), Qt(t, s?.nextSibling ?? null), i !== null) {
                        let a = Uc(t, i + 1);
                        Qt(t, a);
                    }
                    break;
                }
                case 1: {
                    Lo(e, t, n);
                    let s = Uc(t, i + 1);
                    Qt(t, s);
                    break;
                }
            }
            break;
        }
        case 3: {
            let o = t.isConnected ? e.caseQueue.shift() : null, r = { currentNode: null, isConnected: !1 };
            for (let s = 0; s < n.cases.length; s++)
                Nn(e, s === o ? t : r, n.cases[s]);
            o !== null && e.dehydratedIcuData.set(n.index, { case: o, node: n });
            let i = Lo(e, t, n);
            Qt(t, i?.nextSibling ?? null);
            break;
        }
    }
} }
var Uy = () => { };
function Y_(e, t, n) { Uy(e, t, n); }
function $y() { Uy = Z_; }
function Z_(e, t, n) { let o = e[se]?.dehydratedIcuData; o && o.get(t)?.case === n && o.delete(t); }
function K_(e) { let t = e[se]; if (t) {
    let { i18nNodes: n, dehydratedIcuData: o } = t;
    if (n && o) {
        let r = e[T];
        for (let i of o.values())
            J_(r, n, i);
    }
    t.i18nNodes = void 0, t.dehydratedIcuData = void 0;
} }
function J_(e, t, n) { for (let o of n.node.cases[n.case]) {
    let r = t.get(o.index - E);
    r && _r(e, r, !1);
} }
function oa(e) { let t = e[Ce] ?? [], o = e[q][T], r = []; for (let i of t)
    i.data[ws] !== void 0 ? r.push(i) : zy(i, o); e[Ce] = r; }
function X_(e) { let { lContainer: t } = e, n = t[Ce]; if (n === null)
    return; let r = t[q][T]; for (let i of n)
    zy(i, r); }
function zy(e, t) { let n = 0, o = e.firstChild; if (o) {
    let r = e.data[st];
    for (; n < r;) {
        let i = o.nextSibling;
        _r(t, o, !1), o = i, n++;
    }
} }
function ra(e) { oa(e); let t = e[j]; re(t) && ir(t); for (let n = V; n < e.length; n++)
    ir(e[n]); }
function ir(e) { K_(e); let t = e[m]; for (let n = E; n < t.bindingStartIndex; n++)
    if (ee(e[n])) {
        let o = e[n];
        ra(o);
    }
    else
        re(e[n]) && ir(e[n]); }
function ad(e) { let t = e._views; for (let n of t) {
    let o = Tu(n);
    o !== null && o[j] !== null && (re(o) ? ir(o) : ra(o));
} }
function eS(e, t, n, o) { e !== null && (n.cleanup(t), ra(e.lContainer), ad(o)); }
function tS(e, t) { let n = []; for (let o of t)
    for (let r = 0; r < (o[Ir] ?? 1); r++) {
        let i = { data: o, firstChild: null };
        o[st] > 0 && (i.firstChild = e, e = ta(o[st], e)), n.push(i);
    } return [e, n]; }
var Gy = () => null, Wy = () => null;
function qy() { Gy = nS, Wy = oS; }
function nS(e, t) { return Yy(e, t) ? e[Ce].shift() : (oa(e), null); }
function sr(e, t) { return Gy(e, t); }
function oS(e, t, n) { if (t.tView.ssrId === null)
    return null; let o = sr(e, t.tView.ssrId); return n[m].firstUpdatePass && o === null && rS(n, t), o; }
function Qy(e, t, n) { return Wy(e, t, n); }
function rS(e, t) { let n = t; for (; n;) {
    if (lh(e, n))
        return;
    if ((n.flags & 256) === 256)
        break;
    n = n.prev;
} for (n = t.next; n && (n.flags & 512) === 512;) {
    if (lh(e, n))
        return;
    n = n.next;
} }
function Yy(e, t) { let n = e[Ce]; return !t || n === null || n.length === 0 ? !1 : n[0].data[Ms] === t; }
function lh(e, t) { let n = t.tView?.ssrId; if (n == null)
    return !1; let o = e[t.index]; return ee(o) && Yy(o, n) ? (oa(o), !0) : !1; }
var Zy = class {
}, ia = class {
}, xl = class {
    resolveComponentFactory(t) { throw new _(917, !1); }
}, kr = class {
    static NULL = new xl;
}, ar = class {
}, iS = (() => { class e {
    destroyNode = null;
    static __NG_ELEMENT_ID__ = () => sS();
} return e; })();
function sS() { let e = g(), t = M(), n = pe(t.index, e); return (re(n) ? n : e)[T]; }
var Ky = (() => { class e {
    static \u0275prov = B({ token: e, providedIn: "root", factory: () => null });
} return e; })();
function cd(e) { return e.ngModule !== void 0; }
function Yt(e) { return !!vn(e); }
function Si(e) { return !!Ue(e); }
function uh(e) { return !!Ne(e); }
function Uo(e) { return !!W(e); }
function aS(e) { return W(e) ? "component" : Ne(e) ? "directive" : Ue(e) ? "pipe" : "type"; }
function cS(e, t) { if (Kr(e) && (e = G(e), !e))
    throw new Error(`Expected forwardRef function, imported from "${we(t)}", to return a standalone entity or NgModule but got "${we(e) || e}".`); if (vn(e) == null) {
    let n = W(e) || Ne(e) || Ue(e);
    if (n != null) {
        if (!n.standalone) {
            let o = aS(e);
            throw new Error(`The "${we(e)}" ${o}, imported from "${we(t)}", is not standalone. Does the ${o} have the standalone: false flag?`);
        }
    }
    else
        throw cd(e) ? new Error(`A module with providers was imported from "${we(t)}". Modules with providers are not supported in standalone components imports.`) : new Error(`The "${we(e)}" type, imported from "${we(t)}", must be a standalone component / directive / pipe or an NgModule. Did you forget to add the required @Component / @Directive / @Pipe or @NgModule annotation?`);
} }
var Pl = class {
    ownerNgModule = new WeakMap;
    ngModulesWithSomeUnresolvedDecls = new Set;
    ngModulesScopeCache = new WeakMap;
    standaloneComponentsScopeCache = new WeakMap;
    resolveNgModulesDecls() { if (this.ngModulesWithSomeUnresolvedDecls.size !== 0) {
        for (let t of this.ngModulesWithSomeUnresolvedDecls) {
            let n = vn(t);
            if (n?.declarations)
                for (let o of An(n.declarations))
                    Uo(o) && this.ownerNgModule.set(o, t);
        }
        this.ngModulesWithSomeUnresolvedDecls.clear();
    } }
    getComponentDependencies(t, n) { this.resolveNgModulesDecls(); let o = W(t); if (o === null)
        throw new Error(`Attempting to get component dependencies for a type that is not a component: ${t}`); if (o.standalone) {
        let r = this.getStandaloneComponentScope(t, n);
        return r.compilation.isPoisoned ? { dependencies: [] } : { dependencies: [...r.compilation.directives, ...r.compilation.pipes, ...r.compilation.ngModules] };
    }
    else {
        if (!this.ownerNgModule.has(t))
            return { dependencies: [] };
        let r = this.getNgModuleScope(this.ownerNgModule.get(t));
        return r.compilation.isPoisoned ? { dependencies: [] } : { dependencies: [...r.compilation.directives, ...r.compilation.pipes] };
    } }
    registerNgModule(t, n) { if (!Yt(t))
        throw new Error(`Attempting to register a Type which is not NgModule as NgModule: ${t}`); this.ngModulesWithSomeUnresolvedDecls.add(t); }
    clearScopeCacheFor(t) { this.ngModulesScopeCache.delete(t), this.standaloneComponentsScopeCache.delete(t); }
    getNgModuleScope(t) { if (this.ngModulesScopeCache.has(t))
        return this.ngModulesScopeCache.get(t); let n = this.computeNgModuleScope(t); return this.ngModulesScopeCache.set(t, n), n; }
    computeNgModuleScope(t) { let n = ei(t), o = { exported: { directives: new Set, pipes: new Set }, compilation: { directives: new Set, pipes: new Set } }; for (let r of An(n.imports))
        if (Yt(r)) {
            let i = this.getNgModuleScope(r);
            wt(i.exported.directives, o.compilation.directives), wt(i.exported.pipes, o.compilation.pipes);
        }
        else if (Do(r))
            if (uh(r) || Uo(r))
                o.compilation.directives.add(r);
            else if (Si(r))
                o.compilation.pipes.add(r);
            else
                throw new _(980, "The standalone imported type is neither a component nor a directive nor a pipe");
        else {
            o.compilation.isPoisoned = !0;
            break;
        } if (!o.compilation.isPoisoned)
        for (let r of An(n.declarations)) {
            if (Yt(r) || Do(r)) {
                o.compilation.isPoisoned = !0;
                break;
            }
            Si(r) ? o.compilation.pipes.add(r) : o.compilation.directives.add(r);
        } for (let r of An(n.exports))
        if (Yt(r)) {
            let i = this.getNgModuleScope(r);
            wt(i.exported.directives, o.exported.directives), wt(i.exported.pipes, o.exported.pipes), wt(i.exported.directives, o.compilation.directives), wt(i.exported.pipes, o.compilation.pipes);
        }
        else
            Si(r) ? o.exported.pipes.add(r) : o.exported.directives.add(r); return o; }
    getStandaloneComponentScope(t, n) { if (this.standaloneComponentsScopeCache.has(t))
        return this.standaloneComponentsScopeCache.get(t); let o = this.computeStandaloneComponentScope(t, n); return this.standaloneComponentsScopeCache.set(t, o), o; }
    computeStandaloneComponentScope(t, n) { let o = { compilation: { directives: new Set([t]), pipes: new Set, ngModules: new Set } }; for (let r of Fe(n ?? [])) {
        let i = G(r);
        try {
            cS(i, t);
        }
        catch {
            return o.compilation.isPoisoned = !0, o;
        }
        if (Yt(i)) {
            o.compilation.ngModules.add(i);
            let s = this.getNgModuleScope(i);
            if (s.exported.isPoisoned)
                return o.compilation.isPoisoned = !0, o;
            wt(s.exported.directives, o.compilation.directives), wt(s.exported.pipes, o.compilation.pipes);
        }
        else if (Si(i))
            o.compilation.pipes.add(i);
        else if (uh(i) || Uo(i))
            o.compilation.directives.add(i);
        else
            return o.compilation.isPoisoned = !0, o;
    } return o; }
    isOrphanComponent(t) { let n = W(t); return !n || n.standalone ? !1 : (this.resolveNgModulesDecls(), !this.ownerNgModule.has(t)); }
};
function wt(e, t) { for (let n of e)
    t.add(n); }
var Un = new Pl, Fi = {}, Pn = class {
    injector;
    parentInjector;
    constructor(t, n) { this.injector = t, this.parentInjector = n; }
    get(t, n, o) { let r = this.injector.get(t, Fi, o); return r !== Fi || n === Fi ? r : this.parentInjector.get(t, n, o); }
};
function rs(e, t, n) { let o = n ? e.styles : null, r = n ? e.classes : null, i = 0; if (t !== null)
    for (let s = 0; s < t.length; s++) {
        let a = t[s];
        if (typeof a == "number")
            i = a;
        else if (i == 1)
            r = Zr(r, a);
        else if (i == 2) {
            let c = a, l = t[++s];
            o = Zr(o, c + ": " + l + ";");
        }
    } n ? e.styles = o : e.stylesWithoutHost = o, n ? e.classes = r : e.classesWithoutHost = r; }
function uo(e, t = 0) { let n = g(); if (n === null)
    return Le(e, t); let o = M(); return Ig(o, n, G(e), t); }
function Jy() { let e = "invalid"; throw new Error(e); }
function Xy(e, t, n, o, r) { let i = o === null ? null : { "": -1 }, s = r(e, n); if (s !== null) {
    let a = s, c = null, l = null;
    for (let u of s)
        if (u.resolveHostDirectives !== null) {
            [a, c, l] = u.resolveHostDirectives(s);
            break;
        }
    dS(e, t, n, a, i, c, l);
} i !== null && o !== null && lS(n, o, i); }
function lS(e, t, n) { let o = e.localNames = []; for (let r = 0; r < t.length; r += 2) {
    let i = n[t[r + 1]];
    if (i == null)
        throw new _(-301, !1);
    o.push(t[r], i);
} }
function uS(e, t, n) { t.componentOffset = n, (e.components ??= []).push(t.index); }
function dS(e, t, n, o, r, i, s) { let a = o.length, c = null; for (let f = 0; f < a; f++) {
    let p = o[f];
    c === null && Ae(p) && (c = p, uS(e, n, f)), rl(qi(n, t), e, p.type);
} yS(n, e.data.length, a), c?.viewProvidersResolver && c.viewProvidersResolver(c); for (let f = 0; f < a; f++) {
    let p = o[f];
    p.providersResolver && p.providersResolver(p);
} let l = !1, u = !1, d = br(e, t, a, null); a > 0 && (n.directiveToIndex = new Map); for (let f = 0; f < a; f++) {
    let p = o[f];
    if (n.mergedAttrs = Vn(n.mergedAttrs, p.hostAttrs), pS(e, n, t, d, p), mS(d, p, r), s !== null && s.has(p)) {
        let [y, v] = s.get(p);
        n.directiveToIndex.set(p.type, [d, y + n.directiveStart, v + n.directiveStart]);
    }
    else
        (i === null || !i.has(p)) && n.directiveToIndex.set(p.type, d);
    p.contentQueries !== null && (n.flags |= 4), (p.hostBindings !== null || p.hostAttrs !== null || p.hostVars !== 0) && (n.flags |= 64);
    let h = p.type.prototype;
    !l && (h.ngOnChanges || h.ngOnInit || h.ngDoCheck) && ((e.preOrderHooks ??= []).push(n.index), l = !0), !u && (h.ngOnChanges || h.ngDoCheck) && ((e.preOrderCheckHooks ??= []).push(n.index), u = !0), d++;
} fS(e, n, i); }
function fS(e, t, n) { for (let o = t.directiveStart; o < t.directiveEnd; o++) {
    let r = e.data[o];
    if (n === null || !n.has(r))
        dh(0, t, r, o), dh(1, t, r, o), ph(t, o, !1);
    else {
        let i = n.get(r);
        fh(0, t, i, o), fh(1, t, i, o), ph(t, o, !0);
    }
} }
function dh(e, t, n, o) { let r = e === 0 ? n.inputs : n.outputs; for (let i in r)
    if (r.hasOwnProperty(i)) {
        let s;
        e === 0 ? s = t.inputs ??= {} : s = t.outputs ??= {}, s[i] ??= [], s[i].push(o), ev(t, i);
    } }
function fh(e, t, n, o) { let r = e === 0 ? n.inputs : n.outputs; for (let i in r)
    if (r.hasOwnProperty(i)) {
        let s = r[i], a;
        e === 0 ? a = t.hostDirectiveInputs ??= {} : a = t.hostDirectiveOutputs ??= {}, a[s] ??= [], a[s].push(o, i), ev(t, s);
    } }
function ev(e, t) { t === "class" ? e.flags |= 8 : t === "style" && (e.flags |= 16); }
function ph(e, t, n) { let { attrs: o, inputs: r, hostDirectiveInputs: i } = e; if (o === null || !n && r === null || n && i === null || Fu(e)) {
    e.initialInputs ??= [], e.initialInputs.push(null);
    return;
} let s = null, a = 0; for (; a < o.length;) {
    let c = o[a];
    if (c === 0) {
        a += 4;
        continue;
    }
    else if (c === 5) {
        a += 2;
        continue;
    }
    else if (typeof c == "number")
        break;
    if (!n && r.hasOwnProperty(c)) {
        let l = r[c];
        for (let u of l)
            if (u === t) {
                s ??= [], s.push(c, o[a + 1]);
                break;
            }
    }
    else if (n && i.hasOwnProperty(c)) {
        let l = i[c];
        for (let u = 0; u < l.length; u += 2)
            if (l[u] === t) {
                s ??= [], s.push(l[u + 1], o[a + 1]);
                break;
            }
    }
    a += 2;
} e.initialInputs ??= [], e.initialInputs.push(s); }
function pS(e, t, n, o, r) { e.data[o] = r; let i = r.factory || (r.factory = ni(r.type, !0)), s = new en(i, Ae(r), uo, null); e.blueprint[o] = s, n[o] = s, hS(e, t, o, br(e, n, r.hostVars, L), r); }
function hS(e, t, n, o, r) { let i = r.hostBindings; if (i) {
    let s = e.hostBindingOpCodes;
    s === null && (s = e.hostBindingOpCodes = []);
    let a = ~t.index;
    gS(s) != a && s.push(a), s.push(n, o, i);
} }
function gS(e) { let t = e.length; for (; t > 0;) {
    let n = e[--t];
    if (typeof n == "number" && n < 0)
        return n;
} return 0; }
function mS(e, t, n) { if (n) {
    if (t.exportAs)
        for (let o = 0; o < t.exportAs.length; o++)
            n[t.exportAs[o]] = e;
    Ae(t) && (n[""] = e);
} }
function yS(e, t, n) { e.flags |= 1, e.directiveStart = t, e.directiveEnd = t + n, e.providerIndexes = t; }
function ld(e, t, n, o, r, i, s, a) { let c = t[m], l = c.consts, u = de(l, s), d = gn(c, e, n, o, u); return i && Xy(c, t, d, de(l, a), r), d.mergedAttrs = Vn(d.mergedAttrs, d.attrs), d.attrs !== null && rs(d, d.attrs, !1), d.mergedAttrs !== null && rs(d, d.mergedAttrs, !0), c.queries !== null && c.queries.elementStart(c, d), d; }
function ud(e, t) { ug(e, t), Xa(t) && e.queries.elementEnd(t); }
function tv(e, t, n, o, r, i) { let s = t.consts, a = de(s, r), c = gn(t, e, n, o, a); if (c.mergedAttrs = Vn(c.mergedAttrs, c.attrs), i != null) {
    let l = de(s, i);
    c.localNames = [];
    for (let u = 0; u < l.length; u += 2)
        c.localNames.push(l[u], -1);
} return c.attrs !== null && rs(c, c.attrs, !1), c.mergedAttrs !== null && rs(c, c.mergedAttrs, !0), t.queries !== null && t.queries.elementStart(t, c), c; }
function cr(e) { return sa(e) ? Array.isArray(e) || !(e instanceof Map) && Symbol.iterator in e : !1; }
function vS(e, t, n) { let o = e[Symbol.iterator](), r = t[Symbol.iterator](); for (;;) {
    let i = o.next(), s = r.next();
    if (i.done && s.done)
        return !0;
    if (i.done || s.done || !n(i.value, s.value))
        return !1;
} }
function nv(e, t) { if (Array.isArray(e))
    for (let n = 0; n < e.length; n++)
        t(e[n]);
else {
    let n = e[Symbol.iterator](), o;
    for (; !(o = n.next()).done;)
        t(o.value);
} }
function sa(e) { return e !== null && (typeof e == "function" || typeof e == "object"); }
function ov(e, t) { let n = cr(e), o = cr(t); return n && o ? vS(e, t, ov) : !n && (e && (typeof e == "object" || typeof e == "function")) && !o && (t && (typeof t == "object" || typeof t == "function")) ? !0 : Object.is(e, t); }
function Be(e, t, n) { return e[t] = n; }
function fo(e, t) { return e[t]; }
function z(e, t, n) { if (n === L)
    return !1; let o = e[t]; return Object.is(o, n) ? !1 : (e[t] = n, !0); }
function sn(e, t, n, o) { let r = z(e, t, n); return z(e, t + 1, o) || r; }
function aa(e, t, n, o, r) { let i = sn(e, t, n, o); return z(e, t + 2, r) || i; }
function ke(e, t, n, o, r, i) { let s = sn(e, t, n, o); return sn(e, t + 2, r, i) || s; }
function At(e, t, n) { return function o(r) { let i = o.__ngNativeEl__; i !== void 0 && KM(r, i); let s = me(e) ? pe(e.index, t) : t; Rr(s, 5); let a = t[H], c = hh(t, a, n, r), l = o.__ngNextListenerFn__; for (; l;)
    c = hh(t, a, l, r) && c, l = l.__ngNextListenerFn__; return c; }; }
function hh(e, t, n, o) { let r = wn(null); try {
    return x(R.OutputStart, t, n), n(o) !== !1;
}
catch (i) {
    return nd(e, i), !1;
}
finally {
    x(R.OutputEnd, t, n), wn(r);
} }
function dd(e, t, n, o, r, i, s, a) { let c = Dn(e), l = !1, u = null; if (!o && c && (u = IS(t, n, i, e.index)), u !== null) {
    let d = u.__ngLastListenerFn__ || u;
    d.__ngNextListenerFn__ = s, u.__ngLastListenerFn__ = s, l = !0;
}
else {
    let d = te(e, n), f = o ? o(d) : d;
    JM(n, f, i, a), o || (a.__ngNativeEl__ = d);
    let p = r.listen(f, i, a);
    if (!ES(i)) {
        let h = o ? y => o(k(y[e.index])) : e.index;
        rv(h, t, n, i, a, p, !1);
    }
} return l; }
function ES(e) { return e.startsWith("animation") || e.startsWith("transition"); }
function IS(e, t, n, o) { let r = e.cleanup; if (r != null)
    for (let i = 0; i < r.length - 1; i += 2) {
        let s = r[i];
        if (s === n && r[i + 1] === o) {
            let a = t[Ht], c = r[i + 2];
            return a && a.length > c ? a[c] : null;
        }
        typeof s == "string" && (i += 2);
    } return null; }
function rv(e, t, n, o, r, i, s) { let a = t.firstCreatePass ? Ip(t) : null, c = Ep(n), l = c.length; c.push(r, i), a && a.push(o, e, l, (l + 1) * (s ? -1 : 1)); }
function DS(e, t, n, o, r) { let i = At(e, t, n), s = CS(e, t, o, r, i); }
function CS(e, t, n, o, r) { let i = null, s = null, a = null, c = !1, l = e.directiveToIndex.get(n.type); if (typeof l == "number" ? i = l : [i, s, a] = l, s !== null && a !== null && e.hostDirectiveOutputs?.hasOwnProperty(o)) {
    let u = e.hostDirectiveOutputs[o];
    for (let d = 0; d < u.length; d += 2) {
        let f = u[d];
        if (f >= s && f <= a)
            c = !0, $n(e, t, f, u[d + 1], o, r);
        else if (f > a)
            break;
    }
} return n.outputs.hasOwnProperty(o) && (c = !0, $n(e, t, i, o, o, r)), c; }
function $n(e, t, n, o, r, i) { let s = t[n], a = t[m], l = a.data[n].outputs[o], d = s[l].subscribe(i); rv(e.index, a, t, r, i, d, !0); }
function iv() { sv(); }
function sv() { let e = g(), t = w(), n = M(); if (t.firstCreatePass && TS(t, n), n.controlDirectiveIndex === -1)
    return; Q("NgSignalForms"); let o = e[n.controlDirectiveIndex]; t.data[n.controlDirectiveIndex].controlDef.create(o, new is(e, t, n)); }
function av() { cv(); }
function cv() { let e = g(), t = w(), n = Ee(); if (n.controlDirectiveIndex === -1)
    return; let o = t.data[n.controlDirectiveIndex].controlDef, r = e[n.controlDirectiveIndex]; o.update(r, new is(e, t, n)); }
var is = class {
    lView;
    tView;
    tNode;
    hasPassThrough;
    constructor(t, n, o) { this.lView = t, this.tView = n, this.tNode = o, this.hasPassThrough = !!(o.flags & 4096); }
    get customControl() { return this.tNode.customControlIndex !== -1 ? this.lView[this.tNode.customControlIndex] : void 0; }
    get descriptor() { return `<${this.tNode.value}>`; }
    listenToCustomControlOutput(t, n) { lv(this.tView.data[this.tNode.customControlIndex], t) && $n(this.tNode, this.lView, this.tNode.customControlIndex, t, t, At(this.tNode, this.lView, n)); }
    listenToCustomControlModel(t) { let n = this.tNode.flags & 1024 ? "valueChange" : "checkedChange"; $n(this.tNode, this.lView, this.tNode.customControlIndex, n, n, At(this.tNode, this.lView, t)); }
    listenToDom(t, n) { dd(this.tNode, this.tView, this.lView, void 0, this.lView[T], t, n, At(this.tNode, this.lView, n)); }
    setInputOnDirectives(t, n) { let o = this.tNode.inputs?.[t], r = this.tNode.hostDirectiveInputs?.[t]; if (!o && !r)
        return !1; if (o)
        for (let i of o) {
            let s = this.tView.data[i], a = this.lView[i];
            bt(s, a, t, n);
        } if (r)
        for (let i = 0; i < r.length; i += 2) {
            let s = r[i], a = r[i + 1], c = this.tView.data[s], l = this.lView[s];
            bt(c, l, a, n);
        } return !0; }
    setCustomControlModelInput(t) { let n = this.lView[this.tNode.customControlIndex], o = this.tView.data[this.tNode.customControlIndex], r = this.tNode.flags & 1024 ? "value" : "checked"; bt(o, n, r, t); }
    customControlHasInput(t) { return this.tNode.customControlIndex === -1 ? !1 : this.tView.data[this.tNode.customControlIndex].inputs[t] != null; }
};
function TS(e, t, n) { for (let r = t.directiveStart; r < t.directiveEnd; r++)
    if (e.data[r].controlDef) {
        t.controlDirectiveIndex = r;
        break;
    } if (t.controlDirectiveIndex === -1)
    return; let o = e.data[t.controlDirectiveIndex].controlDef; if (o.passThroughInput && (t.inputs?.[o.passThroughInput]?.length ?? 0) > 1) {
    t.flags |= 4096;
    return;
} MS(e, t); }
function MS(e, t) { for (let n = t.directiveStart; n < t.directiveEnd; n++) {
    let o = e.data[n];
    if (gh(o, "value")) {
        t.flags |= 1024, t.customControlIndex = n;
        return;
    }
    if (gh(o, "checked")) {
        t.flags |= 2048, t.customControlIndex = n;
        return;
    }
} }
function gh(e, t) { return NS(e, t) && lv(e, t + "Change"); }
function NS(e, t) { return t in e.inputs; }
function lv(e, t) { return t in e.outputs; }
var it = Symbol("BINDING"), mh = { kind: "input", requiredVars: 1 }, wS = { kind: "output", requiredVars: 0 };
function yh(e, t, n) { let o = g(), r = he(); if (z(o, r, n)) {
    let i = o[m], s = Ee(), a = pe(s.index, o);
    Rr(a, 1);
    let c = i.directiveRegistry[e], l = Ww(s, i, o, c, t, n);
} }
function uv(e, t) { if (e === "formField") {
    let o = { [it]: mh, create: () => { sv(); }, update: () => { yh(o.targetIdx, e, t()), cv(); } };
    return o;
} let n = { [it]: mh, update: () => yh(n.targetIdx, e, t()) }; return n; }
function dv(e, t) { let n = { [it]: wS, create: () => { let o = g(), r = M(), s = o[m].directiveRegistry[n.targetIdx]; DS(r, o, t, s, e); } }; return n; }
function _S(e, t) { let n = uv(e, t), o = dv(e + "Change", i => t.set(i)); return { [it]: { kind: "twoWay", requiredVars: n[it].requiredVars + o[it].requiredVars }, set targetIdx(i) { n.targetIdx = i, o.targetIdx = i; }, create: o.create, update: n.update }; }
function SS(e) { let t = e; for (; t;) {
    let n = CM(t);
    if (n !== null)
        for (let o = E; o < n.length; o++) {
            let r = n[o];
            if (!re(r) && !ee(r) || r[j] !== t)
                continue;
            let i = n[m], s = Ut(i, o);
            if (me(s)) {
                let a = i.data[s.directiveStart + s.componentOffset], c = fd(a);
                if (c !== null)
                    return c;
                break;
            }
        }
    t = t.parentNode;
} return null; }
function fd(e) { return e.debugInfo?.className || e.type.name || null; }
var ss = class extends kr {
    ngModule;
    constructor(t) { super(), this.ngModule = t; }
    resolveComponentFactory(t) { let n = W(t); return new Ot(n, this.ngModule); }
};
function bS(e) { return Object.keys(e).map(t => { let [n, o, r] = e[t], i = { propName: n, templateName: t, isSignal: (o & Fs.SignalBased) !== 0 }; return r && (i.transform = r), i; }); }
function AS(e) { return Object.keys(e).map(t => ({ propName: e[t], templateName: t })); }
function RS(e, t, n) { let o = t instanceof It ? t : t?.injector; return o && e.getStandaloneInjector !== null && (o = e.getStandaloneInjector(o) || o), o ? new Pn(n, o) : n; }
function OS(e) { let t = e.get(ar, null); if (t === null)
    throw new _(407, !1); let n = e.get(Ky, null), o = e.get(Nt, null), r = e.get(hn, null, { optional: !0 }); return { rendererFactory: t, sanitizer: n, changeDetectionScheduler: o, ngReflect: !1, tracingService: r }; }
function kS(e, t) { let n = fv(e); return xs(t, n, n === "svg" ? tc : n === "math" ? fp : null); }
function xS(e) { if (e?.toLowerCase() === "script")
    throw new _(905, !1); }
function fv(e) { return (e.selectors[0][0] || "div").toLowerCase(); }
var Ot = class extends ia {
    componentDef;
    ngModule;
    selector;
    componentType;
    ngContentSelectors;
    isBoundToModule;
    cachedInputs = null;
    cachedOutputs = null;
    get inputs() { return this.cachedInputs ??= bS(this.componentDef.inputs), this.cachedInputs; }
    get outputs() { return this.cachedOutputs ??= AS(this.componentDef.outputs), this.cachedOutputs; }
    constructor(t, n) { super(), this.componentDef = t, this.ngModule = n, this.componentType = t.type, this.selector = uw(t.selectors), this.ngContentSelectors = t.ngContentSelectors ?? [], this.isBoundToModule = !!n; }
    create(t, n, o, r, i, s) { x(R.DynamicComponentStart); let a = P(null); try {
        let c = this.componentDef, l = RS(c, r || this.ngModule, t), u = OS(l), d = u.tracingService;
        return d && d.componentCreate ? d.componentCreate(fd(c), () => this.createComponentRef(u, l, n, o, i, s)) : this.createComponentRef(u, l, n, o, i, s);
    }
    finally {
        P(a);
    } }
    createComponentRef(t, n, o, r, i, s) { let a = this.componentDef, c = PS(r, a, s, i), l = t.rendererFactory.createRenderer(null, a), u = r ? Fw(l, r, a.encapsulation, n) : kS(a, l); xS(u?.tagName); let d = s?.some(vh) || i?.some(h => typeof h != "function" && h.bindings.some(vh)), f = Ls(null, c, null, 512 | Vu(a), null, null, t, l, n, null, nm(u, n, !0)); f[E] = u, mi(f); let p = null; try {
        let h = ld(E, f, 2, "#host", () => c.directiveRegistry, !0, 0);
        Rm(l, u, h), Re(u, f), Ws(c, f, h), wu(c, h, f), ud(c, h), o !== void 0 && FS(h, this.ngContentSelectors, o), p = pe(h.index, f), f[H] = p[H], Ks(c, f, null);
    }
    catch (h) {
        throw p !== null && sl(p), sl(f), h;
    }
    finally {
        x(R.DynamicComponentEnd), yi();
    } return new as(this.componentType, f, !!d); }
};
function PS(e, t, n, o) { let r = e ? ["ng-version", "21.2.20"] : dw(t.selectors[0]), i = null, s = null, a = 0; if (n)
    for (let u of n)
        a += u[it].requiredVars, u.create && (u.targetIdx = 0, (i ??= []).push(u)), u.update && (u.targetIdx = 0, (s ??= []).push(u)); if (o)
    for (let u = 0; u < o.length; u++) {
        let d = o[u];
        if (typeof d != "function")
            for (let f of d.bindings) {
                a += f[it].requiredVars;
                let p = u + 1;
                f.create && (f.targetIdx = p, (i ??= []).push(f)), f.update && (f.targetIdx = p, (s ??= []).push(f));
            }
    } let c = [t]; if (o)
    for (let u of o) {
        let d = typeof u == "function" ? u : u.type, f = Ne(d);
        c.push(f);
    } return Hu(0, null, LS(i, s), 1, a, c, null, null, null, [r], null); }
function LS(e, t) { return !e && !t ? null : n => { if (n & 1 && e)
    for (let o of e)
        o.create(); if (n & 2 && t)
    for (let o of t)
        o.update(); }; }
function vh(e) { let t = e[it].kind; return t === "input" || t === "twoWay"; }
var as = class extends Zy {
    _rootLView;
    _hasInputBindings;
    instance;
    hostView;
    changeDetectorRef;
    componentType;
    location;
    previousInputValues = null;
    _tNode;
    constructor(t, n, o) { super(), this._rootLView = n, this._hasInputBindings = o, this._tNode = Ut(n[m], E), this.location = Kn(this._tNode, n), this.instance = pe(this._tNode.index, n)[H], this.hostView = this.changeDetectorRef = new Rt(n, void 0), this.componentType = t; }
    setInput(t, n) { this._hasInputBindings; let o = this._tNode; if (this.previousInputValues ??= new Map, this.previousInputValues.has(t) && Object.is(this.previousInputValues.get(t), n))
        return; let r = this._rootLView, i = Zs(o, r[m], r, t, n); this.previousInputValues.set(t, n); let s = pe(o.index, r); Rr(s, 1); }
    get injector() { return new St(this._tNode, this._rootLView); }
    destroy() { this.hostView.destroy(); }
    onDestroy(t) { this.hostView.onDestroy(t); }
};
function FS(e, t, n) { let o = e.projection = []; for (let r = 0; r < t.length; r++) {
    let i = n[r];
    o.push(i != null && i.length ? Array.from(i) : null);
} }
var ca = (() => { class e {
    static __NG_ELEMENT_ID__ = HS;
} return e; })();
function HS() { let e = M(); return pv(e, g()); }
var Ll = class e extends ca {
    _lContainer;
    _hostTNode;
    _hostLView;
    constructor(t, n, o) { super(), this._lContainer = t, this._hostTNode = n, this._hostLView = o; }
    get element() { return Kn(this._hostTNode, this._hostLView); }
    get injector() { return new St(this._hostTNode, this._hostLView); }
    get parentInjector() { let t = au(this._hostTNode, this._hostLView); if (hg(t)) {
        let n = Gi(t, this._hostLView), o = zi(t), r = n[m].data[o + 8];
        return new St(r, n);
    }
    else
        return new St(null, this._hostLView); }
    clear() { for (; this.length > 0;)
        this.remove(this.length - 1); }
    get(t) { let n = Eh(this._lContainer); return n !== null && n[t] || null; }
    get length() { return this._lContainer.length - V; }
    createEmbeddedView(t, n, o) { let r, i; typeof o == "number" ? r = o : o != null && (r = o.index, i = o.injector); let s = sr(this._lContainer, t.ssrId), a = t.createEmbeddedViewImpl(n || {}, i, s); return this.insertImpl(a, r, rn(this._hostTNode, s)), a; }
    createComponent(t, n, o, r, i, s, a) { let c = t && !Ho(t), l; if (c)
        l = n;
    else {
        let v = n || {};
        l = v.index, o = v.injector, r = v.projectableNodes, i = v.environmentInjector || v.ngModuleRef, s = v.directives, a = v.bindings;
    } let u = c ? t : new Ot(W(t)), d = o || this.parentInjector; if (!i && u.ngModule == null) {
        let D = (c ? d : this.parentInjector).get(It, null);
        D && (i = D);
    } let f = W(u.componentType ?? {}), p = sr(this._lContainer, f?.id ?? null), h = p?.firstChild ?? null, y = u.create(d, r, h, i, s, a); return this.insertImpl(y.hostView, l, rn(this._hostTNode, p)), y; }
    insert(t, n) { return this.insertImpl(t, n, !0); }
    insertImpl(t, n, o) { let r = t._lView; if (yp(r)) {
        let a = this.indexOf(t);
        if (a !== -1)
            this.detach(a);
        else {
            let c = r[q], l = new e(c, c[ue], c[q]);
            l.detach(l.indexOf(t));
        }
    } let i = this._adjustIndex(n), s = this._lContainer; return co(s, r, i, o), t.attachToViewContainerRef(), qa(zc(s), i, t), t; }
    move(t, n) { return this.insert(t, n); }
    indexOf(t) { let n = Eh(this._lContainer); return n !== null ? n.indexOf(t) : -1; }
    remove(t) { let n = this._adjustIndex(t, -1), o = or(this._lContainer, n); o && (Co(zc(this._lContainer), n), Ar(o[m], o)); }
    detach(t) { let n = this._adjustIndex(t, -1), o = or(this._lContainer, n); return o && Co(zc(this._lContainer), n) != null ? new Rt(o) : null; }
    _adjustIndex(t, n = 0) { return t ?? this.length + n; }
};
function Eh(e) { return e[So]; }
function zc(e) { return e[So] || (e[So] = []); }
function pv(e, t) { let n, o = t[e.index]; return ee(o) ? n = o : (n = Cy(o, t, null, e), t[e.index] = n, ju(t, n)), hv(n, t, e, o), new Ll(n, e, t); }
function VS(e, t) { let n = e[T], o = n.createComment(""), r = te(t, e), i = n.parentNode(r); return tn(n, i, o, n.nextSibling(r), !1), o; }
var hv = mv, pd = () => !1;
function gv(e, t, n) { return pd(e, t, n); }
function mv(e, t, n, o) { if (e[He])
    return; let r; n.type & 8 ? r = k(o) : r = VS(t, n), e[He] = r; }
function jS(e, t, n) { if (e[He] && e[Ce])
    return !0; let o = n[se], r = t.index - E; if (!o || Jn(t) || Rs(o, r))
    return !1; let s = dl(o, r), a = o.data[eo]?.[r]; if (a === void 0)
    return !1; let [c, l] = tS(s, a); return e[He] = c, e[Ce] = l, !0; }
function BS(e, t, n, o) { pd(e, n, t) || mv(e, t, n, o); }
function yv() { hv = BS, pd = jS; }
var Fl = class e {
    queryList;
    matches = null;
    constructor(t) { this.queryList = t; }
    clone() { return new e(this.queryList); }
    setDirty() { this.queryList.setDirty(); }
}, Hl = class e {
    queries;
    constructor(t = []) { this.queries = t; }
    createEmbeddedView(t) { let n = t.queries; if (n !== null) {
        let o = t.contentQueries !== null ? t.contentQueries[0] : n.length, r = [];
        for (let i = 0; i < o; i++) {
            let s = n.getByIndex(i), a = this.queries[s.indexInDeclarationView];
            r.push(a.clone());
        }
        return new e(r);
    } return null; }
    insertView(t) { this.dirtyQueriesWithMatches(t); }
    detachView(t) { this.dirtyQueriesWithMatches(t); }
    finishViewCreation(t) { this.dirtyQueriesWithMatches(t); }
    dirtyQueriesWithMatches(t) { for (let n = 0; n < this.queries.length; n++)
        gd(t, n).matches !== null && this.queries[n].setDirty(); }
}, cs = class {
    flags;
    read;
    predicate;
    constructor(t, n, o = null) { this.flags = n, this.read = o, typeof t == "string" ? this.predicate = WS(t) : this.predicate = t; }
}, Vl = class e {
    queries;
    constructor(t = []) { this.queries = t; }
    elementStart(t, n) { for (let o = 0; o < this.queries.length; o++)
        this.queries[o].elementStart(t, n); }
    elementEnd(t) { for (let n = 0; n < this.queries.length; n++)
        this.queries[n].elementEnd(t); }
    embeddedTView(t) { let n = null; for (let o = 0; o < this.length; o++) {
        let r = n !== null ? n.length : 0, i = this.getByIndex(o).embeddedTView(t, r);
        i && (i.indexInDeclarationView = o, n !== null ? n.push(i) : n = [i]);
    } return n !== null ? new e(n) : null; }
    template(t, n) { for (let o = 0; o < this.queries.length; o++)
        this.queries[o].template(t, n); }
    getByIndex(t) { return this.queries[t]; }
    get length() { return this.queries.length; }
    track(t) { this.queries.push(t); }
}, jl = class e {
    metadata;
    matches = null;
    indexInDeclarationView = -1;
    crossesNgTemplate = !1;
    _declarationNodeIndex;
    _appliesToNextNode = !0;
    constructor(t, n = -1) { this.metadata = t, this._declarationNodeIndex = n; }
    elementStart(t, n) { this.isApplyingToNode(n) && this.matchTNode(t, n); }
    elementEnd(t) { this._declarationNodeIndex === t.index && (this._appliesToNextNode = !1); }
    template(t, n) { this.elementStart(t, n); }
    embeddedTView(t, n) { return this.isApplyingToNode(t) ? (this.crossesNgTemplate = !0, this.addMatch(-t.index, n), new e(this.metadata)) : null; }
    isApplyingToNode(t) { if (this._appliesToNextNode && (this.metadata.flags & 1) !== 1) {
        let n = this._declarationNodeIndex, o = t.parent;
        for (; o !== null && o.type & 8 && o.index !== n;)
            o = o.parent;
        return n === (o !== null ? o.index : -1);
    } return this._appliesToNextNode; }
    matchTNode(t, n) { let o = this.metadata.predicate; if (Array.isArray(o))
        for (let r = 0; r < o.length; r++) {
            let i = o[r];
            this.matchTNodeWithReadOption(t, n, US(n, i)), this.matchTNodeWithReadOption(t, n, xi(n, t, i, !1, !1));
        }
    else
        o === rr ? n.type & 4 && this.matchTNodeWithReadOption(t, n, -1) : this.matchTNodeWithReadOption(t, n, xi(n, t, o, !1, !1)); }
    matchTNodeWithReadOption(t, n, o) { if (o !== null) {
        let r = this.metadata.read;
        if (r !== null)
            if (r === vr || r === ca || r === rr && n.type & 4)
                this.addMatch(n.index, -2);
            else {
                let i = xi(n, t, r, !1, !1);
                i !== null && this.addMatch(n.index, i);
            }
        else
            this.addMatch(n.index, o);
    } }
    addMatch(t, n) { this.matches === null ? this.matches = [t, n] : this.matches.push(t, n); }
};
function US(e, t) { let n = e.localNames; if (n !== null) {
    for (let o = 0; o < n.length; o += 2)
        if (n[o] === t)
            return n[o + 1];
} return null; }
function $S(e, t) { return e.type & 11 ? Kn(e, t) : e.type & 4 ? Xs(e, t) : null; }
function zS(e, t, n, o) { return n === -1 ? $S(t, e) : n === -2 ? GS(e, t, o) : Ko(e, e[m], n, t); }
function GS(e, t, n) { if (n === vr)
    return Kn(t, e); if (n === rr)
    return Xs(t, e); if (n === ca)
    return pv(t, e); }
function vv(e, t, n, o) { let r = t[ze].queries[o]; if (r.matches === null) {
    let i = e.data, s = n.matches, a = [];
    for (let c = 0; s !== null && c < s.length; c += 2) {
        let l = s[c];
        if (l < 0)
            a.push(null);
        else {
            let u = i[l];
            a.push(zS(t, u, s[c + 1], n.metadata.read));
        }
    }
    r.matches = a;
} return r.matches; }
function Bl(e, t, n, o) { let r = e.queries.getByIndex(n), i = r.matches; if (i !== null) {
    let s = vv(e, t, r, n);
    for (let a = 0; a < i.length; a += 2) {
        let c = i[a];
        if (c > 0)
            o.push(s[a / 2]);
        else {
            let l = i[a + 1], u = t[-c];
            for (let d = V; d < u.length; d++) {
                let f = u[d];
                f[Ct] === f[q] && Bl(f[m], f, l, o);
            }
            if (u[jt] !== null) {
                let d = u[jt];
                for (let f = 0; f < d.length; f++) {
                    let p = d[f];
                    Bl(p[m], p, l, o);
                }
            }
        }
    }
} return o; }
function hd(e, t) { return e[ze].queries[t].queryList; }
function Ev(e, t, n) { let o = new Qi((n & 4) === 4); return Dp(e, t, o, o.destroy), (t[ze] ??= new Hl).queries.push(new Fl(o)) - 1; }
function Iv(e, t, n) { let o = w(); return o.firstCreatePass && (Cv(o, new cs(e, t, n), -1), (t & 2) === 2 && (o.staticViewQueries = !0)), Ev(o, g(), t); }
function Dv(e, t, n, o) { let r = w(); if (r.firstCreatePass) {
    let i = M();
    Cv(r, new cs(t, n, o), i.index), qS(r, e), (n & 2) === 2 && (r.staticContentQueries = !0);
} return Ev(r, g(), n); }
function WS(e) { return e.split(",").map(t => t.trim()); }
function Cv(e, t, n) { e.queries === null && (e.queries = new Vl), e.queries.track(new jl(t, n)); }
function qS(e, t) { let n = e.contentQueries || (e.contentQueries = []), o = n.length ? n[n.length - 1] : -1; t !== o && n.push(e.queries.length - 1, t); }
function gd(e, t) { return e.queries.getByIndex(t); }
function Tv(e, t) { let n = e[m], o = gd(n, t); return o.crossesNgTemplate ? Bl(n, e, t, []) : vv(n, e, o, t); }
function md(e, t, n) { let o, r = Jf(() => { o._dirtyCounter(); let i = QS(o, e); if (t && i === void 0)
    throw new _(-951, !1); return i; }); return o = r[tt], o._dirtyCounter = bc(0), o._flatValue = void 0, r; }
function yd(e) { return md(!0, !1, e); }
function vd(e) { return md(!0, !0, e); }
function Ed(e) { return md(!1, !1, e); }
function Mv(e, t) { let n = e[tt]; n._lView = g(), n._queryIndex = t, n._queryList = hd(n._lView, t), n._queryList.onDirty(() => n._dirtyCounter.update(o => o + 1)); }
function QS(e, t) { let n = e._lView, o = e._queryIndex; if (n === void 0 || o === void 0 || n[A] & 4)
    return t ? void 0 : F; let r = hd(n, o), i = Tv(n, o); return r.reset(i, wg), t ? r.first : r._changesDetected || e._flatValue === void 0 ? e._flatValue = r.toArray() : e._flatValue; }
var an = new Map, lr = new Set;
function Nv(e) { return mt(this, null, function* () { let t = an; an = new Map; let n = new Map; function o(i) { let s = n.get(i); if (s)
    return s; let a = e(i).then(c => XS(i, c)); return n.set(i, a), a; } let r = Array.from(t).map(a => mt(null, [a], function* ([i, s]) { if (s.styleUrl && s.styleUrls?.length)
    throw new Error("@Component cannot define both `styleUrl` and `styleUrls`. Use `styleUrl` if the component has one stylesheet, or `styleUrls` if it has multiple"); let c = []; s.templateUrl && c.push(o(s.templateUrl).then(f => { s.template = f; })); let l = typeof s.styles == "string" ? [s.styles] : s.styles ?? []; s.styles = l; let { styleUrl: u, styleUrls: d } = s; if (u && (d = [u], s.styleUrl = void 0), d?.length) {
    let f = Promise.all(d.map(p => o(p))).then(p => { l.push(...p), s.styleUrls = void 0; });
    c.push(f);
} yield Promise.all(c), lr.delete(i); })); yield Promise.all(r); }); }
function YS(e, t) { wv(t) && (an.set(e, t), lr.add(e)); }
function ZS(e) { return lr.has(e); }
function wv(e) { return !!(e.templateUrl && !e.hasOwnProperty("template") || e.styleUrls?.length || e.styleUrl); }
function KS() { let e = an; return an = new Map, e; }
function JS(e) { lr.clear(); for (let t of e.keys())
    lr.add(t); an = e; }
function _v() { return an.size === 0; }
function XS(e, t) { return mt(this, null, function* () { if (typeof t == "string")
    return t; if (t.status !== void 0 && t.status !== 200)
    throw new _(918, !1); return t.text(); }); }
var Ul = new Map, Sv = !0;
function eb(e, t, n) { if (t && t !== n && Sv)
    throw new _(921, !1); }
function Id(e, t) { let n = Ul.get(t) || null; eb(t, n, e), Ul.set(t, e); }
function Dd(e) { return Ul.get(e); }
function tb(e) { Sv = !e; }
var zn = class {
}, bv = class {
};
function Av(e, t) { return new Gn(e, t ?? null, []); }
var nb = Av, Gn = class extends zn {
    ngModuleType;
    _parent;
    _bootstrapComponents = [];
    _r3Injector;
    instance;
    destroyCbs = [];
    componentFactoryResolver = new ss(this);
    constructor(t, n, o, r = !0) { super(), this.ngModuleType = t, this._parent = n; let i = vn(t); this._bootstrapComponents = An(i.bootstrap), this._r3Injector = Ap(t, n, [{ provide: zn, useValue: this }, { provide: kr, useValue: this.componentFactoryResolver }, ...o], Yr(t), new Set(["environment"])), r && this.resolveInjectorInitializers(); }
    resolveInjectorInitializers() { this._r3Injector.resolveInjectorInitializers(), this.instance = this._r3Injector.get(this.ngModuleType); }
    get injector() { return this._r3Injector; }
    destroy() { let t = this._r3Injector; !t.destroyed && t.destroy(), this.destroyCbs.forEach(n => n()), this.destroyCbs = null; }
    onDestroy(t) { this.destroyCbs.push(t); }
}, Wn = class extends bv {
    moduleType;
    constructor(t) { super(), this.moduleType = t; }
    create(t) { return new Gn(this.moduleType, t, []); }
};
function Rv(e, t, n) { return new Gn(e, t, n, !1); }
var ur = class extends zn {
    injector;
    componentFactoryResolver = new ss(this);
    instance = null;
    constructor(t) { super(); let n = new Za([...t.providers, { provide: zn, useValue: this }, { provide: kr, useValue: this.componentFactoryResolver }], t.parent || si(), t.debugName, new Set(["environment"])); this.injector = n, t.runEnvironmentInitializers && n.resolveInjectorInitializers(); }
    destroy() { this.injector.destroy(); }
    onDestroy(t) { this.injector.onDestroy(t); }
};
function Cd(e, t, n = null) { return new ur({ providers: e, parent: t, debugName: n, runEnvironmentInitializers: !0 }).injector; }
var ob = (() => { class e {
    _injector;
    cachedInjectors = new Map;
    constructor(n) { this._injector = n; }
    getOrCreateStandaloneInjector(n) { if (!n.standalone)
        return null; if (!this.cachedInjectors.has(n)) {
        let o = Ya(!1, n.type), r = o.length > 0 ? Cd([o], this._injector, "") : null;
        this.cachedInjectors.set(n, r);
    } return this.cachedInjectors.get(n); }
    ngOnDestroy() { try {
        for (let n of this.cachedInjectors.values())
            n !== null && n.destroy();
    }
    finally {
        this.cachedInjectors.clear();
    } }
    static \u0275prov = B({ token: e, providedIn: "environment", factory: () => new e(Le(It)) });
} return e; })();
function Ov(e) { return Je(() => { let t = Lv(e), n = et(Z({}, t), { decls: e.decls, vars: e.vars, template: e.template, consts: e.consts || null, ngContentSelectors: e.ngContentSelectors, onPush: e.changeDetection === Is.OnPush, directiveDefs: null, pipeDefs: null, dependencies: t.standalone && e.dependencies || null, getStandaloneInjector: t.standalone ? r => r.get(ob).getOrCreateStandaloneInjector(n) : null, getExternalStyles: null, signals: e.signals ?? !1, data: e.data || {}, encapsulation: e.encapsulation || Oe.Emulated, styles: e.styles || F, _: null, schemas: e.schemas || null, tView: null, id: "" }); t.standalone && Q("NgStandalone"), Fv(n); let o = e.dependencies; return n.directiveDefs = ls(o, kv), n.pipeDefs = ls(o, Ue), n.id = ab(n), n; }); }
function kv(e) { return W(e) || Ne(e); }
function Td(e) { return Je(() => ({ type: e.type, bootstrap: e.bootstrap || F, declarations: e.declarations || F, imports: e.imports || F, exports: e.exports || F, transitiveCompileScopes: null, schemas: e.schemas || null, id: e.id || null })); }
function rb(e, t) { if (e == null)
    return _e; let n = {}; for (let o in e)
    if (e.hasOwnProperty(o)) {
        let r = e[o], i, s, a, c;
        Array.isArray(r) ? (a = r[0], i = r[1], s = r[2] ?? i, c = r[3] || null) : (i = r, s = r, a = Fs.None, c = null), n[i] = [o, a, c], t[i] = s;
    } return n; }
function ib(e) { if (e == null)
    return _e; let t = {}; for (let n in e)
    e.hasOwnProperty(n) && (t[e[n]] = n); return t; }
function xv(e) { return Je(() => { let t = Lv(e); return Fv(t), t; }); }
function Pv(e) { return { type: e.type, name: e.name, factory: null, pure: e.pure !== !1, standalone: e.standalone ?? !0, onDestroy: e.type.prototype.ngOnDestroy || null }; }
function Lv(e) { let t = {}; return { type: e.type, providersResolver: null, viewProvidersResolver: null, factory: null, hostBindings: e.hostBindings || null, hostVars: e.hostVars || 0, hostAttrs: e.hostAttrs || null, contentQueries: e.contentQueries || null, declaredInputs: t, inputConfig: e.inputs || _e, exportAs: e.exportAs || null, standalone: e.standalone ?? !0, signals: e.signals === !0, selectors: e.selectors || F, viewQuery: e.viewQuery || null, features: e.features || null, setInput: null, resolveHostDirectives: null, hostDirectives: null, controlDef: null, inputs: rb(e.inputs, t), outputs: ib(e.outputs), debugInfo: null }; }
function Fv(e) { e.features?.forEach(t => t(e)); }
function ls(e, t) { return e ? () => { let n = typeof e == "function" ? e() : e, o = []; for (let r of n) {
    let i = t(r);
    i !== null && o.push(i);
} return o; } : null; }
var sb = new Map;
function ab(e) { let t = 0, n = typeof e.consts == "function" ? "" : e.consts, o = [e.selectors, e.ngContentSelectors, e.hostVars, e.hostAttrs, n, e.vars, e.decls, e.encapsulation, e.standalone, e.signals, e.exportAs, JSON.stringify(e.inputs), JSON.stringify(e.outputs), Object.getOwnPropertyNames(e.type.prototype), !!e.contentQueries, !!e.viewQuery]; for (let i of o.join("|"))
    t = Math.imul(31, t) + i.charCodeAt(0) << 0; return t += 2147483648, "c" + t; }
function Hv(e) { return t => { t.controlDef = { create: (n, o) => { n?.\u0275ngControlCreate(o); }, update: (n, o) => { n?.\u0275ngControlUpdate?.(o); }, passThroughInput: e }; }; }
function Vv(e) { let t = n => { let o = Array.isArray(e); n.hostDirectives === null ? (n.resolveHostDirectives = cb, n.hostDirectives = o ? e.map($l) : [e]) : o ? n.hostDirectives.unshift(...e.map($l)) : n.hostDirectives.unshift(e); }; return t.ngInherit = !0, t; }
function cb(e) { let t = [], n = !1, o = null, r = null; for (let i = 0; i < e.length; i++) {
    let s = e[i];
    if (s.hostDirectives !== null) {
        let a = t.length;
        o ??= new Map, r ??= new Map, jv(s, t, o), r.set(s, [a, t.length - 1]);
    }
    i === 0 && Ae(s) && (n = !0, t.push(s));
} for (let i = n ? 1 : 0; i < e.length; i++)
    t.push(e[i]); return [t, o, r]; }
function jv(e, t, n) { if (e.hostDirectives !== null)
    for (let o of e.hostDirectives)
        if (typeof o == "function") {
            let r = o();
            for (let i of r)
                Ih($l(i), t, n);
        }
        else
            Ih(o, t, n); }
function Ih(e, t, n) { let o = Ne(e.directive); lb(o.declaredInputs, e.inputs), jv(o, t, n), n.set(o, e), t.push(o); }
function $l(e) { return typeof e == "function" ? { directive: G(e), inputs: _e, outputs: _e } : { directive: G(e.directive), inputs: Dh(e.inputs), outputs: Dh(e.outputs) }; }
function Dh(e) { if (e === void 0 || e.length === 0)
    return _e; let t = {}; for (let n = 0; n < e.length; n += 2)
    t[e[n]] = e[n + 1]; return t; }
function lb(e, t) { for (let n in t)
    if (t.hasOwnProperty(n)) {
        let o = t[n], r = e[n];
        e[o] = r;
    } }
function ub(e) { return Object.getPrototypeOf(e.prototype).constructor; }
function Md(e) { let t = ub(e.type), n = !0, o = [e]; for (; t && t !== Function.prototype && t !== Object.prototype;) {
    let r, i = Object.hasOwn(t, yt) ? t[yt] : void 0, s = Object.hasOwn(t, yn) ? t[yn] : void 0;
    if (Ae(e))
        r = i ?? s;
    else {
        if (i)
            throw new _(903, !1);
        r = s;
    }
    if (r) {
        if (n) {
            o.push(r);
            let c = e;
            c.inputs = Gc(e.inputs), c.declaredInputs = Gc(e.declaredInputs), c.outputs = Gc(e.outputs);
            let l = r.hostBindings;
            l && gb(e, l);
            let u = r.viewQuery, d = r.contentQueries;
            if (u && pb(e, u), d && hb(e, d), db(e, r), tp(e.outputs, r.outputs), Ae(r) && r.data.animation) {
                let f = e.data;
                f.animation = (f.animation || []).concat(r.data.animation);
            }
        }
        let a = r.features;
        if (a)
            for (let c = 0; c < a.length; c++) {
                let l = a[c];
                l && l.ngInherit && l(e), l === Md && (n = !1);
            }
    }
    t = Object.getPrototypeOf(t);
} fb(o); }
function db(e, t) { for (let n in t.inputs) {
    if (!t.inputs.hasOwnProperty(n) || e.inputs.hasOwnProperty(n))
        continue;
    let o = t.inputs[n];
    o !== void 0 && (e.inputs[n] = o, e.declaredInputs[n] = t.declaredInputs[n]);
} }
function fb(e) { let t = 0, n = null; for (let o = e.length - 1; o >= 0; o--) {
    let r = e[o];
    r.hostVars = t += r.hostVars, r.hostAttrs = Vn(r.hostAttrs, n = Vn(n, r.hostAttrs));
} }
function Gc(e) { return e === _e ? {} : e === F ? [] : e; }
function pb(e, t) { let n = e.viewQuery; n ? e.viewQuery = (o, r) => { t(o, r), n(o, r); } : e.viewQuery = t; }
function hb(e, t) { let n = e.contentQueries; n ? e.contentQueries = (o, r, i) => { t(o, r, i), n(o, r, i); } : e.contentQueries = t; }
function gb(e, t) { let n = e.hostBindings; n ? e.hostBindings = (o, r) => { t(o, r), n(o, r); } : e.hostBindings = t; }
function Bv(e, t, n, o, r, i, s, a) { if (n.firstCreatePass) {
    e.mergedAttrs = Vn(e.mergedAttrs, e.attrs);
    let u = e.tView = Hu(2, e, r, i, s, n.directiveRegistry, n.pipeRegistry, null, n.schemas, n.consts, null);
    n.queries !== null && (n.queries.template(n, e), u.queries = n.queries.embeddedTView(e));
} a && (e.flags |= a), qe(e, !1); let c = Uv(n, t, e, o); xo() && Ku(n, t, c, e), Re(c, t); let l = Cy(c, t, c, e); t[o + E] = l, ju(t, l), gv(l, e, t); }
function mb(e, t, n, o, r, i, s, a, c, l, u) { let d = n + E, f; return t.firstCreatePass ? (f = gn(t, d, 4, s || null, a || null), pi() && Xy(t, e, f, de(t.consts, l), td), ug(t, f)) : f = t.data[d], Bv(f, e, t, n, o, r, i, c), Dn(f) && Ws(t, e, f), l != null && so(e, f, u), f; }
function cn(e, t, n, o, r, i, s, a, c, l, u) { let d = n + E, f; if (t.firstCreatePass) {
    if (f = gn(t, d, 4, s || null, a || null), l != null) {
        let p = de(t.consts, l);
        f.localNames = [];
        for (let h = 0; h < p.length; h += 2)
            f.localNames.push(p[h], -1);
    }
}
else
    f = t.data[d]; return Bv(f, e, t, n, o, r, i, c), l != null && so(e, f, u), f; }
function Nd(e, t, n, o, r, i, s, a) { let c = g(), l = w(), u = de(l.consts, i); return mb(c, l, e, t, n, o, r, u, void 0, s, a), Nd; }
function wd(e, t, n, o, r, i, s, a) { let c = g(), l = w(), u = de(l.consts, i); return cn(c, l, e, t, n, o, r, u, void 0, s, a), wd; }
var Uv = $v;
function $v(e, t, n, o) { return Ve(!0), t[T].createComment(""); }
function yb(e, t, n, o) { let r = !Os(t, n); Ve(r); let i = t[se]?.data[Ts]?.[o] ?? null; if (i !== null && n.tView !== null && n.tView.ssrId === null && (n.tView.ssrId = i), r)
    return $v(e, t); let s = t[se], a = Or(s, e, t, n); As(s, o, a); let c = Mu(s, o); return ta(c, a); }
function zv() { Uv = yb; }
var ne = (function (e) { return e[e.NOT_STARTED = 0] = "NOT_STARTED", e[e.IN_PROGRESS = 1] = "IN_PROGRESS", e[e.COMPLETE = 2] = "COMPLETE", e[e.FAILED = 3] = "FAILED", e; })(ne || {}), Ch = 0, vb = 1, $ = (function (e) { return e[e.Placeholder = 0] = "Placeholder", e[e.Loading = 1] = "Loading", e[e.Complete = 2] = "Complete", e[e.Error = 3] = "Error", e; })($ || {}), dr = (function (e) { return e[e.Initial = -1] = "Initial", e; })(dr || {}), Ln = 0, pt = 1, jo = 2, bi = 3, Eb = 4, Ib = 5, la = 6, Db = 7, Fn = 8, Cb = 9, _d = (function (e) { return e[e.Manual = 0] = "Manual", e[e.Playthrough = 1] = "Playthrough", e; })(_d || {});
function xr(e, t, n) { let o = Wv(e); t[o] === null && (t[o] = []), t[o].push(n); }
function Hi(e, t) { let n = Wv(e), o = t[n]; if (o !== null) {
    for (let r of o)
        r();
    t[n] = null;
} }
function Gv(e) { Hi(1, e), Hi(0, e), Hi(2, e); }
function Wv(e) { let t = Eb; return e === 1 ? t = Ib : e === 2 && (t = Cb), t; }
function Pr(e) { return e + 1; }
function ye(e, t) { let n = e[m], o = Pr(t.index); return e[o]; }
function Tb(e, t, n) { let o = e[m], r = Pr(t); e[r] = n; }
function ce(e, t) { let n = Pr(t.index); return e.data[n]; }
function Mb(e, t, n) { let o = Pr(t); e.data[o] = n; }
function Nb(e, t, n) { let o = t[m], r = ce(o, n); switch (e) {
    case $.Complete: return r.primaryTmplIndex;
    case $.Loading: return r.loadingTmplIndex;
    case $.Error: return r.errorTmplIndex;
    case $.Placeholder: return r.placeholderTmplIndex;
    default: return null;
} }
function zl(e, t) { return t === $.Placeholder ? e.placeholderBlockConfig?.[Ch] ?? null : t === $.Loading ? e.loadingBlockConfig?.[Ch] ?? null : null; }
function qv(e) { return e.loadingBlockConfig?.[vb] ?? null; }
function Th(e, t) { if (!e || e.length === 0)
    return t; let n = new Set(e); for (let o of t)
    n.add(o); return e.length === n.size ? e : Array.from(n); }
function wb(e, t) { let n = t.primaryTmplIndex + E; return Ut(e, n); }
function Qv(e) { return e !== null && typeof e == "object" && typeof e.primaryTmplIndex == "number"; }
function Yv(e, t) { let n = null, o = Pr(t.index); return E < o && o < e.bindingStartIndex && (n = ce(e, t)), !!n && Qv(n); }
function Sd(e, t, n, o) { let r = n.get(U); return YM(e, () => r.run(t), i => r.runOutsideAngular(() => QM(i)), o); }
function _b(e, t, n) { return n == null ? e : n >= 0 ? vp(n, e) : e[t.index][V] ?? null; }
function Sb(e, t) { return Bt(E + t, e); }
function po(e, t, n, o, r, i, s, a) { let c = e[O], l = c.get(U), u; function d() { if (Tt(e)) {
    u.destroy();
    return;
} let f = ye(e, t), p = f[pt]; if (p !== dr.Initial && p !== $.Placeholder) {
    u.destroy();
    return;
} let h = _b(e, t, o); if (!h || (u.destroy(), Tt(h)))
    return; let y = Sb(h, n), v = r(y, () => { l.run(() => { e !== h && rc(h, v), i(); }); }, c, a); e !== h && fi(h, v), xr(s, f, v); } u = Zm({ read: d }, { injector: c }); }
function ua(e, t) { let n = t.get(Rb), o = () => n.remove(e); return n.add(e), o; }
var bb = () => typeof requestIdleCallback < "u" ? requestIdleCallback : setTimeout, Ab = () => typeof requestIdleCallback < "u" ? cancelIdleCallback : clearTimeout, Rb = (() => { class e {
    executingCallbacks = !1;
    idleId = null;
    current = new Set;
    deferred = new Set;
    ngZone = I(U);
    requestIdleCallbackFn = bb().bind(globalThis);
    cancelIdleCallbackFn = Ab().bind(globalThis);
    add(n) { (this.executingCallbacks ? this.deferred : this.current).add(n), this.idleId === null && this.scheduleIdleCallback(); }
    remove(n) { let { current: o, deferred: r } = this; o.delete(n), r.delete(n), o.size === 0 && r.size === 0 && this.cancelIdleCallback(); }
    scheduleIdleCallback() { let n = () => { this.cancelIdleCallback(), this.executingCallbacks = !0; for (let o of this.current)
        o(); if (this.current.clear(), this.executingCallbacks = !1, this.deferred.size > 0) {
        for (let o of this.deferred)
            this.current.add(o);
        this.deferred.clear(), this.scheduleIdleCallback();
    } }; this.idleId = this.requestIdleCallbackFn(() => this.ngZone.run(n)); }
    cancelIdleCallback() { this.idleId !== null && (this.cancelIdleCallbackFn(this.idleId), this.idleId = null); }
    ngOnDestroy() { this.cancelIdleCallback(), this.current.clear(), this.deferred.clear(); }
    static \u0275prov = B({ token: e, providedIn: "root", factory: () => new e });
} return e; })();
function da(e) { return (t, n) => Zv(e, t, n); }
function Zv(e, t, n) { let o = n.get(Kv), r = n.get(U), i = () => o.remove(t); return o.add(e, t, r), i; }
var Kv = (() => { class e {
    executingCallbacks = !1;
    timeoutId = null;
    invokeTimerAt = null;
    current = [];
    deferred = [];
    add(n, o, r) { let i = this.executingCallbacks ? this.deferred : this.current; this.addToQueue(i, Date.now() + n, o), this.scheduleTimer(r); }
    remove(n) { let { current: o, deferred: r } = this; this.removeFromQueue(o, n) === -1 && this.removeFromQueue(r, n), o.length === 0 && r.length === 0 && this.clearTimeout(); }
    addToQueue(n, o, r) { let i = n.length; for (let s = 0; s < n.length; s += 2)
        if (n[s] > o) {
            i = s;
            break;
        } sp(n, i, o, r); }
    removeFromQueue(n, o) { let r = -1; for (let i = 0; i < n.length; i += 2)
        if (n[i + 1] === o) {
            r = i;
            break;
        } return r > -1 && Qa(n, r, 2), r; }
    scheduleTimer(n) { let o = () => { this.clearTimeout(), this.executingCallbacks = !0; let i = [...this.current], s = Date.now(); for (let c = 0; c < i.length; c += 2) {
        let l = i[c], u = i[c + 1];
        if (l <= s)
            u();
        else
            break;
    } let a = -1; for (let c = 0; c < this.current.length && this.current[c] <= s; c += 2)
        a = c + 1; if (a >= 0 && Qa(this.current, 0, a + 1), this.executingCallbacks = !1, this.deferred.length > 0) {
        for (let c = 0; c < this.deferred.length; c += 2) {
            let l = this.deferred[c], u = this.deferred[c + 1];
            this.addToQueue(this.current, l, u);
        }
        this.deferred.length = 0;
    } this.scheduleTimer(n); }; if (this.current.length > 0) {
        let i = Date.now(), s = this.current[0];
        if (this.timeoutId === null || this.invokeTimerAt && this.invokeTimerAt - s > 16) {
            this.clearTimeout();
            let a = Math.max(s - i, 16);
            this.invokeTimerAt = s, this.timeoutId = n.runOutsideAngular(() => setTimeout(() => n.run(o), a));
        }
    } }
    clearTimeout() { this.timeoutId !== null && (clearTimeout(this.timeoutId), this.timeoutId = null); }
    ngOnDestroy() { this.clearTimeout(), this.current.length = 0, this.deferred.length = 0; }
    static \u0275prov = B({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), Ob = (() => { class e {
    cachedInjectors = new Map;
    getOrCreateInjector(n, o, r, i) { if (!this.cachedInjectors.has(n)) {
        let s = r.length > 0 ? Cd(r, o, i) : null;
        this.cachedInjectors.set(n, s);
    } return this.cachedInjectors.get(n); }
    ngOnDestroy() { try {
        for (let n of this.cachedInjectors.values())
            n !== null && n.destroy();
    }
    finally {
        this.cachedInjectors.clear();
    } }
    static \u0275prov = B({ token: e, providedIn: "environment", factory: () => new e });
} return e; })(), kb = new S("DEFER_BLOCK_DEPENDENCY_INTERCEPTOR"), Jv = new S("");
function Wc(e, t, n) { return e.get(Ob).getOrCreateInjector(t, e, n, ""); }
function xb(e, t, n) { if (e instanceof Pn) {
    let r = e.injector, i = e.parentInjector, s = Wc(i, t, n);
    return new Pn(r, s);
} let o = e.get(It); if (o !== e) {
    let r = Wc(o, t, n);
    return new Pn(e, r);
} return Wc(e, t, n); }
function rt(e, t, n, o = !1) { let r = n[q], i = r[m]; if (Tt(r))
    return; let s = ye(r, t), a = s[pt], c = s[Db]; if (!(c !== null && e < c) && Nh(a, e) && Nh(s[Ln] ?? -1, e)) {
    let l = ce(i, t), d = !o && (typeof ngServerMode > "u" || !ngServerMode) && (qv(l) !== null || zl(l, $.Loading) !== null || zl(l, $.Placeholder)) ? Gl : Xv;
    try {
        d(e, s, n, t, r);
    }
    catch (f) {
        nd(r, f);
    }
} }
function Pb(e, t) { let n = e[Ce]?.findIndex(r => r.data[Cr] === t[pt]) ?? -1; return { dehydratedView: n > -1 ? e[Ce][n] : null, dehydratedViewIx: n }; }
function Xv(e, t, n, o, r) { x(R.DeferBlockStateStart); let i = Nb(e, r, o); if (i !== null) {
    t[pt] = e;
    let s = r[m], a = i + E, c = Ut(s, a), l = 0;
    od(n, l);
    let u;
    if (e === $.Complete) {
        let h = ce(s, o), y = h.providers;
        y && y.length > 0 && (u = xb(r[O], h, y));
    }
    let { dehydratedView: d, dehydratedViewIx: f } = Pb(n, t), p = ao(r, c, null, { injector: u, dehydratedView: d });
    if (co(n, p, l, rn(c, d)), Rr(p, 2), f > -1 && n[Ce]?.splice(f, 1), (e === $.Complete || e === $.Error) && Array.isArray(t[Fn])) {
        for (let h of t[Fn])
            h();
        t[Fn] = null;
    }
} x(R.DeferBlockStateEnd); }
function Lb(e, t, n, o, r) { let i = Date.now(), s = r[m], a = ce(s, o); if (t[jo] === null || t[jo] <= i) {
    t[jo] = null;
    let c = qv(a), l = t[bi] !== null;
    if (e === $.Loading && c !== null && !l) {
        t[Ln] = e;
        let u = Mh(c, t, o, n, r);
        t[bi] = u;
    }
    else {
        e > $.Loading && l && (t[bi](), t[bi] = null, t[Ln] = null), Xv(e, t, n, o, r);
        let u = zl(a, e);
        u !== null && (t[jo] = i + u, Mh(u, t, o, n, r));
    }
}
else
    t[Ln] = e; }
function Mh(e, t, n, o, r) { return Zv(e, () => { let s = t[Ln]; t[jo] = null, t[Ln] = null, s !== null && rt(s, n, o); }, r[O]); }
function Nh(e, t) { return e < t; }
function ho(e, t) { let n = e[t.index]; rt($.Placeholder, t, n); }
function wh(e, t, n) { e.loadingPromise.then(() => { e.loadingState === ne.COMPLETE ? rt($.Complete, t, n) : e.loadingState === ne.FAILED && rt($.Error, t, n); }); }
var Gl = null;
function eE(e, t, n, o) { let r = e.consts; n != null && (t.placeholderBlockConfig = de(r, n)), o != null && (t.loadingBlockConfig = de(r, o)), Gl === null && (Gl = Lb); }
var Vi = "__ngAsyncComponentMetadataFn__";
function Fb(e) { return e[Vi] ?? null; }
function tE(e, t, n) { let o = e; return o[Vi] = () => Promise.all(t()).then(r => (n(...r), o[Vi] = null, r)), o[Vi]; }
function bd(e, t, n, o) { return Je(() => { let r = e; t !== null && (r.hasOwnProperty("decorators") && r.decorators !== void 0 ? r.decorators.push(...t) : r.decorators = t), n !== null && (r.ctorParameters = n), o !== null && (r.hasOwnProperty("propDecorators") && r.propDecorators !== void 0 ? r.propDecorators = Z(Z({}, r.propDecorators), o) : r.propDecorators = o); }); }
var Hb = (() => { class e {
    log(n) { console.log(n); }
    warn(n) { console.warn(n); }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "platform" });
} return e; })();
function Ad(e) { return typeof e == "function" && e[tt] !== void 0; }
function Rd(e) { return Ad(e) && typeof e.set == "function"; }
function ji(e, t) { let n = e[m]; for (let o = E; o < n.bindingStartIndex; o++)
    if (ee(e[o])) {
        let r = e[o];
        if (!(o === n.bindingStartIndex - 1)) {
            let s = n.data[o], a = ce(n, s);
            if (Qv(a)) {
                t.push({ lContainer: r, lView: e, tNode: s, tDetails: a });
                continue;
            }
        }
        re(r[j]) && ji(r[j], t);
        for (let s = V; s < r.length; s++)
            ji(r[s], t);
    }
    else
        re(e[o]) && ji(e[o], t); }
function Vb() { return Q("Chrome DevTools profiling"), () => { }; }
function jb(e) { let t = e.get(zt), n = e.get(lt), o = Hg(t, n), r = {}; for (let [i, s] of Object.entries(o))
    XM(i) || (r[i] = s); return r; }
var _h = "ng";
function Bb(e, t) { Ub(e, t); }
function Ub(e, t) { if (typeof COMPILED > "u" || !COMPILED) {
    let n = De;
    n[_h] ??= {}, n[_h][e] = t;
} }
var nE = new S(""), oE = new S(""), $b = (() => { class e {
    _ngZone;
    registry;
    _isZoneStable = !0;
    _callbacks = [];
    _taskTrackingZone = null;
    _destroyRef;
    constructor(n, o, r) { this._ngZone = n, this.registry = o, up() && (this._destroyRef = I(Po, { optional: !0 }) ?? void 0), Od || (iE(r), r.addToWindow(o)), this._watchAngularEvents(), n.run(() => { this._taskTrackingZone = typeof Zone > "u" ? null : Zone.current.get("TaskTrackingZone"); }); }
    _watchAngularEvents() { let n = this._ngZone.onUnstable.subscribe({ next: () => { this._isZoneStable = !1; } }), o = this._ngZone.runOutsideAngular(() => this._ngZone.onStable.subscribe({ next: () => { U.assertNotInAngularZone(), queueMicrotask(() => { this._isZoneStable = !0, this._runCallbacksIfReady(); }); } })); this._destroyRef?.onDestroy(() => { n.unsubscribe(), o.unsubscribe(); }); }
    isStable() { return this._isZoneStable && !this._ngZone.hasPendingMacrotasks; }
    _runCallbacksIfReady() { if (this.isStable())
        queueMicrotask(() => { for (; this._callbacks.length !== 0;) {
            let n = this._callbacks.pop();
            clearTimeout(n.timeoutId), n.doneCb();
        } });
    else {
        let n = this.getPendingTasks();
        this._callbacks = this._callbacks.filter(o => o.updateCb && o.updateCb(n) ? (clearTimeout(o.timeoutId), !1) : !0);
    } }
    getPendingTasks() { return this._taskTrackingZone ? this._taskTrackingZone.macroTasks.map(n => ({ source: n.source, creationLocation: n.creationLocation, data: n.data })) : []; }
    addCallback(n, o, r) { let i = -1; o && o > 0 && (i = setTimeout(() => { this._callbacks = this._callbacks.filter(s => s.timeoutId !== i), n(); }, o)), this._callbacks.push({ doneCb: n, timeoutId: i, updateCb: r }); }
    whenStable(n, o, r) { if (r && !this._taskTrackingZone)
        throw new Error('Task tracking zone is required when passing an update callback to whenStable(). Is "zone.js/plugins/task-tracking" loaded?'); this.addCallback(n, o, r), this._runCallbacksIfReady(); }
    registerApplication(n) { this.registry.registerApplication(n, this); }
    unregisterApplication(n) { this.registry.unregisterApplication(n); }
    findProviders(n, o, r) { return []; }
    static \u0275fac = function (o) { return new (o || e)(Le(U), Le(rE), Le(oE)); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac });
} return e; })(), rE = (() => { class e {
    _applications = new Map;
    registerApplication(n, o) { this._applications.set(n, o); }
    unregisterApplication(n) { this._applications.delete(n); }
    unregisterAllApplications() { this._applications.clear(); }
    getTestability(n) { return this._applications.get(n) || null; }
    getAllTestabilities() { return Array.from(this._applications.values()); }
    getAllRootElements() { return Array.from(this._applications.keys()); }
    findTestabilityInTree(n, o = !0) { return Od?.findTestabilityInTree(this, n, o) ?? null; }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "platform" });
} return e; })();
function iE(e) { Od = e; }
var Od;
function kd(e) { return !!e && typeof e.then == "function"; }
function sE(e) { return !!e && typeof e.subscribe == "function"; }
var xd = new S("");
function aE(e) { return nt([{ provide: xd, multi: !0, useValue: e }]); }
var Pd = (() => { class e {
    resolve;
    reject;
    initialized = !1;
    done = !1;
    donePromise = new Promise((n, o) => { this.resolve = n, this.reject = o; });
    appInits = I(xd, { optional: !0 }) ?? [];
    injector = I(Te);
    constructor() { }
    runInitializers() { if (this.initialized)
        return; let n = []; for (let r of this.appInits) {
        let i = ai(this.injector, r);
        if (kd(i))
            n.push(i);
        else if (sE(i)) {
            let s = new Promise((a, c) => { i.subscribe({ complete: a, error: c }); });
            n.push(s);
        }
    } let o = () => { this.done = !0, this.resolve(); }; Promise.all(n).then(() => { o(); }).catch(r => { this.reject(r); }), n.length === 0 && o(), this.initialized = !0; }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })(), Lr = new S("");
function Ld() { Xf(() => { let e = ""; throw new _(600, e); }); }
function cE(e) { return e.isBoundToModule; }
var zb = 10;
function Fd(e, t) { return Array.isArray(t) ? t.reduce(Fd, e) : Z(Z({}, e), t); }
var xe = (() => { class e {
    _runningTick = !1;
    _destroyed = !1;
    _destroyListeners = [];
    _views = [];
    internalErrorHandler = I(Wt);
    afterRenderManager = I(Bs);
    zonelessEnabled = I(Tn);
    rootEffectScheduler = I(Rc);
    dirtyFlags = 0;
    tracingSnapshot = null;
    allTestViews = new Set;
    autoDetectTestViews = new Set;
    includeAllTestViews = !1;
    afterTick = new Jh;
    get allViews() { return [...(this.includeAllTestViews ? this.allTestViews : this.autoDetectTestViews).keys(), ...this._views]; }
    get destroyed() { return this._destroyed; }
    componentTypes = [];
    components = [];
    internalPendingTask = I(Gt);
    get isStable() { return this.internalPendingTask.hasPendingTasksObservable.pipe(HT(n => !n)); }
    constructor() { I(hn, { optional: !0 }); }
    whenStable() { let n; return new Promise(o => { n = this.isStable.subscribe({ next: r => { r && o(); } }); }).finally(() => { n.unsubscribe(); }); }
    _injector = I(It);
    _rendererFactory = null;
    get injector() { return this._injector; }
    bootstrap(n, o) { return this.bootstrapImpl(n, o); }
    bootstrapImpl(n, o, r = Te.NULL) { return this._injector.get(U).run(() => { x(R.BootstrapComponentStart); let s = n instanceof ia; if (!this._injector.get(Pd).done) {
        let h = "";
        throw new _(405, h);
    } let c; s ? c = n : c = this._injector.get(kr).resolveComponentFactory(n), this.componentTypes.push(c.componentType); let l = cE(c) ? void 0 : this._injector.get(zn), u = o || c.selector, d = c.create(r, [], u, l), f = d.location.nativeElement, p = d.injector.get(nE, null); return p?.registerApplication(f), d.onDestroy(() => { this.detachView(d.hostView), $o(this.components, d), p?.unregisterApplication(f); }), this._loadComponent(d), x(R.BootstrapComponentEnd, d), d; }); }
    tick() { this.zonelessEnabled || (this.dirtyFlags |= 1), this._tick(); }
    _tick() { x(R.ChangeDetectionStart), this.tracingSnapshot !== null ? this.tracingSnapshot.run(js.CHANGE_DETECTION, this.tickImpl) : this.tickImpl(); }
    tickImpl = () => { if (this._runningTick)
        throw x(R.ChangeDetectionEnd), new _(101, !1); let n = P(null); try {
        this._runningTick = !0, this.synchronize();
    }
    finally {
        this._runningTick = !1, this.tracingSnapshot?.dispose(), this.tracingSnapshot = null, P(n), this.afterTick.next(), x(R.ChangeDetectionEnd);
    } };
    synchronize() { this._rendererFactory === null && !this._injector.destroyed && (this._rendererFactory = this._injector.get(ar, null, { optional: !0 })); let n = 0; for (; this.dirtyFlags !== 0 && n++ < zb;) {
        x(R.ChangeDetectionSyncStart);
        try {
            this.synchronizeOnce();
        }
        finally {
            x(R.ChangeDetectionSyncEnd);
        }
    } }
    synchronizeOnce() { this.dirtyFlags & 16 && (this.dirtyFlags &= -17, this.rootEffectScheduler.flush()); let n = !1; if (this.dirtyFlags & 7) {
        let o = !!(this.dirtyFlags & 1);
        this.dirtyFlags &= -8, this.dirtyFlags |= 8;
        for (let { _lView: r } of this.allViews) {
            if (!o && !Ro(r))
                continue;
            let i = o && !this.zonelessEnabled ? 0 : 1;
            yy(r, i), n = !0;
        }
        if (this.dirtyFlags &= -5, this.syncDirtyFlagsWithViews(), this.dirtyFlags & 23)
            return;
    } n || (this._rendererFactory?.begin?.(), this._rendererFactory?.end?.()), this.dirtyFlags & 8 && (this.dirtyFlags &= -9, this.afterRenderManager.execute()), this.syncDirtyFlagsWithViews(); }
    syncDirtyFlagsWithViews() { if (this.allViews.some(({ _lView: n }) => Ro(n))) {
        this.dirtyFlags |= 2;
        return;
    }
    else
        this.dirtyFlags &= -8; }
    attachView(n) { let o = n; this._views.push(o), o.attachToAppRef(this); }
    detachView(n) { let o = n; $o(this._views, o), o.detachFromAppRef(); }
    _loadComponent(n) { this.attachView(n.hostView); try {
        this.tick();
    }
    catch (r) {
        this.internalErrorHandler(r);
    } this.components.push(n), this._injector.get(Lr, []).forEach(r => r(n)); }
    ngOnDestroy() { if (!this._destroyed)
        try {
            this._destroyListeners.forEach(n => n()), this._views.slice().forEach(n => n.destroy());
        }
        finally {
            this._destroyed = !0, this._views = [], this._destroyListeners = [];
        } }
    onDestroy(n) { return this._destroyListeners.push(n), () => $o(this._destroyListeners, n); }
    destroy() { if (this._destroyed)
        throw new _(406, !1); let n = this._injector; n.destroy && !n.destroyed && n.destroy(); }
    get viewCount() { return this._views.length; }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })();
function $o(e, t) { let n = e.indexOf(t); n > -1 && e.splice(n, 1); }
function fa() { let e, t; return { promise: new Promise((o, r) => { e = o, t = r; }), resolve: e, reject: t }; }
function lE(e) { let t = g(), n = M(); if (ho(t, n), !fE(0, t))
    return; let o = t[O], r = ye(t, n), i = e(() => ve(0, t, n), o); xr(0, r, i); }
function uE(e) { if (typeof ngServerMode < "u" && ngServerMode)
    return; let t = g(), n = t[O], o = M(), r = t[m], i = ce(r, o); if (i.loadingState === ne.NOT_STARTED) {
    let s = ye(t, o), c = e(() => Fr(i, t, o), n);
    xr(1, s, c);
} }
function dE(e, t, n) { if (typeof ngServerMode < "u" && ngServerMode)
    return; let o = t[O], r = ye(t, n), i = r[la], s = e(() => ht(o, i), o); xr(2, r, s); }
function Fr(e, t, n) { pa(e, t, n); }
function pa(e, t, n) { let o = t[O], r = t[m]; if (e.loadingState !== ne.NOT_STARTED)
    return e.loadingPromise ?? Promise.resolve(); let i = ye(t, n), s = wb(r, e); e.loadingState = ne.IN_PROGRESS, Hi(1, i); let a = e.dependencyResolverFn, c = o.get(Ac).add(); return a ? (e.loadingPromise = Promise.allSettled(a()).then(l => { let u = !1, d = null, f = [], p = []; for (let h = 0; h < l.length; h++) {
    let y = l[h];
    if (y.status === "fulfilled") {
        let v = y.value, D = W(v) || Ne(v);
        if (D)
            f.push(D);
        else {
            let b = Ue(v);
            b && p.push(b);
        }
    }
    else {
        u = !0, d = y.reason instanceof Error ? y.reason : new Error(String(y.reason));
        break;
    }
} if (u) {
    if (e.loadingState = ne.FAILED, e.errorTmplIndex === null) {
        let y = "", v = new _(-750, y);
        nd(t, v);
    }
}
else {
    e.loadingState = ne.COMPLETE;
    let h = s.tView;
    if (f.length > 0) {
        h.directiveRegistry = Th(h.directiveRegistry, f);
        let y = f.map(D => D.type), v = Ya(!1, ...y);
        e.providers = v;
    }
    p.length > 0 && (h.pipeRegistry = Th(h.pipeRegistry, p));
} }), e.loadingPromise.finally(() => { e.loadingPromise = null, c(); })) : (e.loadingPromise = Promise.resolve().then(() => { e.loadingPromise = null, e.loadingState = ne.COMPLETE, c(); }), e.loadingPromise); }
function fE(e, t) { return !(e === 0 && typeof ngServerMode < "u" && ngServerMode || t[O].get(Jv, null, { optional: !0 })?.behavior === _d.Manual); }
function ve(e, t, n) { let o = t[m], r = t[n.index]; if (!fE(e, t))
    return; let i = ye(t, n), s = ce(o, n); switch (Gv(i), s.loadingState) {
    case ne.NOT_STARTED:
        rt($.Loading, n, r), pa(s, t, n), s.loadingState === ne.IN_PROGRESS && wh(s, n, r);
        break;
    case ne.IN_PROGRESS:
        rt($.Loading, n, r), wh(s, n, r);
        break;
    case ne.COMPLETE:
        rt($.Complete, n, r);
        break;
    case ne.FAILED:
        rt($.Error, n, r);
        break;
    default:
} }
function ht(e, t, n) { return mt(this, null, function* () { let o = e.get(ut); if (o.hydrating.has(t))
    return; let { parentBlockPromise: i, hydrationQueue: s } = cN(t, e); if (s.length === 0)
    return; i !== null && s.shift(), qb(o, s), i !== null && (yield i); let a = s[0]; o.has(a) ? yield Sh(e, s, n) : o.awaitParentBlock(a, () => mt(null, null, function* () { return yield Sh(e, s, n); })); }); }
function Sh(e, t, n) { return mt(this, null, function* () { let o = e.get(ut), r = o.hydrating, i = e.get(Gt), s = i.add(); for (let c = 0; c < t.length; c++) {
    let l = t[c], u = o.get(l);
    if (u != null) {
        if (yield Yb(u), yield Qb(e), Gb(u)) {
            X_(u), bh(t.slice(c), o);
            break;
        }
        r.get(l).resolve();
    }
    else {
        Wb(c, t, o), bh(t.slice(c), o);
        break;
    }
} let a = t[t.length - 1]; yield r.get(a)?.promise, i.remove(s), n && n(t), eS(o.get(a), t, o, e.get(xe)); }); }
function Gb(e) { return ye(e.lView, e.tNode)[pt] === $.Error; }
function Wb(e, t, n) { let o = e - 1, r = o > -1 ? n.get(t[o]) : null; r && ra(r.lContainer); }
function bh(e, t) { let n = t.hydrating; for (let o in e)
    n.get(o)?.reject(); t.cleanup(e); }
function qb(e, t) { for (let n of t)
    e.hydrating.set(n, fa()); }
function Qb(e) { return new Promise(t => qu(t, { injector: e })); }
function Yb(e) { return mt(this, null, function* () { let { tNode: t, lView: n } = e, o = ye(n, t); return new Promise(r => { Zb(o, r), ve(2, n, t); }); }); }
function Zb(e, t) { Array.isArray(e[Fn]) || (e[Fn] = []), e[Fn].push(t); }
function Y(e, t, n) { return e === 0 ? Ah(t, n) : e === 2 ? !Ah(t, n) : !(typeof ngServerMode < "u" && ngServerMode); }
function Kb(e) { return e != null && (e & 1) === 1; }
function Ah(e, t) { let n = e[O], o = ce(e[m], t), r = Nr(n), i = Kb(o.flags); if (typeof ngServerMode < "u" && ngServerMode)
    return !r || !i; let a = ye(e, t)[la] !== null; return !(i && a && r); }
function kt(e, t) { let n = ce(e, t); return n.hydrateTriggers ??= new Map; }
function pE(e, t, n) { let o = [], r = [], i = [], s = []; for (let [a, c] of t) {
    let l = n.get(a);
    if (l !== void 0) {
        let u = c.data[st], d = l;
        for (let f = 0; f < u; f++) {
            if (d = d.previousSibling, d.nodeType !== Node.ELEMENT_NODE)
                continue;
            let p = { el: d, blockName: a };
            c.hydrate.idle && o.push(p), c.hydrate.immediate && s.push(p), c.hydrate.timer !== null && (p.delay = c.hydrate.timer, r.push(p)), c.hydrate.viewport && (typeof c.hydrate.viewport != "boolean" && (p.intersectionObserverOptions = c.hydrate.viewport), i.push(p));
        }
    }
} Jb(e, o), tA(e, s), Xb(e, i), eA(e, r); }
function Jb(e, t) { for (let n of t) {
    let o = e.get(ut), i = ua(() => ht(e, n.blockName), e);
    o.addCleanupFn(n.blockName, i);
} }
function Xb(e, t) { if (t.length > 0) {
    let n = e.get(ut);
    for (let o of t) {
        let r = Sd(o.el, () => ht(e, o.blockName), e, o.intersectionObserverOptions);
        n.addCleanupFn(o.blockName, r);
    }
} }
function eA(e, t) { for (let n of t) {
    let o = e.get(ut), r = () => ht(e, n.blockName), s = da(n.delay)(r, e);
    o.addCleanupFn(n.blockName, s);
} }
function tA(e, t) { for (let n of t)
    ht(e, n.blockName); }
function hE(e, t, n, o, r, i, s, a, c, l) { let u = g(), d = w(), f = e + E, p = cn(u, d, e, null, 0, 0), h = u[O], y = Nr(h); if (d.firstCreatePass) {
    Q("NgDefer");
    let Xe = { primaryTmplIndex: t, loadingTmplIndex: o ?? null, placeholderTmplIndex: r ?? null, errorTmplIndex: i ?? null, placeholderBlockConfig: null, loadingBlockConfig: null, dependencyResolverFn: n ?? null, loadingState: ne.NOT_STARTED, loadingPromise: null, providers: null, hydrateTriggers: null, debug: null, flags: l ?? 0 };
    c?.(d, Xe, a, s), Mb(d, f, Xe);
} let v = u[f]; gv(v, p, u); let D = null, b = null; if (v[Ce]?.length > 0) {
    let Xe = v[Ce][0].data;
    b = Xe[ws] ?? null, D = Xe[Cr];
} let X = [null, dr.Initial, null, null, null, null, b, D, null, null]; Tb(u, f, X); let Pe = null; b !== null && y && (Pe = h.get(ut), Pe.add(b, { lView: u, tNode: p, lContainer: v })); let Me = () => { Gv(X), b !== null && Pe?.cleanup([b]); }; xr(0, X, () => rc(u, Me)), fi(u, Me); }
function gE(e) { let t = g(), n = Ee(); if (!Y(0, t, n))
    return; let o = he(); if (z(t, o, e)) {
    let r = P(null);
    try {
        let i = !!e, a = ye(t, n)[pt];
        i === !1 && a === dr.Initial ? ho(t, n) : i === !0 && (a === dr.Initial || a === $.Placeholder) && ve(0, t, n);
    }
    finally {
        P(r);
    }
} }
function mE(e) { let t = g(), n = Ee(); if (!Y(1, t, n))
    return; let o = he(); if (z(t, o, e)) {
    let r = P(null);
    try {
        let i = !!e, s = t[m], a = ce(s, n);
        i === !0 && a.loadingState === ne.NOT_STARTED && Fr(a, t, n);
    }
    finally {
        P(r);
    }
} }
function yE(e) { let t = g(), n = Ee(); if (!Y(2, t, n))
    return; let o = he(), r = w(); if (kt(r, n).set(6, null), z(t, o, e))
    if (typeof ngServerMode < "u" && ngServerMode)
        ve(2, t, n);
    else {
        let s = t[O], a = P(null);
        try {
            if (!!e === !0) {
                let u = ye(t, n)[la];
                ht(s, u);
            }
        }
        finally {
            P(a);
        }
    } }
function vE() { let e = g(), t = M(); if (!Y(2, e, t))
    return; kt(w(), t).set(7, null), typeof ngServerMode < "u" && ngServerMode && ve(2, e, t); }
function EE() { let e = g(), t = M(); Y(0, e, t) && lE(ua); }
function IE() { let e = g(), t = M(); Y(1, e, t) && uE(ua); }
function DE() { let e = g(), t = M(); if (!Y(2, e, t))
    return; kt(w(), t).set(0, null), typeof ngServerMode < "u" && ngServerMode ? ve(2, e, t) : dE(ua, e, t); }
function CE() { let e = g(), t = M(); if (!Y(0, e, t))
    return; ce(e[m], t).loadingTmplIndex === null && ho(e, t), ve(0, e, t); }
function TE() { let e = g(), t = M(); if (!Y(1, e, t))
    return; let n = e[m], o = ce(n, t); o.loadingState === ne.NOT_STARTED && pa(o, e, t); }
function ME() { let e = g(), t = M(); if (!Y(2, e, t))
    return; if (kt(w(), t).set(1, null), typeof ngServerMode < "u" && ngServerMode)
    ve(2, e, t);
else {
    let o = e[O], i = ye(e, t)[la];
    ht(o, i);
} }
function NE(e) { let t = g(), n = M(); Y(0, t, n) && lE(da(e)); }
function wE(e) { let t = g(), n = M(); Y(1, t, n) && uE(da(e)); }
function _E(e) { let t = g(), n = M(); if (!Y(2, t, n))
    return; kt(w(), n).set(5, { type: 5, delay: e }), typeof ngServerMode < "u" && ngServerMode ? ve(2, t, n) : dE(da(e), t, n); }
function SE(e, t) { let n = g(), o = M(); Y(0, n, o) && (ho(n, o), typeof ngServerMode < "u" && ngServerMode || po(n, o, e, t, zg, () => ve(0, n, o), 0)); }
function bE(e, t) { let n = g(), o = M(); if (!Y(1, n, o))
    return; let r = n[m], i = ce(r, o); i.loadingState === ne.NOT_STARTED && po(n, o, e, t, zg, () => Fr(i, n, o), 1); }
function AE() { let e = g(), t = M(); if (!Y(2, e, t))
    return; kt(w(), t).set(4, null), typeof ngServerMode < "u" && ngServerMode && ve(2, e, t); }
function RE(e, t) { let n = g(), o = M(); Y(0, n, o) && (ho(n, o), typeof ngServerMode < "u" && ngServerMode || po(n, o, e, t, $g, () => ve(0, n, o), 0)); }
function OE(e, t) { let n = g(), o = M(); if (!Y(1, n, o))
    return; let r = n[m], i = ce(r, o); i.loadingState === ne.NOT_STARTED && po(n, o, e, t, $g, () => Fr(i, n, o), 1); }
function kE() { let e = g(), t = M(); if (!Y(2, e, t))
    return; kt(w(), t).set(3, null), typeof ngServerMode < "u" && ngServerMode && ve(2, e, t); }
function xE(e, t, n) { let o = g(), r = M(); Y(0, o, r) && (ho(o, r), typeof ngServerMode < "u" && ngServerMode || po(o, r, e, t, Sd, () => ve(0, o, r), 0, n)); }
function PE(e, t, n) { let o = g(), r = M(); if (!Y(1, o, r))
    return; let i = o[m], s = ce(i, r); s.loadingState === ne.NOT_STARTED && po(o, r, e, t, Sd, () => Fr(s, o, r), 1, n); }
function LE(e) { let t = g(), n = M(); if (!Y(2, t, n))
    return; kt(w(), n).set(2, e ? { type: 2, intersectionObserverOptions: e } : null), typeof ngServerMode < "u" && ngServerMode && ve(2, t, n); }
function Hd(e, t) { let n = g(), o = he(); if (z(n, o, t)) {
    let r = w(), i = Ee();
    if (Zs(i, r, n, e, t))
        me(i) && dy(n, i.index);
    else {
        let a = te(i, n);
        qs(n[T], a, null, i.value, e, t, null);
    }
} return Hd; }
function Vd(e, t, n, o) { let r = g(), i = he(); if (z(r, i, t)) {
    let s = w(), a = Ee();
    zw(a, r, e, t, n, o);
} return Vd; }
function zo(e) { if (Q("NgAnimateEnter"), typeof ngServerMode < "u" && ngServerMode || !pn)
    return zo; let t = g(); if (Hs(t))
    return zo; let n = M(), o = t[O].get(U); return Vs(es(t), n, () => nA(t, n, e, o)), zs(t[O]), Qu(t[O], es(t)), zo; }
function nA(e, t, n, o) { let r = te(t, e), i = e[T], s = Wm(n), a = [], c = !1, l = d => { if (tr(d) !== r)
    return; let f = d instanceof AnimationEvent ? "animationend" : "transitionend"; o.runOutsideAngular(() => { i.listen(r, f, u); }); }, u = d => { tr(d) === r && (zu(d, r) && (c = !0), oA(d, r, i)); }; if (s && s.length > 0) {
    o.runOutsideAngular(() => { a.push(i.listen(r, "animationstart", l)), a.push(i.listen(r, "transitionstart", l)); }), yw(r, s, a);
    for (let d of s)
        i.addClass(r, d);
    o.runOutsideAngular(() => { requestAnimationFrame(() => { if (!c && (Ym(r, Xt, pn), !Xt.has(r))) {
        for (let d of s)
            i.removeClass(r, d);
        Uu(r);
    } }); });
} }
function oA(e, t, n) { let o = jn.get(t); if (!(tr(e) !== t || !o) && zu(e, t)) {
    e.stopPropagation();
    for (let r of o.classList)
        n.removeClass(t, r);
    Uu(t);
} }
function Go(e) { if (Q("NgAnimateEnter"), typeof ngServerMode < "u" && ngServerMode || !pn)
    return Go; let t = g(); if (Hs(t))
    return Go; let n = M(); return Vs(es(t), n, () => rA(t, n, e)), zs(t[O]), Qu(t[O], es(t)), Go; }
function rA(e, t, n) { let o = te(t, e); n.call(e[H], { target: o, animationComplete: vw }); }
function Wo(e) { if (Q("NgAnimateLeave"), typeof ngServerMode < "u" && ngServerMode || !pn)
    return Wo; let t = g(); if (Hs(t))
    return Wo; let o = M(), r = t[O].get(U); return Vs(nn(t), o, () => iA(t, o, e, r)), zs(t[O]), Wo; }
function iA(e, t, n, o) { let { promise: r, resolve: i } = fa(), s = te(t, e), a = e[T]; on.add(e[Se]), (nn(e).get(t.index).resolvers ??= []).push(i); let c = Wm(n); return c && c.length > 0 ? sA(s, t, e, c, a, o) : i(), { promise: r, resolve: i }; }
function sA(e, t, n, o, r, i) { Iw(e, r); let s = [], a = nn(n).get(t.index)?.resolvers, c, l = !1, u = d => { if (!(tr(d) !== e && d.type !== "animation-fallback") && (d.type === "animation-fallback" || zu(d, e))) {
    if (l = !0, c && clearTimeout(c), d.type !== "animation-fallback" && d.stopPropagation(), Xt.delete(e), Nl(t, e), Array.isArray(t.projection))
        for (let p of o)
            r.removeClass(e, p);
    wl(a, s), _l(n, t);
} }; i.runOutsideAngular(() => { s.push(r.listen(e, "animationend", u)), s.push(r.listen(e, "transitionend", u)); }), $u(t, e); for (let d of o)
    r.addClass(e, d); i.runOutsideAngular(() => { requestAnimationFrame(() => { if (l)
    return; Ym(e, Xt, pn); let d = Xt.get(e); d ? (c = setTimeout(() => { u(new CustomEvent("animation-fallback")); }, d.duration + 50), s.push(() => clearTimeout(c))) : (Nl(t, e), wl(a, s), _l(n, t)); }); }); }
function us(e) { if (Q("NgAnimateLeave"), typeof ngServerMode < "u" && ngServerMode || !pn)
    return us; let t = g(), n = M(); on.add(t[Se]); let o = t[O].get(U), r = t[O].get(Gm); return Vs(nn(t), n, () => aA(t, n, e, o, r)), zs(t[O]), us; }
function aA(e, t, n, o, r) { let { promise: i, resolve: s } = fa(), a = te(t, e), c = [], l = e[T], u = Hs(e); (nn(e).get(t.index).resolvers ??= []).push(s); let d = nn(e).get(t.index)?.resolvers; if (u)
    _i(e, t, a, d, c);
else {
    let f = setTimeout(() => _i(e, t, a, d, c), r), p = { target: a, animationComplete: () => { _i(e, t, a, d, c), clearTimeout(f); } };
    $u(t, a), o.runOutsideAngular(() => { c.push(l.listen(a, "animationend", () => { _i(e, t, a, d, c), clearTimeout(f); }, { once: !0 })); }), n.call(e[H], p);
} return { promise: i, resolve: s }; }
function FE() { return g()[K][H]; }
var Wl = class {
    destroy(t) { }
    updateValue(t, n) { }
    swap(t, n) { let o = Math.min(t, n), r = Math.max(t, n), i = this.detach(r); if (r - o > 1) {
        let s = this.detach(o);
        this.attach(o, i), this.attach(r, s);
    }
    else
        this.attach(o, i); }
    move(t, n) { this.attach(n, this.detach(t)); }
};
function qc(e, t, n, o, r) { return e === n && Object.is(t, o) ? 1 : Object.is(r(e, t), r(n, o)) ? -1 : 0; }
function cA(e, t, n, o) { let r, i, s = 0, a = e.length - 1, c = void 0; if (Array.isArray(t)) {
    wn(o);
    let l = t.length - 1;
    for (wn(null); s <= a && s <= l;) {
        let u = e.at(s), d = t[s], f = qc(s, u, s, d, n);
        if (f !== 0) {
            f < 0 && e.updateValue(s, d), s++;
            continue;
        }
        let p = e.at(a), h = t[l], y = qc(a, p, l, h, n);
        if (y !== 0) {
            y < 0 && e.updateValue(a, h), a--, l--;
            continue;
        }
        let v = n(s, u), D = n(a, p), b = n(s, d);
        if (Object.is(b, D)) {
            let X = n(l, h);
            Object.is(X, v) ? (e.swap(s, a), e.updateValue(a, h), l--, a--) : e.move(a, s), e.updateValue(s, d), s++;
            continue;
        }
        if (r ??= new ds, i ??= Oh(e, s, a, n), ql(e, r, s, b))
            e.updateValue(s, d), s++, a++;
        else if (i.has(b))
            r.set(v, e.detach(s)), a--;
        else {
            let X = e.create(s, t[s]);
            e.attach(s, X), s++, a++;
        }
    }
    for (; s <= l;)
        Rh(e, r, n, s, t[s]), s++;
}
else if (t != null) {
    wn(o);
    let l = t[Symbol.iterator]();
    wn(null);
    let u = l.next();
    for (; !u.done && s <= a;) {
        let d = e.at(s), f = u.value, p = qc(s, d, s, f, n);
        if (p !== 0)
            p < 0 && e.updateValue(s, f), s++, u = l.next();
        else {
            r ??= new ds, i ??= Oh(e, s, a, n);
            let h = n(s, f);
            if (ql(e, r, s, h))
                e.updateValue(s, f), s++, a++, u = l.next();
            else if (!i.has(h))
                e.attach(s, e.create(s, f)), s++, a++, u = l.next();
            else {
                let y = n(s, d);
                r.set(y, e.detach(s)), a--;
            }
        }
    }
    for (; !u.done;)
        Rh(e, r, n, e.length, u.value), u = l.next();
} for (; s <= a;)
    e.destroy(e.detach(a--)); r?.forEach(l => { e.destroy(l); }); }
function ql(e, t, n, o) { return t !== void 0 && t.has(o) ? (e.attach(n, t.get(o)), t.delete(o), !0) : !1; }
function Rh(e, t, n, o, r) { if (ql(e, t, o, n(o, r)))
    e.updateValue(o, r);
else {
    let i = e.create(o, r);
    e.attach(o, i);
} }
function Oh(e, t, n, o) { let r = new Set; for (let i = t; i <= n; i++)
    r.add(o(i, e.at(i))); return r; }
var ds = class {
    kvMap = new Map;
    _vMap = void 0;
    has(t) { return this.kvMap.has(t); }
    delete(t) { if (!this.has(t))
        return !1; let n = this.kvMap.get(t); return this._vMap !== void 0 && this._vMap.has(n) ? (this.kvMap.set(t, this._vMap.get(n)), this._vMap.delete(n)) : this.kvMap.delete(t), !0; }
    get(t) { return this.kvMap.get(t); }
    set(t, n) { if (this.kvMap.has(t)) {
        let o = this.kvMap.get(t);
        this._vMap === void 0 && (this._vMap = new Map);
        let r = this._vMap;
        for (; r.has(o);)
            o = r.get(o);
        r.set(o, n);
    }
    else
        this.kvMap.set(t, n); }
    forEach(t) { for (let [n, o] of this.kvMap)
        if (t(o, n), this._vMap !== void 0) {
            let r = this._vMap;
            for (; r.has(o);)
                o = r.get(o), t(o, n);
        } }
};
function HE(e, t, n, o, r, i, s, a) { Q("NgControlFlow"); let c = g(), l = w(), u = de(l.consts, i); return cn(c, l, e, t, n, o, r, u, 256, s, a), ha; }
function ha(e, t, n, o, r, i, s, a) { Q("NgControlFlow"); let c = g(), l = w(), u = de(l.consts, i); return cn(c, l, e, t, n, o, r, u, 512, s, a), ha; }
function VE(e, t) { Q("NgControlFlow"); let n = g(), o = he(), r = n[o] !== L ? n[o] : -1, i = r !== -1 ? fs(n, E + r) : void 0, s = 0; if (z(n, o, e)) {
    let a = P(null);
    try {
        if (i !== void 0 && od(i, s), e !== -1) {
            let c = E + e, l = fs(n, c), u = Kl(n[m], c), d = Qy(l, u, n), f = ao(n, u, t, { dehydratedView: d });
            co(l, f, s, rn(u, d));
        }
    }
    finally {
        P(a);
    }
}
else if (i !== void 0) {
    let a = Ty(i, s);
    a !== void 0 && (a[H] = t);
} }
var Ql = class {
    lContainer;
    $implicit;
    $index;
    constructor(t, n, o) { this.lContainer = t, this.$implicit = n, this.$index = o; }
    get $count() { return this.lContainer.length - V; }
};
function jE(e) { return e; }
function BE(e, t) { return t; }
var Yl = class {
    hasEmptyBlock;
    trackByFn;
    liveCollection;
    constructor(t, n, o) { this.hasEmptyBlock = t, this.trackByFn = n, this.liveCollection = o; }
};
function UE(e, t, n, o, r, i, s, a, c, l, u, d, f) { Q("NgControlFlow"); let p = g(), h = w(), y = c !== void 0, v = g(), D = a ? s.bind(v[K][H]) : s, b = new Yl(y, D); v[E + e] = b, cn(p, h, e + 1, t, n, o, r, de(h.consts, i), 256), y && cn(p, h, e + 2, c, l, u, d, de(h.consts, f), 512); }
var Zl = class extends Wl {
    lContainer;
    hostLView;
    templateTNode;
    operationsCounter = void 0;
    needsIndexUpdate = !1;
    constructor(t, n, o) { super(), this.lContainer = t, this.hostLView = n, this.templateTNode = o; }
    get length() { return this.lContainer.length - V; }
    at(t) { return this.getLView(t)[H].$implicit; }
    attach(t, n) { let o = n[se]; this.needsIndexUpdate ||= t !== this.length, co(this.lContainer, n, t, rn(this.templateTNode, o)), lA(this.lContainer, t); }
    detach(t) { return this.needsIndexUpdate ||= t !== this.length - 1, uA(this.lContainer, t), dA(this.lContainer, t); }
    create(t, n) { let o = sr(this.lContainer, this.templateTNode.tView.ssrId); return ao(this.hostLView, this.templateTNode, new Ql(this.lContainer, n, t), { dehydratedView: o }); }
    destroy(t) { Ar(t[m], t); }
    updateValue(t, n) { this.getLView(t)[H].$implicit = n; }
    reset() { this.needsIndexUpdate = !1; }
    updateIndexes() { if (this.needsIndexUpdate)
        for (let t = 0; t < this.length; t++)
            this.getLView(t)[H].$index = t; }
    getLView(t) { return fA(this.lContainer, t); }
};
function $E(e) { let t = P(null), n = J(); try {
    let o = g(), r = o[m], i = o[n], s = n + 1, a = fs(o, s);
    if (i.liveCollection === void 0) {
        let l = Kl(r, s);
        i.liveCollection = new Zl(a, o, l);
    }
    else
        i.liveCollection.reset();
    let c = i.liveCollection;
    if (cA(c, e, i.trackByFn, t), c.updateIndexes(), i.hasEmptyBlock) {
        let l = he(), u = c.length === 0;
        if (z(o, l, u)) {
            let d = n + 2, f = fs(o, d);
            if (u) {
                let p = Kl(r, d), h = Qy(f, p, o), y = ao(o, p, void 0, { dehydratedView: h });
                co(f, y, 0, rn(p, h));
            }
            else
                r.firstUpdatePass && oa(f), od(f, 0);
        }
    }
}
finally {
    P(t);
} }
function fs(e, t) { return e[t]; }
function lA(e, t) { if (e.length <= V)
    return; let n = V + t, o = e[n], r = o ? o[Ge] : void 0; if (o && r && r.detachedLeaveAnimationFns && r.detachedLeaveAnimationFns.length > 0) {
    let i = o[O];
    _w(i, r), on.delete(o[Se]), r.detachedLeaveAnimationFns = void 0;
} }
function uA(e, t) { if (e.length <= V)
    return; let n = V + t, o = e[n], r = o ? o[Ge] : void 0; r && r.leave && r.leave.size > 0 && (r.detachedLeaveAnimationFns = []); }
function dA(e, t) { return or(e, t); }
function fA(e, t) { return Ty(e, t); }
function Kl(e, t) { return Ut(e, t); }
function jd(e, t, n) { let o = g(), r = he(); if (z(o, r, t)) {
    let i = w(), s = Ee();
    Xu(s, o, e, t, o[T], n);
} return jd; }
function Jl(e, t, n, o, r) { Zs(t, e, n, r ? "class" : "style", o); }
function fr(e, t, n, o) { let r = g(), i = r[m], s = e + E, a = i.firstCreatePass ? ld(s, r, 2, t, td, pi(), n, o) : i.data[s]; if (me(a)) {
    let c = r[$e].tracingService;
    if (c && c.componentCreate) {
        let l = i.data[a.directiveStart + a.componentOffset];
        return c.componentCreate(fd(l), () => (kh(e, t, r, a, o), fr));
    }
} return kh(e, t, r, a, o), fr; }
function kh(e, t, n, o, r) { if (Qs(o, n, e, t, $d), Dn(o)) {
    let i = n[m];
    Ws(i, n, o), wu(i, o, n);
} r != null && so(n, o); }
function ga() { let e = w(), t = M(), n = Ys(t); return e.firstCreatePass && ud(e, n), sc(n) && lc(), ic(), n.classesWithoutHost != null && YT(n) && Jl(e, n, g(), n.classesWithoutHost, !0), n.stylesWithoutHost != null && ZT(n) && Jl(e, n, g(), n.stylesWithoutHost, !1), ga; }
function Bd(e, t, n, o) { return fr(e, t, n, o), ga(), Bd; }
function ma(e, t, n, o) { let r = g(), i = r[m], s = e + E, a = i.firstCreatePass ? tv(s, i, 2, t, n, o) : i.data[s]; return Qs(a, r, e, t, $d), o != null && so(r, a), ma; }
function ya() { let e = M(), t = Ys(e); return sc(t) && lc(), ic(), ya; }
function Ud(e, t, n, o) { return ma(e, t, n, o), ya(), Ud; }
var $d = (e, t, n, o, r) => (Ve(!0), xs(t[T], o, vi()));
function pA(e, t, n, o, r) { let i = !Os(t, n); if (Ve(i), i)
    return xs(t[T], o, vi()); let s = t[se], a = Or(s, e, t, n); return im(s, r) && As(s, r, a.nextSibling), s && (lu(n) || _g(a)) && me(n) && (Mp(n), Am(a)), a; }
function zE() { $d = pA; }
function va(e, t, n) { let o = g(), r = o[m], i = e + E, s = r.firstCreatePass ? ld(i, o, 8, "ng-container", td, pi(), t, n) : r.data[i]; if (Qs(s, o, e, "ng-container", qd), Dn(s)) {
    let a = o[m];
    Ws(a, o, s), wu(a, s, o);
} return n != null && so(o, s), va; }
function Hr() { let e = w(), t = M(), n = Ys(t); return e.firstCreatePass && ud(e, n), Hr; }
function zd(e, t, n) { return va(e, t, n), Hr(), zd; }
function Ea(e, t, n) { let o = g(), r = o[m], i = e + E, s = r.firstCreatePass ? tv(i, r, 8, "ng-container", t, n) : r.data[i]; return Qs(s, o, e, "ng-container", qd), n != null && so(o, s), Ea; }
function Gd() { let e = M(), t = Ys(e); return Hr; }
function Wd(e, t, n) { return Ea(e, t, n), Gd(), Wd; }
var qd = (e, t, n, o, r) => (Ve(!0), bu(t[T], ""));
function hA(e, t, n, o, r) { let i, s = !Os(t, n); if (Ve(s), s)
    return bu(t[T], ""); let a = t[se], c = Or(a, e, t, n), l = rm(a, r); return As(a, r, c), i = ta(l, c), i; }
function GE() { qd = hA; }
function WE() { return g(); }
function Qd(e, t, n) { let o = g(), r = he(); if (z(o, r, t)) {
    let i = w(), s = Ee();
    ed(s, o, e, t, o[T], n);
} return Qd; }
function Yd(e, t, n) { let o = g(), r = he(); if (z(o, r, t)) {
    let i = w(), s = Ee(), a = hi(i.data), c = fy(a, s, o);
    ed(s, o, e, t, c, n);
} return Yd; }
var Fo = void 0;
function gA(e) { let t = Math.floor(Math.abs(e)), n = e.toString().replace(/^[^.]*\.?/, "").length; return t === 1 && n === 0 ? 1 : 5; }
var mA = ["en", [["a", "p"], ["AM", "PM"]], [["AM", "PM"]], [["S", "M", "T", "W", "T", "F", "S"], ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]], Fo, [["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"], ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]], Fo, [["B", "A"], ["BC", "AD"], ["Before Christ", "Anno Domini"]], 0, [6, 0], ["M/d/yy", "MMM d, y", "MMMM d, y", "EEEE, MMMM d, y"], ["h:mm\u202Fa", "h:mm:ss\u202Fa", "h:mm:ss\u202Fa z", "h:mm:ss\u202Fa zzzz"], ["{1}, {0}", Fo, Fo, Fo], [".", ",", ";", "%", "+", "-", "E", "\xD7", "\u2030", "\u221E", "NaN", ":"], ["#,##0.###", "#,##0%", "\xA4#,##0.00", "#E0"], "USD", "$", "US Dollar", {}, "ltr", gA], Hn = Object.create(null);
function yA(e, t, n) { typeof t != "string" && (n = t, t = e[qn.LocaleId]), t = t.toLowerCase().replace(/_/g, "-"), Hn[t] = e, n && (Hn[t][qn.ExtraData] = n); }
function Zd(e) { let t = IA(e), n = xh(t); if (n)
    return n; let o = t.split("-")[0]; if (n = xh(o), n)
    return n; if (o === "en")
    return mA; throw new _(701, !1); }
function vA(e) { return Zd(e)[qn.CurrencyCode] || null; }
function qE(e) { return Zd(e)[qn.PluralCase]; }
function xh(e) { if (!(e in Hn)) {
    let t = De.ng && De.ng.common && De.ng.common.locales && De.ng.common.locales[e];
    return t !== void 0 && (Hn[e] = t), t;
} return Hn[e]; }
function EA() { Hn = Object.create(null); }
var qn = (function (e) { return e[e.LocaleId = 0] = "LocaleId", e[e.DayPeriodsFormat = 1] = "DayPeriodsFormat", e[e.DayPeriodsStandalone = 2] = "DayPeriodsStandalone", e[e.DaysFormat = 3] = "DaysFormat", e[e.DaysStandalone = 4] = "DaysStandalone", e[e.MonthsFormat = 5] = "MonthsFormat", e[e.MonthsStandalone = 6] = "MonthsStandalone", e[e.Eras = 7] = "Eras", e[e.FirstDayOfWeek = 8] = "FirstDayOfWeek", e[e.WeekendRange = 9] = "WeekendRange", e[e.DateFormat = 10] = "DateFormat", e[e.TimeFormat = 11] = "TimeFormat", e[e.DateTimeFormat = 12] = "DateTimeFormat", e[e.NumberSymbols = 13] = "NumberSymbols", e[e.NumberFormats = 14] = "NumberFormats", e[e.CurrencyCode = 15] = "CurrencyCode", e[e.CurrencySymbol = 16] = "CurrencySymbol", e[e.CurrencyName = 17] = "CurrencyName", e[e.Currencies = 18] = "Currencies", e[e.Directionality = 19] = "Directionality", e[e.PluralCase = 20] = "PluralCase", e[e.ExtraData = 21] = "ExtraData", e; })(qn || {});
function IA(e) { return e.toLowerCase().replace(/_/g, "-"); }
var DA = ["zero", "one", "two", "few", "many"];
function CA(e, t) { let n = qE(t)(parseInt(e, 10)), o = DA[n]; return o !== void 0 ? o : "other"; }
var Vr = "en-US", TA = "USD", QE = { marker: "element" }, YE = { marker: "ICU" }, ot = (function (e) { return e[e.SHIFT = 2] = "SHIFT", e[e.APPEND_EAGERLY = 1] = "APPEND_EAGERLY", e[e.COMMENT = 2] = "COMMENT", e; })(ot || {}), ZE = Vr;
function KE(e) { typeof e == "string" && (ZE = e.toLowerCase().replace(/_/g, "-")); }
function MA() { return ZE; }
var pr = 0, qo = 0;
function NA(e) { e && (pr = pr | 1 << Math.min(qo, 31)), qo++; }
function wA(e, t, n) { try {
    if (qo > 0) {
        let o = e.data[n], r = Array.isArray(o) ? o : o.update, i = Qe() - qo - 1;
        tI(e, t, r, i, pr);
    }
}
finally {
    pr = 0, qo = 0;
} }
function JE(e, t, n) { let o = e[T]; switch (n) {
    case Node.COMMENT_NODE: return bu(o, t);
    case Node.TEXT_NODE: return Su(o, t);
    case Node.ELEMENT_NODE: return xs(o, t, null);
} }
var Qo = (e, t, n, o) => (Ve(!0), JE(e, n, o));
function _A(e, t, n, o) { let r = e[se], i = t - E, s = !na() || !r || Oo() || Rs(r, i); return Ve(s), s ? JE(e, n, o) : Oy(r, i); }
function XE() { Qo = _A; }
function SA(e, t, n, o) { let r = e[T]; for (let i = 0; i < t.length; i++) {
    let s = t[i++], a = t[i], c = (s & ot.COMMENT) === ot.COMMENT, l = (s & ot.APPEND_EAGERLY) === ot.APPEND_EAGERLY, u = s >>> ot.SHIFT, d = e[u], f = !1;
    d === null && (d = e[u] = Qo(e, u, a, c ? Node.COMMENT_NODE : Node.TEXT_NODE), f = xo()), l && n !== null && f && tn(r, n, d, o, !1);
} }
function eI(e, t, n, o) { let r = n[T], i = null, s; for (let a = 0; a < t.length; a++) {
    let c = t[a];
    if (typeof c == "string") {
        let l = t[++a];
        n[l] === null && (n[l] = Qo(n, l, c, Node.TEXT_NODE));
    }
    else if (typeof c == "number")
        switch (c & 1) {
            case 0:
                let l = A_(c);
                i === null && (i = l, s = r.parentNode(o));
                let u, d;
                if (l === i ? (u = o, d = s) : (u = null, d = k(n[l])), d !== null) {
                    let y = R_(c), v = n[y];
                    tn(r, d, v, u, !1);
                    let D = Bo(e, y);
                    if (D !== null && typeof D == "object") {
                        let b = ea(D, n);
                        b !== null && eI(e, D.create[b], n, n[D.anchorIdx]);
                    }
                }
                break;
            case 1:
                let f = c >>> 1, p = t[++a], h = t[++a];
                qs(r, Bt(f, n), null, null, p, h, null);
                break;
            default:
        }
    else
        switch (c) {
            case YE:
                let l = t[++a], u = t[++a];
                if (n[u] === null) {
                    let p = n[u] = Qo(n, u, l, Node.COMMENT_NODE);
                    Re(p, n);
                }
                break;
            case QE:
                let d = t[++a], f = t[++a];
                if (n[f] === null) {
                    let p = n[f] = Qo(n, f, d, Node.ELEMENT_NODE);
                    Re(p, n);
                }
                break;
            default:
        }
} }
function tI(e, t, n, o, r) { for (let i = 0; i < n.length; i++) {
    let s = n[i], a = n[++i];
    if (s & r) {
        let c = "";
        for (let l = i + 1; l <= i + a; l++) {
            let u = n[l];
            if (typeof u == "string")
                c += u;
            else if (typeof u == "number")
                if (u < 0)
                    c += N(t[o - u]);
                else {
                    let d = u >>> 2;
                    switch (u & 3) {
                        case 1:
                            let f = n[++l], p = n[++l], h = e.data[d];
                            if (typeof h == "string")
                                qs(t[T], t[d], null, h, f, c, p);
                            else {
                                let v = J();
                                Ze(d);
                                try {
                                    Xu(h, t, f, c, t[T], p);
                                }
                                finally {
                                    Ze(v);
                                }
                            }
                            break;
                        case 0:
                            let y = t[d];
                            y !== null && Sm(t[T], y, c);
                            break;
                        case 2:
                            bA(e, Bo(e, d), t, c);
                            break;
                        case 3:
                            Ph(e, Bo(e, d), o, t);
                            break;
                    }
                }
        }
    }
    else {
        let c = n[i + 1];
        if (c > 0 && (c & 3) === 3) {
            let l = c >>> 2, u = Bo(e, l);
            t[u.currentCaseLViewIndex] < 0 && Ph(e, u, o, t);
        }
    }
    i += a;
} }
function Ph(e, t, n, o) { let r = o[t.currentCaseLViewIndex]; if (r !== null) {
    let i = pr;
    r < 0 && (r = o[t.currentCaseLViewIndex] = ~r, i = -1), tI(e, o, t.update[r], n, i);
} }
function bA(e, t, n, o) { let r = AA(t, o); if (ea(t, n) !== r && (nI(e, t, n), n[t.currentCaseLViewIndex] = r === null ? null : ~r, r !== null)) {
    let s = n[t.anchorIdx];
    s && eI(e, t.create[r], n, s), Y_(n, t.anchorIdx, r);
} }
function nI(e, t, n) { let o = ea(t, n); if (o !== null) {
    let r = t.remove[o];
    for (let i = 0; i < r.length; i++) {
        let s = r[i];
        if (s > 0) {
            let a = Bt(s, n);
            a !== null && _r(n[T], a);
        }
        else
            nI(e, Bo(e, ~s), n);
    }
} }
function AA(e, t) { let n = e.cases.indexOf(t); if (n === -1)
    switch (e.type) {
        case 1: {
            let o = CA(t, MA());
            n = e.cases.indexOf(o), n === -1 && o !== "other" && (n = e.cases.indexOf("other"));
            break;
        }
        case 0: {
            n = e.cases.indexOf("other");
            break;
        }
    } return n === -1 ? null : n; }
var ps = /�(\d+):?\d*�/gi, RA = /({\s*�\d+:?\d*�\s*,\s*\S{6}\s*,[\s\S]*})/gi, OA = /�(\d+)�/, oI = /^\s*(�\d+:?\d*�)\s*,\s*(select|plural)\s*,/, Yo = "\uFFFD", kA = /�\/?\*(\d+:\d+)�/gi, xA = /�(\/?[#*]\d+):?\d*�/gi, PA = /\uE500/g;
function LA(e) { return e.replace(PA, " "); }
function FA(e, t, n, o, r, i) { let s = Cn(), a = [], c = [], l = [[]], u = [[]]; r = BA(r, i); let d = LA(r).split(xA); for (let f = 0; f < d.length; f++) {
    let p = d[f];
    if ((f & 1) === 0) {
        let h = Xl(p);
        for (let y = 0; y < h.length; y++) {
            let v = h[y];
            if ((y & 1) === 0) {
                let D = v;
                D !== "" && HA(u[0], e, s, l[0], a, c, n, D);
            }
            else {
                let D = v;
                if (typeof D != "object")
                    throw new Error(`Unable to parse ICU expression in "${r}" message.`);
                let X = rI(e, s, l[0], n, a, "", !0).index;
                sI(u[0], e, n, c, t, D, X);
            }
        }
    }
    else {
        let h = p.charCodeAt(0) === 47, y = p.charCodeAt(h ? 1 : 0), v = E + Number.parseInt(p.substring(h ? 2 : 1));
        if (h)
            l.shift(), u.shift(), qe(Cn(), !1);
        else {
            let D = b_(e, l[0], v);
            l.unshift([]), qe(D, !0);
            let b = { kind: 2, index: v, children: [], type: y === 35 ? 0 : 1 };
            u[0].push(b), u.unshift(b.children);
        }
    }
} e.data[o] = { create: a, update: c, ast: u[0], parentTNodeIndex: t }; }
function rI(e, t, n, o, r, i, s) { let a = br(e, o, 1, null), c = a << ot.SHIFT, l = Cn(); t === l && (l = null), l === null && (c |= ot.APPEND_EAGERLY), s && (c |= ot.COMMENT, hw(k_)), r.push(c, i === null ? "" : i); let u = rd(e, a, s ? 32 : 1, i === null ? "" : i, null); Sy(n, u); let d = u.index; return qe(u, !1), l !== null && t !== l && S_(l, d), u; }
function HA(e, t, n, o, r, i, s, a) { let c = a.match(ps), u = rI(t, n, o, s, r, c ? null : a, !1).index; c && hs(i, a, u, null, 0, null), e.push({ kind: 0, index: u }); }
function VA(e, t, n) { let o = M(), r = o.index, i = []; if (e.firstCreatePass && e.data[t] === null) {
    for (let s = 0; s < n.length; s += 2) {
        let a = n[s], c = n[s + 1];
        if (c !== "") {
            if (RA.test(c))
                throw new Error(`ICU expressions are not supported in attributes. Message: "${c}".`);
            let l = o.namespace ? `:${o.namespace}:${o.value}` : o.value;
            hs(i, c, r, a, jA(i), eu(a, l));
        }
    }
    e.data[t] = i;
} }
function hs(e, t, n, o, r, i) { let s = e.length, a = s + 1; e.push(null, null); let c = s + 2, l = t.split(ps), u = 0; for (let d = 0; d < l.length; d++) {
    let f = l[d];
    if (d & 1) {
        let p = r + parseInt(f, 10);
        e.push(-1 - p), u = u | iI(p);
    }
    else
        f !== "" && e.push(f);
} return e.push(n << 2 | (o ? 1 : 0)), o && e.push(o, i), e[s] = u, e[a] = e.length - c, u; }
function jA(e) { let t = 0; for (let n = 0; n < e.length; n++) {
    let o = e[n];
    typeof o == "number" && o < 0 && t++;
} return t; }
function iI(e) { return 1 << Math.min(e, 31); }
function Lh(e) { let t, n = "", o = 0, r = !1, i; for (; (t = kA.exec(e)) !== null;)
    r ? t[0] === `${Yo}/*${i}${Yo}` && (o = t.index, r = !1) : (n += e.substring(o, t.index + t[0].length), i = t[1], r = !0); return n += e.slice(o), n; }
function BA(e, t) { if (Ay(t))
    return Lh(e); {
    let n = e.indexOf(`:${t}${Yo}`) + 2 + t.toString().length, o = e.search(new RegExp(`${Yo}\\/\\*\\d+:${t}${Yo}`));
    return Lh(e.substring(n, o));
} }
function sI(e, t, n, o, r, i, s) { let a = 0, c = { type: i.type, currentCaseLViewIndex: br(t, n, 1, null), anchorIdx: s, cases: [], create: [], remove: [], update: [] }; GA(o, i, s), __(t, s, c); let l = i.values, u = []; for (let d = 0; d < l.length; d++) {
    let f = l[d], p = [];
    for (let y = 0; y < f.length; y++) {
        let v = f[y];
        if (typeof v != "string") {
            let D = p.push(v) - 1;
            f[y] = `<!--\uFFFD${D}\uFFFD-->`;
        }
    }
    let h = [];
    u.push(h), a = $A(h, t, c, n, o, r, i.cases[d], f.join(""), p) | a;
} a && WA(o, a, s), e.push({ kind: 3, index: s, cases: u, currentCaseLViewIndex: c.currentCaseLViewIndex }); }
function UA(e) { let t = [], n = [], o = 1, r = 0; e = e.replace(oI, function (s, a, c) { return c === "select" ? o = 0 : o = 1, r = parseInt(a.slice(1), 10), ""; }); let i = Xl(e); for (let s = 0; s < i.length;) {
    let a = i[s++].trim();
    o === 1 && (a = a.replace(/\s*(?:=)?(\w+)\s*/, "$1")), a.length && t.push(a);
    let c = Xl(i[s++]);
    t.length > n.length && n.push(c);
} return { type: o, mainBinding: r, cases: t, values: n }; }
function Xl(e) { if (!e)
    return []; let t = 0, n = [], o = [], r = /[{}]/g; r.lastIndex = 0; let i; for (; i = r.exec(e);) {
    let a = i.index;
    if (i[0] == "}") {
        if (n.pop(), n.length == 0) {
            let c = e.substring(t, a);
            oI.test(c) ? o.push(UA(c)) : o.push(c), t = a + 1;
        }
    }
    else {
        if (n.length == 0) {
            let c = e.substring(t, a);
            o.push(c), t = a + 1;
        }
        n.push("{");
    }
} let s = e.substring(t); return o.push(s), o; }
function $A(e, t, n, o, r, i, s, a, c) { let l = [], u = [], d = []; n.cases.push(s), n.create.push(l), n.remove.push(u), n.update.push(d); let p = Dm(Cs()).getInertBodyElement(a), h = Tl(p) || p; return h ? aI(e, t, n, o, r, l, u, d, h, i, c, 0) : 0; }
function aI(e, t, n, o, r, i, s, a, c, l, u, d) { let f = 0, p = c.firstChild; for (; p;) {
    let h = br(t, o, 1, null);
    switch (p.nodeType) {
        case Node.ELEMENT_NODE:
            let y = p, v = y.tagName.toLowerCase();
            if (Il.hasOwnProperty(v)) {
                Qc(i, QE, v, l, h), t.data[h] = v;
                let Pe = y.attributes;
                for (let Xe = 0; Xe < Pe.length; Xe++) {
                    let Pt = Pe.item(Xe), zr = Pt.name.toLowerCase(), lT = !!Pt.value.match(ps), Qf = y.namespaceURI, Yf = Qf && vm[Qf], Zf = Yf ? `:${Yf}:${v}` : v;
                    if (lT)
                        Dl.hasOwnProperty(zr) && hs(a, Pt.value, h, Pt.name, 0, eu(zr, Zf));
                    else if (Dl[zr]) {
                        let uT = Pt.value;
                        eu(zr, Zf) ? Hh(i, h, Pt.name, "unsafe:blocked") : Hh(i, h, Pt.name, uT);
                    }
                }
                let Me = { kind: 1, index: h, children: [] };
                e.push(Me), f = aI(Me.children, t, n, o, r, i, s, a, p, h, u, d + 1) | f, Fh(s, h, d);
            }
            break;
        case Node.TEXT_NODE:
            let D = p.textContent || "", b = D.match(ps);
            Qc(i, null, b ? "" : D, l, h), Fh(s, h, d), b && (f = hs(a, D, h, null, 0, null) | f), e.push({ kind: 0, index: h });
            break;
        case Node.COMMENT_NODE:
            let X = OA.exec(p.textContent || "");
            if (X) {
                let Pe = parseInt(X[1], 10), Me = u[Pe];
                Qc(i, YE, "", l, h), sI(e, t, o, r, l, Me, h), zA(s, h, d);
            }
            break;
    }
    p = p.nextSibling;
} return f; }
function Fh(e, t, n) { n === 0 && e.push(t); }
function zA(e, t, n) { n === 0 && (e.push(~t), e.push(t)); }
function GA(e, t, n) { e.push(iI(t.mainBinding), 2, -1 - t.mainBinding, n << 2 | 2); }
function WA(e, t, n) { e.push(t, 1, n << 2 | 3); }
function Qc(e, t, n, o, r) { t !== null && e.push(t), e.push(n, r, O_(0, o, r)); }
function Hh(e, t, n, o) { e.push(t << 1 | 1, n, o); }
function qA(e) { let t = e.toLowerCase(), [n, o] = Au(t, !1); return n === mm || n === ym ? `:${n}:${o}` : o; }
function eu(e, t) { let n = e.toLowerCase(), o = t ? qA(t) : "*", [r] = Au(o, !1), i = pp(); switch (i[`${o}|${n}`] || (r ? i[`:${r}:*|${n}`] : void 0) || i[`*|${n}`] || ae.NONE) {
    case ae.HTML: return Ru;
    case ae.STYLE: return Ou;
    case ae.SCRIPT: return xu;
    case ae.URL: return ks;
    case ae.RESOURCE_URL: return Ps;
    case ae.ATTRIBUTE_NO_BINDING: return Pu;
    default: return null;
} }
var Vh = 0, QA = /\[(�.+?�?)\]/, YA = /\[(�.+?�?)\]|(�\/?\*\d+:\d+�)/g, ZA = /({\s*)(VAR_(PLURAL|SELECT)(_\d+)?)(\s*,)/g, KA = /{([A-Z0-9_]+)}/g, JA = /�I18N_EXP_(ICU(_\d+)?)�/g, XA = /\/\*/, eR = /\d+\:(\d+)/;
function tR(e, t = {}) { let n = e; if (QA.test(e)) {
    let o = {}, r = [Vh];
    n = n.replace(YA, (i, s, a) => { let c = s || a, l = o[c] || []; if (l.length || (c.split("|").forEach(y => { let v = y.match(eR), D = v ? parseInt(v[1], 10) : Vh, b = XA.test(y); l.push([D, b, y]); }), o[c] = l), !l.length)
        throw new Error(`i18n postprocess: unmatched placeholder - ${c}`); let u = r[r.length - 1], d = 0; for (let y = 0; y < l.length; y++)
        if (l[y][0] === u) {
            d = y;
            break;
        } let [f, p, h] = l[d]; return p ? r.pop() : u !== f && r.push(f), l.splice(d, 1), h; });
} return Object.keys(t).length && (n = n.replace(ZA, (o, r, i, s, a, c) => t.hasOwnProperty(i) ? `${r}${t[i]}${c}` : o), n = n.replace(KA, (o, r) => t.hasOwnProperty(r) ? t[r] : o), n = n.replace(JA, (o, r) => { if (t.hasOwnProperty(r)) {
    let i = t[r];
    if (!i.length)
        throw new Error(`i18n postprocess: unmatched ICU - ${o} with key: ${r}`);
    return i.shift();
} return o; })), n; }
function Kd(e, t, n = -1) { let o = w(), r = g(), i = E + e, s = de(o.consts, t), a = Cn(); if (o.firstCreatePass && FA(o, a === null ? 0 : a.index, r, i, s, n), o.type === 2) {
    let f = r[K];
    f[A] |= 32;
}
else
    r[A] |= 32; let c = o.data[i], l = a === r[ue] ? null : a, u = ty(o, l, r), d = a && a.type & 8 ? r[a.index] : null; $_(r, i, a, n), SA(r, c.create, u, d), vc(!0); }
function Jd() { vc(!1); }
function cI(e, t, n) { Kd(e, t, n), Jd(); }
function lI(e, t) { let n = w(), o = de(n.consts, t); VA(n, e + E, o); }
function Xd(e) { let t = g(); return NA(z(t, he(), e)), Xd; }
function uI(e) { wA(w(), g(), e + E); }
function dI(e, t = {}) { return tR(e, t); }
function ef(e, t, n) { let o = g(), r = w(), i = M(); return of(r, o, o[T], i, e, t, n), ef; }
function tf(e, t) { let n = M(), o = g(), r = w(), i = hi(r.data), s = fy(i, n, o); return of(r, o, s, n, e, t), tf; }
function nf(e, t, n) { let o = g(), r = w(), i = M(); return (i.type & 3 || n) && dd(i, r, o, n, o[T], e, t, At(i, o, t)), nf; }
function of(e, t, n, o, r, i, s) { let a = !0, c = null; if ((o.type & 3 || s) && (c ??= At(o, t, i), dd(o, e, t, s, n, r, i, c) && (a = !1)), a) {
    let l = o.outputs?.[r], u = o.hostDirectiveOutputs?.[r];
    if (u && u.length)
        for (let d = 0; d < u.length; d += 2) {
            let f = u[d], p = u[d + 1];
            c ??= At(o, t, i), $n(o, t, f, p, r, c);
        }
    if (l && l.length)
        for (let d of l)
            c ??= At(o, t, i), $n(o, t, d, r, r, c);
} }
function fI(e = 1) { return bp(e); }
function nR(e, t) { let n = null, o = iw(e); for (let r = 0; r < t.length; r++) {
    let i = t[r];
    if (i === "*") {
        n = r;
        continue;
    }
    if (o === null ? jm(e, i, !0) : cw(o, i))
        return r;
} return n; }
function pI(e) { let t = g()[K][ue]; if (!t.projection) {
    let n = e ? e.length : 1, o = t.projection = To(n, null), r = o.slice(), i = t.child;
    for (; i !== null;) {
        if (i.type !== 128) {
            let s = e ? nR(i, e) : 0;
            s !== null && (r[s] ? r[s].projectionNext = i : o[s] = i, r[s] = i);
        }
        i = i.next;
    }
} }
function hI(e, t = 0, n, o, r, i) { let s = g(), a = w(), c = o ? e + 1 : null; c !== null && cn(s, a, c, o, r, i, null, n); let l = gn(a, E + e, 16, null, n || null); l.projection === null && (l.projection = t), pc(); let d = !s[se] || Oo(); s[K][ue].projection[l.projection] === null && c !== null ? oR(s, a, c) : d && !oo(l) && xw(a, s, l); }
function oR(e, t, n) { let o = E + n, r = t.data[o], i = e[o], s = sr(i, r.tView.ssrId), a = ao(e, r, void 0, { dehydratedView: s }); co(i, a, 0, rn(r, s)); }
function rf(e, t, n, o) { return Dv(e, t, n, o), rf; }
function sf(e, t, n) { return Iv(e, t, n), sf; }
function gI(e) { let t = g(), n = w(), o = gi(); ko(o + 1); let r = gd(n, o); if (e.dirty && gp(t) === ((r.metadata.flags & 2) === 2)) {
    if (r.matches === null)
        e.reset([]);
    else {
        let i = Tv(t, o);
        e.reset(i, wg), e.notifyOnChanges();
    }
    return !0;
} return !1; }
function mI() { return hd(g(), gi()); }
function af(e, t, n, o, r) { return Mv(t, Dv(e, n, o, r)), af; }
function cf(e, t, n, o) { return Mv(e, Iv(t, n, o)), cf; }
function yI(e = 1) { ko(gi() + e); }
function vI(e) { let t = hc(); return Mt(t, E + e); }
function Ai(e, t) { return e << 17 | t << 2; }
function ln(e) { return e >> 17 & 32767; }
function rR(e) { return (e & 2) == 2; }
function iR(e, t) { return e & 131071 | t << 17; }
function tu(e) { return e | 2; }
function Qn(e) { return (e & 131068) >> 2; }
function Yc(e, t) { return e & -131069 | t << 2; }
function sR(e) { return (e & 1) === 1; }
function nu(e) { return e | 1; }
function aR(e, t, n, o, r, i) { let s = i ? t.classBindings : t.styleBindings, a = ln(s), c = Qn(s); e[o] = n; let l = !1, u; if (Array.isArray(n)) {
    let d = n;
    u = d[1], (u === null || ri(d, u) > 0) && (l = !0);
}
else
    u = n; if (r)
    if (c !== 0) {
        let f = ln(e[a + 1]);
        e[o + 1] = Ai(f, a), f !== 0 && (e[f + 1] = Yc(e[f + 1], o)), e[a + 1] = iR(e[a + 1], o);
    }
    else
        e[o + 1] = Ai(a, 0), a !== 0 && (e[a + 1] = Yc(e[a + 1], o)), a = o;
else
    e[o + 1] = Ai(c, 0), a === 0 ? a = o : e[c + 1] = Yc(e[c + 1], o), c = o; l && (e[o + 1] = tu(e[o + 1])), jh(e, u, o, !0), jh(e, u, o, !1), cR(t, u, e, o, i), s = Ai(a, c), i ? t.classBindings = s : t.styleBindings = s; }
function cR(e, t, n, o, r) { let i = r ? e.residualClasses : e.residualStyles; i != null && typeof t == "string" && ri(i, t) >= 0 && (n[o + 1] = nu(n[o + 1])); }
function jh(e, t, n, o) { let r = e[n + 1], i = t === null, s = o ? ln(r) : Qn(r), a = !1; for (; s !== 0 && (a === !1 || i);) {
    let c = e[s], l = e[s + 1];
    lR(c, t) && (a = !0, e[s + 1] = o ? nu(l) : tu(l)), s = o ? ln(l) : Qn(l);
} a && (e[n + 1] = o ? tu(r) : nu(r)); }
function lR(e, t) { return e === null || t == null || (Array.isArray(e) ? e[1] : e) === t ? !0 : Array.isArray(e) && typeof t == "string" ? ri(e, t) >= 0 : !1; }
var ie = { textEnd: 0, key: 0, keyEnd: 0, value: 0, valueEnd: 0 };
function EI(e) { return e.substring(ie.key, ie.keyEnd); }
function uR(e) { return e.substring(ie.value, ie.valueEnd); }
function dR(e) { return CI(e), II(e, Yn(e, 0, ie.textEnd)); }
function II(e, t) { let n = ie.textEnd; return n === t ? -1 : (t = ie.keyEnd = pR(e, ie.key = t, n), Yn(e, t, n)); }
function fR(e) { return CI(e), DI(e, Yn(e, 0, ie.textEnd)); }
function DI(e, t) { let n = ie.textEnd, o = ie.key = Yn(e, t, n); return n === o ? -1 : (o = ie.keyEnd = hR(e, o, n), o = Bh(e, o, n, 58), o = ie.value = Yn(e, o, n), o = ie.valueEnd = gR(e, o, n), Bh(e, o, n, 59)); }
function CI(e) { ie.key = 0, ie.keyEnd = 0, ie.value = 0, ie.valueEnd = 0, ie.textEnd = e.length; }
function Yn(e, t, n) { for (; t < n && e.charCodeAt(t) <= 32;)
    t++; return t; }
function pR(e, t, n) { for (; t < n && e.charCodeAt(t) > 32;)
    t++; return t; }
function hR(e, t, n) { let o; for (; t < n && ((o = e.charCodeAt(t)) === 45 || o === 95 || (o & -33) >= 65 && (o & -33) <= 90 || o >= 48 && o <= 57);)
    t++; return t; }
function Bh(e, t, n, o) { return t = Yn(e, t, n), t < n && t++, t; }
function gR(e, t, n) { let o = -1, r = -1, i = -1, s = t, a = s; for (; s < n;) {
    let c = e.charCodeAt(s++);
    if (c === 59)
        return a;
    c === 34 || c === 39 ? a = s = Uh(e, c, s, n) : t === s - 4 && i === 85 && r === 82 && o === 76 && c === 40 ? a = s = Uh(e, 41, s, n) : c > 32 && (a = s), i = r, r = o, o = c & -33;
} return a; }
function Uh(e, t, n, o) { let r = -1, i = n; for (; i < o;) {
    let s = e.charCodeAt(i++);
    if (s == t && r !== 92)
        return i;
    s == 92 && r === 92 ? r = 0 : r = s;
} throw new Error; }
function lf(e, t, n) { return NI(e, t, n, !1), lf; }
function uf(e, t) { return NI(e, t, null, !0), uf; }
function TI(e) { wI(bI, mR, e, !1); }
function mR(e, t) { for (let n = fR(t); n >= 0; n = DI(t, n))
    bI(e, EI(t), uR(t)); }
function MI(e) { wI(TR, yR, e, !0); }
function yR(e, t) { for (let n = dR(t); n >= 0; n = II(t, n))
    Mo(e, EI(t), !0); }
function NI(e, t, n, o) { let r = g(), i = w(), s = Ye(2); if (i.firstUpdatePass && SI(i, e, s, o), t !== L && z(r, s, t)) {
    let a = i.data[J()];
    AI(i, a, r, r[T], e, r[s + 1] = NR(t, n), o, s);
} }
function wI(e, t, n, o) { let r = w(), i = Ye(2); r.firstUpdatePass && SI(r, null, i, o); let s = g(); if (n !== L && z(s, i, n)) {
    let a = r.data[J()];
    if (RI(a, o) && !_I(r, i)) {
        let c = o ? a.classesWithoutHost : a.stylesWithoutHost;
        c !== null && (n = Zr(c, n || "")), Jl(r, a, s, n, o);
    }
    else
        MR(r, a, s, s[T], s[i + 1], s[i + 1] = CR(e, t, n), o, i);
} }
function _I(e, t) { return t >= e.expandoStartIndex; }
function SI(e, t, n, o) { let r = e.data; if (r[n + 1] === null) {
    let i = r[J()], s = _I(e, n);
    RI(i, o) && t === null && !s && (t = !1), t = vR(r, i, t, o), aR(r, i, t, n, s, o);
} }
function vR(e, t, n, o) { let r = hi(e), i = o ? t.residualClasses : t.residualStyles; if (r === null)
    (o ? t.classBindings : t.styleBindings) === 0 && (n = Zc(null, e, t, n, o), n = hr(n, t.attrs, o), i = null);
else {
    let s = t.directiveStylingLast;
    if (s === -1 || e[s] !== r)
        if (n = Zc(r, e, t, n, o), i === null) {
            let c = ER(e, t, o);
            c !== void 0 && Array.isArray(c) && (c = Zc(null, e, t, c[1], o), c = hr(c, t.attrs, o), IR(e, t, o, c));
        }
        else
            i = DR(e, t, o);
} return i !== void 0 && (o ? t.residualClasses = i : t.residualStyles = i), n; }
function ER(e, t, n) { let o = n ? t.classBindings : t.styleBindings; if (Qn(o) !== 0)
    return e[ln(o)]; }
function IR(e, t, n, o) { let r = n ? t.classBindings : t.styleBindings; e[ln(r)] = o; }
function DR(e, t, n) { let o, r = t.directiveEnd; for (let i = 1 + t.directiveStylingLast; i < r; i++) {
    let s = e[i].hostAttrs;
    o = hr(o, s, n);
} return hr(o, t.attrs, n); }
function Zc(e, t, n, o, r) { let i = null, s = n.directiveEnd, a = n.directiveStylingLast; for (a === -1 ? a = n.directiveStart : a++; a < s && (i = t[a], o = hr(o, i.hostAttrs, r), i !== e);)
    a++; return e !== null && (n.directiveStylingLast = a), o; }
function hr(e, t, n) { let o = n ? 1 : 2, r = -1; if (t !== null)
    for (let i = 0; i < t.length; i++) {
        let s = t[i];
        typeof s == "number" ? r = s : r === o && (Array.isArray(e) || (e = e === void 0 ? [] : ["", e]), Mo(e, s, n ? !0 : t[++i]));
    } return e === void 0 ? null : e; }
function CR(e, t, n) { if (n == null || n === "")
    return F; let o = [], r = dt(n); if (Array.isArray(r))
    for (let i = 0; i < r.length; i++)
        e(o, r[i], !0);
else if (r instanceof Set)
    for (let i of r)
        e(o, i, !0);
else if (typeof r == "object")
    for (let i in r)
        r.hasOwnProperty(i) && e(o, i, r[i]);
else
    typeof r == "string" && t(o, r); return o; }
function bI(e, t, n) { Mo(e, t, dt(n)); }
function TR(e, t, n) { let o = String(t); o !== "" && !o.includes(" ") && Mo(e, o, n); }
function MR(e, t, n, o, r, i, s, a) { r === L && (r = F); let c = 0, l = 0, u = 0 < r.length ? r[0] : null, d = 0 < i.length ? i[0] : null; for (; u !== null || d !== null;) {
    let f = c < r.length ? r[c + 1] : void 0, p = l < i.length ? i[l + 1] : void 0, h = null, y;
    u === d ? (c += 2, l += 2, f !== p && (h = d, y = p)) : d === null || u !== null && u < d ? (c += 2, h = u) : (l += 2, h = d, y = p), h !== null && AI(e, t, n, o, h, y, s, a), u = c < r.length ? r[c] : null, d = l < i.length ? i[l] : null;
} }
function AI(e, t, n, o, r, i, s, a) { if (!(t.type & 3))
    return; let c = e.data, l = c[a + 1], u = sR(l) ? $h(c, t, n, r, Qn(l), s) : void 0; if (!gs(u)) {
    gs(i) || rR(l) && (i = $h(c, null, n, r, a, s));
    let d = Bt(J(), n);
    Lw(o, s, d, r, i);
} }
function $h(e, t, n, o, r, i) { let s = t === null, a; for (; r > 0;) {
    let c = e[r], l = Array.isArray(c), u = l ? c[1] : c, d = u === null, f = n[r + 1];
    f === L && (f = d ? F : void 0);
    let p = d ? oi(f, o) : u === o ? f : void 0;
    if (l && !gs(p) && (p = oi(c, o)), gs(p) && (a = p, s))
        return a;
    let h = e[r + 1];
    r = s ? ln(h) : Qn(h);
} if (t !== null) {
    let c = i ? t.residualClasses : t.residualStyles;
    c != null && (a = oi(c, o));
} return a; }
function gs(e) { return e !== void 0; }
function NR(e, t) { return e == null || e === "" || (typeof t == "string" ? e = e + t : typeof e == "object" && (e = Yr(dt(e)))), e; }
function RI(e, t) { return (e.flags & (t ? 8 : 16)) !== 0; }
function OI(e, t = "") { let n = g(), o = w(), r = e + E, i = o.firstCreatePass ? gn(o, r, 1, t, null) : o.data[r], s = kI(o, n, i, t); n[r] = s, xo() && Ku(o, n, s, i), qe(i, !1); }
var kI = (e, t, n, o) => (Ve(!0), Su(t[T], o));
function wR(e, t, n, o) { let r = !Os(t, n); if (Ve(r), r)
    return Su(t[T], o); let i = t[se]; return Or(i, e, t, n); }
function xI() { kI = wR; }
function PI(e, t) { let n = !1, o = Qe(); for (let i = 1; i < t.length; i += 2)
    n = z(e, o++, t[i]) || n; if (yc(o), !n)
    return L; let r = t[0]; for (let i = 1; i < t.length; i += 2)
    r += N(t[i]) + (i + 1 !== t.length ? t[i + 1] : ""); return r; }
function LI(e, t, n, o = "") { return z(e, he(), n) ? t + N(n) + o : L; }
function FI(e, t, n, o, r, i = "") { let s = Qe(), a = sn(e, s, n, r); return Ye(2), a ? t + N(n) + o + N(r) + i : L; }
function HI(e, t, n, o, r, i, s, a = "") { let c = Qe(), l = aa(e, c, n, r, s); return Ye(3), l ? t + N(n) + o + N(r) + i + N(s) + a : L; }
function VI(e, t, n, o, r, i, s, a, c, l = "") { let u = Qe(), d = ke(e, u, n, r, s, c); return Ye(4), d ? t + N(n) + o + N(r) + i + N(s) + a + N(c) + l : L; }
function jI(e, t, n, o, r, i, s, a, c, l, u, d = "") { let f = Qe(), p = ke(e, f, n, r, s, c); return p = z(e, f + 4, u) || p, Ye(5), p ? t + N(n) + o + N(r) + i + N(s) + a + N(c) + l + N(u) + d : L; }
function BI(e, t, n, o, r, i, s, a, c, l, u, d, f, p = "") { let h = Qe(), y = ke(e, h, n, r, s, c); return y = sn(e, h + 4, u, f) || y, Ye(6), y ? t + N(n) + o + N(r) + i + N(s) + a + N(c) + l + N(u) + d + N(f) + p : L; }
function UI(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, y = "") { let v = Qe(), D = ke(e, v, n, r, s, c); return D = aa(e, v + 4, u, f, h) || D, Ye(7), D ? t + N(n) + o + N(r) + i + N(s) + a + N(c) + l + N(u) + d + N(f) + p + N(h) + y : L; }
function $I(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, y, v, D = "") { let b = Qe(), X = ke(e, b, n, r, s, c); return X = ke(e, b + 4, u, f, h, v) || X, Ye(8), X ? t + N(n) + o + N(r) + i + N(s) + a + N(c) + l + N(u) + d + N(f) + p + N(h) + y + N(v) + D : L; }
function df(e) { return Ia("", e), df; }
function Ia(e, t, n) { let o = g(), r = LI(o, e, t, n); return r !== L && gt(o, J(), r), Ia; }
function ff(e, t, n, o, r) { let i = g(), s = FI(i, e, t, n, o, r); return s !== L && gt(i, J(), s), ff; }
function pf(e, t, n, o, r, i, s) { let a = g(), c = HI(a, e, t, n, o, r, i, s); return c !== L && gt(a, J(), c), pf; }
function hf(e, t, n, o, r, i, s, a, c) { let l = g(), u = VI(l, e, t, n, o, r, i, s, a, c); return u !== L && gt(l, J(), u), hf; }
function gf(e, t, n, o, r, i, s, a, c, l, u) { let d = g(), f = jI(d, e, t, n, o, r, i, s, a, c, l, u); return f !== L && gt(d, J(), f), gf; }
function mf(e, t, n, o, r, i, s, a, c, l, u, d, f) { let p = g(), h = BI(p, e, t, n, o, r, i, s, a, c, l, u, d, f); return h !== L && gt(p, J(), h), mf; }
function yf(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h) { let y = g(), v = UI(y, e, t, n, o, r, i, s, a, c, l, u, d, f, p, h); return v !== L && gt(y, J(), v), yf; }
function vf(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, y, v) { let D = g(), b = $I(D, e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, y, v); return b !== L && gt(D, J(), b), vf; }
function Ef(e) { let t = g(), n = PI(t, e); return n !== L && gt(t, J(), n), Ef; }
function gt(e, t, n) { let o = Bt(t, e); Sm(e[T], o, n); }
function If(e, t, n) { Rd(t) && (t = t()); let o = g(), r = he(); if (z(o, r, t)) {
    let i = w(), s = Ee();
    Xu(s, o, e, t, o[T], n);
} return If; }
function zI(e, t) { let n = Rd(e); return n && e.set(t), n; }
function Df(e, t) { let n = g(), o = w(), r = M(); return of(o, n, n[T], r, e, t), Df; }
var GI = {};
function Cf(e) { Q("NgLet"); let t = w(), n = g(), o = e + E, r = gn(t, o, 128, null, null); return qe(r, !1), Ao(t, n, o, GI), Cf; }
function WI(e) { let t = w(), n = g(), o = J(); return Ao(t, n, o, e), e; }
function qI(e) { let t = hc(), n = Mt(t, E + e); if (n === GI)
    throw new _(314, !1); return n; }
function QI(e, t) { let n = w(), o = g(), r = o[T], i = "data-ng-source-location"; for (let [s, a, c, l] of t) {
    let u = Ut(n, s + E), d = Bt(s + E, o);
    if (!d.hasAttribute(i)) {
        let f = `${e}@o:${a},l:${c},c:${l}`;
        r.setAttribute(d, i, f);
    }
} }
function YI(e) { return z(g(), he(), e) ? N(e) : L; }
function ZI(e, t, n = "") { return LI(g(), e, t, n); }
function KI(e, t, n, o, r = "") { return FI(g(), e, t, n, o, r); }
function JI(e, t, n, o, r, i, s = "") { return HI(g(), e, t, n, o, r, i, s); }
function XI(e, t, n, o, r, i, s, a, c = "") { return VI(g(), e, t, n, o, r, i, s, a, c); }
function eD(e, t, n, o, r, i, s, a, c, l, u = "") { return jI(g(), e, t, n, o, r, i, s, a, c, l, u); }
function tD(e, t, n, o, r, i, s, a, c, l, u, d, f = "") { return BI(g(), e, t, n, o, r, i, s, a, c, l, u, d, f); }
function nD(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h = "") { return UI(g(), e, t, n, o, r, i, s, a, c, l, u, d, f, p, h); }
function oD(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, y, v = "") { return $I(g(), e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, y, v); }
function rD(e) { return PI(g(), e); }
function iD(e, t, n) { let o = fe() + e, r = g(); return r[o] === L ? Be(r, o, t(n, r)) : fo(r, o); }
function zh(e, t, n) { let o = w(); o.firstCreatePass && sD(t, o.data, o.blueprint, Ae(e), n); }
function sD(e, t, n, o, r) { if (e = G(e), Array.isArray(e))
    for (let i = 0; i < e.length; i++)
        sD(e[i], t, n, o, r);
else {
    let i = w(), s = g(), a = M(), c = ii(e) ? e : G(e.provide), l = lp(e), u = a.providerIndexes & 1048575, d = a.directiveStart, f = a.providerIndexes >> 20;
    if (ii(e) || !e.multi) {
        let p = new en(l, r, uo, null), h = Jc(c, t, r ? u : u + f, d);
        h === -1 ? (rl(qi(a, s), i, c), Kc(i, e, t.length), t.push(c), a.directiveStart++, a.directiveEnd++, r && (a.providerIndexes += 1048576), n.push(p), s.push(p)) : (n[h] = p, s[h] = p);
    }
    else {
        let p = Jc(c, t, u + f, d), h = Jc(c, t, u, u + f), y = p >= 0 && n[p], v = h >= 0 && n[h];
        if (r && !v || !r && !y) {
            rl(qi(a, s), i, c);
            let D = bR(r ? SR : _R, n.length, r, o, l, e);
            !r && v && (n[h].providerFactory = D), Kc(i, e, t.length, 0), t.push(c), a.directiveStart++, a.directiveEnd++, r && (a.providerIndexes += 1048576), n.push(D), s.push(D);
        }
        else {
            let D = aD(n[r ? h : p], l, !r && o);
            Kc(i, e, p > -1 ? p : h, D);
        }
        !r && o && v && n[h].componentProviders++;
    }
} }
function Kc(e, t, n, o) { let r = ii(t), i = ap(t); if (r || i) {
    let c = (i ? G(t.useClass) : t).prototype.ngOnDestroy;
    if (c) {
        let l = e.destroyHooks || (e.destroyHooks = []);
        if (!r && t.multi) {
            let u = l.indexOf(n);
            u === -1 ? l.push(n, [o, c]) : l[u + 1].push(o, c);
        }
        else
            l.push(n, c);
    }
} }
function aD(e, t, n) { return n && e.componentProviders++, e.multi.push(t) - 1; }
function Jc(e, t, n, o) { for (let r = n; r < o; r++)
    if (t[r] === e)
        return r; return -1; }
function _R(e, t, n, o, r) { return ou(this.multi, []); }
function SR(e, t, n, o, r) { let i = this.multi, s; if (this.providerFactory) {
    let a = this.providerFactory.componentProviders, c = Ko(o, o[m], this.providerFactory.index, r);
    s = c.slice(0, a), ou(i, s);
    for (let l = a; l < c.length; l++)
        s.push(c[l]);
}
else
    s = [], ou(i, s); return s; }
function ou(e, t) { for (let n = 0; n < e.length; n++) {
    let o = e[n];
    t.push(o());
} return t; }
function bR(e, t, n, o, r, i) { let s = new en(e, n, uo, null); return s.multi = [], s.index = t, s.componentProviders = 0, aD(s, r, o && !n), s; }
function cD(e, t) { return n => { n.providersResolver = (o, r) => zh(o, r ? r(e) : e, !1), t && (n.viewProvidersResolver = (o, r) => zh(o, r ? r(t) : t, !0)); }; }
function lD(e) { return t => { e.length < 1 || (t.getExternalStyles = n => e.map(r => r + "?ngcomp" + (n ? "=" + encodeURIComponent(n) : "") + "&e=" + t.encapsulation)); }; }
function uD(e, t, n) { let o = e.\u0275cmp; o.directiveDefs = ls(t, kv), o.pipeDefs = ls(n, Ue); }
function dD(e, t) { return Je(() => { let n = ei(e); n.declarations = Ri(t.declarations || F), n.imports = Ri(t.imports || F), n.exports = Ri(t.exports || F), t.bootstrap && (n.bootstrap = Ri(t.bootstrap)), Un.registerNgModule(e, t); }); }
function Ri(e) { if (typeof e == "function")
    return e; let t = Fe(e); return t.some(Kr) ? () => t.map(G).map(Gh) : t.map(Gh); }
function Gh(e) { return cd(e) ? e.ngModule : e; }
function fD(e, t) { let n = fe() + e, o = g(); return o[n] === L ? Be(o, n, t()) : fo(o, n); }
function pD(e, t, n) { return CD(g(), fe(), e, t, n); }
function hD(e, t, n, o) { return TD(g(), fe(), e, t, n, o); }
function gD(e, t, n, o, r) { return MD(g(), fe(), e, t, n, o, r); }
function mD(e, t, n, o, r, i, s) { return ND(g(), fe(), e, t, n, o, r, i); }
function yD(e, t, n, o, r, i, s) { let a = fe() + e, c = g(), l = ke(c, a, n, o, r, i); return z(c, a + 4, s) || l ? Be(c, a + 5, t(n, o, r, i, s)) : fo(c, a + 5); }
function vD(e, t, n, o, r, i, s, a) { let c = fe() + e, l = g(), u = ke(l, c, n, o, r, i); return sn(l, c + 4, s, a) || u ? Be(l, c + 6, t(n, o, r, i, s, a)) : fo(l, c + 6); }
function ED(e, t, n, o, r, i, s, a, c) { let l = fe() + e, u = g(), d = ke(u, l, n, o, r, i); return aa(u, l + 4, s, a, c) || d ? Be(u, l + 7, t(n, o, r, i, s, a, c)) : fo(u, l + 7); }
function ID(e, t, n, o, r, i, s, a, c, l) { let u = fe() + e, d = g(), f = ke(d, u, n, o, r, i); return ke(d, u + 4, s, a, c, l) || f ? Be(d, u + 8, t(n, o, r, i, s, a, c, l)) : fo(d, u + 8); }
function DD(e, t, n) { return wD(g(), fe(), e, t, n); }
function jr(e, t) { let n = e[t]; return n === L ? void 0 : n; }
function CD(e, t, n, o, r, i) { let s = t + n; return z(e, s, r) ? Be(e, s + 1, i ? o.call(i, r) : o(r)) : jr(e, s + 1); }
function TD(e, t, n, o, r, i, s) { let a = t + n; return sn(e, a, r, i) ? Be(e, a + 2, s ? o.call(s, r, i) : o(r, i)) : jr(e, a + 2); }
function MD(e, t, n, o, r, i, s, a) { let c = t + n; return aa(e, c, r, i, s) ? Be(e, c + 3, a ? o.call(a, r, i, s) : o(r, i, s)) : jr(e, c + 3); }
function ND(e, t, n, o, r, i, s, a, c) { let l = t + n; return ke(e, l, r, i, s, a) ? Be(e, l + 4, c ? o.call(c, r, i, s, a) : o(r, i, s, a)) : jr(e, l + 4); }
function wD(e, t, n, o, r, i) { let s = t + n, a = !1; for (let c = 0; c < r.length; c++)
    z(e, s++, r[c]) && (a = !0); return a ? Be(e, s, o.apply(i, r)) : jr(e, s); }
function _D(e, t) { let n = w(), o, r = e + E; n.firstCreatePass ? (o = AR(t, n.pipeRegistry), n.data[r] = o, o.onDestroy && (n.destroyHooks ??= []).push(r, o.onDestroy)) : o = n.data[r]; let i = o.factory || (o.factory = ni(o.type, !0)), s, a = Ft(uo); try {
    let c = Wi(!1), l = i();
    return Wi(c), Ao(n, g(), r, l), l;
}
finally {
    Ft(a);
} }
function AR(e, t) { if (t)
    for (let n = t.length - 1; n >= 0; n--) {
        let o = t[n];
        if (e === o.name)
            return o;
    } }
function SD(e, t, n) { let o = e + E, r = g(), i = Mt(r, o); return Br(r, o) ? CD(r, fe(), t, i.transform, n, i) : i.transform(n); }
function bD(e, t, n, o) { let r = e + E, i = g(), s = Mt(i, r); return Br(i, r) ? TD(i, fe(), t, s.transform, n, o, s) : s.transform(n, o); }
function AD(e, t, n, o, r) { let i = e + E, s = g(), a = Mt(s, i); return Br(s, i) ? MD(s, fe(), t, a.transform, n, o, r, a) : a.transform(n, o, r); }
function RD(e, t, n, o, r, i) { let s = e + E, a = g(), c = Mt(a, s); return Br(a, s) ? ND(a, fe(), t, c.transform, n, o, r, i, c) : c.transform(n, o, r, i); }
function OD(e, t, n) { let o = e + E, r = g(), i = Mt(r, o); return Br(r, o) ? wD(r, fe(), t, i.transform, n, i) : i.transform.apply(i, n); }
function Br(e, t) { return e[m].data[t].pure; }
function kD(e, t) { return Xs(e, t); }
function xD(e, t) { return () => { try {
    return Un.getComponentDependencies(e, t).dependencies;
}
catch (n) {
    throw console.error(`Computing dependencies in local compilation mode for the component "${e.name}" failed with the exception:`, n), n;
} }; }
function PD(e, t) { let n = W(e); n !== null && (n.debugInfo = t); }
function LD(e, t, n) { let o = `./@ng/component?c=${e}&t=${encodeURIComponent(t)}`; return new URL(o, n).href; }
function FD(e, t, n, o, r = null, i = null) { let s = W(e); t.apply(null, [e, n, ...o]); let { newDef: a, oldDef: c } = RR(s, W(e)); if (e[yt] = a, c.tView) {
    let l = DM().values();
    for (let u of l)
        We(u) && u[q] === null && Bi(r, i, a, c, u);
} }
function RR(e, t) { let n = Z({}, e); return { newDef: Object.assign(e, t, { directiveDefs: n.directiveDefs, pipeDefs: n.pipeDefs, setInput: n.setInput, type: n.type }), oldDef: n }; }
function Bi(e, t, n, o, r) { let i = r[m]; if (i === o.tView) {
    kR(e, t, n, o, r);
    return;
} for (let s = E; s < i.bindingStartIndex; s++) {
    let a = r[s];
    if (ee(a)) {
        re(a[j]) && Bi(e, t, n, o, a[j]);
        for (let c = V; c < a.length; c++)
            Bi(e, t, n, o, a[c]);
    }
    else
        re(a) && Bi(e, t, n, o, a);
} }
function OR(e, t) { e.componentReplaced?.(t.id); }
function kR(e, t, n, o, r) { let i = r[H], s = r[j], a = r[q], c = r[ue], l = r[O].get(U, null), u = () => { if (o.encapsulation === Oe.ShadowDom || o.encapsulation === Oe.ExperimentalIsolatedShadowDom) {
    let h = s.cloneNode(!1);
    s.replaceWith(h), s = h;
} let d = Bm(n), f = Ls(a, d, i, Vu(n), s, c, null, null, null, null, null); xR(a, r, f, c.index), Ar(r[m], r), ir(r); let p = r[$e].rendererFactory; OR(p, o), f[T] = p.createRenderer(s, n), Xm(r[m], r), PR(c), Ks(d, f, i), vy(d, f, d.template, i); }; l === null ? Wh(e, t, u) : l.run(() => Wh(e, t, u)); }
function Wh(e, t, n) {
    try {
        n();
    }
    catch (o) {
        let r = o;
        if (t !== null && r.message) {
            let i = r.message + (r.stack ? `
` + r.stack : "");
            e?.hot?.send?.("angular:invalidate", { id: t, message: i, error: !0 });
        }
        throw o;
    }
}
function xR(e, t, n, o) { for (let r = E; r < e[m].bindingStartIndex; r++) {
    let i = e[r];
    if ((re(i) || ee(i)) && i[le] === t) {
        i[le] = n;
        break;
    }
} e[Dt] === t && (e[Dt] = n), e[No] === t && (e[No] = n), n[le] = t[le], t[le] = null, e[o] = n; }
function PR(e) { if (e.projection !== null) {
    for (let t of e.projection)
        ys(t) && (t.projectionNext = null, t.flags &= -3);
    e.projection = null;
} }
var ge = { \u0275\u0275animateEnter: zo, \u0275\u0275animateEnterListener: Go, \u0275\u0275animateLeave: Wo, \u0275\u0275animateLeaveListener: us, \u0275\u0275attribute: Vd, \u0275\u0275defineComponent: Ov, \u0275\u0275defineDirective: xv, \u0275\u0275defineInjectable: B, \u0275\u0275defineInjector: Io, \u0275\u0275defineNgModule: Td, \u0275\u0275definePipe: Pv, \u0275\u0275directiveInject: uo, \u0275\u0275getInheritedFactory: Cg, \u0275\u0275inject: Le, \u0275\u0275injectAttribute: vs, \u0275\u0275invalidFactory: Jy, \u0275\u0275invalidFactoryDep: ti, \u0275\u0275templateRefExtractor: kD, \u0275\u0275resetView: dc, \u0275\u0275HostDirectivesFeature: Vv, \u0275\u0275NgOnChangesFeature: sg, \u0275\u0275ControlFeature: Hv, \u0275\u0275ProvidersFeature: cD, \u0275\u0275InheritDefinitionFeature: Md, \u0275\u0275ExternalStylesFeature: lD, \u0275\u0275nextContext: fI, \u0275\u0275namespaceHTML: Mc, \u0275\u0275namespaceMathML: Tc, \u0275\u0275namespaceSVG: Cc, \u0275\u0275enableBindings: ac, \u0275\u0275disableBindings: cc, \u0275\u0275elementStart: fr, \u0275\u0275elementEnd: ga, \u0275\u0275element: Bd, \u0275\u0275elementContainerStart: va, \u0275\u0275elementContainerEnd: Hr, \u0275\u0275domElement: Ud, \u0275\u0275domElementStart: ma, \u0275\u0275domElementEnd: ya, \u0275\u0275domElementContainer: Wd, \u0275\u0275domElementContainerStart: Ea, \u0275\u0275domElementContainerEnd: Gd, \u0275\u0275domTemplate: wd, \u0275\u0275domListener: nf, \u0275\u0275elementContainer: zd, \u0275\u0275pureFunction0: fD, \u0275\u0275pureFunction1: pD, \u0275\u0275pureFunction2: hD, \u0275\u0275pureFunction3: gD, \u0275\u0275pureFunction4: mD, \u0275\u0275pureFunction5: yD, \u0275\u0275pureFunction6: vD, \u0275\u0275pureFunction7: ED, \u0275\u0275pureFunction8: ID, \u0275\u0275pureFunctionV: DD, \u0275\u0275getCurrentView: WE, \u0275\u0275restoreView: uc, \u0275\u0275listener: ef, \u0275\u0275projection: hI, \u0275\u0275syntheticHostProperty: Yd, \u0275\u0275syntheticHostListener: tf, \u0275\u0275pipeBind1: SD, \u0275\u0275pipeBind2: bD, \u0275\u0275pipeBind3: AD, \u0275\u0275pipeBind4: RD, \u0275\u0275pipeBindV: OD, \u0275\u0275projectionDef: pI, \u0275\u0275domProperty: Qd, \u0275\u0275ariaProperty: Hd, \u0275\u0275property: jd, \u0275\u0275control: av, \u0275\u0275controlCreate: iv, \u0275\u0275pipe: _D, \u0275\u0275queryRefresh: gI, \u0275\u0275queryAdvance: yI, \u0275\u0275viewQuery: sf, \u0275\u0275viewQuerySignal: cf, \u0275\u0275loadQuery: mI, \u0275\u0275contentQuery: rf, \u0275\u0275contentQuerySignal: af, \u0275\u0275reference: vI, \u0275\u0275classMap: MI, \u0275\u0275styleMap: TI, \u0275\u0275styleProp: lf, \u0275\u0275classProp: uf, \u0275\u0275advance: Um, \u0275\u0275template: Nd, \u0275\u0275conditional: VE, \u0275\u0275conditionalCreate: HE, \u0275\u0275conditionalBranchCreate: ha, \u0275\u0275defer: hE, \u0275\u0275deferWhen: gE, \u0275\u0275deferOnIdle: EE, \u0275\u0275deferOnImmediate: CE, \u0275\u0275deferOnTimer: NE, \u0275\u0275deferOnHover: SE, \u0275\u0275deferOnInteraction: RE, \u0275\u0275deferOnViewport: xE, \u0275\u0275deferPrefetchWhen: mE, \u0275\u0275deferPrefetchOnIdle: IE, \u0275\u0275deferPrefetchOnImmediate: TE, \u0275\u0275deferPrefetchOnTimer: wE, \u0275\u0275deferPrefetchOnHover: bE, \u0275\u0275deferPrefetchOnInteraction: OE, \u0275\u0275deferPrefetchOnViewport: PE, \u0275\u0275deferHydrateWhen: yE, \u0275\u0275deferHydrateNever: vE, \u0275\u0275deferHydrateOnIdle: DE, \u0275\u0275deferHydrateOnImmediate: ME, \u0275\u0275deferHydrateOnTimer: _E, \u0275\u0275deferHydrateOnHover: AE, \u0275\u0275deferHydrateOnInteraction: kE, \u0275\u0275deferHydrateOnViewport: LE, \u0275\u0275deferEnableTimerScheduling: eE, \u0275\u0275repeater: $E, \u0275\u0275repeaterCreate: UE, \u0275\u0275repeaterTrackByIndex: jE, \u0275\u0275repeaterTrackByIdentity: BE, \u0275\u0275componentInstance: FE, \u0275\u0275text: OI, \u0275\u0275textInterpolate: df, \u0275\u0275textInterpolate1: Ia, \u0275\u0275textInterpolate2: ff, \u0275\u0275textInterpolate3: pf, \u0275\u0275textInterpolate4: hf, \u0275\u0275textInterpolate5: gf, \u0275\u0275textInterpolate6: mf, \u0275\u0275textInterpolate7: yf, \u0275\u0275textInterpolate8: vf, \u0275\u0275textInterpolateV: Ef, \u0275\u0275i18n: cI, \u0275\u0275i18nAttributes: lI, \u0275\u0275i18nExp: Xd, \u0275\u0275i18nStart: Kd, \u0275\u0275i18nEnd: Jd, \u0275\u0275i18nApply: uI, \u0275\u0275i18nPostprocess: dI, \u0275\u0275resolveWindow: Fm, \u0275\u0275resolveDocument: Hm, \u0275\u0275resolveBody: Lu, \u0275\u0275setComponentScope: uD, \u0275\u0275setNgModuleScope: dD, \u0275\u0275registerNgModuleType: Id, \u0275\u0275getComponentDepsFactory: xD, \u0275setClassDebugInfo: PD, \u0275\u0275declareLet: Cf, \u0275\u0275storeLet: WI, \u0275\u0275arrowFunction: iD, \u0275\u0275readContextLet: qI, \u0275\u0275attachSourceLocations: QI, \u0275\u0275interpolate: YI, \u0275\u0275interpolate1: ZI, \u0275\u0275interpolate2: KI, \u0275\u0275interpolate3: JI, \u0275\u0275interpolate4: XI, \u0275\u0275interpolate5: eD, \u0275\u0275interpolate6: tD, \u0275\u0275interpolate7: nD, \u0275\u0275interpolate8: oD, \u0275\u0275interpolateV: rD, \u0275\u0275sanitizeHtml: Ru, \u0275\u0275sanitizeStyle: Ou, \u0275\u0275sanitizeResourceUrl: Ps, \u0275\u0275sanitizeScript: xu, \u0275\u0275validateAttribute: Pu, \u0275\u0275sanitizeUrl: ku, \u0275\u0275sanitizeUrlOrResourceUrl: xm, \u0275\u0275trustConstantHtml: Om, \u0275\u0275trustConstantResourceUrl: km, forwardRef: Ua, resolveForwardRef: G, \u0275\u0275twoWayProperty: If, \u0275\u0275twoWayBindingSet: zI, \u0275\u0275twoWayListener: Df, \u0275\u0275replaceMetadata: FD, \u0275\u0275getReplaceMetadataURL: LD }, On = null;
function HD(e) { On !== null && (e.defaultEncapsulation !== On.defaultEncapsulation || e.preserveWhitespaces !== On.preserveWhitespaces) || (On = e); }
function LR() { return On; }
function FR() { On = null; }
var Zo = [];
function HR(e, t) { Zo.push({ moduleType: e, ngModule: t }); }
var Xc = !1;
function VD() { if (!Xc) {
    Xc = !0;
    try {
        for (let e = Zo.length - 1; e >= 0; e--) {
            let { moduleType: t, ngModule: n } = Zo[e];
            n.declarations && n.declarations.every(jD) && (Zo.splice(e, 1), $R(t, n));
        }
    }
    finally {
        Xc = !1;
    }
} }
function jD(e) { return Array.isArray(e) ? e.every(jD) : !!G(e); }
function BD(e, t = {}) { UD(e, t), t.id !== void 0 && Id(e, t.id), HR(e, t); }
function UD(e, t, n = !1) { let o = Fe(t.declarations || F), r = null; Object.defineProperty(e, za, { configurable: !0, get: () => (r === null && (r = oe({ usage: 0, kind: "NgModule", type: e }).compileNgModule(ge, `ng:///${e.name}/\u0275mod.js`, { type: e, bootstrap: Fe(t.bootstrap || F).map(G), declarations: o.map(G), imports: Fe(t.imports || F).map(G).map(qh), exports: Fe(t.exports || F).map(G).map(qh), schemas: t.schemas ? Fe(t.schemas) : null, id: t.id || null }), r.schemas || (r.schemas = [])), r) }); let i = null; Object.defineProperty(e, vt, { get: () => { if (i === null) {
        let a = oe({ usage: 0, kind: "NgModule", type: e });
        i = a.compileFactory(ge, `ng:///${e.name}/\u0275fac.js`, { name: e.name, type: e, deps: Es(e), target: a.FactoryTarget.NgModule, typeArgumentCount: 0 });
    } return i; }, configurable: !1 }); let s = null; Object.defineProperty(e, $a, { get: () => { if (s === null) {
        let a = { name: e.name, type: e, providers: t.providers || F, imports: [(t.imports || F).map(G), (t.exports || F).map(G)] };
        s = oe({ usage: 0, kind: "NgModule", type: e }).compileInjector(ge, `ng:///${e.name}/\u0275inj.js`, a);
    } return s; }, configurable: !1 }); }
function VR(e, t) { let n = `Unexpected "${we(e)}" found in the "declarations" array of the`, o = `"${we(e)}" is marked as standalone and can't be declared in any NgModule - did you intend to import it instead (by adding it to the "imports" array)?`; return `${n} ${t}, ${o}`; }
var jR = new WeakMap, BR = new WeakMap;
function UR() { jR = new WeakMap, BR = new WeakMap, Zo.length = 0, sb.clear(); }
function $R(e, t) { let n = Fe(t.declarations || F), o = Mf(e); n.forEach(r => { if (r = G(r), r.hasOwnProperty(yt)) {
    let s = W(r);
    Tf(s, o);
}
else
    !r.hasOwnProperty(yn) && !r.hasOwnProperty(Xr) && (r.ngSelectorScope = e); }); }
function Tf(e, t) { e.directiveDefs = () => Array.from(t.compilation.directives).map(n => n.hasOwnProperty(yt) ? W(n) : Ne(n)).filter(n => !!n), e.pipeDefs = () => Array.from(t.compilation.pipes).map(n => Ue(n)), e.schemas = t.schemas, e.tView = null; }
function Mf(e) { if (Yt(e)) {
    let t = Un.getNgModuleScope(e), n = ei(e);
    return Z({ schemas: n.schemas || null }, t);
}
else if (Do(e)) {
    if ((W(e) || Ne(e)) !== null)
        return { schemas: null, compilation: { directives: new Set, pipes: new Set }, exported: { directives: new Set([e]), pipes: new Set } };
    if (Ue(e) !== null)
        return { schemas: null, compilation: { directives: new Set, pipes: new Set }, exported: { directives: new Set, pipes: new Set([e]) } };
} throw new Error(`${e.name} does not have a module def (\u0275mod property)`); }
function qh(e) { return cd(e) ? e.ngModule : e; }
var el = 0;
function $D(e, t) {
    let n = null;
    YS(e, t), GD(e, t), Object.defineProperty(e, yt, { get: () => {
            if (n === null) {
                let o = oe({ usage: 0, kind: "component", type: e });
                if (wv(t)) {
                    let u = [`Component '${e.name}' is not resolved:`];
                    throw t.templateUrl && u.push(` - templateUrl: ${t.templateUrl}`), t.styleUrls && t.styleUrls.length && u.push(` - styleUrls: ${JSON.stringify(t.styleUrls)}`), t.styleUrl && u.push(` - styleUrl: ${t.styleUrl}`), u.push("Did you run and wait for 'resolveComponentResources()'?"), new Error(u.join(`
`));
                }
                let r = LR(), i = t.preserveWhitespaces;
                i === void 0 && (r !== null && r.preserveWhitespaces !== void 0 ? i = r.preserveWhitespaces : i = !1);
                let s = t.encapsulation;
                s === void 0 && (r !== null && r.defaultEncapsulation !== void 0 ? s = r.defaultEncapsulation : s = Oe.Emulated);
                let a = t.templateUrl || `ng:///${e.name}/template.html`, c = WD(e, t), l = et(Z({}, c), { typeSourceSpan: o.createParseSourceSpan("Component", e.name, a), template: t.template || "", preserveWhitespaces: i, styles: typeof t.styles == "string" ? [t.styles] : t.styles || F, animations: t.animations, declarations: [], changeDetection: t.changeDetection, encapsulation: s, viewProviders: t.viewProviders || null, hasDirectiveDependencies: !c.isStandalone || t.imports != null && t.imports.length > 0 });
                el++;
                try {
                    if (l.usesInheritance && qD(e), n = o.compileComponent(ge, a, l), l.isStandalone) {
                        let u = Fe(t.imports || F), { directiveDefs: d, pipeDefs: f } = zR(e, u);
                        n.directiveDefs = d, n.pipeDefs = f, n.dependencies = () => u.map(G);
                    }
                }
                finally {
                    el--;
                }
                if (el === 0 && VD(), GR(e)) {
                    let u = Mf(e.ngSelectorScope);
                    Tf(n, u);
                }
                if (t.schemas)
                    if (l.isStandalone)
                        n.schemas = t.schemas;
                    else
                        throw new Error(`The 'schemas' was specified for the ${we(e)} but is only valid on a component that is standalone.`);
                else
                    l.isStandalone && (n.schemas = []);
            }
            return n;
        }, set: o => { n = o; }, configurable: !1 });
}
function zR(e, t) { return { directiveDefs: () => Uo(e) ? [...Un.getStandaloneComponentScope(e, t).compilation.directives].map(i => W(i) || Ne(i)).filter(i => i !== null) : [], pipeDefs: () => Uo(e) ? [...Un.getStandaloneComponentScope(e, t).compilation.pipes].map(i => Ue(i)).filter(i => i !== null) : [] }; }
function GR(e) { return e.ngSelectorScope !== void 0; }
function Nf(e, t) { let n = null; GD(e, t || {}), Object.defineProperty(e, yn, { get: () => { if (n === null) {
        let o = zD(e, t || {});
        n = oe({ usage: 0, kind: "directive", type: e }).compileDirective(ge, o.sourceMapUrl, o.metadata);
    } return n; }, configurable: !1 }); }
function zD(e, t) { let n = e && e.name, o = `ng:///${n}/\u0275dir.js`, r = oe({ usage: 0, kind: "directive", type: e }), i = WD(e, t); return i.typeSourceSpan = r.createParseSourceSpan("Directive", n, o), i.usesInheritance && qD(e), { metadata: i, sourceMapUrl: o }; }
function GD(e, t) { let n = null; Object.defineProperty(e, vt, { get: () => { if (n === null) {
        let o = zD(e, t), r = oe({ usage: 0, kind: "directive", type: e });
        n = r.compileFactory(ge, `ng:///${e.name}/\u0275fac.js`, { name: o.metadata.name, type: o.metadata.type, typeArgumentCount: 0, deps: Es(e), target: r.FactoryTarget.Directive });
    } return n; }, configurable: !1 }); }
function WR(e) { return Object.getPrototypeOf(e.prototype) === Object.prototype; }
function WD(e, t) { let n = cu(), o = n.ownPropMetadata(e); return { name: e.name, type: e, selector: t.selector !== void 0 ? t.selector : null, host: t.host || _e, propMetadata: o, inputs: t.inputs || F, outputs: t.outputs || F, queries: Qh(e, o, QD), lifecycle: { usesOnChanges: n.hasLifecycleHook(e, "ngOnChanges") }, controlCreate: null, typeSourceSpan: null, usesInheritance: !WR(e), exportAs: YR(t.exportAs), providers: t.providers || null, viewQueries: Qh(e, o, YD), isStandalone: t.standalone === void 0 ? !0 : !!t.standalone, isSignal: !!t.signals, hostDirectives: t.hostDirectives?.map(r => typeof r == "function" ? { directive: r } : r) || null }; }
function qD(e) { let t = Object.prototype, n = Object.getPrototypeOf(e.prototype).constructor; for (; n && n !== t;)
    !Ne(n) && !W(n) && KR(n) && Nf(n, null), n = Object.getPrototypeOf(n); }
function qR(e) { return typeof e == "string" ? KD(e) : G(e); }
function QR(e, t) { return { propertyName: e, predicate: qR(t.selector), descendants: t.descendants, first: t.first, read: t.read ? t.read : null, static: !!t.static, emitDistinctChangesOnly: !!t.emitDistinctChangesOnly, isSignal: !!t.isSignal }; }
function Qh(e, t, n) { let o = [], r = []; for (let i in t)
    if (t.hasOwnProperty(i)) {
        let s = t[i];
        s.forEach(a => { if (n(a)) {
            if (!a.selector)
                throw new Error(`Can't construct a query for the property "${i}" of "${we(e)}" since the query selector wasn't defined.`);
            if (s.some(ZD))
                throw new Error("Cannot combine @Input decorators with query decorators");
            let c = QR(i, a);
            c.isSignal ? o.push(c) : r.push(c);
        } });
    } return [...o, ...r]; }
function YR(e) { return e === void 0 ? null : KD(e); }
function QD(e) { let t = e.ngMetadataName; return t === "ContentChild" || t === "ContentChildren"; }
function YD(e) { let t = e.ngMetadataName; return t === "ViewChild" || t === "ViewChildren"; }
function ZD(e) { return e.ngMetadataName === "Input"; }
function KD(e) { return e.split(",").map(t => t.trim()); }
var ZR = ["ngOnChanges", "ngOnInit", "ngOnDestroy", "ngDoCheck", "ngAfterViewInit", "ngAfterViewChecked", "ngAfterContentInit", "ngAfterContentChecked"];
function KR(e) { let t = cu(); if (ZR.some(o => t.hasLifecycleHook(e, o)))
    return !0; let n = t.propMetadata(e); for (let o in n) {
    let r = n[o];
    for (let i = 0; i < r.length; i++) {
        let s = r[i], a = s.ngMetadataName;
        if (ZD(s) || QD(s) || YD(s) || a === "Output" || a === "HostBinding" || a === "HostListener")
            return !0;
    }
} return !1; }
function JD(e, t) { let n = null, o = null; Object.defineProperty(e, vt, { get: () => { if (o === null) {
        let r = Yh(e, t), i = oe({ usage: 0, kind: "pipe", type: r.type });
        o = i.compileFactory(ge, `ng:///${r.name}/\u0275fac.js`, { name: r.name, type: r.type, typeArgumentCount: 0, deps: Es(e), target: i.FactoryTarget.Pipe });
    } return o; }, configurable: !1 }), Object.defineProperty(e, Xr, { get: () => { if (n === null) {
        let r = Yh(e, t);
        n = oe({ usage: 0, kind: "pipe", type: r.type }).compilePipe(ge, `ng:///${r.name}/\u0275pipe.js`, r);
    } return n; }, configurable: !1 }); }
function Yh(e, t) { return { type: e, name: e.name, pipeName: t.name, pure: t.pure !== void 0 ? t.pure : !0, isStandalone: t.standalone === void 0 ? !0 : !!t.standalone }; }
var XD = yr("Directive", (e = {}) => e, void 0, void 0, (e, t) => Nf(e, t)), JR = yr("Component", (e = {}) => Z({ changeDetection: Is.Eager }, e), XD, void 0, (e, t) => $D(e, t)), XR = yr("Pipe", e => Z({ pure: !0 }, e), void 0, void 0, (e, t) => JD(e, t)), eO = ct("Input", e => e ? typeof e == "string" ? { alias: e } : e : {}), tO = ct("Output", e => ({ alias: e })), nO = ct("HostBinding", e => ({ hostPropertyName: e })), oO = ct("HostListener", (e, t) => ({ eventName: e, args: t })), rO = yr("NgModule", e => e, void 0, void 0, (e, t) => BD(e, t)), ms = class {
    ngModuleFactory;
    componentFactories;
    constructor(t, n) { this.ngModuleFactory = t, this.componentFactories = n; }
}, iO = (() => { class e {
    compileModuleSync(n) { return new Wn(n); }
    compileModuleAsync(n) { return Promise.resolve(this.compileModuleSync(n)); }
    compileModuleAndAllComponentsSync(n) { let o = this.compileModuleSync(n), r = vn(n), i = An(r.declarations).reduce((s, a) => { let c = W(a); return c && s.push(new Ot(c)), s; }, []); return new ms(o, i); }
    compileModuleAndAllComponentsAsync(n) { return Promise.resolve(this.compileModuleAndAllComponentsSync(n)); }
    clearCache() { }
    clearCacheFor(n) { }
    getModuleId(n) { }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })(), eC = new S(""), ru = class {
};
var tC = (() => { class e {
    applicationErrorHandler = I(Wt);
    appRef = I(xe);
    taskService = I(Gt);
    ngZone = I(U);
    zonelessEnabled = I(Tn);
    tracing = I(hn, { optional: !0 });
    zoneIsDefined = typeof Zone < "u" && !!Zone.root.run;
    schedulerTickApplyArgs = [{ data: { __scheduler_tick__: !0 } }];
    subscriptions = new FT;
    angularZoneId = this.zoneIsDefined ? this.ngZone._inner?.get(Nc) : null;
    scheduleInRootZone = !this.zonelessEnabled && this.zoneIsDefined && (I(Ii, { optional: !0 }) ?? !1);
    cancelScheduledCallback = null;
    useMicrotaskScheduler = !1;
    runningTick = !1;
    pendingRenderTaskId = null;
    constructor() { this.subscriptions.add(this.appRef.afterTick.subscribe(() => { let n = this.taskService.add(); if (!this.runningTick && (this.cleanup(), !this.zonelessEnabled || this.appRef.includeAllTestViews)) {
        this.taskService.remove(n);
        return;
    } this.switchToMicrotaskScheduler(), this.taskService.remove(n); })), this.subscriptions.add(this.ngZone.onUnstable.subscribe(() => { this.runningTick || this.cleanup(); })); }
    switchToMicrotaskScheduler() { this.ngZone.runOutsideAngular(() => { let n = this.taskService.add(); this.useMicrotaskScheduler = !0, queueMicrotask(() => { this.useMicrotaskScheduler = !1, this.taskService.remove(n); }); }); }
    notify(n) { if (!this.zonelessEnabled && n === 5)
        return; switch (n) {
        case 0: {
            this.appRef.dirtyFlags |= 2;
            break;
        }
        case 3:
        case 2:
        case 4:
        case 5:
        case 1: {
            this.appRef.dirtyFlags |= 4;
            break;
        }
        case 6: {
            this.appRef.dirtyFlags |= 2;
            break;
        }
        case 12: {
            this.appRef.dirtyFlags |= 16;
            break;
        }
        case 13: {
            this.appRef.dirtyFlags |= 2;
            break;
        }
        case 11: break;
        default: this.appRef.dirtyFlags |= 8;
    } if (this.appRef.tracingSnapshot = this.tracing?.snapshot(this.appRef.tracingSnapshot) ?? null, !this.shouldScheduleTick())
        return; let o = this.useMicrotaskScheduler ? xp : kp; this.pendingRenderTaskId = this.taskService.add(), this.scheduleInRootZone ? this.cancelScheduledCallback = Zone.root.run(() => o(() => this.tick())) : this.cancelScheduledCallback = this.ngZone.runOutsideAngular(() => o(() => this.tick())); }
    shouldScheduleTick() { return !(this.appRef.destroyed || this.pendingRenderTaskId !== null || this.runningTick || this.appRef._runningTick || !this.zonelessEnabled && this.zoneIsDefined && Zone.current.get(Nc + this.angularZoneId)); }
    tick() { if (this.runningTick || this.appRef.destroyed)
        return; if (this.appRef.dirtyFlags === 0) {
        this.cleanup();
        return;
    } !this.zonelessEnabled && this.appRef.dirtyFlags & 7 && (this.appRef.dirtyFlags |= 1); let n = this.taskService.add(); try {
        this.ngZone.run(() => { this.runningTick = !0, this.appRef._tick(); }, void 0, this.schedulerTickApplyArgs);
    }
    catch (o) {
        this.applicationErrorHandler(o);
    }
    finally {
        this.taskService.remove(n), this.cleanup();
    } }
    ngOnDestroy() { this.subscriptions.unsubscribe(), this.cleanup(); }
    cleanup() { if (this.runningTick = !1, this.cancelScheduledCallback?.(), this.cancelScheduledCallback = null, this.pendingRenderTaskId !== null) {
        let n = this.pendingRenderTaskId;
        this.pendingRenderTaskId = null, this.taskService.remove(n);
    } }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })();
function sO() { return Q("NgZoneless"), nt([...Da(), []]); }
function Da() { return [{ provide: Nt, useExisting: tC }, { provide: U, useClass: wc }, { provide: Tn, useValue: !0 }]; }
function aO() { return typeof $localize < "u" && $localize.locale || Vr; }
var wf = new S("", { factory: () => I(wf, { optional: !0, skipSelf: !0 }) || aO() }), cO = new S("", { factory: () => TA }), lO = new S(""), uO = new S(""), nC = (function (e) { return e[e.Error = 0] = "Error", e[e.Warning = 1] = "Warning", e[e.Ignore = 2] = "Ignore", e; })(nC || {}), iu = class {
    name;
    callback;
    constructor(t, n) { this.name = t, this.callback = n; }
};
function dO(e) { return e.map(t => t.nativeElement); }
var gr = class {
    nativeNode;
    constructor(t) { this.nativeNode = t; }
    get parent() { let t = this.nativeNode.parentNode; return t ? new un(t) : null; }
    get injector() { return RM(this.nativeNode); }
    get componentInstance() { let t = this.nativeNode; return t && (Qp(t) || AM(t)); }
    get context() { return Qp(this.nativeNode) || bM(this.nativeNode); }
    get listeners() { return LM(this.nativeNode).filter(t => t.type === "dom"); }
    get references() { return xM(this.nativeNode); }
    get providerTokens() { return OM(this.nativeNode); }
}, un = class extends gr {
    constructor(t) { super(t); }
    get nativeElement() { return this.nativeNode.nodeType == Node.ELEMENT_NODE ? this.nativeNode : null; }
    get name() { let t = Ie(this.nativeNode), n = t ? t.lView : null; return n !== null ? n[m].data[t.nodeIndex].value : this.nativeNode.nodeName; }
    get properties() { let t = Ie(this.nativeNode), n = t ? t.lView : null; if (n === null)
        return {}; let o = n[m].data, r = o[t.nodeIndex], i = {}; return fO(this.nativeElement, i), hO(i, r, n, o), i; }
    get attributes() { let t = {}, n = this.nativeElement; if (!n)
        return t; let o = Ie(n), r = o ? o.lView : null; if (r === null)
        return {}; let i = r[m].data[o.nodeIndex].attrs, s = []; if (i) {
        let a = 0;
        for (; a < i.length;) {
            let c = i[a];
            if (typeof c != "string")
                break;
            let l = i[a + 1];
            t[c] = l, s.push(c.toLowerCase()), a += 2;
        }
    } for (let a of n.attributes)
        s.includes(a.name) || (t[a.name] = a.value); return t; }
    get styles() { return this.nativeElement?.style ?? {}; }
    get classes() { let t = {}, o = this.nativeElement.className; return (typeof o != "string" ? o.baseVal.split(" ") : o.split(" ")).forEach(i => t[i] = !0), t; }
    get childNodes() { let t = this.nativeNode.childNodes, n = []; for (let o = 0; o < t.length; o++) {
        let r = t[o];
        n.push(mr(r));
    } return n; }
    get children() { let t = this.nativeElement; if (!t)
        return []; let n = t.children, o = []; for (let r = 0; r < n.length; r++) {
        let i = n[r];
        o.push(mr(i));
    } return o; }
    query(t) { return this.queryAll(t)[0] || null; }
    queryAll(t) { let n = []; return Zh(this, t, n, !0), n; }
    queryAllNodes(t) { let n = []; return Zh(this, t, n, !1), n; }
    triggerEventHandler(t, n) { let o = this.nativeNode, r = []; this.listeners.forEach(i => { if (i.name === t) {
        let s = i.callback;
        s.call(o, n), r.push(s);
    } }), typeof o.eventListeners == "function" && o.eventListeners(t).forEach(i => { if (i.toString().indexOf("__ngUnwrap__") !== -1) {
        let s = i("__ngUnwrap__");
        return r.indexOf(s) === -1 && s.call(o, n);
    } }); }
};
function fO(e, t) { if (e) {
    let n = Object.getPrototypeOf(e), o = Node.prototype;
    for (; n !== null && n !== o;) {
        let r = Object.getOwnPropertyDescriptors(n);
        for (let i in r)
            if (!i.startsWith("__") && !i.startsWith("on")) {
                let s = e[i];
                pO(s) && (t[i] = s);
            }
        n = Object.getPrototypeOf(n);
    }
} }
function pO(e) { return typeof e == "string" || typeof e == "boolean" || typeof e == "number" || e === null; }
function Zh(e, t, n, o) { let r = Ie(e.nativeNode), i = r ? r.lView : null; if (i !== null) {
    let s = i[m].data[r.nodeIndex];
    Zt(s, i, t, n, o, e.nativeNode);
}
else
    _f(e.nativeNode, t, n, o); }
function Zt(e, t, n, o, r, i) { let s = hp(e, t); if (e.type & 11) {
    if (tl(s, n, o, r, i), me(e)) {
        let c = pe(e.index, t);
        c && c[m].firstChild && Zt(c[m].firstChild, c, n, o, r, i);
    }
    else
        e.child && Zt(e.child, t, n, o, r, i), s && _f(s, n, o, r);
    let a = t[e.index];
    ee(a) && Kh(a, n, o, r, i);
}
else if (e.type & 4) {
    let a = t[e.index];
    tl(a[He], n, o, r, i), Kh(a, n, o, r, i);
}
else if (e.type & 16) {
    let a = t[K], l = a[ue].projection[e.projection];
    if (Array.isArray(l))
        for (let u of l)
            tl(u, n, o, r, i);
    else if (l) {
        let u = a[q], d = u[m].data[l.index];
        Zt(d, u, n, o, r, i);
    }
}
else
    e.child && Zt(e.child, t, n, o, r, i); if (i !== s) {
    let a = e.flags & 2 ? e.projectionNext : e.next;
    a && Zt(a, t, n, o, r, i);
} }
function Kh(e, t, n, o, r) { for (let i = V; i < e.length; i++) {
    let s = e[i], a = s[m].firstChild;
    a && Zt(a, s, t, n, o, r);
} }
function tl(e, t, n, o, r) { if (r !== e) {
    let i = mr(e);
    if (!i)
        return;
    (o && i instanceof un && t(i) && n.indexOf(i) === -1 || !o && t(i) && n.indexOf(i) === -1) && n.push(i);
} }
function _f(e, t, n, o) { let r = e.childNodes, i = r.length; for (let s = 0; s < i; s++) {
    let a = r[s], c = mr(a);
    c && ((o && c instanceof un && t(c) && n.indexOf(c) === -1 || !o && t(c) && n.indexOf(c) === -1) && n.push(c), _f(a, t, n, o));
} }
function hO(e, t, n, o) { let r = t.propertyBindings; if (r !== null)
    for (let i = 0; i < r.length; i++) {
        let s = r[i], c = o[s].split(XN), l = c[0];
        if (c.length > 1) {
            let u = c[1];
            for (let d = 1; d < c.length - 1; d++)
                u += N(n[s + d - 1]) + c[d + 1];
            e[l] = u;
        }
        else
            e[l] = n[s];
    } }
var nl = "__ng_debug__";
function mr(e) { return e instanceof Node ? (e.hasOwnProperty(nl) || (e[nl] = e.nodeType == Node.ELEMENT_NODE ? new un(e) : new gr(e)), e[nl]) : null; }
import { Subscription as QO } from "rxjs";
var Of = { JSACTION: "__jsaction", OWNER: "__owner" }, sC = {};
function gO(e) { return e[Of.JSACTION]; }
function oC(e, t) { e[Of.JSACTION] = t; }
function mO(e) { return sC[e]; }
function yO(e, t) { sC[e] = t; }
var C = { CLICK: "click", CLICKMOD: "clickmod", DBLCLICK: "dblclick", FOCUS: "focus", FOCUSIN: "focusin", BLUR: "blur", FOCUSOUT: "focusout", SUBMIT: "submit", KEYDOWN: "keydown", KEYPRESS: "keypress", KEYUP: "keyup", MOUSEOVER: "mouseover", MOUSEOUT: "mouseout", MOUSEENTER: "mouseenter", MOUSELEAVE: "mouseleave", POINTEROVER: "pointerover", POINTEROUT: "pointerout", POINTERENTER: "pointerenter", POINTERLEAVE: "pointerleave", ERROR: "error", LOAD: "load", TOUCHSTART: "touchstart", TOUCHEND: "touchend", TOUCHMOVE: "touchmove", TOGGLE: "toggle" }, vO = [C.MOUSEENTER, C.MOUSELEAVE, "pointerenter", "pointerleave"], EO = [C.CLICK, C.DBLCLICK, C.FOCUSIN, C.FOCUSOUT, C.KEYDOWN, C.KEYUP, C.KEYPRESS, C.MOUSEOVER, C.MOUSEOUT, C.SUBMIT, C.TOUCHSTART, C.TOUCHEND, C.TOUCHMOVE, "touchcancel", "auxclick", "change", "compositionstart", "compositionupdate", "compositionend", "beforeinput", "input", "select", "copy", "cut", "paste", "mousedown", "mouseup", "wheel", "contextmenu", "dragover", "dragenter", "dragleave", "drop", "dragstart", "dragend", "pointerdown", "pointermove", "pointerup", "pointercancel", "pointerover", "pointerout", "gotpointercapture", "lostpointercapture", "ended", "loadedmetadata", "pagehide", "pageshow", "visibilitychange", "beforematch"], aC = [C.FOCUS, C.BLUR, C.ERROR, C.LOAD, C.TOGGLE], _a = e => aC.indexOf(e) >= 0, IO = EO.concat(aC), cC = e => IO.indexOf(e) >= 0;
function DO(e) { return e === C.MOUSEENTER ? C.MOUSEOVER : e === C.MOUSELEAVE ? C.MOUSEOUT : e === C.POINTERENTER ? C.POINTEROVER : e === C.POINTERLEAVE ? C.POINTEROUT : e; }
function CO(e, t, n, o) { let r = !1; _a(t) && (r = !0); let i = typeof o == "boolean" ? { capture: r, passive: o } : r; return e.addEventListener(t, n, i), { eventType: t, handler: n, capture: r, passive: o }; }
function TO(e, t) { if (e.removeEventListener) {
    let n = typeof t.passive == "boolean" ? { capture: t.capture } : t.capture;
    e.removeEventListener(t.eventType, t.handler, n);
}
else
    e.detachEvent && e.detachEvent(`on${t.eventType}`, t.handler); }
function MO(e) { e.preventDefault ? e.preventDefault() : e.returnValue = !1; }
var rC = typeof navigator < "u" && /Macintosh/.test(navigator.userAgent);
function NO(e) { return e.which === 2 || e.which == null && e.button === 4; }
function wO(e) { return rC && e.metaKey || !rC && e.ctrlKey || NO(e) || e.shiftKey; }
function _O(e, t, n) { let o = e.relatedTarget; return (e.type === C.MOUSEOVER && t === C.MOUSEENTER || e.type === C.MOUSEOUT && t === C.MOUSELEAVE || e.type === C.POINTEROVER && t === C.POINTERENTER || e.type === C.POINTEROUT && t === C.POINTERLEAVE) && (!o || o !== n && !n.contains(o)); }
function SO(e, t) { let n = {}; for (let o in e) {
    if (o === "srcElement" || o === "target")
        continue;
    let r = o, i = e[r];
    typeof i != "function" && (n[r] = i);
} return e.type === C.MOUSEOVER ? n.type = C.MOUSEENTER : e.type === C.MOUSEOUT ? n.type = C.MOUSELEAVE : e.type === C.POINTEROVER ? n.type = C.POINTERENTER : n.type = C.POINTERLEAVE, n.target = n.srcElement = t, n.bubbles = !1, n._originalEvent = e, n; }
var Na = class {
    element;
    handlerInfos = [];
    constructor(t) { this.element = t; }
    addEventListener(t, n, o) { this.handlerInfos.push(CO(this.element, t, n(this.element), o)); }
    cleanUp() { for (let t = 0; t < this.handlerInfos.length; t++)
        TO(this.element, this.handlerInfos[t]); this.handlerInfos = []; }
}, bO = { EVENT_ACTION_SEPARATOR: ":" };
function xt(e) { return e.eventType; }
function kf(e, t) { e.eventType = t; }
function Ta(e) { return e.event; }
function lC(e, t) { e.event = t; }
function uC(e) { return e.targetElement; }
function dC(e, t) { e.targetElement = t; }
function fC(e) { return e.eic; }
function AO(e, t) { e.eic = t; }
function RO(e) { return e.timeStamp; }
function OO(e, t) { e.timeStamp = t; }
function Ma(e) { return e.eia; }
function pC(e, t, n) { e.eia = [t, n]; }
function Sf(e) { e.eia = void 0; }
function Ca(e) { return e[1]; }
function kO(e) { return e.eirp; }
function hC(e, t) { e.eirp = t; }
function gC(e) { return e.eir; }
function mC(e, t) { e.eir = t; }
function yC(e) { return { eventType: e.eventType, event: e.event, targetElement: e.targetElement, eic: e.eic, eia: e.eia, timeStamp: e.timeStamp, eirp: e.eirp, eiack: e.eiack, eir: e.eir }; }
function xO(e, t, n, o, r, i, s, a) { return { eventType: e, event: t, targetElement: n, eic: o, timeStamp: r, eia: i, eirp: s, eiack: a }; }
var bf = class e {
    eventInfo;
    constructor(t) { this.eventInfo = t; }
    getEventType() { return xt(this.eventInfo); }
    setEventType(t) { kf(this.eventInfo, t); }
    getEvent() { return Ta(this.eventInfo); }
    setEvent(t) { lC(this.eventInfo, t); }
    getTargetElement() { return uC(this.eventInfo); }
    setTargetElement(t) { dC(this.eventInfo, t); }
    getContainer() { return fC(this.eventInfo); }
    setContainer(t) { AO(this.eventInfo, t); }
    getTimestamp() { return RO(this.eventInfo); }
    setTimestamp(t) { OO(this.eventInfo, t); }
    getAction() { let t = Ma(this.eventInfo); if (t)
        return { name: t[0], element: t[1] }; }
    setAction(t) { if (!t) {
        Sf(this.eventInfo);
        return;
    } pC(this.eventInfo, t.name, t.element); }
    getIsReplay() { return kO(this.eventInfo); }
    setIsReplay(t) { hC(this.eventInfo, t); }
    getResolved() { return gC(this.eventInfo); }
    setResolved(t) { mC(this.eventInfo, t); }
    clone() { return new e(yC(this.eventInfo)); }
}, PO = {}, LO = /\s*;\s*/, FO = C.CLICK, Af = class {
    a11yClickSupport = !1;
    clickModSupport = !0;
    syntheticMouseEventSupport;
    updateEventInfoForA11yClick = void 0;
    preventDefaultForA11yClick = void 0;
    populateClickOnlyAction = void 0;
    constructor({ syntheticMouseEventSupport: t = !1, clickModSupport: n = !0 } = {}) { this.syntheticMouseEventSupport = t, this.clickModSupport = n; }
    resolveEventType(t) { this.clickModSupport && xt(t) === C.CLICK && wO(Ta(t)) ? kf(t, C.CLICKMOD) : this.a11yClickSupport && this.updateEventInfoForA11yClick(t); }
    resolveAction(t) { gC(t) || (this.populateAction(t, uC(t)), mC(t, !0)); }
    resolveParentAction(t) { let n = Ma(t), o = n && Ca(n); Sf(t); let r = o && this.getParentNode(o); r && this.populateAction(t, r); }
    populateAction(t, n) { let o = n; for (; o && o !== fC(t) && (o.nodeType === Node.ELEMENT_NODE && this.populateActionOnElement(o, t), !Ma(t));)
        o = this.getParentNode(o); let r = Ma(t); if (r && (this.a11yClickSupport && this.preventDefaultForA11yClick(t), this.syntheticMouseEventSupport && (xt(t) === C.MOUSEENTER || xt(t) === C.MOUSELEAVE || xt(t) === C.POINTERENTER || xt(t) === C.POINTERLEAVE)))
        if (_O(Ta(t), xt(t), Ca(r))) {
            let i = SO(Ta(t), Ca(r));
            lC(t, i), dC(t, Ca(r));
        }
        else
            Sf(t); }
    getParentNode(t) { let n = t[Of.OWNER]; if (n)
        return n; let o = t.parentNode; return o?.nodeName === "#document-fragment" ? o?.host ?? null : o; }
    populateActionOnElement(t, n) { let o = this.parseActions(t), r = o[xt(n)]; r !== void 0 && pC(n, r, t), this.a11yClickSupport && this.populateClickOnlyAction(t, n, o); }
    parseActions(t) { let n = gO(t); if (!n) {
        let o = t.getAttribute(Mn.JSACTION);
        if (!o)
            n = PO, oC(t, n);
        else {
            if (n = mO(o), !n) {
                n = {};
                let r = o.split(LO);
                for (let i = 0; i < r.length; i++) {
                    let s = r[i];
                    if (!s)
                        continue;
                    let a = s.indexOf(bO.EVENT_ACTION_SEPARATOR), c = a !== -1, l = c ? s.substr(0, a).trim() : FO, u = c ? s.substr(a + 1).trim() : s;
                    n[l] = u;
                }
                yO(o, n);
            }
            oC(t, n);
        }
    } return n; }
    addA11yClickSupport(t, n, o) { this.a11yClickSupport = !0, this.updateEventInfoForA11yClick = t, this.preventDefaultForA11yClick = n, this.populateClickOnlyAction = o; }
}, vC = (function (e) { return e[e.I_AM_THE_JSACTION_FRAMEWORK = 0] = "I_AM_THE_JSACTION_FRAMEWORK", e; })(vC || {}), Rf = class {
    dispatchDelegate;
    actionResolver;
    eventReplayer;
    eventReplayScheduled = !1;
    replayEventInfoWrappers = [];
    constructor(t, { actionResolver: n, eventReplayer: o } = {}) { this.dispatchDelegate = t, this.actionResolver = n, this.eventReplayer = o; }
    dispatch(t) { let n = new bf(t); this.actionResolver?.resolveEventType(t), this.actionResolver?.resolveAction(t); let o = n.getAction(); if (o && HO(o.element, n) && MO(n.getEvent()), this.eventReplayer && n.getIsReplay()) {
        this.scheduleEventInfoWrapperReplay(n);
        return;
    } this.dispatchDelegate(n); }
    scheduleEventInfoWrapperReplay(t) { this.replayEventInfoWrappers.push(t), !this.eventReplayScheduled && (this.eventReplayScheduled = !0, Promise.resolve().then(() => { this.eventReplayScheduled = !1, this.eventReplayer(this.replayEventInfoWrappers); })); }
};
function HO(e, t) { return e.tagName === "A" && (t.getEventType() === C.CLICK || t.getEventType() === C.CLICKMOD); }
var EC = Symbol.for("propagationStopped"), xf = { REPLAY: 101 };
var VO = "`preventDefault` called during event replay.";
var jO = "`composedPath` called during event replay.", wa = class {
    dispatchDelegate;
    clickModSupport;
    actionResolver;
    dispatcher;
    constructor(t, n = !0) { this.dispatchDelegate = t, this.clickModSupport = n, this.actionResolver = new Af({ clickModSupport: n }), this.dispatcher = new Rf(o => { this.dispatchToDelegate(o); }, { actionResolver: this.actionResolver }); }
    dispatch(t) { this.dispatcher.dispatch(t); }
    dispatchToDelegate(t) { for (t.getIsReplay() && $O(t), BO(t); t.getAction();) {
        if (zO(t), _a(t.getEventType()) && t.getAction().element !== t.getTargetElement() || (this.dispatchDelegate(t.getEvent(), t.getAction().name), UO(t)))
            return;
        this.actionResolver.resolveParentAction(t.eventInfo);
    } }
};
function BO(e) { let t = e.getEvent(), n = e.getEvent().stopPropagation.bind(t), o = () => { t[EC] = !0, n(); }; mn(t, "stopPropagation", o), mn(t, "stopImmediatePropagation", o); }
function UO(e) { return !!e.getEvent()[EC]; }
function $O(e) { let t = e.getEvent(), n = e.getTargetElement(), o = t.preventDefault.bind(t); mn(t, "target", n), mn(t, "eventPhase", xf.REPLAY), mn(t, "preventDefault", () => { throw o(), new Error(VO + ""); }), mn(t, "composedPath", () => { throw new Error(jO + ""); }); }
function zO(e) { let t = e.getEvent(), n = e.getAction()?.element; n && mn(t, "currentTarget", n, { configurable: !0 }); }
function mn(e, t, n, { configurable: o = !1 } = {}) { Object.defineProperty(e, t, { value: n, configurable: o }); }
function IC(e, t) { e.ecrd(n => { t.dispatch(n); }, vC.I_AM_THE_JSACTION_FRAMEWORK); }
function GO(e) { return e?.q ?? []; }
function WO(e) { e && (iC(e.c, e.et, e.h), iC(e.c, e.etc, e.h, !0)); }
function iC(e, t, n, o) { for (let r = 0; r < t.length; r++)
    e.removeEventListener(t[r], n, o); }
var qO = !1, DC = (() => { class e {
    static MOUSE_SPECIAL_SUPPORT = qO;
    containerManager;
    eventHandlers = {};
    browserEventTypeToExtraEventTypes = {};
    dispatcher = null;
    queuedEventInfos = [];
    constructor(n) { this.containerManager = n; }
    handleEvent(n, o, r) { let i = xO(n, o, o.target, r, Date.now()); this.handleEventInfo(i); }
    handleEventInfo(n) { if (!this.dispatcher) {
        hC(n, !0), this.queuedEventInfos?.push(n);
        return;
    } this.dispatcher(n); }
    addEvent(n, o, r) { if (n in this.eventHandlers || !this.containerManager || !e.MOUSE_SPECIAL_SUPPORT && vO.indexOf(n) >= 0)
        return; let i = (a, c, l) => { this.handleEvent(a, c, l); }; this.eventHandlers[n] = i; let s = DO(o || n); if (s !== n) {
        let a = this.browserEventTypeToExtraEventTypes[s] || [];
        a.push(n), this.browserEventTypeToExtraEventTypes[s] = a;
    } this.containerManager.addEventListener(s, a => c => { i(n, c, a); }, r); }
    replayEarlyEvents(n = window._ejsa) { n && (this.replayEarlyEventInfos(n.q), WO(n), delete window._ejsa); }
    replayEarlyEventInfos(n) { for (let o = 0; o < n.length; o++) {
        let r = n[o], i = this.getEventTypesForBrowserEventType(r.eventType);
        for (let s = 0; s < i.length; s++) {
            let a = yC(r);
            kf(a, i[s]), this.handleEventInfo(a);
        }
    } }
    getEventTypesForBrowserEventType(n) { let o = []; return this.eventHandlers[n] && o.push(n), this.browserEventTypeToExtraEventTypes[n] && o.push(...this.browserEventTypeToExtraEventTypes[n]), o; }
    handler(n) { return this.eventHandlers[n]; }
    cleanUp() { this.containerManager?.cleanUp(), this.containerManager = null, this.eventHandlers = {}, this.browserEventTypeToExtraEventTypes = {}, this.dispatcher = null, this.queuedEventInfos = []; }
    registerDispatcher(n, o) { this.ecrd(n, o); }
    ecrd(n, o) { if (this.dispatcher = n, this.queuedEventInfos?.length) {
        for (let r = 0; r < this.queuedEventInfos.length; r++)
            this.handleEventInfo(this.queuedEventInfos[r]);
        this.queuedEventInfos = null;
    } }
} return e; })();
function CC(e, t = window) { return GO(t._ejsas?.[e]); }
function Pf(e, t = window) { t._ejsas && (t._ejsas[e] = void 0); }
import "@angular/core/primitives/signals";
import "rxjs/operators";
import "@angular/core/primitives/di";
typeof globalThis.ngServerMode > "u" && (globalThis.ngServerMode = typeof window > "u");
var xa = Symbol("InputSignalNode#UNSET"), $C = et(Z({}, Va), { transformFn: void 0, applyValueToInputSignal(e, t) { Ha(e, t); } }), OP = Symbol();
function zC(e, t) { let n = Object.create($C); n.value = e, n.transformFn = t?.transform; function o() { if (Gr(n), n.value === xa) {
    let r = null;
    throw new _(-950, r);
} return n.value; } return o[tt] = n, o; }
var go = (function (e) { return e[e.Directive = 0] = "Directive", e[e.Component = 1] = "Component", e[e.Injectable = 2] = "Injectable", e[e.Pipe = 3] = "Pipe", e[e.NgModule = 4] = "NgModule", e; })(go || {});
var YO = (function (e) { return e.Angular = "angular", e.ACX = "acx", e.Wiz = "wiz", e; })(YO || {}), TC = class {
    attributeName;
    constructor(t) { this.attributeName = t; }
    __NG_ELEMENT_ID__ = () => vs(this.attributeName);
    toString() { return `HostAttributeToken ${this.attributeName}`; }
}, kP = (() => { let e = new S(""); return e.__NG_ELEMENT_ID__ = t => { let n = M(); if (n === null)
    throw new _(-204, !1); if (n.type & 2)
    return n.value; if (t & 8)
    return null; throw new _(-204, !1); }, e; })();
function xP(e) { return new Oc; }
function MC(e, t) { return zC(e, t); }
function ZO(e) { return zC(xa, e); }
var PP = (MC.required = ZO, MC);
function NC(e, t) { return yd(t); }
function KO(e, t) { return vd(t); }
var LP = (NC.required = KO, NC);
function FP(e, t) { return Ed(t); }
function wC(e, t) { return yd(t); }
function JO(e, t) { return vd(t); }
var HP = (wC.required = JO, wC);
function VP(e, t) { return Ed(t); }
function GC(e, t) { let n = Object.create($C), o = new Oc; n.value = e; function r() { return Gr(n), _C(n.value), n.value; } return r[tt] = n, r.asReadonly = Pp.bind(r), r.set = i => { n.equal(n.value, i) || (Ha(n, i), o.emit(i)); }, r.update = i => { _C(n.value), r.set(i(n.value)); }, r.subscribe = o.subscribe.bind(o), r.destroyRef = o.destroyRef, r; }
function _C(e) { if (e === xa)
    throw new _(952, !1); }
function SC(e, t) { return GC(e, t); }
function XO(e) { return GC(xa, e); }
var jP = (SC.required = XO, SC), WC = !0, yo = class {
}, BP = ct("ContentChildren", (e, t = {}) => Z({ selector: e, first: !1, isViewQuery: !1, descendants: !1, emitDistinctChangesOnly: WC }, t), yo), UP = ct("ContentChild", (e, t = {}) => Z({ selector: e, first: !0, isViewQuery: !1, descendants: !0 }, t), yo), $P = ct("ViewChildren", (e, t = {}) => Z({ selector: e, first: !1, isViewQuery: !0, descendants: !0, emitDistinctChangesOnly: WC }, t), yo), zP = ct("ViewChild", (e, t) => Z({ selector: e, first: !0, isViewQuery: !0, descendants: !0 }, t), yo);
function ek(e, t, n) { let o = new Wn(n); return Promise.resolve(o); }
function bC(e) { for (let t = e.length - 1; t >= 0; t--)
    if (e[t] !== void 0)
        return e[t]; }
var tk = (() => { class e {
    zone = I(U);
    changeDetectionScheduler = I(Nt);
    applicationRef = I(xe);
    applicationErrorHandler = I(Wt);
    _onMicrotaskEmptySubscription;
    initialize() { this._onMicrotaskEmptySubscription || (this._onMicrotaskEmptySubscription = this.zone.onMicrotaskEmpty.subscribe({ next: () => { this.changeDetectionScheduler.runningTick || this.zone.run(() => { try {
            this.applicationRef.dirtyFlags |= 1, this.applicationRef._tick();
        }
        catch (n) {
            this.applicationErrorHandler(n);
        } }); } })); }
    ngOnDestroy() { this._onMicrotaskEmptySubscription?.unsubscribe(); }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })(), nk = new S("", { factory: () => !1 });
function ok({ ngZoneFactory: e, scheduleInRootZone: t }) { return e ??= () => new U(et(Z({}, qC()), { scheduleInRootZone: t })), [{ provide: Tn, useValue: !1 }, { provide: U, useFactory: e }, { provide: Et, multi: !0, useFactory: () => { let n = I(tk, { optional: !0 }); return () => n.initialize(); } }, { provide: Et, multi: !0, useFactory: () => { let n = I(rk); return () => { n.initialize(); }; } }, { provide: Ii, useValue: t ?? Rp }]; }
function GP(e) { let t = e?.scheduleInRootZone, n = ok({ ngZoneFactory: () => { let o = qC(e); return o.scheduleInRootZone = t, o.shouldCoalesceEventChangeDetection && Q("NgZone_CoalesceEvent"), new U(o); }, scheduleInRootZone: t }); return nt([{ provide: nk, useValue: !0 }, n]); }
function qC(e) { return { enableLongStackTrace: !1, shouldCoalesceEventChangeDetection: e?.eventCoalescing ?? !1, shouldCoalesceRunChangeDetection: e?.runCoalescing ?? !1 }; }
var rk = (() => { class e {
    subscription = new QO;
    initialized = !1;
    zone = I(U);
    pendingTasks = I(Gt);
    initialize() { if (this.initialized)
        return; this.initialized = !0; let n = null; !this.zone.isStable && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks && (n = this.pendingTasks.add()), this.zone.runOutsideAngular(() => { this.subscription.add(this.zone.onStable.subscribe(() => { U.assertNotInAngularZone(), queueMicrotask(() => { n !== null && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks && (this.pendingTasks.remove(n), n = null); }); })); }), this.subscription.add(this.zone.onUnstable.subscribe(() => { U.assertInAngularZone(), n ??= this.pendingTasks.add(); })); }
    ngOnDestroy() { this.subscription.unsubscribe(); }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })();
var ba = new S(""), ik = new S("");
function Ur(e) { return !e.moduleRef; }
function QC(e) { let t = Ur(e) ? e.r3Injector : e.moduleRef.injector, n = t.get(U); return n.run(() => { Ur(e) ? e.r3Injector.resolveInjectorInitializers() : e.moduleRef.resolveInjectorInitializers(); let o = t.get(Wt), r; if (n.runOutsideAngular(() => { r = n.onError.subscribe({ next: o }); }), Ur(e)) {
    let i = () => t.destroy(), s = e.platformInjector.get(ba);
    s.add(i), t.onDestroy(() => { r.unsubscribe(), s.delete(i); });
}
else {
    let i = () => e.moduleRef.destroy(), s = e.platformInjector.get(ba);
    s.add(i), e.moduleRef.onDestroy(() => { $o(e.allPlatformModules, e.moduleRef), r.unsubscribe(), s.delete(i); });
} return ak(o, n, () => { let i = t.get(Gt), s = i.add(), a = t.get(Pd); return a.runInitializers(), a.donePromise.then(() => { let c = t.get(wf, Vr); if (KE(c || Vr), !t.get(ik, !0))
    return Ur(e) ? t.get(xe) : (e.allPlatformModules.push(e.moduleRef), e.moduleRef); if (Ur(e)) {
    let u = t.get(xe);
    return e.rootComponent !== void 0 && u.bootstrap(e.rootComponent), u;
}
else
    return YC?.(e.moduleRef, e.allPlatformModules), e.moduleRef; }).finally(() => { i.remove(s); }); }); }); }
var YC;
function AC() { YC = sk; }
function sk(e, t) { let n = e.injector.get(xe); if (e._bootstrapComponents.length > 0)
    e._bootstrapComponents.forEach(o => n.bootstrap(o));
else if (e.instance.ngDoBootstrap)
    e.instance.ngDoBootstrap(n);
else
    throw new _(-403, !1); t.push(e); }
function ak(e, t, n) { try {
    let o = n();
    return kd(o) ? o.catch(r => { throw t.runOutsideAngular(() => e(r)), r; }) : o;
}
catch (o) {
    throw t.runOutsideAngular(() => e(o)), o;
} }
var ZC = (() => { class e {
    _injector;
    _modules = [];
    _destroyListeners = [];
    _destroyed = !1;
    constructor(n) { this._injector = n; }
    bootstrapModuleFactory(n, o) { let r = [Da(), ...o?.applicationProviders ?? [], Sc], i = Rv(n.moduleType, this.injector, r); return AC(), QC({ moduleRef: i, allPlatformModules: this._modules, platformInjector: this.injector }); }
    bootstrapModule(n, o = []) { let r = Fd({}, o); return AC(), ek(this.injector, r, n).then(i => this.bootstrapModuleFactory(i, r)); }
    onDestroy(n) { this._destroyListeners.push(n); }
    get injector() { return this._injector; }
    destroy() { if (this._destroyed)
        throw new _(404, !1); this._modules.slice().forEach(o => o.destroy()), this._destroyListeners.forEach(o => o()); let n = this._injector.get(ba, null); n && (n.forEach(o => o()), n.clear()), this._destroyed = !0; }
    get destroyed() { return this._destroyed; }
    static \u0275fac = function (o) { return new (o || e)(Le(Te)); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "platform" });
} return e; })(), mo = null;
function ck(e) { if (Pa())
    throw new _(400, !1); Ld(), mo = typeof ngServerMode > "u" || !ngServerMode ? e : null; let t = e.get(ZC); return JC(e), t; }
function lk(e, t, n = []) { let o = `Platform: ${t}`, r = new S(o); return (i = []) => { let s = Pa(); if (!s) {
    let a = [...n, ...i, { provide: r, useValue: !0 }];
    s = e?.(a) ?? ck(KC(a, o));
} return typeof ngServerMode < "u" && ngServerMode ? s : uk(r); }; }
function KC(e = [], t) { return Te.create({ name: t, providers: [{ provide: cp, useValue: "platform" }, { provide: ba, useValue: new Set([() => mo = null]) }, ...e] }); }
function uk(e) { let t = Pa(); if (!t)
    throw new _(-401, !1); return t; }
function Pa() { return typeof ngServerMode < "u" && ngServerMode ? null : mo?.get(ZC) ?? null; }
function WP() { Pa()?.destroy(); }
function dk(e = []) { if (mo)
    return mo; let t = KC(e); return (typeof ngServerMode > "u" || !ngServerMode) && (mo = t), Ld(), JC(t), t; }
function qP(e) { return { provide: uu, useValue: e, multi: !0 }; }
function JC(e) { let t = e.get(uu, null); ai(e, () => { t?.forEach(n => n()); }); }
function QP(e) { return nt([]); }
function YP() { return !1; }
function ZP() { }
var Sa = new WeakSet, RC = "";
function OC(e) { return e.get(_s, mu); }
function fk() { let e = [{ provide: _s, useFactory: () => { let t = !0; if (typeof ngServerMode > "u" || !ngServerMode) {
            let n = I(lt);
            t = !!window._ejsas?.[n];
        } return t && Q("NgEventReplay"), t; } }]; return (typeof ngServerMode > "u" || !ngServerMode) && e.push({ provide: Et, useValue: () => { let t = I(xe), { injector: n } = t; if (!Sa.has(t)) {
        let o = I(Mr);
        if (OC(n)) {
            Yg();
            let r = n.get(lt), i = qg(r, (s, a, c) => { s.nodeType === Node.ELEMENT_NODE && (Wg(s, a, c), Eu(s, o)); });
            t.onDestroy(i);
        }
    } }, multi: !0 }, { provide: Lr, useFactory: () => { let t = I(xe), { injector: n } = t; return () => { if (!OC(n) || Sa.has(t))
        return; Sa.add(t); let o = n.get(lt); t.onDestroy(() => { Sa.delete(t), typeof ngServerMode < "u" && !ngServerMode && Pf(o); }), t.whenStable().then(() => { if (t.destroyed)
        return; let r = n.get(Du); pk(r, n); let i = n.get(Mr); i.get(RC)?.forEach(Iu), i.delete(RC); let s = r.instance; Nr(n) ? t.onDestroy(() => s.cleanUp()) : s.cleanUp(); }); }; }, multi: !0 }), e; }
var pk = (e, t) => { let n = t.get(lt), o = window._ejsas[n], r = e.instance = new DC(new Na(o.c)); for (let a of o.et)
    r.addEvent(a); for (let a of o.etc)
    r.addEvent(a); let i = CC(n); r.replayEarlyEventInfos(i), Pf(n); let s = new wa(a => { gk(t, a, a.currentTarget); }); IC(r, s); };
function hk(e, t, n) { let o = new Map, r = t[Ht], i = e.cleanup; if (!i || !r)
    return o; for (let s = 0; s < i.length;) {
    let a = i[s++], c = i[s++];
    if (typeof a != "string")
        continue;
    let l = a;
    if (!cC(l))
        continue;
    _a(l) ? n.capture.add(l) : n.regular.add(l);
    let u = k(t[c]);
    s++;
    let d = i[s++];
    (typeof d == "boolean" || d >= 0) && (o.has(u) ? o.get(u).push(l) : o.set(u, [l]));
} return o; }
function gk(e, t, n) { let o = (n && n.getAttribute(no)) ?? ""; /d\d+/.test(o) ? mk(o, e, t, n) : t.eventPhase === xf.REPLAY && Cu(t, n); }
function mk(e, t, n, o) { let r = t.get(Ug); r.push({ event: n, currentTarget: o }), ht(t, e, yk(r)); }
function yk(e) { return t => { let n = new Set(t), o = []; for (let { event: r, currentTarget: i } of e) {
    let s = i.getAttribute(no);
    n.has(s) ? Cu(r, i) : o.push({ event: r, currentTarget: i });
} e.length = 0, e.push(...o); }; }
var kC = !1, xC = !1, PC = !1, vk = 1e4;
function Ek() { kC || (kC = !0, tm(), zE(), xI(), GE(), zv(), yv(), qy(), uy()); }
function Ik() { xC || (xC = !0, XE(), Hy(), $y()); }
function Dk() { PC || (PC = !0, um()); }
function Ck(e) { return e.whenStable(); }
var KP = "ngcm";
function JP() { let e = [{ provide: fn, useFactory: () => { let t = !0; return (typeof ngServerMode > "u" || !ngServerMode) && (t = !!I(Xn, { optional: !0 })?.get(Ss, null)), t && Q("NgHydration"), t; } }, { provide: Et, useValue: () => { if (sd(!1), typeof ngServerMode < "u" && ngServerMode)
            return; let t = I(zt); I(fn) && (fm(t), Ek()); }, multi: !0 }]; return (typeof ngServerMode > "u" || !ngServerMode) && e.push({ provide: hu, useFactory: () => I(fn) }, { provide: Lr, useFactory: () => { let t = I(Nt); if (I(fn)) {
        let n = I(xe);
        return () => { Ck(n).then(() => { n.destroyed || (ad(n), t.notify(7)); }); };
    } return () => { }; }, multi: !0 }), nt(e); }
function XP() { return [{ provide: gu, useFactory: () => I(fn) }, { provide: Et, useValue: () => { I(fn) && (Ik(), sd(!0), Q("NgI18nHydration")); }, multi: !0 }]; }
function eL() { let e = [fk(), { provide: yu, useValue: !0 }, { provide: ut, useClass: Zg }, { provide: Et, useValue: () => { Dk(), Q("NgIncrementalHydration"); }, multi: !0 }]; return (typeof ngServerMode > "u" || !ngServerMode) && e.push({ provide: Lr, useFactory: () => { let t = I(Te), n = I(zt); return () => { let o = dm(t), r = Py(n, n.body); pE(t, o, r), cm(n, t); }; }, multi: !0 }), e; }
var LC = vk - 1e3, Hf = class {
    openTasks = new Map;
    add(t) { this.openTasks.set(t, new Error("Task stack tracking error")); }
    remove(t) { this.openTasks.delete(t); }
};
function tL() { let e = new Hf, { openTasks: t } = e; return nt([{ provide: Op, useValue: e }, aE(() => { console.warn("Stability debugging utility was provided in production mode. This will cause debug code to be included in production bundles. If this is intentional because you are debugging stability issues in a production environment, you can ignore this warning."); let n = I(U), o = I(xe), r = null; typeof Zone < "u" && n.run(() => { r = Zone.current.get("TaskTrackingZone"); }), n.runOutsideAngular(() => { let i = setTimeout(() => { if (console.debug(`---- Application did not stabilize within ${LC / 1e3} seconds ----`), typeof Zone < "u" && !r && console.info('Zone.js is present but no TaskTrackingZone found. To enable better debugging of tasks in the Angular Zone, import "zone.js/plugins/task-tracking" in your application.'), r?.macroTasks?.length) {
        console.group("Macrotasks keeping Angular Zone unstable:");
        for (let s of r?.macroTasks ?? [])
            console.debug(s.creationLocation.stack);
        console.groupEnd();
    } console.group("PendingTasks keeping application unstable:"); for (let s of t.values())
        console.debug(s.stack); console.groupEnd(); }, LC); o.whenStable().then(() => { clearTimeout(i); }); }); })]); }
function nL(e) { let t = Dd(e); if (!t)
    throw XC(e); return new Wn(t); }
function oL(e) { let t = Dd(e); if (!t)
    throw XC(e); return t; }
function XC(e) { return new _(920, !1); }
var Tk = (() => { class e {
    static __NG_ELEMENT_ID__ = Mk;
} return e; })();
function Mk(e) { return Nk(M(), g(), (e & 16) === 16); }
function Nk(e, t, n) { if (me(e) && !n) {
    let o = pe(e.index, t);
    return new Rt(o, o);
}
else if (e.type & 175) {
    let o = t[K];
    return new Rt(o, t);
} return null; }
var Vf = class extends Tk {
}, FC = class extends Vf {
}, Aa = class {
    supports(t) { return cr(t); }
    create(t) { return new jf(t); }
}, wk = (e, t) => t, jf = class {
    length = 0;
    collection;
    _linkedRecords = null;
    _unlinkedRecords = null;
    _previousItHead = null;
    _itHead = null;
    _itTail = null;
    _additionsHead = null;
    _additionsTail = null;
    _movesHead = null;
    _movesTail = null;
    _removalsHead = null;
    _removalsTail = null;
    _identityChangesHead = null;
    _identityChangesTail = null;
    _trackByFn;
    constructor(t) { this._trackByFn = t || wk; }
    forEachItem(t) { let n; for (n = this._itHead; n !== null; n = n._next)
        t(n); }
    forEachOperation(t) { let n = this._itHead, o = this._removalsHead, r = 0, i = null; for (; n || o;) {
        let s = !o || n && n.currentIndex < HC(o, r, i) ? n : o, a = HC(s, r, i), c = s.currentIndex;
        if (s === o)
            r--, o = o._nextRemoved;
        else if (n = n._next, s.previousIndex == null)
            r++;
        else {
            i || (i = []);
            let l = a - r, u = c - r;
            if (l != u) {
                for (let f = 0; f < l; f++) {
                    let p = f < i.length ? i[f] : i[f] = 0, h = p + f;
                    u <= h && h < l && (i[f] = p + 1);
                }
                let d = s.previousIndex;
                i[d] = u - l;
            }
        }
        a !== c && t(s, a, c);
    } }
    forEachPreviousItem(t) { let n; for (n = this._previousItHead; n !== null; n = n._nextPrevious)
        t(n); }
    forEachAddedItem(t) { let n; for (n = this._additionsHead; n !== null; n = n._nextAdded)
        t(n); }
    forEachMovedItem(t) { let n; for (n = this._movesHead; n !== null; n = n._nextMoved)
        t(n); }
    forEachRemovedItem(t) { let n; for (n = this._removalsHead; n !== null; n = n._nextRemoved)
        t(n); }
    forEachIdentityChange(t) { let n; for (n = this._identityChangesHead; n !== null; n = n._nextIdentityChange)
        t(n); }
    diff(t) { if (t == null && (t = []), !cr(t))
        throw new _(900, !1); return this.check(t) ? this : null; }
    onDestroy() { }
    check(t) { this._reset(); let n = this._itHead, o = !1, r, i, s; if (Array.isArray(t)) {
        this.length = t.length;
        for (let a = 0; a < this.length; a++)
            i = t[a], s = this._trackByFn(a, i), n === null || !Object.is(n.trackById, s) ? (n = this._mismatch(n, i, s, a), o = !0) : (o && (n = this._verifyReinsertion(n, i, s, a)), Object.is(n.item, i) || this._addIdentityChange(n, i)), n = n._next;
    }
    else
        r = 0, nv(t, a => { s = this._trackByFn(r, a), n === null || !Object.is(n.trackById, s) ? (n = this._mismatch(n, a, s, r), o = !0) : (o && (n = this._verifyReinsertion(n, a, s, r)), Object.is(n.item, a) || this._addIdentityChange(n, a)), n = n._next, r++; }), this.length = r; return this._truncate(n), this.collection = t, this.isDirty; }
    get isDirty() { return this._additionsHead !== null || this._movesHead !== null || this._removalsHead !== null || this._identityChangesHead !== null; }
    _reset() { if (this.isDirty) {
        let t;
        for (t = this._previousItHead = this._itHead; t !== null; t = t._next)
            t._nextPrevious = t._next;
        for (t = this._additionsHead; t !== null; t = t._nextAdded)
            t.previousIndex = t.currentIndex;
        for (this._additionsHead = this._additionsTail = null, t = this._movesHead; t !== null; t = t._nextMoved)
            t.previousIndex = t.currentIndex;
        this._movesHead = this._movesTail = null, this._removalsHead = this._removalsTail = null, this._identityChangesHead = this._identityChangesTail = null;
    } }
    _mismatch(t, n, o, r) { let i; return t === null ? i = this._itTail : (i = t._prev, this._remove(t)), t = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(o, null), t !== null ? (Object.is(t.item, n) || this._addIdentityChange(t, n), this._reinsertAfter(t, i, r)) : (t = this._linkedRecords === null ? null : this._linkedRecords.get(o, r), t !== null ? (Object.is(t.item, n) || this._addIdentityChange(t, n), this._moveAfter(t, i, r)) : t = this._addAfter(new Bf(n, o), i, r)), t; }
    _verifyReinsertion(t, n, o, r) { let i = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(o, null); return i !== null ? t = this._reinsertAfter(i, t._prev, r) : t.currentIndex != r && (t.currentIndex = r, this._addToMoves(t, r)), t; }
    _truncate(t) { for (; t !== null;) {
        let n = t._next;
        this._addToRemovals(this._unlink(t)), t = n;
    } this._unlinkedRecords !== null && this._unlinkedRecords.clear(), this._additionsTail !== null && (this._additionsTail._nextAdded = null), this._movesTail !== null && (this._movesTail._nextMoved = null), this._itTail !== null && (this._itTail._next = null), this._removalsTail !== null && (this._removalsTail._nextRemoved = null), this._identityChangesTail !== null && (this._identityChangesTail._nextIdentityChange = null); }
    _reinsertAfter(t, n, o) { this._unlinkedRecords !== null && this._unlinkedRecords.remove(t); let r = t._prevRemoved, i = t._nextRemoved; return r === null ? this._removalsHead = i : r._nextRemoved = i, i === null ? this._removalsTail = r : i._prevRemoved = r, this._insertAfter(t, n, o), this._addToMoves(t, o), t; }
    _moveAfter(t, n, o) { return this._unlink(t), this._insertAfter(t, n, o), this._addToMoves(t, o), t; }
    _addAfter(t, n, o) { return this._insertAfter(t, n, o), this._additionsTail === null ? this._additionsTail = this._additionsHead = t : this._additionsTail = this._additionsTail._nextAdded = t, t; }
    _insertAfter(t, n, o) { let r = n === null ? this._itHead : n._next; return t._next = r, t._prev = n, r === null ? this._itTail = t : r._prev = t, n === null ? this._itHead = t : n._next = t, this._linkedRecords === null && (this._linkedRecords = new Ra), this._linkedRecords.put(t), t.currentIndex = o, t; }
    _remove(t) { return this._addToRemovals(this._unlink(t)); }
    _unlink(t) { this._linkedRecords !== null && this._linkedRecords.remove(t); let n = t._prev, o = t._next; return n === null ? this._itHead = o : n._next = o, o === null ? this._itTail = n : o._prev = n, t; }
    _addToMoves(t, n) { return t.previousIndex === n || (this._movesTail === null ? this._movesTail = this._movesHead = t : this._movesTail = this._movesTail._nextMoved = t), t; }
    _addToRemovals(t) { return this._unlinkedRecords === null && (this._unlinkedRecords = new Ra), this._unlinkedRecords.put(t), t.currentIndex = null, t._nextRemoved = null, this._removalsTail === null ? (this._removalsTail = this._removalsHead = t, t._prevRemoved = null) : (t._prevRemoved = this._removalsTail, this._removalsTail = this._removalsTail._nextRemoved = t), t; }
    _addIdentityChange(t, n) { return t.item = n, this._identityChangesTail === null ? this._identityChangesTail = this._identityChangesHead = t : this._identityChangesTail = this._identityChangesTail._nextIdentityChange = t, t; }
}, Bf = class {
    item;
    trackById;
    currentIndex = null;
    previousIndex = null;
    _nextPrevious = null;
    _prev = null;
    _next = null;
    _prevDup = null;
    _nextDup = null;
    _prevRemoved = null;
    _nextRemoved = null;
    _nextAdded = null;
    _nextMoved = null;
    _nextIdentityChange = null;
    constructor(t, n) { this.item = t, this.trackById = n; }
}, Uf = class {
    _head = null;
    _tail = null;
    add(t) { this._head === null ? (this._head = this._tail = t, t._nextDup = null, t._prevDup = null) : (this._tail._nextDup = t, t._prevDup = this._tail, t._nextDup = null, this._tail = t); }
    get(t, n) { let o; for (o = this._head; o !== null; o = o._nextDup)
        if ((n === null || n <= o.currentIndex) && Object.is(o.trackById, t))
            return o; return null; }
    remove(t) { let n = t._prevDup, o = t._nextDup; return n === null ? this._head = o : n._nextDup = o, o === null ? this._tail = n : o._prevDup = n, this._head === null; }
}, Ra = class {
    map = new Map;
    put(t) { let n = t.trackById, o = this.map.get(n); o || (o = new Uf, this.map.set(n, o)), o.add(t); }
    get(t, n) { let o = t, r = this.map.get(o); return r ? r.get(t, n) : null; }
    remove(t) { let n = t.trackById; return this.map.get(n).remove(t) && this.map.delete(n), t; }
    get isEmpty() { return this.map.size === 0; }
    clear() { this.map.clear(); }
};
function HC(e, t, n) { let o = e.previousIndex; if (o === null)
    return o; let r = 0; return n && o < n.length && (r = n[o]), o + t + r; }
var Oa = class {
    supports(t) { return t instanceof Map || sa(t); }
    create() { return new $f; }
}, $f = class {
    _records = new Map;
    _mapHead = null;
    _appendAfter = null;
    _previousMapHead = null;
    _changesHead = null;
    _changesTail = null;
    _additionsHead = null;
    _additionsTail = null;
    _removalsHead = null;
    get isDirty() { return this._additionsHead !== null || this._changesHead !== null || this._removalsHead !== null; }
    forEachItem(t) { let n; for (n = this._mapHead; n !== null; n = n._next)
        t(n); }
    forEachPreviousItem(t) { let n; for (n = this._previousMapHead; n !== null; n = n._nextPrevious)
        t(n); }
    forEachChangedItem(t) { let n; for (n = this._changesHead; n !== null; n = n._nextChanged)
        t(n); }
    forEachAddedItem(t) { let n; for (n = this._additionsHead; n !== null; n = n._nextAdded)
        t(n); }
    forEachRemovedItem(t) { let n; for (n = this._removalsHead; n !== null; n = n._nextRemoved)
        t(n); }
    diff(t) { if (!t)
        t = new Map;
    else if (!(t instanceof Map || sa(t)))
        throw new _(900, !1); return this.check(t) ? this : null; }
    check(t) { this._reset(); let n = this._mapHead; if (this._appendAfter = null, this._forEach(t, (o, r) => { if (n && n.key === r)
        this._maybeAddToChanges(n, o), this._appendAfter = n, n = n._next;
    else {
        let i = this._getOrCreateRecordForKey(r, o);
        n = this._insertBeforeOrAppend(n, i);
    } }), n) {
        n._prev && (n._prev._next = null), this._removalsHead = n;
        for (let o = n; o !== null; o = o._nextRemoved)
            o === this._mapHead && (this._mapHead = null), this._records.delete(o.key), o._nextRemoved = o._next, o.previousValue = o.currentValue, o.currentValue = null, o._prev = null, o._next = null;
    } return this._changesTail && (this._changesTail._nextChanged = null), this._additionsTail && (this._additionsTail._nextAdded = null), this.isDirty; }
    _insertBeforeOrAppend(t, n) { if (t) {
        let o = t._prev;
        return n._next = t, n._prev = o, t._prev = n, o && (o._next = n), t === this._mapHead && (this._mapHead = n), this._appendAfter = t, t;
    } return this._appendAfter ? (this._appendAfter._next = n, n._prev = this._appendAfter) : this._mapHead = n, this._appendAfter = n, null; }
    _getOrCreateRecordForKey(t, n) { if (this._records.has(t)) {
        let r = this._records.get(t);
        this._maybeAddToChanges(r, n);
        let i = r._prev, s = r._next;
        return i && (i._next = s), s && (s._prev = i), r._next = null, r._prev = null, r;
    } let o = new zf(t); return this._records.set(t, o), o.currentValue = n, this._addToAdditions(o), o; }
    _reset() { if (this.isDirty) {
        let t;
        for (this._previousMapHead = this._mapHead, t = this._previousMapHead; t !== null; t = t._next)
            t._nextPrevious = t._next;
        for (t = this._changesHead; t !== null; t = t._nextChanged)
            t.previousValue = t.currentValue;
        for (t = this._additionsHead; t != null; t = t._nextAdded)
            t.previousValue = t.currentValue;
        this._changesHead = this._changesTail = null, this._additionsHead = this._additionsTail = null, this._removalsHead = null;
    } }
    _maybeAddToChanges(t, n) { Object.is(n, t.currentValue) || (t.previousValue = t.currentValue, t.currentValue = n, this._addToChanges(t)); }
    _addToAdditions(t) { this._additionsHead === null ? this._additionsHead = this._additionsTail = t : (this._additionsTail._nextAdded = t, this._additionsTail = t); }
    _addToChanges(t) { this._changesHead === null ? this._changesHead = this._changesTail = t : (this._changesTail._nextChanged = t, this._changesTail = t); }
    _forEach(t, n) { t instanceof Map ? t.forEach(n) : Object.keys(t).forEach(o => n(t[o], o)); }
}, zf = class {
    key;
    previousValue = null;
    currentValue = null;
    _nextPrevious = null;
    _next = null;
    _prev = null;
    _nextAdded = null;
    _nextRemoved = null;
    _nextChanged = null;
    constructor(t) { this.key = t; }
};
function VC() { return new eT([new Aa]); }
var eT = (() => { class e {
    factories;
    static \u0275prov = B({ token: e, providedIn: "root", factory: VC });
    constructor(n) { this.factories = n; }
    static create(n, o) { if (o != null) {
        let r = o.factories.slice();
        n = n.concat(r);
    } return new e(n); }
    static extend(n) { return { provide: e, useFactory: () => { let o = I(e, { optional: !0, skipSelf: !0 }); return e.create(n, o || VC()); } }; }
    find(n) { let o = this.factories.find(r => r.supports(n)); if (o != null)
        return o; throw new _(901, !1); }
} return e; })();
function jC() { return new tT([new Oa]); }
var tT = (() => { class e {
    static \u0275prov = B({ token: e, providedIn: "root", factory: jC });
    factories;
    constructor(n) { this.factories = n; }
    static create(n, o) { if (o) {
        let r = o.factories.slice();
        n = n.concat(r);
    } return new e(n); }
    static extend(n) { return { provide: e, useFactory: () => { let o = I(e, { optional: !0, skipSelf: !0 }); return e.create(n, o || jC()); } }; }
    find(n) { let o = this.factories.find(r => r.supports(n)); if (o)
        return o; throw new _(901, !1); }
} return e; })(), _k = [new Oa], Sk = [new Aa], rL = new eT(Sk), iL = new tT(_k), sL = lk(null, "core", []), aL = (() => { class e {
    constructor(n) { }
    static \u0275fac = function (o) { return new (o || e)(Le(xe)); };
    static \u0275mod = Td({ type: e });
    static \u0275inj = Io({});
} return e; })();
function cL(e) { let { rootComponent: t, appProviders: n, platformProviders: o, platformRef: r } = e; if (x(R.BootstrapApplicationStart), typeof ngServerMode < "u" && ngServerMode && !r)
    throw new _(-401, !1); try {
    let i = r?.injector ?? dk(o), s = [Da(), Sc, ...n || []], a = new ur({ providers: s, parent: i, debugName: "", runEnvironmentInitializers: !1 });
    return QC({ r3Injector: a.injector, platformInjector: i, rootComponent: t });
}
catch (i) {
    return Promise.reject(i);
}
finally {
    x(R.BootstrapApplicationEnd);
} }
var Gf = class {
    views = [];
    indexByContent = new Map;
    add(t) { let n = JSON.stringify(t); if (!this.indexByContent.has(n)) {
        let o = this.views.length;
        return this.views.push(t), this.indexByContent.set(n, o), o;
    } return this.indexByContent.get(n); }
    getAll() { return this.views; }
}, bk = 0;
function nT(e) { return e.ssrId || (e.ssrId = `t${bk++}`), e.ssrId; }
function oT(e, t, n) { let o = []; return Bn(e, t, n, o), o.length; }
function Ak(e) { let t = []; return Js(e, t), t.length; }
function rT(e, t) { let n = e[j]; return n && !n.hasAttribute(dn) ? ka(n, e, null, t) : null; }
function iT(e, t) { let n = bo(e[j]), o = rT(n, t); if (o === null)
    return; let r = k(n[j]), i = e[q], s = ka(r, i, null, t), a = n[T], c = `${o}|${s}`; a.setAttribute(r, xn, c); }
function lL(e, t) { let n = e.injector, o = Vy(n), r = Nr(n), i = new Gf, s = new Map, a = e._views, c = n.get(_s, mu), l = { regular: new Set, capture: new Set }, u = new Map; e.injector.get(lt); for (let p of a) {
    let h = Tu(p);
    if (h !== null) {
        let y = { serializedViewCollection: i, corruptedTextNodes: s, isI18nHydrationEnabled: o, isIncrementalHydrationEnabled: r, i18nChildren: new Map, eventTypesToReplay: l, shouldReplayEvents: c, deferBlocks: u };
        ee(h) ? iT(h, y) : rT(h, y), Pk(s, t);
    }
} let d = i.getAll(), f = n.get(Xn); if (f.set(Ss, d), u.size > 0) {
    let p = {};
    for (let [h, y] of u.entries())
        p[h] = y;
    f.set(bs, p);
} return l; }
function Rk(e, t, n, o, r) { let i = [], s = ""; for (let a = V; a < e.length; a++) {
    let c = e[a], l, u, d;
    if (We(c) && (c = c[E], ee(c))) {
        u = Ak(c) + 1, iT(c, r);
        let p = bo(c[j]);
        d = { [Ms]: p[m].ssrId, [st]: u };
    }
    if (!d) {
        let p = c[m];
        p.type === 1 ? (l = p.ssrId, u = 1) : (l = nT(p), u = oT(p, c, p.firstChild)), d = { [Ms]: l, [st]: u };
        let h = !1;
        if (Yv(n[m], t)) {
            let y = ye(n, t), v = ce(n[m], t);
            if (r.isIncrementalHydrationEnabled && v.hydrateTriggers !== null) {
                let D = `d${r.deferBlocks.size}`;
                v.hydrateTriggers.has(7) && (h = !0);
                let b = [];
                Js(e, b);
                let X = { [st]: b.length, [Cr]: y[pt] }, Pe = Ok(v.hydrateTriggers);
                Pe.length > 0 && (X[Tr] = Pe), o !== null && (X[pu] = o), r.deferBlocks.set(D, X);
                let Me = k(e);
                Me !== void 0 ? Me.nodeType === Node.COMMENT_NODE && BC(Me, D) : BC(Me, D), h || Fk(v, b, D, r), o = D, d[ws] = D;
            }
            d[Cr] = y[pt];
        }
        if (!h) {
            let y = k(c[j]);
            (c[m].type !== 1 || y === null || !y.hasAttribute(dn)) && Object.assign(d, sT(e[a], o, r));
        }
    }
    let f = JSON.stringify(d);
    if (i.length > 0 && f === s) {
        let p = i[i.length - 1];
        p[Ir] ??= 1, p[Ir]++;
    }
    else
        s = f, i.push(d);
} return i; }
function Ok(e) { let t = new Set([0, 1, 2, 5]), n = []; for (let [o, r] of e)
    t.has(o) && (r === null ? n.push(o) : r.type === 5 ? n.push({ trigger: o, delay: r.delay }) : n.push({ trigger: o, intersectionObserverOptions: r.intersectionObserverOptions })); return n; }
function $r(e, t, n, o) { let r = t.index - E; e[Dr] ??= {}, e[Dr][r] ??= xy(t, n, o); }
function Lf(e, t) { let n = typeof t == "number" ? t : t.index - E; e[to] ??= [], e[to].includes(n) || e[to].push(n); }
function sT(e, t = null, n) { let o = {}, r = e[m], i = jy(r, n), s = n.shouldReplayEvents ? hk(r, e, n.eventTypesToReplay) : null; for (let a = E; a < r.bindingStartIndex; a++) {
    let c = r.data[a], l = a - E, u = By(e, a, n);
    if (u) {
        o[Ns] ??= {}, o[Ns][l] = u.caseQueue;
        for (let d of u.disconnectedNodes)
            Lf(o, d);
        for (let d of u.disjointNodes) {
            let f = r.data[d + E];
            $r(o, f, e, i);
        }
        continue;
    }
    if (ys(c) && !oo(c)) {
        if (ee(e[a]) && c.tView && (o[Ts] ??= {}, o[Ts][l] = nT(c.tView)), lo(c, e) && Lk(c)) {
            Lf(o, c);
            continue;
        }
        if (Array.isArray(c.projection)) {
            for (let d of c.projection)
                if (d)
                    if (!Array.isArray(d))
                        !ec(d) && !Jn(d) && (lo(d, e) ? Lf(o, d) : $r(o, d, e, i));
                    else
                        throw Ny(k(e[a]));
        }
        if (kk(o, c, e, i), ee(e[a])) {
            let d = e[a][j];
            if (Array.isArray(d)) {
                let f = k(d);
                f.hasAttribute(dn) || ka(f, d, t, n);
            }
            o[eo] ??= {}, o[eo][l] = Rk(e[a], c, e, t, n);
        }
        else if (Array.isArray(e[a]) && !fg(c)) {
            let d = k(e[a][j]);
            d.hasAttribute(dn) || ka(d, e[a], t, n);
        }
        else if (c.type & 8)
            o[Er] ??= {}, o[Er][l] = oT(r, e, c.child);
        else if (c.type & 144) {
            let d = c.next;
            for (; d !== null && d.type & 144;)
                d = d.next;
            d && !Jn(d) && $r(o, d, e, i);
        }
        else if (c.type & 1) {
            let d = k(e[a]);
            Nu(n, d);
        }
        if (s && c.type & 2) {
            let d = k(e[a]);
            s.has(d) && vu(d, s.get(d), t);
        }
    }
} return o; }
function kk(e, t, n, o) { ec(t) || (t.projectionNext && t.projectionNext !== t.next && !Jn(t.projectionNext) && $r(e, t.projectionNext, n, o), t.prev === null && t.parent !== null && lo(t.parent, n) && !lo(t, n) && $r(e, t, n, o)); }
function xk(e) { let t = e[H]; if (!t?.constructor)
    return !1; let n = W(t.constructor); return n?.encapsulation === Oe.ShadowDom || n?.encapsulation === Oe.ExperimentalIsolatedShadowDom; }
function ka(e, t, n, o) { let r = t[T]; if (dp(t) && !na() || xk(t))
    return r.setAttribute(e, dn, ""), null; {
    let i = sT(t, n, o), s = o.serializedViewCollection.add(i);
    return r.setAttribute(e, xn, s.toString()), s;
} }
function BC(e, t) { e.textContent = `ngh=${t}`; }
function Pk(e, t) { for (let [n, o] of e)
    n.after(t.createComment(o)); }
function Lk(e) { let t = e; for (; t != null;) {
    if (me(t))
        return !0;
    t = t.parent;
} return !1; }
function Fk(e, t, n, o) { let r = am(e.hydrateTriggers); for (let i of r)
    o.eventTypesToReplay.regular.add(i); if (r.length > 0) {
    let i = t.filter(s => s.nodeType === Node.ELEMENT_NODE);
    for (let s of i)
        vu(s, r, n);
} }
function uL(e) { return typeof e == "boolean" ? e : e != null && e !== "false"; }
function dL(e, t = NaN) { return !isNaN(parseFloat(e)) && !isNaN(Number(e)) ? Number(e) : t; }
var Hk = "\u{1F170}\uFE0F", La = !1;
function fL(e) { if (!La)
    return; let { startLabel: t } = aT(e); performance.mark(t); }
function pL(e) { if (!La)
    return; let { startLabel: t, labelName: n, endLabel: o } = aT(e); performance.mark(o), performance.measure(n, t, o), performance.clearMarks(t), performance.clearMarks(o); }
function aT(e) { let t = `${Hk}:${e}`; return { labelName: t, startLabel: `start:${t}`, endLabel: `end:${t}` }; }
var UC = !1;
function hL() { if (!UC && (typeof performance > "u" || !performance.mark || !performance.measure)) {
    UC = !0, console.warn("Performance API is not supported on this platform");
    return;
} La = !0; }
function gL() { La = !1; }
function mL(e) { }
function yL(e) { return oe({ usage: 1, kind: "directive", type: e.type }).compileDirectiveDeclaration(ge, `ng:///${e.type.name}/\u0275fac.js`, e); }
function vL(e) { bd(e.type, e.decorators, e.ctorParameters ?? null, e.propDecorators ?? null); }
function EL(e) { tE(e.type, e.resolveDeferredDeps, (...t) => { let n = e.resolveMetadata(...t); bd(e.type, n.decorators, n.ctorParameters, n.propDecorators); }); }
function IL(e) { return oe({ usage: 1, kind: "component", type: e.type }).compileComponentDeclaration(ge, `ng:///${e.type.name}/\u0275cmp.js`, e); }
function DL(e) { return oe({ usage: 1, kind: Vk(e.target), type: e.type }).compileFactoryDeclaration(ge, `ng:///${e.type.name}/\u0275fac.js`, e); }
function Vk(e) { switch (e) {
    case go.Directive: return "directive";
    case go.Component: return "component";
    case go.Injectable: return "injectable";
    case go.Pipe: return "pipe";
    case go.NgModule: return "NgModule";
} }
function CL(e) { return oe({ usage: 1, kind: "injectable", type: e.type }).compileInjectableDeclaration(ge, `ng:///${e.type.name}/\u0275prov.js`, e); }
function TL(e) { return oe({ usage: 1, kind: "NgModule", type: e.type }).compileInjectorDeclaration(ge, `ng:///${e.type.name}/\u0275inj.js`, e); }
function ML(e) { return oe({ usage: 1, kind: "NgModule", type: e.type }).compileNgModuleDeclaration(ge, `ng:///${e.type.name}/\u0275mod.js`, e); }
function NL(e) { return oe({ usage: 1, kind: "pipe", type: e.type }).compilePipeDeclaration(ge, `ng:///${e.type.name}/\u0275pipe.js`, e); }
var Ff = Symbol("NOT_SET"), cT = new Set, jk = et(Z({}, Va), { kind: "afterRenderEffectPhase", consumerIsAlwaysLive: !0, consumerAllowSignalWrites: !0, value: Ff, cleanup: null, consumerMarkedDirty() { if (this.sequence.impl.executing) {
        if (this.sequence.lastPhase === null || this.sequence.lastPhase < this.phase)
            return;
        this.sequence.erroredOrDestroyed = !0;
    } this.sequence.scheduler.notify(7); }, phaseFn(e) { if (this.sequence.lastPhase = this.phase, !this.dirty)
        return this.signal; if (this.dirty = !1, this.value !== Ff && !qr(this))
        return this.signal; try {
        for (let r of this.cleanup ?? cT)
            r();
    }
    finally {
        this.cleanup?.clear();
    } let t = []; e !== void 0 && t.push(e), t.push(this.registerCleanupFn); let n = vo(this), o; try {
        o = this.userFn.apply(null, t);
    }
    finally {
        Wr(this, n);
    } return (this.value === Ff || !this.equal(this.value, o)) && (this.value = o, this.version++), this.signal; } }), Wf = class extends nr {
    scheduler;
    lastPhase = null;
    nodes = [void 0, void 0, void 0, void 0];
    onDestroyFns = null;
    constructor(t, n, o, r, i, s = null) { super(t, [void 0, void 0, void 0, void 0], o, !1, i.get(Po), s), this.scheduler = r; for (let a of Gu) {
        let c = n[a];
        if (c === void 0)
            continue;
        let l = Object.create(jk);
        l.sequence = this, l.phase = a, l.userFn = c, l.dirty = !0, l.signal = () => (Gr(l), l.value), l.signal[tt] = l, l.registerCleanupFn = u => (l.cleanup ??= new Set).add(u), this.nodes[a] = l, this.hooks[a] = u => l.phaseFn(u);
    } }
    afterRun() { super.afterRun(), this.lastPhase = null; }
    destroy() { if (this.onDestroyFns !== null)
        for (let t of this.onDestroyFns)
            t(); super.destroy(); for (let t of this.nodes)
        if (t)
            try {
                for (let n of t.cleanup ?? cT)
                    n();
            }
            finally {
                Eo(t);
            } }
};
function wL(e, t) { if (typeof ngServerMode < "u" && ngServerMode)
    return Us; let n = t?.injector ?? I(Te), o = n.get(Nt), r = n.get(Bs), i = n.get(hn, null, { optional: !0 }); r.impl ??= n.get(Wu); let s = e; typeof s == "function" && (s = { mixedReadWrite: e }); let a = n.get(Ei, null, { optional: !0 }), c = new Wf(r.impl, [s.earlyRead, s.write, s.mixedReadWrite, s.read], a?.view, o, n, i?.snapshot(null)); return r.impl.register(c), c; }
function _L(e) { return new qf(Ad(e) ? e : qt(e)); }
var qf = class {
    snapshot;
    constructor(t) { this.snapshot = t; }
    get state() { return this.snapshot(); }
    value = qt(() => { if (this.state.status === "error")
        throw new Lp(this.state.error); return this.state.value; });
    status = qt(() => this.state.status);
    error = qt(() => this.state.status === "error" ? this.state.error : void 0);
    isLoading = qt(() => this.state.status === "loading" || this.state.status === "reloading");
    isValueDefined = qt(() => this.state.status !== "error" && this.state.value !== void 0);
    hasValue() { return this.isValueDefined(); }
};
function SL(e, t) { let n = W(e), o = t.elementInjector || si(); return new Ot(n).create(o, t.projectableNodes, t.hostElement, t.environmentInjector, t.directives, t.bindings); }
function bL(e) { let t = W(e); if (!t)
    return null; let n = new Ot(t); return { get selector() { return n.selector; }, get type() { return n.componentType; }, get inputs() { return n.inputs; }, get outputs() { return n.outputs; }, get ngContentSelectors() { return n.ngContentSelectors; }, get isStandalone() { return t.standalone; }, get isSignal() { return t.signals; } }; }
function AL(...e) { return e.reduce((t, n) => Object.assign(t, n, { providers: [...t.providers, ...n.providers] }), { providers: [] }); }
var RL = new S("", { providedIn: "platform", factory: () => null }), OL = new S("", { providedIn: "platform", factory: () => null }), kL = new S("", { providedIn: "platform", factory: () => null });
export { $M as ANIMATION_MODULE_TYPE, Lr as APP_BOOTSTRAP_LISTENER, lt as APP_ID, xd as APP_INITIALIZER, Pd as ApplicationInitStatus, aL as ApplicationModule, xe as ApplicationRef, Mg as Attribute, eC as COMPILER_OPTIONS, zM as CSP_NONCE, mN as CUSTOM_ELEMENTS_SCHEMA, Is as ChangeDetectionStrategy, Tk as ChangeDetectorRef, iO as Compiler, ru as CompilerFactory, JR as Component, ia as ComponentFactory, kr as ComponentFactoryResolver, Zy as ComponentRef, UP as ContentChild, BP as ContentChildren, cO as DEFAULT_CURRENCY_CODE, zt as DOCUMENT, un as DebugElement, iu as DebugEventListener, gr as DebugNode, jf as DefaultIterableDiffer, Po as DestroyRef, XD as Directive, Et as ENVIRONMENT_INITIALIZER, vr as ElementRef, FC as EmbeddedViewRef, It as EnvironmentInjector, _c as ErrorHandler, MT as EventEmitter, kP as HOST_TAG_NAME, og as Host, TC as HostAttributeToken, nO as HostBinding, oO as HostListener, ET as INJECTOR, Xh as Inject, hM as Injectable, S as InjectionToken, Te as Injector, eO as Input, eT as IterableDiffers, tT as KeyValueDiffers, wf as LOCALE_ID, Gm as MAX_ANIMATION_TIMEOUT, nC as MissingTranslationStrategy, ms as ModuleWithComponentFactories, yN as NO_ERRORS_SCHEMA, rO as NgModule, bv as NgModuleFactory, zn as NgModuleRef, U as NgZone, eg as Optional, tO as Output, Oc as OutputEmitterRef, UM as PLATFORM_ID, uu as PLATFORM_INITIALIZER, Ac as PendingTasks, XR as Pipe, ZC as PlatformRef, yo as Query, Qi as QueryList, RL as REQUEST, kL as REQUEST_CONTEXT, OL as RESPONSE_INIT, iS as Renderer2, ar as RendererFactory2, Xi as RendererStyleFlags2, Ky as Sanitizer, ae as SecurityContext, tg as Self, $i as SimpleChange, ng as SkipSelf, lO as TRANSLATIONS, uO as TRANSLATIONS_FORMAT, rr as TemplateRef, $b as Testability, rE as TestabilityRegistry, Xn as TransferState, rg as Type, pT as VERSION, fT as Version, zP as ViewChild, $P as ViewChildren, ca as ViewContainerRef, Oe as ViewEncapsulation, Vf as ViewRef, Zm as afterEveryRender, qu as afterNextRender, wL as afterRenderEffect, dO as asNativeElements, CT as assertInInjectionContext, _T as assertNotInReactiveContext, uk as assertPlatform, uL as booleanAttribute, qt as computed, HP as contentChild, VP as contentChildren, SL as createComponent, Cd as createEnvironmentInjector, Av as createNgModule, nb as createNgModuleRef, ck as createPlatform, lk as createPlatformFactory, WP as destroyPlatform, bT as effect, ZP as enableProdMode, Vb as enableProfiling, Ua as forwardRef, mr as getDebugNode, nL as getModuleFactory, oL as getNgModuleById, Pa as getPlatform, DT as importProvidersFrom, I as inject, PP as input, uv as inputBinding, YP as isDevMode, Ad as isSignal, Do as isStandalone, Rd as isWritableSignal, OT as linkedSignal, nt as makeEnvironmentProviders, WM as makeStateKey, AL as mergeApplicationConfig, jP as model, dL as numberAttribute, xP as output, dv as outputBinding, sL as platformCore, aE as provideAppInitializer, NT as provideBrowserGlobalErrorListeners, QP as provideCheckNoChangesConfig, IT as provideEnvironmentInitializer, JN as provideNgReflectAttributes, qP as providePlatformInitializer, tL as provideStabilityDebugging, GP as provideZoneChangeDetection, sO as provideZonelessChangeDetection, bL as reflectComponentType, G as resolveForwardRef, kT as resource, _L as resourceFromSnapshots, ai as runInInjectionContext, iE as setTestabilityGetter, bc as signal, _S as twoWayBinding, RT as untracked, LP as viewChild, FP as viewChildren, zm as \u0275ANIMATIONS_DISABLED, Pg as \u0275AcxChangeDetectionStrategy, Lg as \u0275AcxViewEncapsulation, Bs as \u0275AfterRenderManager, KP as \u0275CLIENT_RENDER_MODE_FLAG, V as \u0275CONTAINER_HEADER_OFFSET, Nt as \u0275ChangeDetectionScheduler, ia as \u0275ComponentFactory, Hb as \u0275Console, Vr as \u0275DEFAULT_LOCALE_ID, Jv as \u0275DEFER_BLOCK_CONFIG, kb as \u0275DEFER_BLOCK_DEPENDENCY_INTERCEPTOR, ut as \u0275DEHYDRATED_BLOCK_REGISTRY, _d as \u0275DeferBlockBehavior, $ as \u0275DeferBlockState, ik as \u0275ENABLE_ROOT_COMPONENT_BOOTSTRAP, Ug as \u0275EVENT_REPLAY_QUEUE, Rc as \u0275EffectScheduler, YO as \u0275Framework, om as \u0275HydrationStatus, GM as \u0275IMAGE_CONFIG, Fg as \u0275IMAGE_CONFIG_DEFAULTS, cp as \u0275INJECTOR_SCOPE, OP as \u0275INPUT_SIGNAL_BRAND_WRITE_TYPE, Wt as \u0275INTERNAL_APPLICATION_ERROR_HANDLER, qM as \u0275IS_ENABLED_BLOCKING_INITIAL_NAVIGATION, fn as \u0275IS_HYDRATION_DOM_REUSE_ENABLED, yu as \u0275IS_INCREMENTAL_HYDRATION_ENABLED, Mr as \u0275JSACTION_BLOCK_ELEMENT_MAP, Du as \u0275JSACTION_EVENT_CONTRACT, Yi as \u0275LContext, qn as \u0275LocaleDataIndex, yt as \u0275NG_COMP_DEF, yn as \u0275NG_DIR_DEF, Lt as \u0275NG_ELEMENT_ID, $a as \u0275NG_INJ_DEF, za as \u0275NG_MOD_DEF, Xr as \u0275NG_PIPE_DEF, Jr as \u0275NG_PROV_DEF, Fi as \u0275NOT_FOUND_CHECK_ONLY_ELEMENT_INJECTOR, L as \u0275NO_CHANGE, Wn as \u0275NgModuleFactory, wc as \u0275NoopNgZone, Hk as \u0275PERFORMANCE_MARK_PREFIX, nk as \u0275PROVIDED_NG_ZONE, ST as \u0275PROVIDED_ZONELESS, Gt as \u0275PendingTasksInternal, R as \u0275ProfilerEvent, Za as \u0275R3Injector, Ui as \u0275ReflectionCapabilities, Ot as \u0275Render3ComponentFactory, as as \u0275Render3ComponentRef, Gn as \u0275Render3NgModuleRef, xT as \u0275ResourceImpl, _ as \u0275RuntimeError, tt as \u0275SIGNAL, Xg as \u0275SSR_CONTENT_INTEGRITY_MARKER, nE as \u0275TESTABILITY, oE as \u0275TESTABILITY_GETTER, Kv as \u0275TimerScheduler, js as \u0275TracingAction, hn as \u0275TracingService, Rt as \u0275ViewRef, Qr as \u0275XSS_SECURITY_URL, Tn as \u0275ZONELESS_ENABLED, _m as \u0275_sanitizeHtml, ks as \u0275_sanitizeUrl, on as \u0275allLeavingAnimations, io as \u0275allowSanitizationBypassAndThrow, lL as \u0275annotateForHydration, mL as \u0275assertType, TN as \u0275bypassSanitizationTrustHtml, _N as \u0275bypassSanitizationTrustResourceUrl, NN as \u0275bypassSanitizationTrustScript, MN as \u0275bypassSanitizationTrustStyle, wN as \u0275bypassSanitizationTrustUrl, KS as \u0275clearResolutionOfComponentResourcesQueue, $D as \u0275compileComponent, Nf as \u0275compileDirective, BD as \u0275compileNgModule, UD as \u0275compileNgModuleDefs, ek as \u0275compileNgModuleFactory, JD as \u0275compilePipe, Wa as \u0275convertToBitFlags, TT as \u0275createInjector, dk as \u0275createOrReusePlatformInjector, rL as \u0275defaultIterableDiffers, iL as \u0275defaultKeyValueDiffers, Un as \u0275depsTracker, ov as \u0275devModeEqual, gL as \u0275disableProfiling, hL as \u0275enableProfiling, PT as \u0275encapsulateResourceError, Zd as \u0275findLocaleData, VD as \u0275flushModuleScopingQueueAsMuchAsPossible, ep as \u0275formatRuntimeError, VR as \u0275generateStandaloneInDeclarationsError, Fb as \u0275getAsyncClassMetadataFn, SS as \u0275getClosestComponentName, W as \u0275getComponentDef, ji as \u0275getDeferBlocks, kM as \u0275getDirectives, Cs as \u0275getDocument, PM as \u0275getHostElement, gT as \u0275getInjectableDef, Ie as \u0275getLContext, vA as \u0275getLocaleCurrencyCode, qE as \u0275getLocalePluralCase, AT as \u0275getOutputDestroyRef, Im as \u0275getSanitizationBypassType, jb as \u0275getTransferState, EN as \u0275getUnknownElementStrictMode, DN as \u0275getUnknownPropertyStrictMode, De as \u0275global, fv as \u0275inferTagNameFromDefinition, Mk as \u0275injectChangeDetectorRef, cL as \u0275internalCreateApplication, ok as \u0275internalProvideZoneChangeDetection, cE as \u0275isBoundToModule, ZS as \u0275isComponentDefPendingResolution, vT as \u0275isEnvironmentProviders, mT as \u0275isInjectable, Yt as \u0275isNgModule, kd as \u0275isPromise, sE as \u0275isSubscribable, c_ as \u0275isViewDirty, l_ as \u0275markForRefresh, Je as \u0275noSideEffects, Tf as \u0275patchComponentDefWithScope, Q as \u0275performanceMarkFeature, fa as \u0275promiseWithResolvers, Da as \u0275provideZonelessChangeDetectionInternal, Bb as \u0275publishExternalGlobalUtil, rN as \u0275readHydrationInfo, yA as \u0275registerLocaleData, rt as \u0275renderDeferBlockState, UR as \u0275resetCompiledComponents, sN as \u0275resetIncrementalHydrationEnabledWarnedForTests, FR as \u0275resetJitOptions, Nv as \u0275resolveComponentResources, JS as \u0275restoreComponentResolutionQueue, tb as \u0275setAllowDuplicateNgModuleIdsForTest, LT as \u0275setAlternateWeakRefImpl, PD as \u0275setClassDebugInfo, bd as \u0275setClassMetadata, tE as \u0275setClassMetadataAsync, dT as \u0275setCurrentInjector, jM as \u0275setDocument, yT as \u0275setInjectorProfilerContext, KE as \u0275setLocaleId, vN as \u0275setUnknownElementStrictMode, IN as \u0275setUnknownPropertyStrictMode, fL as \u0275startMeasuring, pL as \u0275stopMeasuring, Ao as \u0275store, Yr as \u0275stringify, Mf as \u0275transitiveScopesFor, pa as \u0275triggerResourceLoading, hT as \u0275truncateMiddle, EA as \u0275unregisterLocaleData, dt as \u0275unwrapSafeValue, wT as \u0275unwrapWritableSignal, JP as \u0275withDomHydration, fk as \u0275withEventReplay, XP as \u0275withI18nSupport, eL as \u0275withIncrementalHydration, Hv as \u0275\u0275ControlFeature, lD as \u0275\u0275ExternalStylesFeature, go as \u0275\u0275FactoryTarget, Vv as \u0275\u0275HostDirectivesFeature, Md as \u0275\u0275InheritDefinitionFeature, sg as \u0275\u0275NgOnChangesFeature, cD as \u0275\u0275ProvidersFeature, Um as \u0275\u0275advance, zo as \u0275\u0275animateEnter, Go as \u0275\u0275animateEnterListener, Wo as \u0275\u0275animateLeave, us as \u0275\u0275animateLeaveListener, Hd as \u0275\u0275ariaProperty, iD as \u0275\u0275arrowFunction, QI as \u0275\u0275attachSourceLocations, Vd as \u0275\u0275attribute, MI as \u0275\u0275classMap, uf as \u0275\u0275classProp, FE as \u0275\u0275componentInstance, VE as \u0275\u0275conditional, ha as \u0275\u0275conditionalBranchCreate, HE as \u0275\u0275conditionalCreate, rf as \u0275\u0275contentQuery, af as \u0275\u0275contentQuerySignal, av as \u0275\u0275control, iv as \u0275\u0275controlCreate, Cf as \u0275\u0275declareLet, hE as \u0275\u0275defer, eE as \u0275\u0275deferEnableTimerScheduling, vE as \u0275\u0275deferHydrateNever, AE as \u0275\u0275deferHydrateOnHover, DE as \u0275\u0275deferHydrateOnIdle, ME as \u0275\u0275deferHydrateOnImmediate, kE as \u0275\u0275deferHydrateOnInteraction, _E as \u0275\u0275deferHydrateOnTimer, LE as \u0275\u0275deferHydrateOnViewport, yE as \u0275\u0275deferHydrateWhen, SE as \u0275\u0275deferOnHover, EE as \u0275\u0275deferOnIdle, CE as \u0275\u0275deferOnImmediate, RE as \u0275\u0275deferOnInteraction, NE as \u0275\u0275deferOnTimer, xE as \u0275\u0275deferOnViewport, bE as \u0275\u0275deferPrefetchOnHover, IE as \u0275\u0275deferPrefetchOnIdle, TE as \u0275\u0275deferPrefetchOnImmediate, OE as \u0275\u0275deferPrefetchOnInteraction, wE as \u0275\u0275deferPrefetchOnTimer, PE as \u0275\u0275deferPrefetchOnViewport, mE as \u0275\u0275deferPrefetchWhen, gE as \u0275\u0275deferWhen, Ov as \u0275\u0275defineComponent, xv as \u0275\u0275defineDirective, B as \u0275\u0275defineInjectable, Io as \u0275\u0275defineInjector, Td as \u0275\u0275defineNgModule, Pv as \u0275\u0275definePipe, uo as \u0275\u0275directiveInject, cc as \u0275\u0275disableBindings, Ud as \u0275\u0275domElement, Wd as \u0275\u0275domElementContainer, Gd as \u0275\u0275domElementContainerEnd, Ea as \u0275\u0275domElementContainerStart, ya as \u0275\u0275domElementEnd, ma as \u0275\u0275domElementStart, nf as \u0275\u0275domListener, Qd as \u0275\u0275domProperty, wd as \u0275\u0275domTemplate, Bd as \u0275\u0275element, zd as \u0275\u0275elementContainer, Hr as \u0275\u0275elementContainerEnd, va as \u0275\u0275elementContainerStart, ga as \u0275\u0275elementEnd, fr as \u0275\u0275elementStart, ac as \u0275\u0275enableBindings, xD as \u0275\u0275getComponentDepsFactory, WE as \u0275\u0275getCurrentView, Cg as \u0275\u0275getInheritedFactory, LD as \u0275\u0275getReplaceMetadataURL, cI as \u0275\u0275i18n, uI as \u0275\u0275i18nApply, lI as \u0275\u0275i18nAttributes, Jd as \u0275\u0275i18nEnd, Xd as \u0275\u0275i18nExp, dI as \u0275\u0275i18nPostprocess, Kd as \u0275\u0275i18nStart, Le as \u0275\u0275inject, vs as \u0275\u0275injectAttribute, YI as \u0275\u0275interpolate, ZI as \u0275\u0275interpolate1, KI as \u0275\u0275interpolate2, JI as \u0275\u0275interpolate3, XI as \u0275\u0275interpolate4, eD as \u0275\u0275interpolate5, tD as \u0275\u0275interpolate6, nD as \u0275\u0275interpolate7, oD as \u0275\u0275interpolate8, rD as \u0275\u0275interpolateV, Jy as \u0275\u0275invalidFactory, ti as \u0275\u0275invalidFactoryDep, ef as \u0275\u0275listener, mI as \u0275\u0275loadQuery, Mc as \u0275\u0275namespaceHTML, Tc as \u0275\u0275namespaceMathML, Cc as \u0275\u0275namespaceSVG, fI as \u0275\u0275nextContext, vL as \u0275\u0275ngDeclareClassMetadata, EL as \u0275\u0275ngDeclareClassMetadataAsync, IL as \u0275\u0275ngDeclareComponent, yL as \u0275\u0275ngDeclareDirective, DL as \u0275\u0275ngDeclareFactory, CL as \u0275\u0275ngDeclareInjectable, TL as \u0275\u0275ngDeclareInjector, ML as \u0275\u0275ngDeclareNgModule, NL as \u0275\u0275ngDeclarePipe, _D as \u0275\u0275pipe, SD as \u0275\u0275pipeBind1, bD as \u0275\u0275pipeBind2, AD as \u0275\u0275pipeBind3, RD as \u0275\u0275pipeBind4, OD as \u0275\u0275pipeBindV, hI as \u0275\u0275projection, pI as \u0275\u0275projectionDef, jd as \u0275\u0275property, fD as \u0275\u0275pureFunction0, pD as \u0275\u0275pureFunction1, hD as \u0275\u0275pureFunction2, gD as \u0275\u0275pureFunction3, mD as \u0275\u0275pureFunction4, yD as \u0275\u0275pureFunction5, vD as \u0275\u0275pureFunction6, ED as \u0275\u0275pureFunction7, ID as \u0275\u0275pureFunction8, DD as \u0275\u0275pureFunctionV, yI as \u0275\u0275queryAdvance, gI as \u0275\u0275queryRefresh, qI as \u0275\u0275readContextLet, vI as \u0275\u0275reference, Id as \u0275\u0275registerNgModuleType, $E as \u0275\u0275repeater, UE as \u0275\u0275repeaterCreate, BE as \u0275\u0275repeaterTrackByIdentity, jE as \u0275\u0275repeaterTrackByIndex, FD as \u0275\u0275replaceMetadata, dc as \u0275\u0275resetView, Lu as \u0275\u0275resolveBody, Hm as \u0275\u0275resolveDocument, Fm as \u0275\u0275resolveWindow, uc as \u0275\u0275restoreView, Ru as \u0275\u0275sanitizeHtml, Ps as \u0275\u0275sanitizeResourceUrl, xu as \u0275\u0275sanitizeScript, Ou as \u0275\u0275sanitizeStyle, ku as \u0275\u0275sanitizeUrl, xm as \u0275\u0275sanitizeUrlOrResourceUrl, uD as \u0275\u0275setComponentScope, dD as \u0275\u0275setNgModuleScope, WI as \u0275\u0275storeLet, TI as \u0275\u0275styleMap, lf as \u0275\u0275styleProp, tf as \u0275\u0275syntheticHostListener, Yd as \u0275\u0275syntheticHostProperty, Nd as \u0275\u0275template, kD as \u0275\u0275templateRefExtractor, OI as \u0275\u0275text, df as \u0275\u0275textInterpolate, Ia as \u0275\u0275textInterpolate1, ff as \u0275\u0275textInterpolate2, pf as \u0275\u0275textInterpolate3, hf as \u0275\u0275textInterpolate4, gf as \u0275\u0275textInterpolate5, mf as \u0275\u0275textInterpolate6, yf as \u0275\u0275textInterpolate7, vf as \u0275\u0275textInterpolate8, Ef as \u0275\u0275textInterpolateV, Om as \u0275\u0275trustConstantHtml, km as \u0275\u0275trustConstantResourceUrl, zI as \u0275\u0275twoWayBindingSet, Df as \u0275\u0275twoWayListener, If as \u0275\u0275twoWayProperty, Pu as \u0275\u0275validateAttribute, sf as \u0275\u0275viewQuery, cf as \u0275\u0275viewQuerySignal };
/*! Bundled license information:

@angular/core/fesm2022/_attribute-chunk.mjs:
@angular/core/fesm2022/_debug_node-chunk.mjs:
@angular/core/fesm2022/primitives-event-dispatch.mjs:
@angular/core/fesm2022/core.mjs:
  (**
   * @license Angular v21.2.20
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
