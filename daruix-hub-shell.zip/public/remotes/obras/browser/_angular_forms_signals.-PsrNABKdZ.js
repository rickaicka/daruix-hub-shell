import { a as y, b as V, d as L } from "@nf-internal/chunk-4CLCTAJ7";
import * as w from "@angular/core";
import { InjectionToken as Oe, resource as jt, \u0275isPromise as et, linkedSignal as it, inject as S, \u0275RuntimeError as Se, untracked as H, input as st, Renderer2 as xt, DestroyRef as Bt, computed as J, Injector as Ut, ElementRef as Ht, signal as Gt, afterRenderEffect as zt, effect as $t } from "@angular/core";
import { Validators as qt, NG_VALUE_ACCESSOR as Xt, NgControl as Yt } from "@angular/forms";
import { untracked as l, \u0275RuntimeError as p, computed as d, runInInjectionContext as He, Injector as Ge, linkedSignal as $, signal as G, APP_ID as lt, effect as ht, inject as ft } from "@angular/core";
import { AbstractControl as gt, FormGroup as Rr, FormArray as Tr } from "@angular/forms";
import { SIGNAL as Ke } from "@angular/core/primitives/signals";
var te = 0;
function mt() { return te; }
function M(t, e) { return (...r) => { try {
    return te = e, t(...r);
}
finally {
    te = 0;
} }; }
function pt(t) { return !t; }
function je(t) { return t; }
function N(t) { return Array.isArray(t); }
function k(t) { return (typeof t == "object" || typeof t == "function") && t != null; }
var D = Symbol(), Q = Symbol(), j = class {
    predicates;
    fns = [];
    constructor(e) { this.predicates = e; }
    push(e) { this.fns.push(xe(this.predicates, e)); }
    mergeIn(e) { let r = this.predicates ? e.fns.map(n => xe(this.predicates, n)) : e.fns; this.fns.push(...r); }
}, q = class extends j {
    get defaultValue() { return !1; }
    compute(e) { return this.fns.some(r => { let n = r(e); return n && n !== Q; }); }
}, F = class t extends j {
    ignore;
    static ignoreNull(e) { return new t(e, r => r === null); }
    constructor(e, r) { super(e), this.ignore = r; }
    get defaultValue() { return []; }
    compute(e) { return this.fns.reduce((r, n) => { let i = n(e); return i === void 0 || i === Q ? r : N(i) ? [...r, ...this.ignore ? i.filter(s => !this.ignore(s)) : i] : this.ignore && this.ignore(i) ? r : [...r, i]; }, []); }
}, re = class extends F {
    constructor(e) { super(e, void 0); }
}, ne = class extends j {
    key;
    get defaultValue() { return this.key.reducer.getInitial(); }
    constructor(e, r) { super(e), this.key = r; }
    compute(e) { if (this.fns.length === 0)
        return this.key.reducer.getInitial(); let r = this.key.reducer.getInitial(); for (let n = 0; n < this.fns.length; n++) {
        let i = this.fns[n](e);
        i !== Q && (r = this.key.reducer.reduce(r, i));
    } return r; }
};
function xe(t, e) { return t.length === 0 ? e : r => { for (let n of t) {
    let i = r.stateOf(n.path), s = l(i.structure.pathKeys).length - n.depth;
    for (let o = 0; o < s; o++)
        i = i.structure.parent;
    if (!n.fn(i.context))
        return Q;
} return e(r); }; }
var O = class {
    predicates;
    hidden;
    disabledReasons;
    readonly;
    syncErrors;
    syncTreeErrors;
    asyncErrors;
    metadata = new Map;
    constructor(e) { this.predicates = e, this.hidden = new q(e), this.disabledReasons = new re(e), this.readonly = new q(e), this.syncErrors = F.ignoreNull(e), this.syncTreeErrors = F.ignoreNull(e), this.asyncErrors = F.ignoreNull(e); }
    hasMetadata(e) { return this.metadata.has(e); }
    getMetadataKeys() { return this.metadata.keys(); }
    getMetadata(e) { return this.metadata.has(e) || this.metadata.set(e, new ne(this.predicates, e)), this.metadata.get(e); }
    mergeIn(e) { this.hidden.mergeIn(e.hidden), this.disabledReasons.mergeIn(e.disabledReasons), this.readonly.mergeIn(e.readonly), this.syncErrors.mergeIn(e.syncErrors), this.syncTreeErrors.mergeIn(e.syncTreeErrors), this.asyncErrors.mergeIn(e.asyncErrors); for (let r of e.getMetadataKeys()) {
        let n = e.metadata.get(r);
        this.getMetadata(r).mergeIn(n);
    } }
}, X = class {
    depth;
    constructor(e) { this.depth = e; }
    build() { return new Y(this, [], 0); }
}, _ = class t extends X {
    constructor(e) { super(e); }
    current;
    all = [];
    addHiddenRule(e) { this.getCurrent().addHiddenRule(e); }
    addDisabledReasonRule(e) { this.getCurrent().addDisabledReasonRule(e); }
    addReadonlyRule(e) { this.getCurrent().addReadonlyRule(e); }
    addSyncErrorRule(e) { this.getCurrent().addSyncErrorRule(e); }
    addSyncTreeErrorRule(e) { this.getCurrent().addSyncTreeErrorRule(e); }
    addAsyncErrorRule(e) { this.getCurrent().addAsyncErrorRule(e); }
    addMetadataRule(e, r) { this.getCurrent().addMetadataRule(e, r); }
    getChild(e) { if (e === D) {
        let r = this.getCurrent().children;
        r.size > (r.has(D) ? 1 : 0) && (this.current = void 0);
    } return this.getCurrent().getChild(e); }
    hasLogic(e) { return this === e ? !0 : this.all.some(({ builder: r }) => r.hasLogic(e)); }
    mergeIn(e, r) { r ? this.all.push({ builder: e, predicate: { fn: M(r.fn, this.depth), path: r.path } }) : this.all.push({ builder: e }), this.current = void 0; }
    getCurrent() { return this.current === void 0 && (this.current = new x(this.depth), this.all.push({ builder: this.current })), this.current; }
    static newRoot() { return new t(0); }
}, x = class extends X {
    logic = new O([]);
    children = new Map;
    constructor(e) { super(e); }
    addHiddenRule(e) { this.logic.hidden.push(M(e, this.depth)); }
    addDisabledReasonRule(e) { this.logic.disabledReasons.push(M(e, this.depth)); }
    addReadonlyRule(e) { this.logic.readonly.push(M(e, this.depth)); }
    addSyncErrorRule(e) { this.logic.syncErrors.push(M(e, this.depth)); }
    addSyncTreeErrorRule(e) { this.logic.syncTreeErrors.push(M(e, this.depth)); }
    addAsyncErrorRule(e) { this.logic.asyncErrors.push(M(e, this.depth)); }
    addMetadataRule(e, r) { this.logic.getMetadata(e).push(M(r, this.depth)); }
    getChild(e) { return this.children.has(e) || this.children.set(e, new _(this.depth + 1)), this.children.get(e); }
    hasLogic(e) { return this === e; }
}, Y = class t {
    builder;
    predicates;
    depth;
    logic;
    constructor(e, r, n) { this.builder = e, this.predicates = r, this.depth = n, this.logic = e ? yt(e, r, n) : new O([]); }
    getChild(e) { let r = this.builder ? ze(this.builder, e) : []; if (r.length === 0)
        return new t(void 0, [], this.depth + 1); if (r.length === 1) {
        let { builder: n, predicates: i } = r[0];
        return new t(n, [...this.predicates, ...i.map(s => se(s, this.depth))], this.depth + 1);
    }
    else {
        let n = r.map(({ builder: i, predicates: s }) => new t(i, [...this.predicates, ...s.map(o => se(o, this.depth))], this.depth + 1));
        return new ie(n);
    } }
    hasLogic(e) { return this.builder?.hasLogic(e) ?? !1; }
}, ie = class t {
    all;
    logic;
    constructor(e) { this.all = e, this.logic = new O([]); for (let r of e)
        this.logic.mergeIn(r.logic); }
    getChild(e) { return new t(this.all.flatMap(r => r.getChild(e))); }
    hasLogic(e) { return this.all.some(r => r.hasLogic(e)); }
};
function ze(t, e) { if (t instanceof _)
    return t.all.flatMap(({ builder: r, predicate: n }) => { let i = ze(r, e); return n ? i.map(({ builder: s, predicates: o }) => ({ builder: s, predicates: [...o, n] })) : i; }); if (t instanceof x)
    return [...e !== D && t.children.has(D) ? [{ builder: t.getChild(D), predicates: [] }] : [], ...t.children.has(e) ? [{ builder: t.getChild(e), predicates: [] }] : []]; throw new p(1909, !1); }
function yt(t, e, r) { let n = new O(e); if (t instanceof _) {
    let i = t.all.map(({ builder: s, predicate: o }) => new Y(s, o ? [...e, se(o, r)] : e, r));
    for (let s of i)
        n.mergeIn(s.logic);
}
else if (t instanceof x)
    n.mergeIn(t.logic);
else
    throw new p(1909, !1); return n; }
function se(t, e) { return V(y({}, t), { depth: e }); }
var $e = Symbol("PATH"), h = class t {
    keys;
    parent;
    keyInParent;
    root;
    children = new Map;
    fieldPathProxy = new Proxy(this, bt);
    logicBuilder;
    constructor(e, r, n, i) { this.keys = e, this.parent = n, this.keyInParent = i, this.root = r ?? this, n || (this.logicBuilder = _.newRoot()); }
    get builder() { return this.logicBuilder ? this.logicBuilder : this.parent.builder.getChild(this.keyInParent); }
    getChild(e) { return this.children.has(e) || this.children.set(e, new t([...this.keys, e], this.root, this, e)), this.children.get(e); }
    mergeIn(e, r) { let n = e.compile(); this.builder.mergeIn(n.builder, r); }
    static unwrapFieldPath(e) { return e[$e]; }
    static newRoot() { return new t([], void 0, void 0, void 0); }
}, bt = { get(t, e) { return e === $e ? t : t.getChild(e).fieldPathProxy; } }, z, K = new Map, T = class t {
    schemaFn;
    constructor(e) { this.schemaFn = e; }
    compile() { if (K.has(this))
        return K.get(this); let e = h.newRoot(); K.set(this, e); let r = z; try {
        z = e, this.schemaFn(e.fieldPathProxy);
    }
    finally {
        z = r;
    } return e; }
    static create(e) { return e instanceof t ? e : new t(e); }
    static rootCompile(e) { try {
        return K.clear(), e === void 0 ? h.newRoot() : e instanceof t ? e.compile() : new t(e).compile();
    }
    finally {
        K.clear();
    } }
};
function vt(t) { return t instanceof T || typeof t == "function"; }
function b(t) { if (z !== h.unwrapFieldPath(t).root)
    throw new p(1908, !1); }
function f(t, e, r) { return b(t), h.unwrapFieldPath(t).builder.addMetadataRule(e, r), e; }
var E = { list() { return { reduce: (t, e) => e === void 0 ? t : [...t, e], getInitial: () => [] }; }, min() { return { reduce: (t, e) => t === void 0 || e === void 0 ? t ?? e : Math.min(t, e), getInitial: () => { } }; }, max() { return { reduce: (t, e) => t === void 0 || e === void 0 ? t ?? e : Math.max(t, e), getInitial: () => { } }; }, or() { return { reduce: (t, e) => t || e, getInitial: () => !1 }; }, and() { return { reduce: (t, e) => t && e, getInitial: () => !0 }; }, override: Nt };
function Nt(t) { return { reduce: (e, r) => r, getInitial: () => t?.() }; }
var B = class {
    reducer;
    create;
    brand;
    constructor(e, r) { this.reducer = e, this.create = r; }
};
function g(t) { return new B(t ?? E.override()); }
function qe(t, e) { return new B(e ?? E.override(), t); }
var pe = g(E.or()), ye = g(E.max()), be = g(E.min()), ve = g(E.max()), Ne = g(E.min()), Ee = g(E.list());
function Et(t) { return t.errors().length > 0 ? "invalid" : t.pending() ? "unknown" : "valid"; }
var oe = class {
    node;
    constructor(e) { this.node = e; }
    rawSyncTreeErrors = d(() => this.shouldSkipValidation() ? [] : [...this.node.logicNode.logic.syncTreeErrors.compute(this.node.context), ...this.node.structure.parent?.validationState.rawSyncTreeErrors() ?? []]);
    syncErrors = d(() => this.shouldSkipValidation() ? [] : [...this.node.logicNode.logic.syncErrors.compute(this.node.context), ...this.syncTreeErrors(), ...St(this.node.submitState.submissionErrors())]);
    syncValid = d(() => this.shouldSkipValidation() ? !0 : this.node.structure.reduceChildren(this.syncErrors().length === 0, (e, r) => r && e.validationState.syncValid(), pt));
    syncTreeErrors = d(() => this.rawSyncTreeErrors().filter(e => e.fieldTree === this.node.fieldTree));
    rawAsyncErrors = d(() => this.shouldSkipValidation() ? [] : [...this.node.logicNode.logic.asyncErrors.compute(this.node.context), ...this.node.structure.parent?.validationState.rawAsyncErrors() ?? []]);
    asyncErrors = d(() => this.shouldSkipValidation() ? [] : this.rawAsyncErrors().filter(e => e === "pending" || e.fieldTree === this.node.fieldTree));
    parseErrors = d(() => this.node.formFieldBindings().flatMap(e => e.parseErrors()));
    errors = d(() => [...this.parseErrors(), ...this.syncErrors(), ...this.asyncErrors().filter(e => e !== "pending")]);
    errorSummary = d(() => { let e = this.node.structure.reduceChildren(this.errors(), (r, n) => [...n, ...r.errorSummary()]); return (typeof ngServerMode > "u" || !ngServerMode) && l(() => e.sort(wt)), e; });
    pending = d(() => this.node.structure.reduceChildren(this.asyncErrors().includes("pending"), (e, r) => r || e.validationState.asyncErrors().includes("pending")));
    status = d(() => { if (this.shouldSkipValidation())
        return "valid"; let e = Et(this); return this.node.structure.reduceChildren(e, (r, n) => n === "invalid" || r.validationState.status() === "invalid" ? "invalid" : n === "unknown" || r.validationState.status() === "unknown" ? "unknown" : "valid", r => r === "invalid"); });
    valid = d(() => this.status() === "valid");
    invalid = d(() => this.status() === "invalid");
    shouldSkipValidation = d(() => this.node.hidden() || this.node.disabled() || this.node.readonly());
};
function St(t) { return t === void 0 ? [] : N(t) ? t : [t]; }
function A(t, e) { if (N(t))
    for (let r of t)
        r.fieldTree ??= e;
else
    t && (t.fieldTree ??= e); return t; }
function Be(t) { return t.formField ? t.formField.element : t.fieldTree().formFieldBindings().reduce((e, r) => !e || !r.element ? e ?? r.element : e.compareDocumentPosition(r.element) & Node.DOCUMENT_POSITION_PRECEDING ? r.element : e, void 0); }
function wt(t, e) { let r = Be(t), n = Be(e); return r === n ? 0 : r === void 0 || n === void 0 ? r === void 0 ? 1 : -1 : r.compareDocumentPosition(n) & Node.DOCUMENT_POSITION_PRECEDING ? 1 : -1; }
var W = g(), ae = class {
    node;
    cache = new WeakMap;
    constructor(e) { this.node = e; }
    resolve(e) { if (!this.cache.has(e)) {
        let r = d(() => { let n = h.unwrapFieldPath(e), i = this.node, s = mt(); for (; s > 0 || !i.structure.logic.hasLogic(n.root.builder);)
            if (s--, i = i.structure.parent, i === void 0)
                throw new p(1900, !1); for (let o of n.keys)
            if (i = i.structure.getChild(o), i === void 0)
                throw new p(1901, !1); return i.fieldTree; });
        this.cache.set(e, r);
    } return this.cache.get(e)(); }
    get fieldTree() { return this.node.fieldProxy; }
    get state() { return this.node; }
    get value() { return this.node.structure.value; }
    get key() { return this.node.structure.keyInParent; }
    get pathKeys() { return this.node.structure.pathKeys; }
    index = d(() => { let e = this.key(); if (!N(l(this.node.structure.parent.value)))
        throw new p(1906, !1); return Number(e); });
    fieldTreeOf = e => this.resolve(e);
    stateOf = e => this.resolve(e)();
    valueOf = e => { let r = this.resolve(e)().value(); if (r instanceof gt)
        throw new p(1907, !1); return r; };
}, de = class {
    node;
    metadata = new Map;
    constructor(e) { this.node = e; for (let r of this.node.logicNode.logic.getMetadataKeys())
        if (r.create) {
            let n = this.node.logicNode.logic.getMetadata(r), i = l(() => He(this.node.structure.injector, () => r.create(d(() => n.compute(this.node.context)))));
            this.metadata.set(r, i);
        } }
    get(e) { if (this.has(e) && !this.metadata.has(e)) {
        if (e.create)
            throw new p(1912, !1);
        let r = this.node.logicNode.logic.getMetadata(e);
        this.metadata.set(e, d(() => r.compute(this.node.context)));
    } return this.metadata.get(e); }
    has(e) { return this.node.logicNode.logic.hasMetadata(e); }
}, Mt = { get(t, e, r) { let n = t(), i = n.structure.getChild(e); if (i !== void 0)
        return i.fieldTree; let s = l(n.value); if (N(s)) {
        if (e === "length")
            return n.value().length;
        if (e === Symbol.iterator)
            return () => (n.value(), Array.prototype[Symbol.iterator].apply(n.fieldTree));
    } if (k(s) && e === Symbol.iterator)
        return function* () { for (let o in r)
            yield [o, r[o]]; }; }, getOwnPropertyDescriptor(t, e) { let r = l(t().value), n = Reflect.getOwnPropertyDescriptor(r, e); return n && !n.configurable && (n.configurable = !0), n; }, ownKeys(t) { let e = l(t().value); return typeof e == "object" && e !== null ? Reflect.ownKeys(e) : []; } };
function Dt(t, e) { let r = d(() => t()[e()]); return r[Ke] = t[Ke], r.set = n => { t.update(i => Rt(i, n, e())); }, r.update = n => { r.set(n(l(r))); }, r.asReadonly = () => r, r; }
function Rt(t, e, r) { if (N(t)) {
    let n = [...t];
    return n[r] = e, n;
}
else
    return V(y({}, t), { [r]: e }); }
var Z = class {
    logic;
    node;
    createChildNode;
    identitySymbol = Symbol();
    _injector = void 0;
    get injector() { return this._injector ??= Ge.create({ providers: [], parent: this.fieldManager.injector }), this._injector; }
    constructor(e, r, n) { this.logic = e, this.node = r, this.createChildNode = n; }
    children() { let e = this.childrenMap(); return e === void 0 ? [] : Array.from(e.byPropertyKey.values()).map(r => l(r.reader)); }
    getChild(e) { let r = e.toString(), n = l(this.childrenMap)?.byPropertyKey.get(r)?.reader; return n || (n = this.createReader(r)), n(); }
    reduceChildren(e, r, n) { let i = this.childrenMap(); if (!i)
        return e; let s = e; for (let o of i.byPropertyKey.values()) {
        if (n?.(s))
            break;
        s = r(l(o.reader), s);
    } return s; }
    destroy() { this.injector.destroy(); }
    createKeyInParent(e, r, n) { if (e.kind === "root")
        return Xe; if (r === void 0) {
        let i = n;
        return d(() => { if (this.parent.structure.getChild(i) !== this.node)
            throw new p(-1902, !1); return i; });
    }
    else {
        let i = n;
        return d(() => { let s = this.parent.structure.value(); if (!N(s))
            throw new p(1903, !1); let o = s[i]; if (k(o) && o.hasOwnProperty(this.parent.structure.identitySymbol) && o[this.parent.structure.identitySymbol] === r)
            return i; for (let a = 0; a < s.length; a++) {
            let c = s[a];
            if (k(c) && c.hasOwnProperty(this.parent.structure.identitySymbol) && c[this.parent.structure.identitySymbol] === r)
                return i = a.toString();
        } throw new p(1904, !1); });
    } }
    createChildrenMap() { return $({ source: this.value, computation: (e, r) => { if (!k(e))
            return; let n = r?.value ?? { byPropertyKey: new Map }, i, s = N(e); n !== void 0 && (s ? i = At(n, e, this.identitySymbol) : i = Pt(n, e)); for (let o of Object.keys(e)) {
            let a, c = e[o];
            if (c === void 0) {
                n.byPropertyKey.has(o) && (i ??= y({}, n), i.byPropertyKey.delete(o));
                continue;
            }
            s && k(c) && !N(c) && (a = c[this.identitySymbol] ??= Symbol(""));
            let u;
            a && (n.byTrackingKey?.has(a) || (i ??= y({}, n), i.byTrackingKey ??= new Map, i.byTrackingKey.set(a, this.createChildNode(o, a, s))), u = (i ?? n).byTrackingKey.get(a));
            let R = n.byPropertyKey.get(o);
            R === void 0 ? (i ??= y({}, n), i.byPropertyKey.set(o, { reader: this.createReader(o), node: u ?? this.createChildNode(o, a, s) })) : u && u !== R.node && (i ??= y({}, n), R.node = u);
        } return i ?? n; } }); }
    createReader(e) { return d(() => this.childrenMap()?.byPropertyKey.get(e)?.node); }
}, ue = class extends Z {
    fieldManager;
    value;
    get parent() { }
    get root() { return this.node; }
    get pathKeys() { return Tt; }
    get keyInParent() { return Xe; }
    childrenMap;
    constructor(e, r, n, i, s) { super(r, e, s), this.fieldManager = n, this.value = i, this.childrenMap = this.createChildrenMap(); }
}, ce = class extends Z {
    logic;
    parent;
    root;
    pathKeys;
    keyInParent;
    value;
    childrenMap;
    get fieldManager() { return this.root.structure.fieldManager; }
    constructor(e, r, n, i, s, o) { super(r, e, o), this.logic = r, this.parent = n, this.root = this.parent.structure.root, this.keyInParent = this.createKeyInParent({ kind: "child", parent: n, pathNode: void 0, logic: r, initialKeyInParent: s, identityInParent: i, fieldAdapter: void 0 }, i, s), this.pathKeys = d(() => [...n.structure.pathKeys(), this.keyInParent()]), this.value = Dt(this.parent.structure.value, this.keyInParent), this.childrenMap = this.createChildrenMap(), this.fieldManager.structures.add(this); }
};
var Tt = d(() => []), Xe = d(() => { throw new p(1905, !1); });
function At(t, e, r) { let n, i = new Set(t.byPropertyKey.keys()), s = new Set(t.byTrackingKey?.keys()); for (let o = 0; o < e.length; o++) {
    let a = e[o];
    i.delete(o.toString()), k(a) && a.hasOwnProperty(r) && s.delete(a[r]);
} if (i.size > 0) {
    n ??= y({}, t);
    for (let o of i)
        n.byPropertyKey.delete(o);
} if (s.size > 0) {
    n ??= y({}, t);
    for (let o of s)
        n.byTrackingKey?.delete(o);
} return n; }
function Pt(t, e) { let r; for (let n of t.byPropertyKey.keys())
    e.hasOwnProperty(n) || (r ??= y({}, t), r.byPropertyKey.delete(n)); return r; }
var le = class {
    node;
    selfSubmitting = G(!1);
    submissionErrors;
    constructor(e) { this.node = e, this.submissionErrors = $({ source: this.node.structure.value, computation: () => [] }); }
    submitting = d(() => this.selfSubmitting() || (this.node.structure.parent?.submitting() ?? !1));
}, U = class {
    structure;
    validationState;
    metadataState;
    nodeState;
    submitState;
    fieldAdapter;
    controlValue;
    _context = void 0;
    get context() { return this._context ??= new ae(this); }
    fieldProxy = new Proxy(() => this, Mt);
    pathNode;
    constructor(e) { this.pathNode = e.pathNode, this.fieldAdapter = e.fieldAdapter, this.structure = this.fieldAdapter.createStructure(this, e), this.validationState = this.fieldAdapter.createValidationState(this, e), this.nodeState = this.fieldAdapter.createNodeState(this, e), this.metadataState = new de(this), this.submitState = new le(this), this.controlValue = this.controlValueSignal(); }
    focusBoundControl(e) { this.getBindingForFocus()?.focus(e); }
    getBindingForFocus() { let e = this.formFieldBindings().filter(r => r.focus !== void 0).reduce(Ue, void 0); return e || this.structure.children().map(r => r.getBindingForFocus()).reduce(Ue, void 0); }
    pendingSync = $({ source: () => this.value(), computation: (e, r) => { r?.value?.abort(); } });
    get fieldTree() { return this.fieldProxy; }
    get logicNode() { return this.structure.logic; }
    get value() { return this.structure.value; }
    get keyInParent() { return this.structure.keyInParent; }
    get errors() { return this.validationState.errors; }
    get parseErrors() { return this.validationState.parseErrors; }
    get errorSummary() { return this.validationState.errorSummary; }
    get pending() { return this.validationState.pending; }
    get valid() { return this.validationState.valid; }
    get invalid() { return this.validationState.invalid; }
    get dirty() { return this.nodeState.dirty; }
    get touched() { return this.nodeState.touched; }
    get disabled() { return this.nodeState.disabled; }
    get disabledReasons() { return this.nodeState.disabledReasons; }
    get hidden() { return this.nodeState.hidden; }
    get readonly() { return this.nodeState.readonly; }
    get formFieldBindings() { return this.nodeState.formFieldBindings; }
    get submitting() { return this.submitState.submitting; }
    get name() { return this.nodeState.name; }
    get max() { return this.metadata(be); }
    get maxLength() { return this.metadata(Ne); }
    get min() { return this.metadata(ye); }
    get minLength() { return this.metadata(ve); }
    get pattern() { return this.metadata(Ee) ?? Ct; }
    get required() { return this.metadata(pe) ?? It; }
    metadata(e) { return this.metadataState.get(e); }
    hasMetadata(e) { return this.metadataState.has(e); }
    markAsTouched() { l(() => { this.nodeState.markAsTouched(), this.flushSync(); }); }
    markAsDirty() { this.nodeState.markAsDirty(); }
    markAsPristine() { this.nodeState.markAsPristine(); }
    markAsUntouched() { this.nodeState.markAsUntouched(); }
    reset(e) { l(() => this._reset(e)); }
    _reset(e) { e !== void 0 && this.value.set(e), this.nodeState.markAsUntouched(), this.nodeState.markAsPristine(); for (let r of this.structure.children())
        r._reset(); }
    controlValueSignal() { let e = $(this.value), { set: r, update: n } = e; return e.set = i => { r(i), this.markAsDirty(), this.debounceSync(); }, e.update = i => { n(i), this.markAsDirty(), this.debounceSync(); }, e; }
    sync() { this.value.set(this.controlValue()); }
    flushSync() { let e = this.pendingSync(); e && !e.signal.aborted && (e.abort(), this.sync()); }
    debounceSync() { return L(this, null, function* () { let e = l(() => (this.pendingSync()?.abort(), this.nodeState.debouncer())); if (e) {
        let r = new AbortController, n = e(r.signal);
        if (n && (this.pendingSync.set(r), yield n, r.signal.aborted))
            return;
    } this.sync(); }); }
    static newRoot(e, r, n, i) { return i.newRoot(e, r, n, i); }
    createStructure(e) { return e.kind === "root" ? new ue(this, e.logic, e.fieldManager, e.value, this.newChild.bind(this)) : new ce(this, e.logic, e.parent, e.identityInParent, e.initialKeyInParent, this.newChild.bind(this)); }
    newChild(e, r, n) { let i, s; return n ? (i = this.pathNode.getChild(D), s = this.structure.logic.getChild(D)) : (i = this.pathNode.getChild(e), s = this.structure.logic.getChild(e)), this.fieldAdapter.newChild({ kind: "child", parent: this, pathNode: i, logic: s, initialKeyInParent: e, identityInParent: r, fieldAdapter: this.fieldAdapter }); }
}, Ct = d(() => []), It = d(() => !1);
function Ue(t, e) { return t ? e && t.element.compareDocumentPosition(e.element) & Node.DOCUMENT_POSITION_PRECEDING ? e : t : e; }
var he = class {
    node;
    selfTouched = G(!1);
    selfDirty = G(!1);
    markAsTouched() { this.selfTouched.set(!0); }
    markAsDirty() { this.selfDirty.set(!0); }
    markAsPristine() { this.selfDirty.set(!1); }
    markAsUntouched() { this.selfTouched.set(!1); }
    formFieldBindings = G([]);
    constructor(e) { this.node = e; }
    dirty = d(() => { let e = this.selfDirty() && !this.isNonInteractive(); return this.node.structure.reduceChildren(e, (r, n) => n || r.nodeState.dirty(), je); });
    touched = d(() => { let e = this.selfTouched() && !this.isNonInteractive(); return this.node.structure.reduceChildren(e, (r, n) => n || r.nodeState.touched(), je); });
    disabledReasons = d(() => [...this.node.structure.parent?.nodeState.disabledReasons() ?? [], ...this.node.logicNode.logic.disabledReasons.compute(this.node.context)]);
    disabled = d(() => !!this.disabledReasons().length);
    readonly = d(() => (this.node.structure.parent?.nodeState.readonly() || this.node.logicNode.logic.readonly.compute(this.node.context)) ?? !1);
    hidden = d(() => (this.node.structure.parent?.nodeState.hidden() || this.node.logicNode.logic.hidden.compute(this.node.context)) ?? !1);
    name = d(() => { let e = this.node.structure.parent; return e ? `${e.name()}.${this.node.structure.keyInParent()}` : this.node.structure.fieldManager.rootName; });
    debouncer = d(() => { if (this.node.logicNode.logic.hasMetadata(W)) {
        let r = this.node.logicNode.logic.getMetadata(W).compute(this.node.context);
        if (r)
            return n => r(this.node.context, n);
    } return this.node.structure.parent?.nodeState.debouncer?.(); });
    isNonInteractive = d(() => this.hidden() || this.disabled() || this.readonly());
}, fe = class {
    newRoot(e, r, n, i) { return new U({ kind: "root", fieldManager: e, value: r, pathNode: n, logic: n.builder.build(), fieldAdapter: i }); }
    newChild(e) { return new U(e); }
    createNodeState(e) { return new he(e); }
    createValidationState(e) { return new oe(e); }
    createStructure(e, r) { return e.createStructure(r); }
}, ge = class {
    injector;
    rootName;
    submitOptions;
    constructor(e, r, n) { this.injector = e, this.rootName = r ?? `${this.injector.get(lt)}.form${kt++}`, this.submitOptions = n; }
    structures = new Set;
    createFieldManagementEffect(e) { ht(() => { let r = new Set; this.markStructuresLive(e, r); for (let n of this.structures)
        r.has(n) || (this.structures.delete(n), l(() => n.destroy())); }, { injector: this.injector }); }
    markStructuresLive(e, r) { r.add(e); for (let n of e.children())
        this.markStructuresLive(n.structure, r); }
}, kt = 0;
function Ft(t) { let e, r, n; return t.length === 3 ? [e, r, n] = t : t.length === 2 ? vt(t[1]) ? [e, r] = t : [e, n] = t : [e] = t, [e, r, n]; }
function Ot(...t) { let [e, r, n] = Ft(t), i = n?.injector ?? ft(Ge), s = He(i, () => T.rootCompile(r)), o = new ge(i, n?.name, n?.submission), a = n?.adapter ?? new fe, c = U.newRoot(o, e, s, a); return o.createFieldManagementEffect(c.structure), c.fieldTree; }
function _t(t, e) { b(t); let r = h.unwrapFieldPath(t).getChild(D).fieldPathProxy; Ye(r, e); }
function Ye(t, e) { b(t), h.unwrapFieldPath(t).mergeIn(T.create(e)); }
function We(t, e, r) { b(t), h.unwrapFieldPath(t).mergeIn(T.create(r), { fn: e, path: t }); }
function Vt(t, e, r) { We(t, ({ value: n }) => e(n()), r); }
function Ze(t, e) { return L(this, null, function* () { let r = l(t); if (l(r.submitState.submitting))
    return !1; let n = e === void 0 ? r.structure.root.fieldProxy : t, i = { root: r.structure.root.fieldProxy, submitted: t }; e = typeof e == "function" ? { action: e } : e ?? r.structure.fieldManager.submitOptions; let s = e?.action; if (!s)
    throw new p(1915, !1); let o = e?.onInvalid, a = e?.ignoreValidators ?? "pending", c = !0; l(() => { Qe(r), a === "none" ? c = r.valid() : a === "pending" && (c = !r.invalid()); }); try {
    if (c) {
        r.submitState.selfSubmitting.set(!0);
        let u = yield l(() => s?.(n, i));
        return u && Kt(r, u), !u || N(u) && u.length === 0;
    }
    else
        l(() => o?.(n, i));
    return !1;
}
finally {
    r.submitState.selfSubmitting.set(!1);
} }); }
function Lt(t) { return T.create(t); }
function Qe(t) { if (!t.validationState.shouldSkipValidation()) {
    t.markAsTouched();
    for (let e of t.structure.children())
        Qe(e);
} }
function Kt(t, e) { N(e) || (e = [e]); let r = new Map; for (let n of e) {
    let i = A(n, t.fieldTree), s = i.fieldTree(), o = r.get(s);
    o || (o = [], r.set(s, o)), o.push(i);
} for (let [n, i] of r)
    n.submitState.submissionErrors.set(i); }
var me = class {
    kind = "compat";
    control;
    fieldTree;
    context;
    message;
    constructor({ context: e, kind: r, control: n }) { this.context = e, this.kind = r, this.control = n; }
};
function Je(t) { if (t.length === 0)
    return null; let e = {}; for (let r of t)
    e[r.kind] = r instanceof me ? r.context : r; return e; }
import { httpResource as Wt } from "@angular/common/http";
import "@angular/core/primitives/signals";
var ot = new Oe("");
function Kr(t) { return [{ provide: ot, useValue: t }]; }
function jr(t, e) { b(t), h.unwrapFieldPath(t).builder.addDisabledReasonRule(n => { let i = !0; return typeof e == "string" ? i = e : e && (i = e(n)), typeof i == "string" ? { fieldTree: n.fieldTree, message: i } : i ? { fieldTree: n.fieldTree } : void 0; }); }
function xr(t, e) { b(t), h.unwrapFieldPath(t).builder.addHiddenRule(e); }
function Br(t, e = () => !0) { b(t), h.unwrapFieldPath(t).builder.addReadonlyRule(e); }
function at(t) { let e = t; return typeof e.length == "number" ? e.length : e.size; }
function m(t, e) { return t instanceof Function ? t(e) : t; }
function C(t) { return typeof t == "number" ? isNaN(t) : t === "" || t === !1 || t == null; }
function tt(t) { return t === void 0 ? [] : Array.isArray(t) ? t : [t]; }
function I(t, e) { b(t), h.unwrapFieldPath(t).builder.addSyncErrorRule(n => A(e(n), n.fieldTree)); }
function Zt(t) { return new we(t); }
function Qt(t, e) { return new Me(t, e); }
function Jt(t, e) { return new De(t, e); }
function er(t, e) { return new Re(t, e); }
function tr(t, e) { return new Te(t, e); }
function rr(t, e) { return new Ae(t, e); }
function nr(t) { return new Pe(t); }
var v = class {
    __brand = void 0;
    kind = "";
    fieldTree;
    message;
    constructor(e) { e && Object.assign(this, e); }
}, we = class extends v {
    kind = "required";
}, Me = class extends v {
    min;
    kind = "min";
    constructor(e, r) { super(r), this.min = e; }
}, De = class extends v {
    max;
    kind = "max";
    constructor(e, r) { super(r), this.max = e; }
}, Re = class extends v {
    minLength;
    kind = "minLength";
    constructor(e, r) { super(r), this.minLength = e; }
}, Te = class extends v {
    maxLength;
    kind = "maxLength";
    constructor(e, r) { super(r), this.maxLength = e; }
}, Ae = class extends v {
    pattern;
    kind = "pattern";
    constructor(e, r) { super(r), this.pattern = e; }
}, Pe = class extends v {
    kind = "email";
}, Ce = class extends v {
    kind = "parse";
}, Ur = v, ir = /^(?=.{1,254}$)(?=.{1,64}@)[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
function Hr(t, e) { I(t, r => { if (!C(r.value()) && !ir.test(r.value()))
    return e?.error ? m(e.error, r) : nr({ message: m(e?.message, r) }); }); }
function Gr(t, e, r) { let n = f(t, g(), i => typeof e == "number" ? e : e(i)); f(t, be, ({ state: i }) => i.metadata(n)()), I(t, i => { if (C(i.value()))
    return; let s = i.state.metadata(n)(); if (s === void 0 || Number.isNaN(s))
    return; let o = i.value(); if ((!o && o !== 0 ? NaN : Number(o)) > s)
    return r?.error ? m(r.error, i) : Jt(s, { message: m(r?.message, i) }); }); }
function zr(t, e, r) { let n = f(t, g(), i => typeof e == "number" ? e : e(i)); f(t, Ne, ({ state: i }) => i.metadata(n)()), I(t, i => { if (C(i.value()))
    return; let s = i.state.metadata(n)(); if (s !== void 0 && at(i.value()) > s)
    return r?.error ? m(r.error, i) : tr(s, { message: m(r?.message, i) }); }); }
function $r(t, e, r) { let n = f(t, g(), i => typeof e == "number" ? e : e(i)); f(t, ye, ({ state: i }) => i.metadata(n)()), I(t, i => { if (C(i.value()))
    return; let s = i.state.metadata(n)(); if (s === void 0 || Number.isNaN(s))
    return; let o = i.value(); if ((!o && o !== 0 ? NaN : Number(o)) < s)
    return r?.error ? m(r.error, i) : Qt(s, { message: m(r?.message, i) }); }); }
function qr(t, e, r) { let n = f(t, g(), i => typeof e == "number" ? e : e(i)); f(t, ve, ({ state: i }) => i.metadata(n)()), I(t, i => { if (C(i.value()))
    return; let s = i.state.metadata(n)(); if (s !== void 0 && at(i.value()) < s)
    return r?.error ? m(r.error, i) : er(s, { message: m(r?.message, i) }); }); }
function Xr(t, e, r) { let n = f(t, g(), i => e instanceof RegExp ? e : e(i)); f(t, Ee, ({ state: i }) => i.metadata(n)()), I(t, i => { if (C(i.value()))
    return; let s = i.state.metadata(n)(); if (s !== void 0 && !s.test(i.value()))
    return r?.error ? m(r.error, i) : rr(s, { message: m(r?.message, i) }); }); }
function Yr(t, e) { let r = f(t, g(), n => e?.when ? e.when(n) : !0); f(t, pe, ({ state: n }) => n.metadata(r)()), I(t, n => { if (n.state.metadata(r)() && C(n.value()))
    return e?.error ? m(e.error, n) : Zt({ message: m(e?.message, n) }); }); }
function dt(t, e) { b(t); let r = h.unwrapFieldPath(t), n = qe(e.factory); f(t, n, i => { let o = i.stateOf(t).validationState; if (!(o.shouldSkipValidation() || !o.syncValid()))
    return e.params(i); }), r.builder.addAsyncErrorRule(i => { let s = i.state.metadata(n), o; switch (s.status()) {
    case "idle": return;
    case "loading":
    case "reloading": return "pending";
    case "resolved":
    case "local": return s.hasValue() ? (o = e.onSuccess(s.value(), i), A(o, i.fieldTree)) : void 0;
    case "error": return o = e.onError(s.error(), i), A(o, i.fieldTree);
} }); }
function sr(t, e) { b(t), h.unwrapFieldPath(t).builder.addSyncTreeErrorRule(n => A(e(n), n.fieldTree)); }
function Wr(t, e) { let r = f(t, g(), n => { let i = typeof e == "function" ? e(n) : e; return i ? i["~standard"].validate(n.value()) : void 0; }); sr(t, ({ state: n, fieldTreeOf: i }) => { let s = n.metadata(r)(); return !s || et(s) ? [] : s?.issues?.map(o => rt(i(t), o)) ?? []; }), dt(t, { params: ({ state: n }) => { let i = n.metadata(r)(); return i && et(i) ? i : void 0; }, factory: n => jt({ params: n, loader: s => L(null, [s], function* ({ params: i }) { return (yield i)?.issues ?? []; }) }), onSuccess: (n, { fieldTreeOf: i }) => n.map(s => rt(i(t), s)), onError: () => { } }); }
function or(t, e) { return new Ie(t, e); }
function rt(t, e) { let r = t; for (let n of e.path ?? []) {
    let i = typeof n == "object" ? n.key : n;
    r = r[i];
} return A(or(e, { message: e.message }), r); }
var Ie = class extends v {
    issue;
    kind = "standardSchema";
    constructor(e, r) { super(r), this.issue = e; }
};
function Zr(t, e) { dt(t, { params: e.request, factory: r => Wt(r, e.options), onSuccess: e.onSuccess, onError: e.onError }); }
function Qr(t, e) { b(t); let r = h.unwrapFieldPath(t), n = ar(e); r.builder.addMetadataRule(W, () => n); }
function ar(t) { return typeof t == "function" ? t : t === "blur" ? ur() : t > 0 ? dr(t) : cr; }
function dr(t) { return (e, r) => new Promise(n => { let i, s = () => { clearTimeout(i), n(); }; i = setTimeout(() => { r.removeEventListener("abort", s), n(); }, t), r.addEventListener("abort", s, { once: !0 }); }); }
function ur() { return (t, e) => new Promise(r => { e.addEventListener("abort", () => r(), { once: !0 }); }); }
function cr() { }
var ut = new Oe("");
function ct(t, e, r) { let n = it({ source: t, computation: () => [] }), i = s => { let o = r(s); n.set(tt(o.error)), o.value !== void 0 && e(o.value), n.set(tt(o.error)); }; return { errors: n.asReadonly(), setRawValue: i }; }
function Jr(t, e) { let { parse: r, format: n } = e, i = ct(t, t.set, r), s = S(ut, { self: !0, optional: !0 }); s && s.set(i.errors); let o = it(() => n(t())), a = o; a.parseErrors = i.errors; let c = a.set.bind(a); return a.set = u => { i.setRawValue(u), c(u); }, a.update = u => { a.set(u(o())); }, a; }
var ke = class {
    field;
    constructor(e) { this.field = e; }
    control = this;
    get value() { return this.field().value(); }
    get valid() { return this.field().valid(); }
    get invalid() { return this.field().invalid(); }
    get pending() { return this.field().pending(); }
    get disabled() { return this.field().disabled(); }
    get enabled() { return !this.field().disabled(); }
    get errors() { return Je(this.field().errors()); }
    get pristine() { return !this.field().dirty(); }
    get dirty() { return this.field().dirty(); }
    get touched() { return this.field().touched(); }
    get untouched() { return !this.field().touched(); }
    get status() { if (this.field().disabled())
        return "DISABLED"; if (this.field().valid())
        return "VALID"; if (this.field().invalid())
        return "INVALID"; if (this.field().pending())
        return "PENDING"; throw new Se(1910, !1); }
    valueAccessor = null;
    hasValidator(e) { return e === qt.required ? this.field().required() : !1; }
    updateValueAndValidity() { }
}, Fe = { disabled: "disabled", disabledReasons: "disabledReasons", dirty: "dirty", errors: "errors", hidden: "hidden", invalid: "invalid", max: "max", maxLength: "maxLength", min: "min", minLength: "minLength", name: "name", pattern: "pattern", pending: "pending", readonly: "readonly", required: "required", touched: "touched" }, lr = (() => { let t = {}; for (let e of Object.keys(Fe))
    t[Fe[e]] = e; return t; })();
function _e(t, e) { let r = lr[e]; return t[r]?.(); }
var Ve = Object.values(Fe);
function ee() { return {}; }
function P(t, e, r) { return t[e] !== r ? (t[e] = r, !0) : !1; }
function hr(t) { return t.tagName === "INPUT" || t.tagName === "SELECT" || t.tagName === "TEXTAREA"; }
function fr(t) { if (t.tagName !== "INPUT")
    return !1; let e = t.type; return e === "date" || e === "datetime-local" || e === "month" || e === "number" || e === "range" || e === "time" || e === "week"; }
function gr(t) { return t.tagName === "INPUT" || t.tagName === "TEXTAREA"; }
function mr(t, e) { let r; if (t.validity.badInput)
    return { error: new Ce }; switch (t.type) {
    case "checkbox": return { value: t.checked };
    case "number":
    case "range":
    case "datetime-local":
        if (r = H(e), typeof r == "number" || r === null)
            return { value: t.value === "" ? null : t.valueAsNumber };
        break;
    case "date":
    case "month":
    case "time":
    case "week":
        if (r = H(e), r === null || r instanceof Date)
            return { value: t.valueAsDate };
        if (typeof r == "number")
            return { value: t.valueAsNumber };
        break;
} return { value: t.value }; }
function pr(t, e) { switch (t.type) {
    case "checkbox":
        t.checked = e;
        return;
    case "radio":
        t.checked = e === t.value;
        return;
    case "number":
    case "range":
    case "datetime-local":
        if (typeof e == "number") {
            nt(t, e);
            return;
        }
        else if (e === null) {
            t.value = "";
            return;
        }
        break;
    case "date":
    case "month":
    case "time":
    case "week": if (e === null || e instanceof Date) {
        t.valueAsDate = e;
        return;
    }
    else if (typeof e == "number") {
        nt(t, e);
        return;
    }
} t.value = e; }
function nt(t, e) { isNaN(e) ? t.value = "" : t.valueAsNumber = e; }
function Le(t, e, r, n) { switch (r) {
    case "name":
        t.setAttribute(e, r, n);
        break;
    case "disabled":
    case "readonly":
    case "required":
        n ? t.setAttribute(e, r, "") : t.removeAttribute(e, r);
        break;
    case "max":
    case "min":
    case "minLength":
    case "maxLength":
        n !== void 0 ? t.setAttribute(e, r, n.toString()) : t.removeAttribute(e, r);
        break;
} }
function yr(t, e) { t.listenToCustomControlModel(n => e.state().controlValue.set(n)), t.listenToCustomControlOutput("touchedChange", () => e.state().markAsTouched()), e.registerAsBinding(t.customControl); let r = ee(); return () => { let n = e.state(), i = n.controlValue(); P(r, "controlValue", i) && t.setCustomControlModelInput(i); for (let s of Ve) {
    let o;
    s === "errors" ? o = e.errors() : o = _e(n, s), P(r, s, o) && (t.setInputOnDirectives(s, o), e.elementAcceptsNativeProperty(s) && !t.customControlHasInput(s) && Le(e.renderer, e.nativeFormElement, s, o));
} }; }
function br(t, e) { e.controlValueAccessor.registerOnChange(n => e.state().controlValue.set(n)), e.controlValueAccessor.registerOnTouched(() => e.state().markAsTouched()), e.registerAsBinding(); let r = ee(); return () => { let n = e.state(), i = n.value(); P(r, "controlValue", i) && H(() => e.controlValueAccessor.writeValue(i)); for (let s of Ve) {
    let o = _e(n, s);
    if (P(r, s, o)) {
        let a = t.setInputOnDirectives(s, o);
        s === "disabled" && e.controlValueAccessor.setDisabledState ? H(() => e.controlValueAccessor.setDisabledState(o)) : !a && e.elementAcceptsNativeProperty(s) && Le(e.renderer, e.nativeFormElement, s, o);
    }
} }; }
function vr(t, e, r) { if (typeof MutationObserver != "function")
    return; let n = new MutationObserver(i => { i.some(s => Nr(s)) && e(); }); n.observe(t, { attributes: !0, attributeFilter: ["value"], characterData: !0, childList: !0, subtree: !0 }), r.onDestroy(() => n.disconnect()); }
function Nr(t) { if (t.type === "childList" || t.type === "characterData") {
    if (t.target instanceof Comment)
        return !1;
    for (let e of t.addedNodes)
        if (!(e instanceof Comment))
            return !0;
    for (let e of t.removedNodes)
        if (!(e instanceof Comment))
            return !0;
    return !1;
} return t.type === "attributes" && t.target instanceof HTMLOptionElement; }
function Er(t, e, r) { let n = !1, i = e.nativeFormElement, s = ct(() => e.state().value(), a => e.state().controlValue.set(a), () => mr(i, e.state().value)); r.set(s.errors), t.listenToDom("input", () => s.setRawValue(void 0)), t.listenToDom("blur", () => e.state().markAsTouched()), e.registerAsBinding(), i.tagName === "SELECT" && vr(i, () => { n && (i.value = e.state().controlValue()); }, e.destroyRef); let o = ee(); return () => { let a = e.state(), c = a.controlValue(); P(o, "controlValue", c) && pr(i, c); for (let u of Ve) {
    let R = _e(a, u);
    P(o, u, R) && (t.setInputOnDirectives(u, R), e.elementAcceptsNativeProperty(u) && Le(e.renderer, i, u, R));
} n = !0; }; }
var Sr = Symbol(), wr = new Oe(""), en = (() => { class t {
    field = st.required({ alias: "formField" });
    renderer = S(xt);
    destroyRef = S(Bt);
    state = J(() => this.field()());
    injector = S(Ut);
    element = S(Ht).nativeElement;
    elementIsNativeFormElement = hr(this.element);
    elementAcceptsNumericValues = fr(this.element);
    elementAcceptsTextualValues = gr(this.element);
    nativeFormElement = this.elementIsNativeFormElement ? this.element : void 0;
    focuser = r => this.element.focus(r);
    controlValueAccessors = S(Xt, { optional: !0, self: !0 });
    config = S(ot, { optional: !0 });
    parseErrorsSource = Gt(void 0);
    _interopNgControl;
    get interopNgControl() { return this._interopNgControl ??= new ke(this.state); }
    parseErrors = J(() => this.parseErrorsSource()?.().map(r => V(y({}, r), { fieldTree: H(this.state).fieldTree, formField: this })) ?? []);
    errors = J(() => this.state().errors().filter(r => !r.formField || r.formField === this));
    isFieldBinding = !1;
    get controlValueAccessor() { return this.controlValueAccessors?.[0] ?? this.interopNgControl?.valueAccessor ?? void 0; }
    installClassBindingEffect() { let r = Object.entries(this.config?.classes ?? {}).map(([i, s]) => [i, J(() => s(this))]); if (r.length === 0)
        return; let n = ee(); zt({ write: () => { for (let [i, s] of r) {
            let o = s();
            P(n, i, o) && (o ? this.renderer.addClass(this.element, i) : this.renderer.removeClass(this.element, i));
        } } }, { injector: this.injector }); }
    focus(r) { this.focuser(r); }
    registerAsBinding(r) { if (this.isFieldBinding)
        throw new Se(1913, !1); this.isFieldBinding = !0, this.installClassBindingEffect(), r?.focus && (this.focuser = n => r.focus(n)), $t(n => { let i = this.state(); i.nodeState.formFieldBindings.update(s => [...s, this]), n(() => { i.nodeState.formFieldBindings.update(s => s.filter(o => o !== this)); }); }, { injector: this.injector }); }
    [Sr];
    \u0275ngControlCreate(r) { if (!r.hasPassThrough)
        if (this.controlValueAccessor)
            this.\u0275ngControlUpdate = br(r, this);
        else if (r.customControl)
            this.\u0275ngControlUpdate = yr(r, this);
        else if (this.elementIsNativeFormElement)
            this.\u0275ngControlUpdate = Er(r, this, this.parseErrorsSource);
        else
            throw new Se(1914, !1); }
    \u0275ngControlUpdate;
    elementAcceptsNativeProperty(r) { if (!this.elementIsNativeFormElement)
        return !1; switch (r) {
        case "min":
        case "max": return this.elementAcceptsNumericValues;
        case "minLength":
        case "maxLength": return this.elementAcceptsTextualValues;
        case "disabled":
        case "required":
        case "readonly":
        case "name": return !0;
        default: return !1;
    } }
    static \u0275fac = function (n) { return new (n || t); };
    static \u0275dir = w.\u0275\u0275defineDirective({ type: t, selectors: [["", "formField", ""]], inputs: { field: [1, "formField", "field"] }, exportAs: ["formField"], features: [w.\u0275\u0275ProvidersFeature([{ provide: wr, useExisting: t }, { provide: Yt, useFactory: () => S(t).interopNgControl }, { provide: ut, useFactory: () => S(t).parseErrorsSource }]), w.\u0275\u0275ControlFeature("formField")] });
} return t; })(), tn = (() => { class t {
    fieldTree = st.required({ alias: "formRoot" });
    onSubmit(r) { r.preventDefault(), Ze(this.fieldTree()); }
    static \u0275fac = function (n) { return new (n || t); };
    static \u0275dir = w.\u0275\u0275defineDirective({ type: t, selectors: [["form", "formRoot", ""]], hostAttrs: ["novalidate", ""], hostBindings: function (n, i) { n & 1 && w.\u0275\u0275listener("submit", function (o) { return i.onSubmit(o); }); }, inputs: { fieldTree: [1, "formRoot", "fieldTree"] } });
} return t; })();
export { v as BaseNgValidationError, Pe as EmailValidationError, wr as FORM_FIELD, en as FormField, tn as FormRoot, be as MAX, Ne as MAX_LENGTH, ye as MIN, ve as MIN_LENGTH, Te as MaxLengthValidationError, De as MaxValidationError, B as MetadataKey, E as MetadataReducer, Re as MinLengthValidationError, Me as MinValidationError, Ce as NativeInputParseError, Ur as NgValidationError, Ee as PATTERN, Ae as PatternValidationError, pe as REQUIRED, we as RequiredValidationError, Ie as StandardSchemaValidationError, Ye as apply, _t as applyEach, We as applyWhen, Vt as applyWhenValue, qe as createManagedMetadataKey, g as createMetadataKey, Qr as debounce, jr as disabled, Hr as email, nr as emailError, Ot as form, xr as hidden, Gr as max, Jt as maxError, zr as maxLength, tr as maxLengthError, f as metadata, $r as min, Qt as minError, qr as minLength, er as minLengthError, Xr as pattern, rr as patternError, Kr as provideSignalFormsConfig, Br as readonly, Yr as required, Zt as requiredError, Lt as schema, or as standardSchemaError, Ze as submit, Jr as transformedValue, I as validate, dt as validateAsync, Zr as validateHttp, Wr as validateStandardSchema, sr as validateTree, Sr as \u0275NgFieldDirective };
/*! Bundled license information:

@angular/forms/fesm2022/_validation_errors-chunk.mjs:
@angular/forms/fesm2022/signals.mjs:
  (**
   * @license Angular v21.2.20
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
