import { a as w, d as B } from "@nf-internal/chunk-4CLCTAJ7";
import * as e from "@angular/core";
import { input as r, booleanAttribute as xe, computed as u, model as C, output as p, inject as M, DestroyRef as X, signal as g, linkedSignal as E, viewChild as D, TemplateRef as T, contentChildren as F, contentChild as K, effect as j } from "@angular/core";
import { NgComponentOutlet as ge, NgTemplateOutlet as ee } from "@angular/common";
import * as L from "@lucide/angular";
import { Router as be, RouterLink as fe } from "@angular/router";
import { takeUntilDestroyed as I } from "@angular/core/rxjs-interop";
import { Subject as N, map as S, distinctUntilChanged as he, debounce as A, timer as z, merge as ve, switchMap as Ce, of as H, take as ye, catchError as Me, finalize as we } from "rxjs";
function De(n, a) { n & 1 && e.\u0275\u0275elementContainer(0); }
var $ = ["*"];
function Pe(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "div", 9)(1, "span", 10), e.\u0275\u0275text(2), e.\u0275\u0275elementEnd()()), n & 2) {
    let t = a.$implicit;
    e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate(t);
} }
function Oe(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "div", 5), e.\u0275\u0275repeaterCreate(1, Pe, 3, 1, "div", 9, e.\u0275\u0275repeaterTrackByIndex), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275advance(), e.\u0275\u0275repeater(t.platform());
} }
function Ee(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "p", 6), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.description(), " ");
} }
function Te(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "button", 11), e.\u0275\u0275listener("click", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(2); return e.\u0275\u0275resetView(d.onFavoriteClick(o)); }), e.\u0275\u0275element(1, "app-hub-icon", 12), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275classProp("card-favorite--active", t.favorite()), e.\u0275\u0275property("title", t.favorite() ? "Remover dos favoritos" : "Adicionar aos favoritos"), e.\u0275\u0275attribute("aria-pressed", t.favorite())("aria-label", t.favorite() ? "Remover dos favoritos" : "Adicionar aos favoritos"), e.\u0275\u0275advance(), e.\u0275\u0275classProp("is-filled", t.favorite());
} }
function Se(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "button", 13), e.\u0275\u0275listener("click", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(2); return e.\u0275\u0275resetView(d.onNavigateClick(o)); }), e.\u0275\u0275element(1, "app-hub-icon", 14), e.\u0275\u0275elementEnd();
} }
function ke(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "div", 0), e.\u0275\u0275element(1, "app-hub-icon", 1), e.\u0275\u0275elementStart(2, "div", 2)(3, "strong", 3)(4, "span", 4), e.\u0275\u0275text(5), e.\u0275\u0275elementEnd()(), e.\u0275\u0275conditionalCreate(6, Oe, 3, 0, "div", 5), e.\u0275\u0275conditionalCreate(7, Ee, 2, 1, "p", 6), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(8, Te, 2, 7, "button", 7), e.\u0275\u0275conditionalCreate(9, Se, 2, 0, "button", 8), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275property("name", t.icon()), e.\u0275\u0275advance(4), e.\u0275\u0275textInterpolate1(" ", t.title(), " "), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.platform().length > 0 ? 6 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.description() ? 7 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.favoritable() && !t.navigable() ? 8 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.navigable() ? 9 : -1);
} }
function Ne(n, a) { n & 1 && e.\u0275\u0275projection(0); }
var Fe = [[["", "card-header-action", ""]], "*"], Ie = ["[card-header-action]", "*"];
function Ae(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "span", 11), e.\u0275\u0275element(1, "app-hub-icon", 12), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275styleProp("--module-icon-color", t.iconColor(t.color())), e.\u0275\u0275advance(), e.\u0275\u0275property("name", t.icone());
} }
function ze(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "button", 7), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(o.handleHeaderAction()); }), e.\u0275\u0275conditionalCreate(1, Ae, 2, 3, "span", 8), e.\u0275\u0275elementStart(2, "span", 9)(3, "strong", 10), e.\u0275\u0275text(4), e.\u0275\u0275elementEnd()()();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.icone() ? 1 : -1), e.\u0275\u0275advance(3), e.\u0275\u0275textInterpolate1(" ", t.nome(), " ");
} }
function Le(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "span", 11), e.\u0275\u0275element(1, "app-hub-icon", 12), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275styleProp("--module-icon-color", t.iconColor(t.color())), e.\u0275\u0275advance(), e.\u0275\u0275property("name", t.icone());
} }
function $e(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "div", 3), e.\u0275\u0275conditionalCreate(1, Le, 2, 3, "span", 8), e.\u0275\u0275elementStart(2, "span", 9)(3, "strong", 10), e.\u0275\u0275text(4), e.\u0275\u0275elementEnd()()()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.icone() ? 1 : -1), e.\u0275\u0275advance(3), e.\u0275\u0275textInterpolate1(" ", t.nome(), " ");
} }
function Ve(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "footer", 6)(1, "button", 13), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(o.handleFooterAction()); }), e.\u0275\u0275text(2), e.\u0275\u0275elementStart(3, "span", 14), e.\u0275\u0275text(4, " \u203A "), e.\u0275\u0275elementEnd()()();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate1(" ", t.textFooter(), " ");
} }
function Re(n, a) { n & 1 && (e.\u0275\u0275elementStart(0, "span", 5), e.\u0275\u0275text(1, " \u203A "), e.\u0275\u0275elementEnd()); }
function qe(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "button", 4), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(o.handleItemClick()); }), e.\u0275\u0275conditionalCreate(1, Re, 2, 0, "span", 5), e.\u0275\u0275elementStart(2, "span", 6), e.\u0275\u0275text(3), e.\u0275\u0275elementEnd()();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275property("disabled", t.disabled()), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.showArrow() ? 1 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate1(" ", t.label(), " ");
} }
function Be(n, a) { n & 1 && (e.\u0275\u0275elementStart(0, "span", 5), e.\u0275\u0275text(1, " \u203A "), e.\u0275\u0275elementEnd()); }
function Ke(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "div", 2), e.\u0275\u0275conditionalCreate(1, Be, 2, 0, "span", 5), e.\u0275\u0275elementStart(2, "span", 6), e.\u0275\u0275text(3), e.\u0275\u0275elementEnd()()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.showArrow() ? 1 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate1(" ", t.label(), " ");
} }
function je(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "button", 7), e.\u0275\u0275listener("click", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(d.handleFavorite(o)); }), e.\u0275\u0275element(1, "app-hub-icon", 8), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275classProp("card-list-item__favorite--active", t.favorite()), e.\u0275\u0275property("disabled", t.disabled()), e.\u0275\u0275attribute("aria-pressed", t.favorite())("aria-label", t.favorite() ? "Remover dos favoritos" : "Adicionar aos favoritos"), e.\u0275\u0275advance(), e.\u0275\u0275classProp("is-filled", t.favorite());
} }
var He = ["searchInput"], Qe = ["dropdown"];
function We(n, a) { return this.optionIdentifier(a); }
function Ue(n, a) { n & 1 && (e.\u0275\u0275domElementStart(0, "span", 14), e.\u0275\u0275text(1, " * "), e.\u0275\u0275domElementEnd()); }
function Ge(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "label", 3), e.\u0275\u0275text(1), e.\u0275\u0275conditionalCreate(2, Ue, 2, 0, "span", 14), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275domProperty("htmlFor", t.inputId), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.label(), " "), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.required() ? 2 : -1);
} }
function Je(n, a) { n & 1 && e.\u0275\u0275domElement(0, "span", 9); }
function Ye(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275domElementStart(0, "button", 15), e.\u0275\u0275domListener("pointerdown", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(d.clear(o)); }), e.\u0275\u0275text(1, " \xD7 "), e.\u0275\u0275domElementEnd();
} }
function Ze(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "p", 11), e.\u0275\u0275text(1), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" Digite mais ", t.remainingCharacters(), " caractere(s). ");
} }
function Xe(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "p", 11), e.\u0275\u0275text(1), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.hint(), " ");
} }
function et(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "div", 17), e.\u0275\u0275text(1), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.loadingText(), " ");
} }
function tt(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "div", 18), e.\u0275\u0275text(1), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.searchError(), " ");
} }
function nt(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "div", 19), e.\u0275\u0275text(1), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.emptyText(), " ");
} }
function it(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "span", 25), e.\u0275\u0275text(1), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit, i = e.\u0275\u0275nextContext(3);
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", i.secondaryText()(t), " ");
} }
function ot(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275domElementStart(0, "button", 23), e.\u0275\u0275domListener("mouseenter", function () { let o = e.\u0275\u0275restoreView(t).$index, d = e.\u0275\u0275nextContext(3); return e.\u0275\u0275resetView(d.setActiveIndex(o)); })("pointerdown", function (o) { let d = e.\u0275\u0275restoreView(t).$implicit, l = e.\u0275\u0275nextContext(3); return e.\u0275\u0275resetView(l.selectOption(d, o)); }), e.\u0275\u0275domElementStart(1, "span", 24), e.\u0275\u0275text(2), e.\u0275\u0275domElementEnd(), e.\u0275\u0275conditionalCreate(3, it, 2, 1, "span", 25), e.\u0275\u0275domElementEnd();
} if (n & 2) {
    let t = a.$implicit, i = a.$index, o = e.\u0275\u0275nextContext(3);
    e.\u0275\u0275classProp("drx-autocomplete__option--active", i === o.activeIndex()), e.\u0275\u0275domProperty("id", o.inputId + "-option-" + i), e.\u0275\u0275attribute("aria-selected", o.value() === t), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate1(" ", o.displayWith()(t), " "), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.secondaryText()(t) ? 3 : -1);
} }
function at(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "div", 21), e.\u0275\u0275domElement(1, "span", 26), e.\u0275\u0275text(2), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(3);
    e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate1(" ", t.loadingMoreText(), " ");
} }
function rt(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275domElementStart(0, "div", 22)(1, "span"), e.\u0275\u0275text(2), e.\u0275\u0275domElementEnd(), e.\u0275\u0275domElementStart(3, "button", 27), e.\u0275\u0275domListener("pointerdown", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(3); return e.\u0275\u0275resetView(d.retryLoadMore(o)); }), e.\u0275\u0275text(4), e.\u0275\u0275domElementEnd()();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext(3);
    e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate(t.loadMoreError()), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate1(" ", t.retryText(), " ");
} }
function dt(n, a) { if (n & 1 && (e.\u0275\u0275repeaterCreate(0, ot, 4, 6, "button", 20, We, !0), e.\u0275\u0275conditionalCreate(2, at, 3, 1, "div", 21)(3, rt, 5, 2, "div", 22)), n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275repeater(t.results()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(t.loadingMore() ? 2 : t.loadMoreError() ? 3 : -1);
} }
function lt(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275domElementStart(0, "div", 16, 1), e.\u0275\u0275domListener("scroll", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(d.handleResultsScroll(o)); }), e.\u0275\u0275conditionalCreate(2, et, 2, 1, "div", 17)(3, tt, 2, 1, "div", 18)(4, nt, 2, 1, "div", 19)(5, dt, 4, 1), e.\u0275\u0275domElementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275domProperty("id", t.listboxId), e.\u0275\u0275attribute("popover", "manual"), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(t.loading() ? 2 : t.searchError() ? 3 : t.results().length === 0 ? 4 : 5);
} }
function ct(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "span", 28), e.\u0275\u0275text(1), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = a.$implicit;
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.message, " ");
} }
function st(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "div", 13), e.\u0275\u0275repeaterCreate(1, ct, 2, 1, "span", 28, e.\u0275\u0275repeaterTrackByIdentity), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275repeater(t.errors());
} }
var te = (n, a) => a.id;
function pt(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "span", 3), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit;
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.prefix, " ");
} }
function ut(n, a) { if (n & 1 && e.\u0275\u0275element(0, "app-hub-icon", 4), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit;
    e.\u0275\u0275property("name", t.icon);
} }
function _t(n, a) { n & 1 && e.\u0275\u0275element(0, "app-hub-icon", 6); }
function mt(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "span", 7), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit;
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.badge, " ");
} }
function xt(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "button", 2), e.\u0275\u0275listener("click", function () { let o = e.\u0275\u0275restoreView(t).$implicit, d = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(d.select(o)); })("keydown", function (o) { let d = e.\u0275\u0275restoreView(t).$index, l = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(l.handleKeydown(o, d)); }), e.\u0275\u0275conditionalCreate(1, pt, 2, 1, "span", 3), e.\u0275\u0275conditionalCreate(2, ut, 1, 1, "app-hub-icon", 4), e.\u0275\u0275elementStart(3, "span", 5), e.\u0275\u0275text(4), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(5, _t, 1, 0, "app-hub-icon", 6), e.\u0275\u0275conditionalCreate(6, mt, 2, 1, "span", 7), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = a.$implicit, i = e.\u0275\u0275nextContext();
    e.\u0275\u0275classProp("drx-tabs__tab--active", i.isActive(t))("drx-tabs__tab--completed", i.isCompleted(t)), e.\u0275\u0275property("disabled", t.disabled), e.\u0275\u0275attribute("aria-selected", i.isActive(t))("aria-controls", i.panelId(t))("tabindex", i.isActive(t) ? 0 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(i.variant() === "steps" && t.prefix !== void 0 && t.prefix !== null ? 1 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.icon ? 2 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate1(" ", t.label, " "), e.\u0275\u0275advance(), e.\u0275\u0275conditional(i.variant() === "steps" && i.isCompleted(t) ? 5 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.badge !== void 0 && t.badge !== null ? 6 : -1);
} }
var ne = ["inputElement"];
function gt(n, a) { n & 1 && (e.\u0275\u0275domElementStart(0, "span", 5), e.\u0275\u0275text(1, " * "), e.\u0275\u0275domElementEnd()); }
function bt(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "label", 2), e.\u0275\u0275text(1), e.\u0275\u0275conditionalCreate(2, gt, 2, 0, "span", 5), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275domProperty("htmlFor", t.resolvedInputId), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.label(), " "), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.required() ? 2 : -1);
} }
function ft(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "p", 6), e.\u0275\u0275text(1), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = a.$implicit;
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.message, " ");
} }
function ht(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "div", 4), e.\u0275\u0275repeaterCreate(1, ft, 2, 1, "p", 6, e.\u0275\u0275repeaterTrackByIndex), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275repeater(t.errors());
} }
var vt = [[["", "drxFooterStart", ""]], [["", "drxFooterAction", ""]], [["", "drxFooterEnd", ""]]], Ct = ["[drxFooterStart]", "[drxFooterAction]", "[drxFooterEnd]"];
function yt(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "drx-button", 6), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(o.handleCancel()); }), e.\u0275\u0275element(1, "app-hub-icon", 7), e.\u0275\u0275elementStart(2, "span"), e.\u0275\u0275text(3), e.\u0275\u0275elementEnd()();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275property("disabled", t.saving()), e.\u0275\u0275advance(), e.\u0275\u0275property("name", t.cancelIcon()), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate(t.cancelLabel());
} }
function Mt(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "drx-button", 8), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(o.handleSaveAndContinue()); }), e.\u0275\u0275element(1, "app-hub-icon", 7), e.\u0275\u0275elementStart(2, "span"), e.\u0275\u0275text(3), e.\u0275\u0275elementEnd()();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275property("disabled", t.saveDisabled()), e.\u0275\u0275advance(), e.\u0275\u0275property("name", t.saveAndContinueIcon()), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate(t.saveAndContinueLabel());
} }
function wt(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "drx-button", 9), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(o.handleSave()); }), e.\u0275\u0275element(1, "app-hub-icon", 7), e.\u0275\u0275elementStart(2, "span"), e.\u0275\u0275text(3), e.\u0275\u0275elementEnd()();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275property("disabled", t.saveDisabled()), e.\u0275\u0275advance(), e.\u0275\u0275property("name", t.saveIcon()), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate(t.primaryLabel());
} }
function Dt(n, a) { n & 1 && (e.\u0275\u0275elementStart(0, "span", 9), e.\u0275\u0275text(1, "*"), e.\u0275\u0275elementEnd()); }
function Pt(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "label", 2), e.\u0275\u0275text(1), e.\u0275\u0275conditionalCreate(2, Dt, 2, 0, "span", 9), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275property("for", t.resolvedId), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.label(), " "), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.required() ? 2 : -1);
} }
function Ot(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "p", 7), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate(t.hint());
} }
function Et(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "p", 10), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = a.$implicit;
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate(t.message);
} }
function Tt(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "div", 8), e.\u0275\u0275repeaterCreate(1, Et, 2, 1, "p", 10, e.\u0275\u0275repeaterTrackByIndex), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275repeater(t.errors());
} }
var St = ["selectElement"], kt = (n, a) => a.value;
function Nt(n, a) { n & 1 && (e.\u0275\u0275elementStart(0, "span", 10), e.\u0275\u0275text(1, "*"), e.\u0275\u0275elementEnd()); }
function Ft(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "label", 2), e.\u0275\u0275text(1), e.\u0275\u0275conditionalCreate(2, Nt, 2, 0, "span", 10), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275property("for", t.resolvedId), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.label(), " "), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.required() ? 2 : -1);
} }
function It(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "option", 5), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275property("disabled", t.required()), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.placeholder(), " ");
} }
function At(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "option", 6), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = a.$implicit;
    e.\u0275\u0275property("value", t.value)("disabled", t.disabled ?? !1), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.label, " ");
} }
function zt(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "p", 8), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate(t.hint());
} }
function Lt(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "p", 11), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = a.$implicit;
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate(t.message);
} }
function $t(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "div", 9), e.\u0275\u0275repeaterCreate(1, Lt, 2, 1, "p", 11, e.\u0275\u0275repeaterTrackByIndex), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275repeater(t.errors());
} }
function Vt(n, a) { if (n & 1 && e.\u0275\u0275element(0, "app-hub-icon", 1), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275property("name", t.icon() ?? "");
} }
var ie = () => [], y = (n, a) => a.key;
function Rt(n, a) { return this.rowKey()(a, n); }
function qt(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "span", 8), e.\u0275\u0275element(1, "app-hub-icon", 12), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275advance(), e.\u0275\u0275property("name", t.icon() ?? "");
} }
function Bt(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "strong"), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate(t.title());
} }
function Kt(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "div", 10), e.\u0275\u0275element(1, "app-hub-icon", 12), e.\u0275\u0275elementStart(2, "drx-input", 13), e.\u0275\u0275listener("valueChange", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(2); return e.\u0275\u0275resetView(d.onSearchChange(o)); }), e.\u0275\u0275elementEnd()();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275advance(), e.\u0275\u0275property("name", "search"), e.\u0275\u0275advance(), e.\u0275\u0275property("placeholder", t.searchPlaceholder())("value", t.currentSearch());
} }
function jt(n, a) { if (n & 1 && e.\u0275\u0275element(0, "app-hub-icon", 12), n & 2) {
    let t = e.\u0275\u0275nextContext(3);
    e.\u0275\u0275property("name", t.primaryActionIcon() ?? "");
} }
function Ht(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "drx-button", 14), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(2); return e.\u0275\u0275resetView(o.primaryAction.emit()); }), e.\u0275\u0275conditionalCreate(1, jt, 1, 1, "app-hub-icon", 12), e.\u0275\u0275elementStart(2, "span"), e.\u0275\u0275text(3), e.\u0275\u0275elementEnd()();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275property("disabled", t.primaryActionDisabled()), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.primaryActionIcon() ? 1 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate(t.primaryActionLabel());
} }
function Qt(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "header", 1)(1, "div", 7), e.\u0275\u0275conditionalCreate(2, qt, 2, 1, "span", 8), e.\u0275\u0275conditionalCreate(3, Bt, 2, 1, "strong"), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(4, "div", 9), e.\u0275\u0275conditionalCreate(5, Kt, 3, 3, "div", 10), e.\u0275\u0275conditionalCreate(6, Ht, 4, 3, "drx-button", 11), e.\u0275\u0275elementEnd()()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(2), e.\u0275\u0275conditional(t.icon() ? 2 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.title() ? 3 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(t.searchable() ? 5 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.primaryActionLabel() ? 6 : -1);
} }
function Wt(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "span", 16), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit, i = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", i.sortIndicator(t), " ");
} }
function Ut(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "th")(1, "button", 15), e.\u0275\u0275listener("click", function () { let o = e.\u0275\u0275restoreView(t).$implicit, d = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(d.toggleSort(o)); }), e.\u0275\u0275elementStart(2, "span"), e.\u0275\u0275text(3), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(4, Wt, 2, 1, "span", 16), e.\u0275\u0275elementEnd()();
} if (n & 2) {
    let t = a.$implicit, i = e.\u0275\u0275nextContext();
    e.\u0275\u0275classMap(i.alignClass(t)), e.\u0275\u0275styleProp("width", t.width ?? null), e.\u0275\u0275advance(), e.\u0275\u0275classProp("drx-data-table__heading--sortable", t.sortable), e.\u0275\u0275property("disabled", !t.sortable), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate(t.label), e.\u0275\u0275advance(), e.\u0275\u0275conditional(i.sortIndicator(t) ? 4 : -1);
} }
function Gt(n, a) { n & 1 && (e.\u0275\u0275elementStart(0, "th", 4), e.\u0275\u0275text(1, "A\xE7\xF5es"), e.\u0275\u0275elementEnd()); }
function Jt(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "drx-select", 20), e.\u0275\u0275listener("valueChange", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(2).$implicit, l = e.\u0275\u0275nextContext(2); return e.\u0275\u0275resetView(l.onFilterChange(d, o)); }), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext(2).$implicit, i = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275property("placeholder", (t.filter == null ? null : t.filter.placeholder) ?? "Filtrar " + t.label)("options", (t.filter == null ? null : t.filter.options) ?? e.\u0275\u0275pureFunction0(3, ie))("value", i.filterValue(t.key));
} }
function Yt(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "drx-calendar", 21), e.\u0275\u0275listener("valueChange", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(2).$implicit, l = e.\u0275\u0275nextContext(2); return e.\u0275\u0275resetView(l.onFilterChange(d, o)); }), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext(2).$implicit, i = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275property("value", i.filterValue(t.key));
} }
function Zt(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "drx-input", 13), e.\u0275\u0275listener("valueChange", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(2).$implicit, l = e.\u0275\u0275nextContext(2); return e.\u0275\u0275resetView(l.onFilterChange(d, o)); }), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext(2).$implicit, i = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275property("placeholder", (t.filter == null ? null : t.filter.placeholder) ?? "Filtrar " + t.label)("value", i.filterValue(t.key));
} }
function Xt(n, a) { if (n & 1 && e.\u0275\u0275conditionalCreate(0, Jt, 1, 4, "drx-select", 17)(1, Yt, 1, 1, "drx-calendar", 18)(2, Zt, 1, 2, "drx-input", 19), n & 2) {
    let t, i = e.\u0275\u0275nextContext().$implicit;
    e.\u0275\u0275conditional((t = (i.filter == null ? null : i.filter.type) ?? "text") === "select" ? 0 : t === "date" ? 1 : 2);
} }
function en(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "th"), e.\u0275\u0275conditionalCreate(1, Xt, 3, 1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = a.$implicit;
    e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.filterable !== !1 ? 1 : -1);
} }
function tn(n, a) { n & 1 && e.\u0275\u0275element(0, "th"); }
function nn(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "tr", 5), e.\u0275\u0275repeaterCreate(1, en, 2, 1, "th", null, y), e.\u0275\u0275conditionalCreate(3, tn, 1, 0, "th"), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275repeater(t.columns()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(t.actions().length > 0 ? 3 : -1);
} }
function on(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "tr")(1, "td", 22), e.\u0275\u0275text(2), e.\u0275\u0275elementEnd()()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275attribute("colspan", t.columns().length + (t.actions().length > 0 ? 1 : 0)), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.loadingText(), " ");
} }
function an(n, a) { if (n & 1 && e.\u0275\u0275element(0, "drx-badge", 26), n & 2) {
    let t = a;
    e.\u0275\u0275property("label", t.label)("tone", t.tone ?? "neutral")("size", t.size ?? "small")("icon", t.icon ?? null);
} }
function rn(n, a) { if (n & 1 && e.\u0275\u0275text(0), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit, i = e.\u0275\u0275nextContext().$implicit, o = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275textInterpolate1(" ", o.displayValue(i, t), " ");
} }
function dn(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "td", 25), e.\u0275\u0275conditionalCreate(1, an, 1, 4, "drx-badge", 26)(2, rn, 1, 1), e.\u0275\u0275elementEnd()), n & 2) {
    let t, i = a.$implicit, o = e.\u0275\u0275nextContext().$implicit, d = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275classMap(d.alignClass(i)), e.\u0275\u0275advance(), e.\u0275\u0275conditional((t = d.badgeConfig(o, i)) ? 1 : 2, t);
} }
function ln(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "button", 28), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext().$implicit, d = e.\u0275\u0275nextContext(2).$implicit, l = e.\u0275\u0275nextContext(2); return e.\u0275\u0275resetView(l.emitRowAction(o, d)); }), e.\u0275\u0275element(1, "app-hub-icon", 12), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit, i = e.\u0275\u0275nextContext(2).$implicit, o = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275property("title", t.label)("disabled", o.isActionDisabled(t, i)), e.\u0275\u0275attribute("aria-label", t.label), e.\u0275\u0275advance(), e.\u0275\u0275property("name", t.icon ?? "");
} }
function cn(n, a) { if (n & 1 && e.\u0275\u0275conditionalCreate(0, ln, 2, 4, "button", 27), n & 2) {
    let t = a.$implicit, i = e.\u0275\u0275nextContext(2).$implicit, o = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275conditional(o.isActionHidden(t, i) ? -1 : 0);
} }
function sn(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "td", 24), e.\u0275\u0275repeaterCreate(1, cn, 1, 1, null, null, te), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(3);
    e.\u0275\u0275advance(), e.\u0275\u0275repeater(t.actions());
} }
function pn(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "tr"), e.\u0275\u0275repeaterCreate(1, dn, 3, 3, "td", 23, y), e.\u0275\u0275conditionalCreate(3, sn, 3, 0, "td", 24), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275advance(), e.\u0275\u0275repeater(t.columns()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(t.actions().length > 0 ? 3 : -1);
} }
function un(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "tr")(1, "td", 22), e.\u0275\u0275text(2), e.\u0275\u0275elementEnd()()), n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275advance(), e.\u0275\u0275attribute("colspan", t.columns().length + (t.actions().length > 0 ? 1 : 0)), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.emptyText(), " ");
} }
function _n(n, a) { if (n & 1 && e.\u0275\u0275repeaterCreate(0, pn, 4, 1, "tr", null, Rt, !0, un, 3, 2, "tr"), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275repeater(t.displayedRows());
} }
function mn(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "footer", 6)(1, "div", 29)(2, "span", 30), e.\u0275\u0275text(3, "Itens por p\xE1gina"), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(4, "drx-select", 31), e.\u0275\u0275listener("valueChange", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(d.onPageSizeChange(o)); }), e.\u0275\u0275elementEnd()(), e.\u0275\u0275elementStart(5, "span", 32), e.\u0275\u0275text(6), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(7, "div", 33)(8, "button", 34), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(o.goToPreviousPage()); }), e.\u0275\u0275element(9, "app-hub-icon", 12), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(10, "span", 35), e.\u0275\u0275text(11), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(12, "span", 30), e.\u0275\u0275text(13), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(14, "button", 36), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(o.goToNextPage()); }), e.\u0275\u0275element(15, "app-hub-icon", 12), e.\u0275\u0275elementEnd()()();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(4), e.\u0275\u0275property("value", t.currentPageSize().toString())("options", t.pageSizeSelectOptions()), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate3(" ", t.rangeStart(), "\u2013", t.rangeEnd(), " de ", t.effectiveTotal(), " "), e.\u0275\u0275advance(2), e.\u0275\u0275property("disabled", t.currentPage() <= 1), e.\u0275\u0275advance(), e.\u0275\u0275property("name", "chevron-left"), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate(t.currentPage()), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate1("de ", t.totalPages()), e.\u0275\u0275advance(), e.\u0275\u0275property("disabled", t.currentPage() >= t.totalPages()), e.\u0275\u0275advance(), e.\u0275\u0275property("name", "chevron-right");
} }
var xn = ["draftRow"], gn = (n, a, t, i, o) => ({ $implicit: n, draft: a, column: t, errors: i, patch: o }), bn = (n, a, t) => ({ $implicit: n, row: a, column: t }), oe = (n, a, t) => ({ $implicit: n, row: a, columnCount: t }), fn = (n, a, t, i, o) => ({ $implicit: n, node: a, row: t, depth: i, columnKey: o }), hn = (n, a, t, i) => ({ $implicit: n, node: a, row: t, depth: i, columnKey: "$actions" });
function vn(n, a) { return this.rowKey()(a); }
function Cn(n, a) { if (n & 1 && e.\u0275\u0275elementContainer(0, 14), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit, i = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275property("ngTemplateOutlet", a.template)("ngTemplateOutletContext", e.\u0275\u0275pureFunction5(2, gn, i.draft(), i.draft(), t, i.visibleColumnErrors(t.key), i.patchDraftContext));
} }
function yn(n, a) { }
function Mn(n, a) { if (n & 1 && e.\u0275\u0275element(0, "input", 16), n & 2) {
    let t = e.\u0275\u0275nextContext(2).$implicit, i = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275property("value", i.draftValue(t)), e.\u0275\u0275attribute("aria-label", t.label);
} }
function wn(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "input", 18), e.\u0275\u0275listener("input", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(2).$implicit, l = e.\u0275\u0275nextContext(2); return e.\u0275\u0275resetView(l.updateDefaultEditor(d, o)); }), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext(2).$implicit, i = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275property("type", t.inputType ?? t.editor ?? "text")("placeholder", t.placeholder ?? "")("value", i.draftValue(t)), e.\u0275\u0275attribute("aria-label", t.label)("aria-invalid", i.visibleColumnErrors(t.key).length > 0)("inputmode", t.inputMode ?? null)("min", t.min ?? null)("max", t.max ?? null)("step", t.step ?? null)("drxEditableAutofocus", i.isFirstEditableColumn(t) ? "" : null)("drxEditableCommitOnEnter", i.isLastEditableColumn(t) ? "" : null)("drxEditableNextOnEnter", i.isLastEditableColumn(t) ? null : "");
} }
function Dn(n, a) { if (n & 1 && e.\u0275\u0275conditionalCreate(0, yn, 0, 0)(1, Mn, 1, 2, "input", 16)(2, wn, 1, 12, "input", 17), n & 2) {
    let t, i = e.\u0275\u0275nextContext().$implicit;
    e.\u0275\u0275conditional((t = i.editor ?? "text") === "none" ? 0 : t === "readonly" ? 1 : 2);
} }
function Pn(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "small", 15), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = a.$implicit;
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t, " ");
} }
function On(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "td", 12), e.\u0275\u0275listener("focusout", function (o) { let d = e.\u0275\u0275restoreView(t).$implicit, l = e.\u0275\u0275nextContext(2); return e.\u0275\u0275resetView(l.markColumnTouched(d.key, o)); }), e.\u0275\u0275elementStart(1, "div", 13), e.\u0275\u0275conditionalCreate(2, Cn, 1, 8, "ng-container", 14)(3, Dn, 3, 1), e.\u0275\u0275repeaterCreate(4, Pn, 2, 1, "small", 15, e.\u0275\u0275repeaterTrackByIdentity), e.\u0275\u0275elementEnd()();
} if (n & 2) {
    let t, i = a.$implicit, o = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275classMap("drx-editable-table__cell--" + (i.align ?? "left")), e.\u0275\u0275classProp("drx-editable-table__editor-cell--invalid", o.visibleColumnErrors(i.key).length > 0), e.\u0275\u0275attribute("data-label", i.label)("data-column-key", i.key), e.\u0275\u0275advance(2), e.\u0275\u0275conditional((t = o.editorTemplate(i.key)) ? 2 : 3, t), e.\u0275\u0275advance(2), e.\u0275\u0275repeater(o.visibleColumnErrors(i.key));
} }
function En(n, a) { if (n & 1 && e.\u0275\u0275repeaterCreate(0, On, 6, 7, "td", 11, y), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275repeater(t.columns());
} }
function Tn(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "button", 23), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(3); return e.\u0275\u0275resetView(o.cancelEditing()); }), e.\u0275\u0275element(1, "app-hub-icon", 24), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext(3);
    e.\u0275\u0275property("disabled", t.busy());
} }
function Sn(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "td", 19)(1, "button", 20), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(2); return e.\u0275\u0275resetView(o.commitDraft()); }), e.\u0275\u0275element(2, "app-hub-icon", 21), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(3, Tn, 2, 1, "button", 22), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275advance(), e.\u0275\u0275property("title", t.isEditing() ? t.saveLabel() : t.addLabel())("disabled", !t.canCommit()), e.\u0275\u0275attribute("aria-label", t.isEditing() ? t.saveLabel() : t.addLabel()), e.\u0275\u0275advance(), e.\u0275\u0275property("name", t.isEditing() ? "save-pen" : "circle-plus"), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.isEditing() || t.draftDirty() ? 3 : -1);
} }
function kn(n, a) { if (n & 1 && e.\u0275\u0275conditionalCreate(0, Sn, 4, 5, "td", 19), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275conditional(t.showActions() ? 0 : -1);
} }
function Nn(n, a) { if (n & 1 && e.\u0275\u0275element(0, "col"), n & 2) {
    let t = a.$implicit, i = e.\u0275\u0275nextContext();
    e.\u0275\u0275styleProp("width", i.columnWidthPx(t), "px");
} }
function Fn(n, a) { n & 1 && e.\u0275\u0275element(0, "col", 7); }
function In(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "th", 25), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = a.$implicit;
    e.\u0275\u0275classMap("drx-editable-table__cell--" + (t.align ?? "left")), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.label, " ");
} }
function An(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "th", 9), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.actionsLabel(), " ");
} }
function zn(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "tr", 27, 2), e.\u0275\u0275listener("keydown", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(2); return e.\u0275\u0275resetView(d.handleDraftKeydown(o)); }), e.\u0275\u0275elementContainer(2, 28)(3, 28), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit, i = e.\u0275\u0275nextContext(), o = e.\u0275\u0275reference(2), d = e.\u0275\u0275reference(4);
    e.\u0275\u0275attribute("data-state", i.rowState()(t)), e.\u0275\u0275advance(2), e.\u0275\u0275property("ngTemplateOutlet", o), e.\u0275\u0275advance(), e.\u0275\u0275property("ngTemplateOutlet", d);
} }
function Ln(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "button", 32), e.\u0275\u0275listener("click", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(3).$implicit, l = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(l.toggleRowExpansion(d, o)); }), e.\u0275\u0275element(1, "app-hub-icon", 33), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext(3).$implicit, i = e.\u0275\u0275nextContext();
    e.\u0275\u0275classProp("is-expanded", i.isRowExpanded(t)), e.\u0275\u0275attribute("aria-expanded", i.isRowExpanded(t))("aria-label", (i.isRowExpanded(t) ? "Recolher " : "Expandir ") + i.treeRowLabel()(t));
} }
function $n(n, a) { if (n & 1 && e.\u0275\u0275elementContainer(0, 14), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit, i = e.\u0275\u0275nextContext(2).$implicit;
    e.\u0275\u0275property("ngTemplateOutlet", a.template)("ngTemplateOutletContext", e.\u0275\u0275pureFunction3(2, bn, i, i, t));
} }
function Vn(n, a) { if (n & 1 && e.\u0275\u0275text(0), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit, i = e.\u0275\u0275nextContext(2).$implicit, o = e.\u0275\u0275nextContext();
    e.\u0275\u0275textInterpolate1(" ", o.displayValue(i, t), " ");
} }
function Rn(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "td")(1, "div"), e.\u0275\u0275conditionalCreate(2, Ln, 2, 4, "button", 30), e.\u0275\u0275elementStart(3, "span", 31), e.\u0275\u0275conditionalCreate(4, $n, 1, 6, "ng-container", 14)(5, Vn, 1, 1), e.\u0275\u0275elementEnd()()()), n & 2) {
    let t, i = a.$implicit, o = e.\u0275\u0275nextContext(2).$implicit, d = e.\u0275\u0275nextContext();
    e.\u0275\u0275classMap("drx-editable-table__cell--" + (i.align ?? "left")), e.\u0275\u0275attribute("data-label", i.label), e.\u0275\u0275advance(), e.\u0275\u0275classProp("drx-editable-table__tree-cell", d.rowChildren() && d.isTreeColumn(i.key)), e.\u0275\u0275advance(), e.\u0275\u0275conditional(d.isTreeColumn(i.key) && d.canExpand(o) ? 2 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275conditional((t = d.cellTemplate(i.key)) ? 4 : 5, t);
} }
function qn(n, a) { if (n & 1 && e.\u0275\u0275elementContainer(0, 14), n & 2) {
    let t = e.\u0275\u0275nextContext(3).$implicit, i = e.\u0275\u0275nextContext();
    e.\u0275\u0275property("ngTemplateOutlet", a.template)("ngTemplateOutletContext", e.\u0275\u0275pureFunction3(2, oe, t, t, i.renderedColumnCount()));
} }
function Bn(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "button", 34), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(3).$implicit, d = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(d.startEditing(o)); }), e.\u0275\u0275element(1, "app-hub-icon", 35), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(2, "button", 36), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(3).$implicit, d = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(d.remove(o)); }), e.\u0275\u0275element(3, "app-hub-icon", 37), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext(3).$implicit, i = e.\u0275\u0275nextContext();
    e.\u0275\u0275property("disabled", !i.editable() || i.busy() || !i.canEditRow()(t)), e.\u0275\u0275advance(2), e.\u0275\u0275property("disabled", !i.editable() || i.busy() || !i.canRemoveRow()(t));
} }
function Kn(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "td", 19), e.\u0275\u0275conditionalCreate(1, qn, 1, 6, "ng-container", 14)(2, Bn, 4, 2), e.\u0275\u0275elementEnd()), n & 2) {
    let t, i = e.\u0275\u0275nextContext(3);
    e.\u0275\u0275advance(), e.\u0275\u0275conditional((t = i.rowActionsTemplate()) ? 1 : 2, t);
} }
function jn(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "tr", 38)(1, "td", 39), e.\u0275\u0275text(2), e.\u0275\u0275elementEnd()()), n & 2) {
    let t = e.\u0275\u0275nextContext(5);
    e.\u0275\u0275advance(), e.\u0275\u0275attribute("colspan", t.renderedColumnCount()), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate(a);
} }
function Hn(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "button", 32), e.\u0275\u0275listener("click", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(2).$implicit, l = e.\u0275\u0275nextContext(4).$implicit, c = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(c.toggleTreeExpansion(l, d, o)); }), e.\u0275\u0275element(1, "app-hub-icon", 33), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = e.\u0275\u0275nextContext(2).$implicit, i = e.\u0275\u0275nextContext(5);
    e.\u0275\u0275classProp("is-expanded", i.isTreeNodeExpanded(t.key)), e.\u0275\u0275attribute("aria-expanded", i.isTreeNodeExpanded(t.key))("aria-label", (i.isTreeNodeExpanded(t.key) ? "Recolher " : "Expandir ") + t.node.label);
} }
function Qn(n, a) { if (n & 1 && e.\u0275\u0275elementContainer(0, 14), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit, i = e.\u0275\u0275nextContext().$implicit, o = e.\u0275\u0275nextContext(4).$implicit;
    e.\u0275\u0275property("ngTemplateOutlet", a.template)("ngTemplateOutletContext", e.\u0275\u0275pureFunction5(2, fn, i.node, i.node, o, i.depth, t.key));
} }
function Wn(n, a) { if (n & 1 && e.\u0275\u0275text(0), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit, i = e.\u0275\u0275nextContext().$implicit;
    e.\u0275\u0275textInterpolate1(" ", i.node.cells[t.key] ?? "\u2014", " ");
} }
function Un(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "td")(1, "div"), e.\u0275\u0275conditionalCreate(2, Hn, 2, 4, "button", 30), e.\u0275\u0275elementStart(3, "span", 31), e.\u0275\u0275conditionalCreate(4, Qn, 1, 8, "ng-container", 14)(5, Wn, 1, 1), e.\u0275\u0275elementEnd()()()), n & 2) {
    let t, i = a.$implicit, o = e.\u0275\u0275nextContext().$implicit, d = e.\u0275\u0275nextContext(5);
    e.\u0275\u0275classMap("drx-editable-table__cell--" + (i.align ?? "left")), e.\u0275\u0275attribute("data-label", i.label), e.\u0275\u0275advance(), e.\u0275\u0275styleProp("padding-inline-start", d.isTreeColumn(i.key) ? o.depth * 16 : null, "px"), e.\u0275\u0275classProp("drx-editable-table__tree-cell", d.isTreeColumn(i.key)), e.\u0275\u0275advance(), e.\u0275\u0275conditional(d.isTreeColumn(i.key) && d.canExpandTreeNode(o.node) ? 2 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275conditional((t = d.treeCellTemplate(i.key)) ? 4 : 5, t);
} }
function Gn(n, a) { if (n & 1 && e.\u0275\u0275elementContainer(0, 14), n & 2) {
    let t = e.\u0275\u0275nextContext(2).$implicit, i = e.\u0275\u0275nextContext(4).$implicit;
    e.\u0275\u0275property("ngTemplateOutlet", a.template)("ngTemplateOutletContext", e.\u0275\u0275pureFunction4(2, hn, t.node, t.node, i, t.depth));
} }
function Jn(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "td", 19), e.\u0275\u0275conditionalCreate(1, Gn, 1, 7, "ng-container", 14), e.\u0275\u0275elementEnd()), n & 2) {
    let t, i = e.\u0275\u0275nextContext(6);
    e.\u0275\u0275advance(), e.\u0275\u0275conditional((t = i.treeCellTemplate("$actions")) ? 1 : -1, t);
} }
function Yn(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "tr", 38)(1, "td", 39), e.\u0275\u0275text(2), e.\u0275\u0275elementEnd()()), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit, i = e.\u0275\u0275nextContext(5);
    e.\u0275\u0275advance(), e.\u0275\u0275attribute("colspan", i.renderedColumnCount()), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate(t.node.status);
} }
function Zn(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "tr", 40), e.\u0275\u0275repeaterCreate(1, Un, 6, 9, "td", 29, y), e.\u0275\u0275conditionalCreate(3, Jn, 2, 1, "td", 19), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(4, Yn, 3, 2, "tr", 38)), n & 2) {
    let t = a.$implicit, i = e.\u0275\u0275nextContext(5);
    e.\u0275\u0275attribute("data-state", t.node.state ?? null), e.\u0275\u0275advance(), e.\u0275\u0275repeater(i.columns()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(i.showActions() ? 3 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(i.isTreeNodeExpanded(t.key) && t.node.status ? 4 : -1);
} }
function Xn(n, a) { if (n & 1 && (e.\u0275\u0275conditionalCreate(0, jn, 3, 2, "tr", 38), e.\u0275\u0275repeaterCreate(1, Zn, 5, 3, null, null, y)), n & 2) {
    let t, i = e.\u0275\u0275nextContext(3).$implicit, o = e.\u0275\u0275nextContext();
    e.\u0275\u0275conditional((t = o.rowChildrenStatus()(i)) ? 0 : -1, t), e.\u0275\u0275advance(), e.\u0275\u0275repeater(o.visibleTreeRows().get(o.rowKey()(i)) ?? e.\u0275\u0275pureFunction0(1, ie));
} }
function ei(n, a) { if (n & 1 && e.\u0275\u0275conditionalCreate(0, Xn, 3, 2), n & 2) {
    let t = e.\u0275\u0275nextContext(2).$implicit, i = e.\u0275\u0275nextContext();
    e.\u0275\u0275conditional(i.isRowExpanded(t) ? 0 : -1);
} }
function ti(n, a) { if (n & 1 && e.\u0275\u0275elementContainer(0, 14), n & 2) {
    let t = e.\u0275\u0275nextContext(3).$implicit, i = e.\u0275\u0275nextContext();
    e.\u0275\u0275property("ngTemplateOutlet", a.template)("ngTemplateOutletContext", e.\u0275\u0275pureFunction3(2, oe, t, t, i.renderedColumnCount()));
} }
function ni(n, a) { if (n & 1 && e.\u0275\u0275conditionalCreate(0, ti, 1, 6, "ng-container", 14), n & 2) {
    let t, i = e.\u0275\u0275nextContext(3);
    e.\u0275\u0275conditional((t = i.rowDetailsTemplate()) ? 0 : -1, t);
} }
function ii(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "tr"), e.\u0275\u0275repeaterCreate(1, Rn, 6, 7, "td", 29, y), e.\u0275\u0275conditionalCreate(3, Kn, 3, 1, "td", 19), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(4, ei, 1, 1)(5, ni, 1, 1)), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit, i = e.\u0275\u0275nextContext();
    e.\u0275\u0275attribute("data-state", i.rowState()(t)), e.\u0275\u0275advance(), e.\u0275\u0275repeater(i.columns()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(i.showActions() ? 3 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(i.rowChildren() ? 4 : 5);
} }
function oi(n, a) { if (n & 1 && e.\u0275\u0275conditionalCreate(0, zn, 4, 3, "tr", 26)(1, ii, 6, 3), n & 2) {
    let t = a.$implicit, i = e.\u0275\u0275nextContext();
    e.\u0275\u0275conditional(i.isEditingRow(t) ? 0 : 1);
} }
function ai(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "tr")(1, "td", 41), e.\u0275\u0275text(2), e.\u0275\u0275elementEnd()()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275attribute("colspan", t.columns().length + (t.showActions() ? 1 : 0)), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.emptyText(), " ");
} }
function ri(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "tr", 42, 2), e.\u0275\u0275listener("keydown", function (o) { e.\u0275\u0275restoreView(t); let d = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(d.handleDraftKeydown(o)); }), e.\u0275\u0275elementContainer(2, 28)(3, 28), e.\u0275\u0275elementEnd();
} if (n & 2) {
    e.\u0275\u0275nextContext();
    let t = e.\u0275\u0275reference(2), i = e.\u0275\u0275reference(4);
    e.\u0275\u0275advance(2), e.\u0275\u0275property("ngTemplateOutlet", t), e.\u0275\u0275advance(), e.\u0275\u0275property("ngTemplateOutlet", i);
} }
function di(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "tr")(1, "td", 43), e.\u0275\u0275text(2), e.\u0275\u0275elementEnd()()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275attribute("colspan", t.columns().length + (t.showActions() ? 1 : 0)), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.tableError(), " ");
} }
var V = (n, a) => ({ $implicit: n, label: a }), ae = n => ({ $implicit: n });
function li(n, a) { if (n & 1 && e.\u0275\u0275element(0, "img", 4), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275property("src", t.logoSrc(), e.\u0275\u0275sanitizeUrl)("alt", t.logoAlt());
} }
function ci(n, a) { if (n & 1 && e.\u0275\u0275element(0, "img", 4), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275property("src", t.compactLogoSrc(), e.\u0275\u0275sanitizeUrl)("alt", t.logoAlt());
} }
function si(n, a) { if (n & 1 && e.\u0275\u0275elementContainer(0, 12), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit;
    e.\u0275\u0275property("ngTemplateOutlet", a)("ngTemplateOutletContext", e.\u0275\u0275pureFunction2(2, V, t.icon, t.label));
} }
function pi(n, a) { if (n & 1 && e.\u0275\u0275element(0, "app-hub-icon", 13), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit;
    e.\u0275\u0275property("name", t.icon);
} }
function ui(n, a) { n & 1 && (e.\u0275\u0275elementStart(0, "span", 15), e.\u0275\u0275element(1, "app-hub-icon", 16), e.\u0275\u0275elementEnd()); }
function _i(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "span", 14), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(2, ui, 2, 0, "span", 15)), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit;
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.label, " "), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.categories.length > 0 ? 2 : -1);
} }
function mi(n, a) { if (n & 1 && e.\u0275\u0275elementContainer(0, 12), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit;
    e.\u0275\u0275nextContext();
    let i = e.\u0275\u0275reference(11);
    e.\u0275\u0275property("ngTemplateOutlet", i)("ngTemplateOutletContext", e.\u0275\u0275pureFunction1(2, ae, t));
} }
function xi(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "li", 9)(1, "button", 10), e.\u0275\u0275listener("click", function () { let o = e.\u0275\u0275restoreView(t).$implicit, d = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(d.toggleModule(o)); })("mouseenter", function () { let o = e.\u0275\u0275restoreView(t).$implicit, d = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(d.openFlyout(o)); }), e.\u0275\u0275elementStart(2, "span", 11), e.\u0275\u0275conditionalCreate(3, si, 1, 5, "ng-container", 12)(4, pi, 1, 1, "app-hub-icon", 13), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(5, _i, 3, 2), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(6, mi, 1, 4, "ng-container", 12), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t, i = a.$implicit, o = e.\u0275\u0275nextContext();
    e.\u0275\u0275classProp("is-expanded", o.isModuleExpanded(i)), e.\u0275\u0275advance(), e.\u0275\u0275classProp("is-active", o.isModuleActive(i)), e.\u0275\u0275attribute("aria-expanded", i.categories.length > 0 ? o.isModuleExpanded(i) : null), e.\u0275\u0275advance(2), e.\u0275\u0275conditional((t = o.iconTemplate()) ? 3 : 4, t), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.collapsed() ? -1 : 5), e.\u0275\u0275advance(), e.\u0275\u0275conditional(!o.collapsed() && i.categories.length > 0 && o.isModuleExpanded(i) ? 6 : -1);
} }
function gi(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "section", 17), e.\u0275\u0275listener("mouseenter", function () { let o = e.\u0275\u0275restoreView(t), d = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(d.openFlyout(o)); }), e.\u0275\u0275elementStart(1, "strong", 18), e.\u0275\u0275text(2), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementContainer(3, 12), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = a;
    e.\u0275\u0275nextContext();
    let i = e.\u0275\u0275reference(11);
    e.\u0275\u0275attribute("aria-label", t.label), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate(t.label), e.\u0275\u0275advance(), e.\u0275\u0275property("ngTemplateOutlet", i)("ngTemplateOutletContext", e.\u0275\u0275pureFunction1(4, ae, t));
} }
function bi(n, a) { if (n & 1 && e.\u0275\u0275elementContainer(0, 12), n & 2) {
    let t = e.\u0275\u0275nextContext(2).$implicit;
    e.\u0275\u0275property("ngTemplateOutlet", a)("ngTemplateOutletContext", e.\u0275\u0275pureFunction2(2, V, t.icon, t.label));
} }
function fi(n, a) { if (n & 1 && e.\u0275\u0275element(0, "app-hub-icon", 13), n & 2) {
    let t = e.\u0275\u0275nextContext(2).$implicit;
    e.\u0275\u0275property("name", t.icon);
} }
function hi(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "span", 24), e.\u0275\u0275conditionalCreate(1, bi, 1, 5, "ng-container", 12)(2, fi, 1, 1, "app-hub-icon", 13), e.\u0275\u0275elementEnd()), n & 2) {
    let t, i = e.\u0275\u0275nextContext(3);
    e.\u0275\u0275advance(), e.\u0275\u0275conditional((t = i.iconTemplate()) ? 1 : 2, t);
} }
function vi(n, a) { if (n & 1 && e.\u0275\u0275elementContainer(0, 12), n & 2) {
    let t = e.\u0275\u0275nextContext(2).$implicit;
    e.\u0275\u0275property("ngTemplateOutlet", a)("ngTemplateOutletContext", e.\u0275\u0275pureFunction2(2, V, t.icon, t.label));
} }
function Ci(n, a) { if (n & 1 && e.\u0275\u0275element(0, "app-hub-icon", 13), n & 2) {
    let t = e.\u0275\u0275nextContext(2).$implicit;
    e.\u0275\u0275property("name", t.icon);
} }
function yi(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "span", 29), e.\u0275\u0275conditionalCreate(1, vi, 1, 5, "ng-container", 12)(2, Ci, 1, 1, "app-hub-icon", 13), e.\u0275\u0275elementEnd()), n & 2) {
    let t, i = e.\u0275\u0275nextContext(5);
    e.\u0275\u0275advance(), e.\u0275\u0275conditional((t = i.iconTemplate()) ? 1 : 2, t);
} }
function Mi(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "li")(1, "button", 28), e.\u0275\u0275listener("click", function () { let o = e.\u0275\u0275restoreView(t).$implicit, d = e.\u0275\u0275nextContext(2).$implicit, l = e.\u0275\u0275nextContext().$implicit, c = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(c.selectFeature(l, d, o)); }), e.\u0275\u0275conditionalCreate(2, yi, 3, 1, "span", 29), e.\u0275\u0275elementStart(3, "span", 30), e.\u0275\u0275text(4), e.\u0275\u0275elementEnd()()();
} if (n & 2) {
    let t = a.$implicit, i = e.\u0275\u0275nextContext(4);
    e.\u0275\u0275advance(), e.\u0275\u0275classProp("is-active", i.isFeatureActive(t)), e.\u0275\u0275property("disabled", t.disabled), e.\u0275\u0275attribute("aria-current", i.isFeatureActive(t) ? "page" : null), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.icon ? 2 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate1(" ", t.label, " ");
} }
function wi(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "ul", 27), e.\u0275\u0275repeaterCreate(1, Mi, 5, 6, "li", null, e.\u0275\u0275componentInstance().trackFeature, !0), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit;
    e.\u0275\u0275advance(), e.\u0275\u0275repeater(t.features);
} }
function Di(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "li", 21)(1, "button", 22), e.\u0275\u0275listener("click", function () { let o = e.\u0275\u0275restoreView(t).$implicit, d = e.\u0275\u0275nextContext().$implicit, l = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(l.toggleCategory(d, o)); }), e.\u0275\u0275elementStart(2, "span", 23), e.\u0275\u0275conditionalCreate(3, hi, 3, 1, "span", 24), e.\u0275\u0275elementStart(4, "span", 25), e.\u0275\u0275text(5), e.\u0275\u0275elementEnd()(), e.\u0275\u0275elementStart(6, "span", 26), e.\u0275\u0275element(7, "app-hub-icon", 16), e.\u0275\u0275elementEnd()(), e.\u0275\u0275conditionalCreate(8, wi, 3, 0, "ul", 27), e.\u0275\u0275elementEnd();
} if (n & 2) {
    let t = a.$implicit, i = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275classProp("is-expanded", i.isCategoryExpanded(t)), e.\u0275\u0275advance(), e.\u0275\u0275attribute("aria-expanded", i.isCategoryExpanded(t)), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(t.icon ? 3 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate1(" ", t.label, " "), e.\u0275\u0275advance(3), e.\u0275\u0275conditional(i.isCategoryExpanded(t) ? 8 : -1);
} }
function Pi(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "ul", 19), e.\u0275\u0275repeaterCreate(1, Di, 9, 6, "li", 20, e.\u0275\u0275componentInstance().trackCategory, !0), e.\u0275\u0275elementEnd()), n & 2) {
    let t = a.$implicit;
    e.\u0275\u0275advance(), e.\u0275\u0275repeater(t.categories);
} }
var Oi = ["textareaElement"];
function Ei(n, a) { n & 1 && (e.\u0275\u0275domElementStart(0, "span", 5), e.\u0275\u0275text(1, " * "), e.\u0275\u0275domElementEnd()); }
function Ti(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "label", 2), e.\u0275\u0275text(1), e.\u0275\u0275conditionalCreate(2, Ei, 2, 0, "span", 5), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275domProperty("htmlFor", t.resolvedTextareaId), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.label(), " "), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.required() ? 2 : -1);
} }
function Si(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "p", 6), e.\u0275\u0275text(1), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = a.$implicit;
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate1(" ", t.message, " ");
} }
function ki(n, a) { if (n & 1 && (e.\u0275\u0275domElementStart(0, "div", 4), e.\u0275\u0275repeaterCreate(1, Si, 2, 1, "p", 6, e.\u0275\u0275repeaterTrackByIndex), e.\u0275\u0275domElementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(), e.\u0275\u0275repeater(t.errors());
} }
var Ni = [[["", "drxSidenavHeader", ""]], "*", [["", "drxSidenavFooter", ""]]], Fi = ["[drxSidenavHeader]", "*", "[drxSidenavFooter]"];
function Ii(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "p"), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(2);
    e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate(t.subtitle());
} }
function Ai(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "div", 5)(1, "h2"), e.\u0275\u0275text(2), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(3, Ii, 2, 1, "p"), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext();
    e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate(t.title()), e.\u0275\u0275advance(), e.\u0275\u0275conditional(t.subtitle() ? 3 : -1);
} }
function zi(n, a) { if (n & 1) {
    let t = e.\u0275\u0275getCurrentView();
    e.\u0275\u0275elementStart(0, "button", 9), e.\u0275\u0275listener("click", function () { e.\u0275\u0275restoreView(t); let o = e.\u0275\u0275nextContext(); return e.\u0275\u0275resetView(o.requestClose("button")); }), e.\u0275\u0275element(1, "app-hub-icon", 10), e.\u0275\u0275elementEnd();
} }
function Li(n, a) { n & 1 && (e.\u0275\u0275elementStart(0, "span", 3), e.\u0275\u0275text(1, "/"), e.\u0275\u0275elementEnd()); }
function $i(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "a", 4), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext().$implicit;
    e.\u0275\u0275property("routerLink", t.route), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate(t.label);
} }
function Vi(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "span"), e.\u0275\u0275text(1), e.\u0275\u0275elementEnd()), n & 2) {
    let t = e.\u0275\u0275nextContext(), i = t.$implicit, o = t.$index, d = t.$count;
    e.\u0275\u0275classProp("drx-breadcrumb__current", o === d - 1), e.\u0275\u0275attribute("aria-current", o === d - 1 ? "page" : null), e.\u0275\u0275advance(), e.\u0275\u0275textInterpolate(i.label);
} }
function Ri(n, a) { if (n & 1 && (e.\u0275\u0275elementStart(0, "li", 2), e.\u0275\u0275conditionalCreate(1, Li, 2, 0, "span", 3), e.\u0275\u0275conditionalCreate(2, $i, 2, 2, "a", 4)(3, Vi, 2, 4, "span", 5), e.\u0275\u0275elementEnd()), n & 2) {
    let t = a.$implicit, i = a.$index, o = a.$count;
    e.\u0275\u0275advance(), e.\u0275\u0275conditional(i !== 0 ? 1 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(i !== o - 1 && t.route ? 2 : 3);
} }
var mo = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-ui"]], decls: 2, vars: 0, template: function (i, o) { i & 1 && (e.\u0275\u0275domElementStart(0, "p"), e.\u0275\u0275text(1, "ui works!"), e.\u0275\u0275domElementEnd()); }, encapsulation: 2 });
} return n; })(), Q = L.LucideCircleHelp, qi = { dashboard: "layout-grid", grid_view: "layout-grid", "lucide-layout": "layout-grid", proposta: "file-text", description: "file-text", article: "file-text", po: "file-text", request_quote: "file-text", obra: "building-2", engineering: "building-2", business: "building-2", financeiro: "wallet", payments: "wallet", relatorio: "chart-bar", user_profile: "user", admin: "settings", admin_panel_settings: "shield-check", favorito: "star", "eye-outline": "eye", "trash-outline": "trash", "send-outline": "send", tune: "sliders-horizontal", calculate: "calculator" };
function R(n) { return n.trim().replace(/^Lucide/, "lucide-").replace(/([a-z0-9])([A-Z])/g, "$1-$2").replace(/([A-Z])([A-Z][a-z])/g, "$1-$2").replace(/[\s_]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "").toLowerCase(); }
function Bi(n) { if (typeof n != "function")
    return !1; let a = n; return typeof a.icon == "object" && a.icon !== null && typeof a.icon.name == "string" && a.icon.name.length > 0; }
function k(n, a, t) { let i = R(a); i && (n[i] = t); }
function Ki() { let n = {}; for (let [a, t] of Object.entries(L)) {
    if (!a.startsWith("Lucide") || !Bi(t))
        continue;
    let i = t, o = t.icon?.name, d = a.slice(6);
    o && k(n, o, i), k(n, d, i), k(n, a, i);
} return n; }
var W = Ki();
function ji() { let n = Object.entries(qi).reduce((a, [t, i]) => { let o = W[R(i)]; return o && k(a, t, o), a; }, {}); return w(w({}, n), W); }
var Hi = Object.freeze(ji());
function Qi(n) { if (!n)
    return Q; let a = R(n); return Hi[a] ?? Q; }
var v = (() => { class n {
    name = r(null);
    action = r(!1, { transform: xe });
    iconComponent = u(() => Qi(this.name()));
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["app-hub-icon"]], hostVars: 2, hostBindings: function (i, o) { i & 2 && e.\u0275\u0275classProp("cursor-pointer", o.action()); }, inputs: { name: [1, "name"], action: [1, "action"] }, decls: 1, vars: 1, consts: [[4, "ngComponentOutlet"]], template: function (i, o) { i & 1 && e.\u0275\u0275template(0, De, 1, 0, "ng-container", 0), i & 2 && e.\u0275\u0275property("ngComponentOutlet", o.iconComponent()); }, dependencies: [ge], styles: ["[_nghost-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:var(--hub-icon-size, 24px);height:var(--hub-icon-size, 24px);color:inherit;line-height:0;flex-shrink:0}.cursor-pointer[_nghost-%COMP%]{cursor:pointer}[_nghost-%COMP%]     svg{width:var(--hub-icon-size, 24px)!important;height:var(--hub-icon-size, 24px)!important;min-width:var(--hub-icon-size, 24px);min-height:var(--hub-icon-size, 24px);stroke:currentColor}.is-filled[_nghost-%COMP%]{color:#f4b400}.is-filled[_nghost-%COMP%]     svg{fill:currentColor}"] });
} return n; })(), xo = (() => { class n {
    size = r("medium");
    moduloColor = r("#c00d0e");
    icon = r(null);
    title = r("");
    description = r("");
    platform = r([]);
    favorite = C(!1);
    favoritable = r(!0);
    navigable = r(!1);
    cardClasses = u(() => ["drx-card", `drx-card--${this.size()}`].join(" "));
    navigate = p();
    onFavoriteClick(t) { t.stopPropagation(), this.favorite.update(i => !i); }
    onNavigateClick(t) { t.stopPropagation(), this.navigable() && this.navigate.emit(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-card"]], inputs: { size: [1, "size"], moduloColor: [1, "moduloColor"], icon: [1, "icon"], title: [1, "title"], description: [1, "description"], platform: [1, "platform"], favorite: [1, "favorite"], favoritable: [1, "favoritable"], navigable: [1, "navigable"] }, outputs: { favorite: "favoriteChange", navigate: "navigate" }, ngContentSelectors: $, decls: 3, vars: 7, consts: [[1, "card-title-wrapper"], [3, "name"], [1, "card-content"], [1, "card-title", "drx-font-family-heading"], [1, "drx-card--font-gothic", "drx-card--subtitle-sm", "drx-card--body-md"], [1, "chip-platform-wrapper"], [1, "card-description", "drx-card--body-md"], ["type", "button", 1, "card-favorite", 3, "card-favorite--active", "title"], ["type", "button", "aria-label", "Abrir", "title", "Abrir", 1, "card-navigation"], [1, "chip-item"], [1, "drx-button--font-quicksand"], ["type", "button", 1, "card-favorite", 3, "click", "title"], ["name", "favorito", "action", ""], ["type", "button", "aria-label", "Abrir", "title", "Abrir", 1, "card-navigation", 3, "click"], ["name", "chevron-right", "action", ""]], template: function (i, o) { i & 1 && (e.\u0275\u0275projectionDef(), e.\u0275\u0275elementStart(0, "div"), e.\u0275\u0275conditionalCreate(1, ke, 10, 6, "div", 0)(2, Ne, 1, 0), e.\u0275\u0275elementEnd()), i & 2 && (e.\u0275\u0275classMap(o.cardClasses()), e.\u0275\u0275styleProp("--module-color", o.moduloColor()), e.\u0275\u0275classProp("card-routing-navigate", o.favoritable()), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.title() ? 1 : 2)); }, dependencies: [v], styles: [".drx-card[_ngcontent-%COMP%]{min-width:0;min-height:130px;display:flex;flex-direction:column;padding:16px;background:var(--ex-gray-scale-100, #ffffff);border:1px solid var(--ex-gray-scale-400);border-radius:8px;box-shadow:0 2px 8px #2528310f;transition:border-color .16s ease,box-shadow .16s ease,transform .16s ease}.drx-card[_ngcontent-%COMP%]:hover{border-color:var(--ex-gray-scale-500);box-shadow:0 8px 22px #25283117;transform:translateY(-1px)}.drx-card.drx-card--small[_ngcontent-%COMP%]{min-height:32px}.drx-card.drx-card--large[_ngcontent-%COMP%]{min-height:260px}.card-title-wrapper[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;min-height:inherit}app-hub-icon[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;padding:9px;flex-shrink:0;color:var(--module-color, #c00d0e);background-color:color-mix(in srgb,var(--module-color, #c00d0e) 12%,transparent);border-radius:50%;--hub-icon-size: 22px}.card-content[_ngcontent-%COMP%]{min-width:0;flex:1;display:flex;flex-direction:column;gap:4px}.card-title[_ngcontent-%COMP%]{color:var(--drx-color-heading, #252831)}.card-description[_ngcontent-%COMP%]{margin:0;color:var(--drx-color-text-secondary, #687083)}.chip-platform-wrapper[_ngcontent-%COMP%]{display:flex;justify-content:flex-start;align-items:center;width:100%;gap:8px}.chip-platform-wrapper[_ngcontent-%COMP%]   .chip-item[_ngcontent-%COMP%]{padding:4px;min-width:40px;text-align:center;background-color:var(--drx-gray-200);border-radius:25px;font-size:12px}.drx-card--title-sm[_ngcontent-%COMP%]{font-size:var(--drx-button-font-size, var(--drx-font-size-subtitle-sm));font-weight:var(--drx-button-font-weight, var(--drx-font-weight-semibold));line-height:var(--drx-button-line-height, var(--drx-line-height-tight))}.drx-card--font-quicksand[_ngcontent-%COMP%]{font-family:var(--drx-font-family-base)}.drx-card--font-gothic[_ngcontent-%COMP%]{font-family:var(--drx-font-family-display)}.drx-card--body-md[_ngcontent-%COMP%]{font-size:var(--drx-font-size-body-sm)}.card-favorite[_ngcontent-%COMP%]{margin-left:auto;margin-bottom:auto;width:30px;height:30px;display:flex;align-items:center;justify-content:center;flex:0 0 auto;color:#f5b400;border-radius:50%;cursor:pointer}.card-favorite[_ngcontent-%COMP%]   app-hub-icon[_ngcontent-%COMP%]{--hub-icon-size: 14px;color:unset;background-color:unset}.card-favorite[_ngcontent-%COMP%]:hover{background:#f5b4001a}.card-favorite--active[_ngcontent-%COMP%]{background:#f5b40014}.card-navigation[_ngcontent-%COMP%]{margin-left:auto;width:40px;height:40px;display:flex;align-items:center;justify-content:center;flex:0 0 auto;border-radius:50%;cursor:pointer;background:unset}.card-navigation[_ngcontent-%COMP%]   app-hub-icon[_ngcontent-%COMP%]{--hub-icon-size: 24px;color:var(--drx-brand-dark);background-color:unset}.card-routing-navigate[_ngcontent-%COMP%]{cursor:pointer}"] });
} return n; })(), go = (() => { class n {
    modulos = r([]);
    children = r([]);
    nome = r("");
    icone = r("");
    rota = r("");
    color = r("");
    routing = r();
    headerClickable = r(!1);
    showFooter = r(!1);
    textFooter = r("Ver todos");
    contentVariant = r("plain");
    minHeight = r(null);
    headerAction = p();
    footerAction = p();
    router = M(be);
    cardSquareText = () => { this.children.length > 0; };
    iconColor(t) { return t?.trim(); }
    handleHeaderAction() { this.headerClickable() && this.headerAction.emit(); }
    handleFooterAction() { this.footerAction.emit(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-card-square"]], inputs: { modulos: [1, "modulos"], children: [1, "children"], nome: [1, "nome"], icone: [1, "icone"], rota: [1, "rota"], color: [1, "color"], routing: [1, "routing"], headerClickable: [1, "headerClickable"], showFooter: [1, "showFooter"], textFooter: [1, "textFooter"], contentVariant: [1, "contentVariant"], minHeight: [1, "minHeight"] }, outputs: { headerAction: "headerAction", footerAction: "footerAction" }, ngContentSelectors: Ie, decls: 9, vars: 10, consts: [[1, "card"], [1, "card__header"], ["type", "button", 1, "card__module", "card__module--clickable"], [1, "card__module"], [1, "card__header-actions"], [1, "card__content"], [1, "card__footer"], ["type", "button", 1, "card__module", "card__module--clickable", 3, "click"], [1, "card__module-icon", 3, "--module-icon-color"], [1, "card__module-info"], [1, "quicksand-m", "bolder-font"], [1, "card__module-icon"], [3, "name"], ["type", "button", 1, "card__footer-action", "quicksand-sm", "bolder-font", 3, "click"], ["aria-hidden", "true"]], template: function (i, o) { i & 1 && (e.\u0275\u0275projectionDef(Fe), e.\u0275\u0275elementStart(0, "article", 0)(1, "header", 1), e.\u0275\u0275conditionalCreate(2, ze, 5, 2, "button", 2)(3, $e, 5, 2, "div", 3), e.\u0275\u0275elementStart(4, "div", 4), e.\u0275\u0275projection(5), e.\u0275\u0275elementEnd()(), e.\u0275\u0275elementStart(6, "div", 5), e.\u0275\u0275projection(7, 1), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(8, Ve, 5, 1, "footer", 6), e.\u0275\u0275elementEnd()), i & 2 && (e.\u0275\u0275styleProp("min-height", o.minHeight()), e.\u0275\u0275classProp("card--interactive", o.headerClickable() || o.showFooter()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.headerClickable() ? 2 : 3), e.\u0275\u0275advance(4), e.\u0275\u0275classProp("card__content--outlined", o.contentVariant() === "outlined")("card__content--soft", o.contentVariant() === "soft"), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.showFooter() ? 8 : -1)); }, dependencies: [v], styles: ['@charset "UTF-8";[_nghost-%COMP%]{display:block;width:100%;min-width:0}.card[_ngcontent-%COMP%]{width:100%;min-width:0;min-height:inherit;display:flex;flex-direction:column;padding:16px;background:var(--ex-gray-scale-100, #ffffff);border:1px solid var(--ex-gray-scale-400);border-radius:8px;box-shadow:0 2px 8px #2528310f;transition:border-color .16s ease,box-shadow .16s ease,transform .16s ease}.card--interactive[_ngcontent-%COMP%]:hover{border-color:var(--ex-gray-scale-500);box-shadow:0 8px 22px #25283117;transform:translateY(-1px)}.card__header[_ngcontent-%COMP%]{width:100%;display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.card__module[_ngcontent-%COMP%]{flex:1;min-width:0;display:grid;grid-template-columns:auto minmax(0,1fr);align-items:center;gap:10px;padding:0;color:inherit;text-align:left;border:0;border-radius:6px;background:transparent}.card__module--clickable[_ngcontent-%COMP%]{cursor:pointer}.card__module--clickable[_ngcontent-%COMP%]:hover   .card__module-info[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--drx-red-base)}.card__module--clickable[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--drx-red-base);outline-offset:4px}.card__module-icon[_ngcontent-%COMP%]{width:42px;height:42px;display:flex;align-items:center;justify-content:center;flex-shrink:0;color:var(--module-icon-color, var(--drx-red-base));background:color-mix(in srgb,var(--module-icon-color, var(--drx-red-base)) 10%,transparent);border-radius:50%}.card__module-icon[_ngcontent-%COMP%]   app-hub-icon[_ngcontent-%COMP%]{--hub-icon-size: 24px}.card__module-info[_ngcontent-%COMP%]{min-width:0;display:flex;flex-direction:column;gap:3px}.card__module-info[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{display:block;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;transition:color .14s ease}.card__header-actions[_ngcontent-%COMP%]{display:flex;align-items:center;flex:0 0 auto;gap:4px}.card__header-actions[_ngcontent-%COMP%]:empty{display:none}.card__content[_ngcontent-%COMP%]{min-width:0;margin-top:16px}.card__content--outlined[_ngcontent-%COMP%]{padding:8px;border:1px solid var(--ex-gray-scale-400);border-radius:10px}.card__content--soft[_ngcontent-%COMP%]{padding:12px;background:var(--ex-gray-scale-200);border-radius:10px}.card__footer[_ngcontent-%COMP%]{margin-top:auto;padding-top:14px}.card__footer-action[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:5px;padding:0;color:var(--drx-red-base);border:0;background:transparent;border-radius:3px;cursor:pointer}.card__footer-action[_ngcontent-%COMP%]:hover{text-decoration:underline}.card__footer-action[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--drx-red-base);outline-offset:3px}'] });
} return n; })(), bo = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-card-list"]], ngContentSelectors: $, decls: 2, vars: 0, consts: [[1, "card-list"]], template: function (i, o) { i & 1 && (e.\u0275\u0275projectionDef(), e.\u0275\u0275domElementStart(0, "div", 0), e.\u0275\u0275projection(1), e.\u0275\u0275domElementEnd()); }, styles: ["[_nghost-%COMP%]{display:block;width:100%}.card-list[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:2px}"], changeDetection: 0 });
} return n; })(), fo = (() => { class n {
    label = r.required();
    clickable = r(!1);
    showArrow = r(!1);
    favoriteEnabled = r(!1);
    favorite = r(!1);
    disabled = r(!1);
    itemClick = p();
    favoriteChange = p();
    handleItemClick() { !this.clickable() || this.disabled() || this.itemClick.emit(); }
    handleFavorite(t) { t.stopPropagation(), !this.disabled() && this.favoriteChange.emit(!this.favorite()); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-card-list-item"]], inputs: { label: [1, "label"], clickable: [1, "clickable"], showArrow: [1, "showArrow"], favoriteEnabled: [1, "favoriteEnabled"], favorite: [1, "favorite"], disabled: [1, "disabled"] }, outputs: { itemClick: "itemClick", favoriteChange: "favoriteChange" }, decls: 4, vars: 6, consts: [[1, "card-list-item"], ["type", "button", 1, "card-list-item__content", 3, "disabled"], [1, "card-list-item__content"], ["type", "button", 1, "card-list-item__favorite", 3, "card-list-item__favorite--active", "disabled"], ["type", "button", 1, "card-list-item__content", 3, "click", "disabled"], ["aria-hidden", "true", 1, "card-list-item__arrow"], [1, "card-list-item__label", "quicksand-m"], ["type", "button", 1, "card-list-item__favorite", 3, "click", "disabled"], ["name", "favorito", "action", ""]], template: function (i, o) { i & 1 && (e.\u0275\u0275elementStart(0, "div", 0), e.\u0275\u0275conditionalCreate(1, qe, 4, 3, "button", 1)(2, Ke, 4, 2, "div", 2), e.\u0275\u0275conditionalCreate(3, je, 2, 7, "button", 3), e.\u0275\u0275elementEnd()), i & 2 && (e.\u0275\u0275classProp("card-list-item--clickable", o.clickable())("card-list-item--disabled", o.disabled()), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.clickable() ? 1 : 2), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.favoriteEnabled() ? 3 : -1)); }, dependencies: [v], styles: ["[_nghost-%COMP%]{display:block;width:100%}.card-list-item[_ngcontent-%COMP%]{width:100%;min-height:32px;display:grid;grid-template-columns:minmax(0,1fr);align-items:center;gap:4px;color:var(--ex-gray-scale-800);border-radius:4px;transition:color .14s ease,background-color .14s ease}.card-list-item[_ngcontent-%COMP%]:has(.card-list-item__favorite){grid-template-columns:minmax(0,1fr) 28px;padding-right:2px}.card-list-item--clickable[_ngcontent-%COMP%]:hover{color:var(--drx-red-base);background:color-mix(in srgb,var(--drx-red-base) 5%,transparent)}.card-list-item--disabled[_ngcontent-%COMP%]{opacity:.55;pointer-events:none}.card-list-item__content[_ngcontent-%COMP%]{width:100%;min-width:0;min-height:32px;display:grid;grid-template-columns:minmax(0,1fr);align-items:center;gap:6px;padding:5px 6px;color:inherit;text-align:left;border:0;border-radius:4px;background:transparent}.card-list-item--clickable[_ngcontent-%COMP%]   .card-list-item__content[_ngcontent-%COMP%]{cursor:pointer}.card-list-item__content[_ngcontent-%COMP%]:has(.card-list-item__arrow){grid-template-columns:12px minmax(0,1fr)}.card-list-item__arrow[_ngcontent-%COMP%]{color:var(--drx-red-base);font-size:20px;line-height:1;padding-bottom:4px}.card-list-item__label[_ngcontent-%COMP%]{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.card-list-item__favorite[_ngcontent-%COMP%]{width:26px;height:26px;display:inline-flex;align-items:center;justify-content:center;padding:0;color:#8b93a3;border:0;border-radius:50%;background:transparent;cursor:pointer}.card-list-item__favorite[_ngcontent-%COMP%]   app-hub-icon[_ngcontent-%COMP%]{--hub-icon-size: 16px}.card-list-item__favorite[_ngcontent-%COMP%]:hover, .card-list-item__favorite--active[_ngcontent-%COMP%]{color:#f5b400;background:#f5b4001a}"], changeDetection: 0 });
} return n; })(), re = (() => { class n {
    variant = r("primary");
    size = r("medium");
    disabled = r(!1);
    type = r("button");
    font = r("quicksand");
    buttonClasses = u(() => { let t = ["drx-button", `drx-button--${this.variant()}`, `drx-button--font-${this.font()}`]; return this.size() === "small" && t.push("drx-button--small"), t.join(" "); });
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-button"]], inputs: { variant: [1, "variant"], size: [1, "size"], disabled: [1, "disabled"], type: [1, "type"], font: [1, "font"] }, ngContentSelectors: $, decls: 2, vars: 4, consts: [[3, "disabled"]], template: function (i, o) { i & 1 && (e.\u0275\u0275projectionDef(), e.\u0275\u0275domElementStart(0, "button", 0), e.\u0275\u0275projection(1), e.\u0275\u0275domElementEnd()), i & 2 && (e.\u0275\u0275classMap(o.buttonClasses()), e.\u0275\u0275domProperty("disabled", o.disabled()), e.\u0275\u0275attribute("type", o.type())); }, styles: [".drx-button[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:var(--drx-button-gap, var(--drx-space-2));min-height:var(--drx-button-height, var(--drx-control-height-md));padding:var(--drx-button-padding-y, var(--drx-space-3)) var(--drx-button-padding-x, var(--drx-space-6));border:var(--drx-button-border-width, 0) solid var(--drx-button-border-color, transparent);border-radius:var(--drx-button-radius, var(--drx-radius-control));font-family:var(--drx-button-font-family, var(--drx-font-family-base));font-size:var(--drx-button-font-size, var(--drx-font-size-body-md));font-weight:var(--drx-button-font-weight, var(--drx-font-weight-semibold));line-height:var(--drx-button-line-height, var(--drx-line-height-tight));text-decoration:none;white-space:nowrap;cursor:pointer;-webkit-user-select:none;user-select:none;transition:background-color .2s ease-in-out,color .2s ease-in-out,border-color .2s ease-in-out,opacity .2s ease-in-out}.drx-button[_ngcontent-%COMP%]:disabled, .drx-button[aria-disabled=true][_ngcontent-%COMP%]{opacity:var(--drx-button-disabled-opacity, .6);cursor:not-allowed;pointer-events:none}.drx-button--font-quicksand[_ngcontent-%COMP%]{font-family:var(--drx-font-family-base)}.drx-button--font-gothic[_ngcontent-%COMP%]{font-family:var(--drx-font-family-display)}.drx-button--font-raleway[_ngcontent-%COMP%]{font-family:var(--drx-font-family-heading)}.drx-button--primary[_ngcontent-%COMP%]{background:var(--drx-button-primary-bg, var(--drx-color-primary));color:var(--drx-button-primary-color, var(--drx-color-primary-contrast))}.drx-button--primary[_ngcontent-%COMP%]:hover:not(:disabled):not([aria-disabled=true]){background:var(--drx-button-primary-bg-hover, var(--drx-color-primary-hover));color:var(--drx-button-primary-color-hover, var(--drx-color-primary-contrast))}.drx-button--secondary[_ngcontent-%COMP%]{background:var(--drx-button-secondary-bg, var(--drx-color-surface-muted));color:var(--drx-button-secondary-color, var(--drx-color-text-muted));border-color:var(--drx-button-secondary-border-color, var(--drx-color-border-subtle))}.drx-button--secondary[_ngcontent-%COMP%]:hover:not(:disabled):not([aria-disabled=true]){background:var(--drx-button-secondary-bg-hover, var(--drx-color-surface-subtle));color:var(--drx-button-secondary-color-hover, var(--drx-color-text-default));border-color:var(--drx-button-secondary-border-color-hover, var(--drx-color-border-default))}.drx-button--tertiary[_ngcontent-%COMP%]{background:var(--drx-button-tertiary-bg, transparent);color:var(--drx-button-tertiary-color, var(--drx-color-primary));border-color:transparent}.drx-button--tertiary[_ngcontent-%COMP%]:hover:not(:disabled):not([aria-disabled=true]){background:var(--drx-button-tertiary-bg-hover, var(--drx-color-primary-soft));color:var(--drx-button-tertiary-color-hover, var(--drx-color-primary-hover))}.drx-button--small[_ngcontent-%COMP%]{min-height:var(--drx-button-small-height, var(--drx-control-height-sm));padding:var(--drx-button-small-padding-y, var(--drx-space-1)) var(--drx-button-small-padding-x, var(--drx-space-4));font-size:var(--drx-button-small-font-size, var(--drx-font-size-body-sm))}.drx-button--full[_ngcontent-%COMP%]{width:100%}"] });
} return n; })(), Wi = 0, ho = (() => { class n {
    destroyRef = M(X);
    value = C(null);
    disabled = r(!1);
    required = r(!1);
    invalid = r(!1);
    errors = r([]);
    touch = p();
    hasBeenTouched = g(!1);
    hasFocus = g(!1);
    showValidation = u(() => this.hasBeenTouched() && this.invalid());
    label = r("Buscar");
    placeholder = r("Digite para buscar...");
    hint = r("");
    minimumSearchLength = r(3);
    debounceMs = r(300);
    pageSize = r(20);
    loadMoreThreshold = r(64);
    maxDropdownHeight = r(280);
    dropdownGap = r(6);
    viewportPadding = r(8);
    emptyText = r("Nenhum resultado encontrado.");
    loadingText = r("Buscando...");
    loadingMoreText = r("Carregando mais resultados...");
    loadMoreErrorText = r("N\xE3o foi poss\xEDvel carregar mais resultados.");
    retryText = r("Tentar novamente");
    errorText = r("N\xE3o foi poss\xEDvel realizar a busca.");
    clearable = r(!0);
    allowFreeText = r(!1);
    search = r.required();
    displayWith = r(t => String(t));
    secondaryText = r(() => "");
    identifyBy = r(t => String(t));
    selected = p();
    cleared = p();
    freeTextChange = p();
    searchFailed = p();
    results = g([]);
    loading = g(!1);
    loadingMore = g(!1);
    hasMore = g(!1);
    currentPage = g(0);
    opened = g(!1);
    searchError = g(null);
    loadMoreError = g(null);
    activeIndex = g(-1);
    inputId = `drx-autocomplete-${Wi++}`;
    listboxId = `${this.inputId}-listbox`;
    query = E(() => { let t = this.value(); return t ? this.displayWith()(t) : ""; });
    inputElement = D("searchInput");
    dropdownElement = D("dropdown");
    searchTerms$ = new N;
    nextPage$ = new N;
    overlayFrame = null;
    viewportListenersAttached = !1;
    popoverOpened = !1;
    portaledDropdown = null;
    dropdownOriginParent = null;
    dropdownOriginNextSibling = null;
    handleViewportChange = () => { this.opened() && this.scheduleDropdownPosition(); };
    constructor() { this.configureSearch(), this.destroyRef.onDestroy(() => { this.detachViewportListeners(), this.cancelScheduledDropdownPosition(), this.hideDropdownPopover(!1); }); }
    focus(t) { this.inputElement()?.nativeElement.focus(t); }
    reset() { this.hasBeenTouched.set(!1), this.hasFocus.set(!1), this.value.set(null), this.query.set(""), this.resetSearchState(), this.searchTerms$.next(""); }
    handleInput(t) { let o = t.target.value, d = this.query().trim(), c = o.trim() !== d; this.searchError.set(null), this.loadMoreError.set(null); let s = this.value(); s && o !== this.displayWith()(s) && (this.value.set(null), this.cleared.emit()), this.query.set(o), this.allowFreeText() && this.freeTextChange.emit(o), this.hasMinimumSearchLength(o) ? (this.setDropdownOpen(!0), c && (this.results.set([]), this.loading.set(!1), this.loadingMore.set(!1), this.hasMore.set(!1), this.currentPage.set(0), this.activeIndex.set(-1))) : this.resetSearchState(), this.searchTerms$.next(o); }
    handleFocus() { this.hasFocus.set(!0), this.hasMinimumSearchLength(this.query()) && (this.results().length > 0 || this.searchError() || this.currentPage() > 0) && this.setDropdownOpen(!0); }
    handleBlur() { this.hasBeenTouched.set(!0), this.hasFocus.set(!1), this.touch.emit(), setTimeout(() => { this.hasFocus() || this.setDropdownOpen(!1); }, 120); }
    handleKeydown(t) { let i = this.results(); if (t.key === "Escape") {
        t.preventDefault(), this.setDropdownOpen(!1);
        return;
    } if (!(!this.opened() || i.length === 0))
        switch (t.key) {
            case "ArrowDown": {
                if (t.preventDefault(), this.activeIndex() >= i.length - 1 && this.hasMore()) {
                    this.requestNextPage();
                    return;
                }
                this.activeIndex.update(d => (d + 1) % i.length);
                break;
            }
            case "ArrowUp":
                t.preventDefault(), this.activeIndex.update(o => o <= 0 ? i.length - 1 : o - 1);
                break;
            case "Enter": {
                t.preventDefault();
                let o = i[this.activeIndex()];
                o && this.selectOption(o);
                break;
            }
        } }
    handleResultsScroll(t) { let i = t.currentTarget; i.scrollHeight - i.scrollTop - i.clientHeight <= Math.max(0, this.loadMoreThreshold()) && this.requestNextPage(); }
    retryLoadMore(t) { t.preventDefault(), this.requestNextPage(); }
    selectOption(t, i) { i?.preventDefault(), this.value.set(t), this.query.set(this.displayWith()(t)), this.resetSearchState(), this.selected.emit(t); }
    clear(t) { t.preventDefault(), this.reset(), this.cleared.emit(), this.allowFreeText() && this.freeTextChange.emit(""), this.focus(); }
    setActiveIndex(t) { this.activeIndex.set(t); }
    optionIdentifier(t) { return this.identifyBy()(t); }
    activeOptionId() { let t = this.activeIndex(); return t >= 0 ? `${this.inputId}-option-${t}` : null; }
    remainingCharacters() { return Math.max(this.minimumSearchLength() - this.query().trim().length, 0); }
    configureSearch() { let t = this.searchTerms$.pipe(S(o => o.trim()), he(), A(() => z(Math.max(0, this.debounceMs()))), S(o => ({ term: o, page: 1, append: !1 }))), i = this.nextPage$.pipe(S(() => ({ term: this.query().trim(), page: this.currentPage() + 1, append: !0 }))); ve(t, i).pipe(Ce(o => this.executeSearch(o)), I(this.destroyRef)).subscribe(({ request: o, page: d, failed: l }) => { let c = this.query().trim(); if (o.term !== c)
        return; if (l) {
        o.append || (this.results.set([]), this.currentPage.set(0), this.hasMore.set(!1), this.activeIndex.set(-1), this.setDropdownOpen(this.hasFocus() && this.hasMinimumSearchLength(c)));
        return;
    } let s = o.append ? this.mergeUniqueResults(this.results(), d.items) : d.items; this.results.set(s), this.currentPage.set(o.page), this.hasMore.set(d.hasMore), this.setDropdownOpen(this.hasFocus() && this.hasMinimumSearchLength(c)), o.append || this.activeIndex.set(s.length > 0 ? 0 : -1); }); }
    executeSearch(t) { return this.hasMinimumSearchLength(t.term) ? (t.append ? (this.loadingMore.set(!0), this.loadMoreError.set(null)) : (this.loading.set(!0), this.searchError.set(null), this.loadMoreError.set(null), this.currentPage.set(0), this.hasMore.set(!1)), this.search()(t.term, t.page, this.normalizedPageSize()).pipe(ye(1), S(i => ({ request: t, page: this.normalizeResult(i), failed: !1 })), Me(i => (t.append ? this.loadMoreError.set(this.loadMoreErrorText()) : this.searchError.set(this.errorText()), this.searchFailed.emit(i), H({ request: t, page: t.append ? { items: [], hasMore: !0 } : this.emptyPage(), failed: !0 }))), we(() => { t.append ? this.loadingMore.set(!1) : this.loading.set(!1); }))) : H({ request: t, page: this.emptyPage(), failed: !1 }); }
    requestNextPage() { !this.hasMore() || this.loading() || this.loadingMore() || !this.hasMinimumSearchLength(this.query()) || this.nextPage$.next(); }
    setDropdownOpen(t) { if (t === this.opened()) {
        t && this.scheduleDropdownPosition();
        return;
    } if (!t) {
        this.hideDropdownPopover(), this.opened.set(!1), this.detachViewportListeners(), this.cancelScheduledDropdownPosition();
        return;
    } this.opened.set(!0), this.attachViewportListeners(), this.scheduleDropdownPosition(); }
    scheduleDropdownPosition() { this.cancelScheduledDropdownPosition(), !(!this.opened() || typeof requestAnimationFrame > "u") && (this.overlayFrame = requestAnimationFrame(() => { this.overlayFrame = null, this.positionDropdown(); })); }
    cancelScheduledDropdownPosition() { this.overlayFrame === null || typeof cancelAnimationFrame > "u" || (cancelAnimationFrame(this.overlayFrame), this.overlayFrame = null); }
    positionDropdown() { if (!this.opened())
        return; let t = this.inputElement()?.nativeElement, i = this.dropdownElement()?.nativeElement; if (!t || !i)
        return; let o = t.getBoundingClientRect(), d = document.documentElement.clientWidth || window.innerWidth, l = window.innerHeight, c = Math.max(0, this.viewportPadding()), s = Math.max(0, this.dropdownGap()); if (o.bottom <= 0 || o.top >= l || o.right <= 0 || o.left >= d) {
        this.setDropdownOpen(!1);
        return;
    } let m = Math.max(1, this.maxDropdownHeight()), x = Math.max(0, l - o.bottom - s - c), b = Math.max(0, o.top - s - c), h = x < Math.min(m, 160) && b > x, O = Math.max(1, Math.min(m, h ? b : x)), ue = Math.max(1, d - c * 2), q = Math.min(o.width, ue), _e = Math.max(c, d - c - q), me = Math.min(Math.max(o.left, c), _e); i.style.left = `${Math.round(me)}px`, i.style.width = `${Math.round(q)}px`, i.style.maxHeight = `${Math.floor(O)}px`, i.dataset.placement = h ? "top" : "bottom", h ? (i.style.top = "auto", i.style.bottom = `${Math.max(0, Math.round(l - o.top + s))}px`) : (i.style.top = `${Math.max(0, Math.round(o.bottom + s))}px`, i.style.bottom = "auto"), this.showDropdownPopover(i); }
    attachViewportListeners() { this.viewportListenersAttached || typeof window > "u" || (this.viewportListenersAttached = !0, window.addEventListener("resize", this.handleViewportChange, { passive: !0 }), document.addEventListener("scroll", this.handleViewportChange, { capture: !0, passive: !0 }), window.visualViewport?.addEventListener("resize", this.handleViewportChange, { passive: !0 }), window.visualViewport?.addEventListener("scroll", this.handleViewportChange, { passive: !0 })); }
    detachViewportListeners() { !this.viewportListenersAttached || typeof window > "u" || (this.viewportListenersAttached = !1, window.removeEventListener("resize", this.handleViewportChange), document.removeEventListener("scroll", this.handleViewportChange, !0), window.visualViewport?.removeEventListener("resize", this.handleViewportChange), window.visualViewport?.removeEventListener("scroll", this.handleViewportChange)); }
    showDropdownPopover(t) { let i = t; if (!(this.popoverOpened || this.portaledDropdown === t)) {
        if (typeof i.showPopover == "function")
            try {
                i.showPopover(), this.popoverOpened = t.matches(":popover-open");
            }
            catch {
                this.popoverOpened = !1;
            }
        this.popoverOpened || this.attachDropdownToBody(t);
    } }
    hideDropdownPopover(t = !0) { let i = this.dropdownElement()?.nativeElement ?? this.portaledDropdown; if (!i) {
        this.popoverOpened = !1;
        return;
    } if (this.popoverOpened && typeof i.hidePopover == "function")
        try {
            i.hidePopover();
        }
        catch { } this.popoverOpened = !1, this.detachDropdownFromBody(t); }
    attachDropdownToBody(t) { typeof document > "u" || this.portaledDropdown === t || (this.dropdownOriginParent = t.parentNode, this.dropdownOriginNextSibling = t.nextSibling, t.removeAttribute("popover"), document.body.appendChild(t), this.portaledDropdown = t); }
    detachDropdownFromBody(t) { let i = this.portaledDropdown; if (!i)
        return; let o = this.dropdownOriginParent, d = this.dropdownOriginNextSibling; i.setAttribute("popover", "manual"), t && o && o.isConnected ? d?.parentNode === o ? o.insertBefore(i, d) : o.appendChild(i) : i.remove(), this.portaledDropdown = null, this.dropdownOriginParent = null, this.dropdownOriginNextSibling = null; }
    normalizeResult(t) { if (Array.isArray(t))
        return { items: t, hasMore: !1, total: t.length }; let i = t; if (!i || !Array.isArray(i.items))
        throw new TypeError("A busca do autocomplete retornou um formato inv\xE1lido."); return i; }
    mergeUniqueResults(t, i) { let o = new Set(t.map(l => this.identifyBy()(l))), d = i.filter(l => { let c = this.identifyBy()(l); return o.has(c) ? !1 : (o.add(c), !0); }); return [...t, ...d]; }
    resetSearchState() { this.results.set([]), this.loading.set(!1), this.loadingMore.set(!1), this.hasMore.set(!1), this.currentPage.set(0), this.searchError.set(null), this.loadMoreError.set(null), this.activeIndex.set(-1), this.setDropdownOpen(!1); }
    hasMinimumSearchLength(t) { return t.trim().length >= Math.max(0, this.minimumSearchLength()); }
    normalizedPageSize() { return Math.max(1, Math.trunc(this.pageSize())); }
    emptyPage() { return { items: [], hasMore: !1, total: 0 }; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-autocomplete"]], viewQuery: function (i, o) { i & 1 && e.\u0275\u0275viewQuerySignal(o.inputElement, He, 5)(o.dropdownElement, Qe, 5), i & 2 && e.\u0275\u0275queryAdvance(2); }, inputs: { value: [1, "value"], disabled: [1, "disabled"], required: [1, "required"], invalid: [1, "invalid"], errors: [1, "errors"], label: [1, "label"], placeholder: [1, "placeholder"], hint: [1, "hint"], minimumSearchLength: [1, "minimumSearchLength"], debounceMs: [1, "debounceMs"], pageSize: [1, "pageSize"], loadMoreThreshold: [1, "loadMoreThreshold"], maxDropdownHeight: [1, "maxDropdownHeight"], dropdownGap: [1, "dropdownGap"], viewportPadding: [1, "viewportPadding"], emptyText: [1, "emptyText"], loadingText: [1, "loadingText"], loadingMoreText: [1, "loadingMoreText"], loadMoreErrorText: [1, "loadMoreErrorText"], retryText: [1, "retryText"], errorText: [1, "errorText"], clearable: [1, "clearable"], allowFreeText: [1, "allowFreeText"], search: [1, "search"], displayWith: [1, "displayWith"], secondaryText: [1, "secondaryText"], identifyBy: [1, "identifyBy"] }, outputs: { value: "valueChange", touch: "touch", selected: "selected", cleared: "cleared", freeTextChange: "freeTextChange", searchFailed: "searchFailed" }, decls: 14, vars: 19, consts: [["searchInput", ""], ["dropdown", ""], [1, "drx-autocomplete"], [1, "drx-autocomplete__label", 3, "for"], [1, "drx-autocomplete__control"], ["viewBox", "0 0 24 24", "aria-hidden", "true", 1, "drx-autocomplete__search-icon"], ["cx", "11", "cy", "11", "r", "7", "fill", "none", "stroke", "currentColor", "stroke-width", "2"], ["d", "m16 16 5 5", "fill", "none", "stroke", "currentColor", "stroke-linecap", "round", "stroke-width", "2"], ["type", "search", "role", "combobox", "autocomplete", "off", 1, "drx-autocomplete__input", 3, "input", "focus", "blur", "keydown", "id", "value", "placeholder", "disabled", "required"], ["aria-label", "Carregando", 1, "drx-autocomplete__spinner", "drx-autocomplete__hint"], ["type", "button", "aria-label", "Limpar busca", 1, "drx-autocomplete__clear"], [1, "drx-autocomplete__hint"], ["role", "listbox", 1, "drx-autocomplete__dropdown", 3, "id"], ["role", "alert", 1, "drx-autocomplete__errors"], ["aria-hidden", "true", 1, "drx-autocomplete__required"], ["type", "button", "aria-label", "Limpar busca", 1, "drx-autocomplete__clear", 3, "pointerdown"], ["role", "listbox", 1, "drx-autocomplete__dropdown", 3, "scroll", "id"], [1, "drx-autocomplete__state"], ["role", "alert", 1, "drx-autocomplete__state", "drx-autocomplete__state--error", "drx-button--font-quicksand"], [1, "drx-autocomplete__state", "drx-autocomplete__hint", "drx-button--font-quicksand"], ["type", "button", "role", "option", 1, "drx-autocomplete__option", "drx-font-quicksand-body-lg", "drx-button--font-quicksand", 3, "id", "drx-autocomplete__option--active"], ["role", "status", "aria-live", "polite", 1, "drx-autocomplete__load-more"], ["role", "alert", 1, "drx-autocomplete__load-more", "drx-autocomplete__load-more--error"], ["type", "button", "role", "option", 1, "drx-autocomplete__option", "drx-font-quicksand-body-lg", "drx-button--font-quicksand", 3, "mouseenter", "pointerdown", "id"], [1, "drx-autocomplete__option-label", "drx-button--font-gothic"], [1, "drx-autocomplete__option-detail", "drx-button--font-gothic"], ["aria-hidden", "true", 1, "drx-autocomplete__spinner", "drx-autocomplete__spinner--inline"], ["type", "button", 1, "drx-autocomplete__retry", 3, "pointerdown"], [1, "drx-autocomplete__error"]], template: function (i, o) { i & 1 && (e.\u0275\u0275domElementStart(0, "div", 2), e.\u0275\u0275conditionalCreate(1, Ge, 3, 3, "label", 3), e.\u0275\u0275domElementStart(2, "div", 4), e.\u0275\u0275namespaceSVG(), e.\u0275\u0275domElementStart(3, "svg", 5), e.\u0275\u0275domElement(4, "circle", 6)(5, "path", 7), e.\u0275\u0275domElementEnd(), e.\u0275\u0275namespaceHTML(), e.\u0275\u0275domElementStart(6, "input", 8, 0), e.\u0275\u0275domListener("input", function (l) { return o.handleInput(l); })("focus", function () { return o.handleFocus(); })("blur", function () { return o.handleBlur(); })("keydown", function (l) { return o.handleKeydown(l); }), e.\u0275\u0275domElementEnd(), e.\u0275\u0275conditionalCreate(8, Je, 1, 0, "span", 9)(9, Ye, 2, 0, "button", 10), e.\u0275\u0275domElementEnd(), e.\u0275\u0275conditionalCreate(10, Ze, 2, 1, "p", 11)(11, Xe, 2, 1, "p", 11), e.\u0275\u0275conditionalCreate(12, lt, 6, 3, "div", 12), e.\u0275\u0275conditionalCreate(13, st, 3, 0, "div", 13), e.\u0275\u0275domElementEnd()), i & 2 && (e.\u0275\u0275classProp("drx-autocomplete--open", o.opened())("drx-autocomplete--invalid", o.showValidation()), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.label() ? 1 : -1), e.\u0275\u0275advance(5), e.\u0275\u0275domProperty("id", o.inputId)("value", o.query())("placeholder", o.placeholder())("disabled", o.disabled())("required", o.required()), e.\u0275\u0275attribute("aria-expanded", o.opened())("aria-controls", o.listboxId)("aria-activedescendant", o.activeOptionId())("aria-invalid", o.showValidation())("aria-busy", o.loading() || o.loadingMore()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.loading() ? 8 : o.clearable() && o.query() && !o.disabled() ? 9 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.query().length > 0 && o.query().trim().length < o.minimumSearchLength() ? 10 : o.hint() ? 11 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.opened() ? 12 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.showValidation() && o.errors().length > 0 ? 13 : -1)); }, styles: ["[_nghost-%COMP%]{position:relative;display:block;width:100%;min-width:0}.drx-autocomplete[_ngcontent-%COMP%]{position:relative;display:flex;flex-direction:column;gap:8px;width:100%;min-width:0}.drx-autocomplete__label[_ngcontent-%COMP%]{color:var(--ex-gray-scale-900, #14142b);font-family:var(--drx-font-family-brand, sans-serif);font-size:14px;font-weight:700}.drx-autocomplete__required[_ngcontent-%COMP%]{color:var(--drx-brand-primary, #c00d0e)}.drx-autocomplete__control[_ngcontent-%COMP%]{position:relative;display:flex;align-items:center;width:100%}.drx-autocomplete__search-icon[_ngcontent-%COMP%]{position:absolute;left:14px;z-index:1;width:18px;height:18px;color:var(--ex-gray-scale-600, #6e7191);pointer-events:none}.drx-autocomplete__input[_ngcontent-%COMP%]{width:100%;height:44px;box-sizing:border-box;padding:8px 44px;border:1px solid var(--ex-gray-scale-400, #d6d8e7);border-radius:8px;outline:none;background:var(--ex-gray-scale-100, #fff);color:var(--ex-gray-scale-900, #14142b);font-family:var(--drx-font-family-heading);font-size:14px;transition:border-color .2s ease-in-out,box-shadow .2s ease-in-out}.drx-autocomplete__input[_ngcontent-%COMP%]::placeholder{color:var(--ex-gray-scale-600, #6e7191)}.drx-autocomplete__input[_ngcontent-%COMP%]:focus{border-color:var(--drx-brand-primary, #c00d0e);box-shadow:0 0 0 3px #c00d0e1f}.drx-autocomplete__input[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.65}.drx-autocomplete__input[_ngcontent-%COMP%]::-webkit-search-cancel-button{appearance:none}.drx-autocomplete__spinner[_ngcontent-%COMP%]{position:absolute;right:14px;width:16px;height:16px;border:2px solid var(--ex-gray-scale-400, #d6d8e7);border-top-color:var(--drx-brand-primary, #c00d0e);border-radius:50%;animation:_ngcontent-%COMP%_drx-autocomplete-spin .7s linear infinite}.drx-autocomplete__spinner--inline[_ngcontent-%COMP%]{position:static;flex:0 0 auto}.drx-autocomplete__clear[_ngcontent-%COMP%]{position:absolute;right:10px;width:28px;height:28px;padding:0;border:0;border-radius:50%;background:transparent;color:var(--ex-gray-scale-600, #6e7191);font-size:22px;line-height:1;cursor:pointer}.drx-autocomplete__clear[_ngcontent-%COMP%]:hover{background:var(--ex-gray-scale-200, #f2f2f5);color:var(--ex-gray-scale-900, #14142b)}.drx-autocomplete__hint[_ngcontent-%COMP%]{margin:0;color:var(--ex-gray-scale-600, #6e7191);font-size:var(--drx-font-size-caption);font-family:var(--drx-font-family-base)!important}.drx-autocomplete__dropdown[_ngcontent-%COMP%]{position:fixed;inset:auto;z-index:var(--drx-z-index-overlay, 10000);width:auto;max-width:calc(100vw - 16px);max-height:280px;box-sizing:border-box;margin:0;padding:6px;overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;background:var(--ex-gray-scale-100, #fff);border:1px solid var(--ex-gray-scale-400, #d6d8e7);border-radius:8px;box-shadow:0 14px 32px #2528312e}.drx-autocomplete__option[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:flex-start;gap:4px;width:100%;padding:10px 12px;border:0;border-radius:6px;background:transparent;color:var(--ex-gray-scale-900, #14142b);font:inherit;text-align:left;cursor:pointer}.drx-autocomplete__option[_ngcontent-%COMP%]:hover, .drx-autocomplete__option--active[_ngcontent-%COMP%]{background:#c00d0e14}.drx-autocomplete__option-label[_ngcontent-%COMP%]{width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:700}.drx-autocomplete__option-detail[_ngcontent-%COMP%]{width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--ex-gray-scale-600, #6e7191);font-size:12px}.drx-autocomplete__state[_ngcontent-%COMP%]{padding:14px 12px;color:var(--ex-gray-scale-600, #6e7191);font-size:13px;text-align:center}.drx-autocomplete__state--error[_ngcontent-%COMP%]{color:var(--drx-brand-primary, #c00d0e)}.drx-autocomplete__load-more[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;gap:8px;min-height:40px;padding:8px 12px;box-sizing:border-box;color:var(--ex-gray-scale-600, #6e7191);font-size:12px;text-align:center}.drx-autocomplete__load-more--error[_ngcontent-%COMP%]{flex-direction:column;color:var(--drx-brand-primary, #c00d0e)}.drx-autocomplete__retry[_ngcontent-%COMP%]{padding:4px 8px;border:0;border-radius:4px;background:transparent;color:inherit;font:inherit;font-weight:700;text-decoration:underline;cursor:pointer}.drx-autocomplete__errors[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px}.drx-autocomplete__error[_ngcontent-%COMP%]{color:var(--drx-brand-primary, #c00d0e);font-size:12px;font-family:var(--drx-font-family-base);font-weight:var(--drx-font-weight-bold)}.drx-autocomplete--invalid[_ngcontent-%COMP%]   .drx-autocomplete__input[_ngcontent-%COMP%]{border-color:var(--drx-brand-primary, #c00d0e)}@keyframes _ngcontent-%COMP%_drx-autocomplete-spin{to{transform:rotate(360deg)}}"], changeDetection: 0 });
} return n; })(), vo = (() => { class n {
    tabs = r.required();
    activeId = C(null);
    size = r("medium");
    variant = r("tabs");
    ariaLabel = r("Navega\xE7\xE3o por abas");
    stretch = r(!1);
    tabChange = p();
    selectedId = u(() => { let t = this.tabs(), i = this.activeId(), o = t.find(d => d.id === i && !d.disabled); return o ? o.id : t.find(d => !d.disabled)?.id ?? null; });
    isActive(t) { return t.id === this.selectedId(); }
    isCompleted(t) { return t.state === "completed"; }
    select(t) { t.disabled || this.isActive(t) || (this.activeId.set(t.id), this.tabChange.emit(t)); }
    handleKeydown(t, i) { let d = { ArrowLeft: -1, ArrowRight: 1 }[t.key], l = t.key === "Home", c = t.key === "End"; if (d === void 0 && !l && !c)
        return; t.preventDefault(); let s = this.tabs().map((f, O) => ({ tab: f, tabIndex: O })).filter(({ tab: f }) => !f.disabled); if (!s.length)
        return; let _ = s.findIndex(({ tabIndex: f }) => f === i), m; l ? m = 0 : c ? m = s.length - 1 : m = ((_ >= 0 ? _ : 0) + d + s.length) % s.length; let x = s[m]; if (!x)
        return; this.select(x.tab), t.currentTarget.closest('[role="tablist"]')?.querySelectorAll('[role="tab"]')?.item(x.tabIndex).focus(); }
    panelId(t) { return t.ariaControls ?? `drx-tab-panel-${t.id}`; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-tabs"]], hostAttrs: [1, "drx-tabs-host"], inputs: { tabs: [1, "tabs"], activeId: [1, "activeId"], size: [1, "size"], variant: [1, "variant"], ariaLabel: [1, "ariaLabel"], stretch: [1, "stretch"] }, outputs: { activeId: "activeIdChange", tabChange: "tabChange" }, decls: 3, vars: 7, consts: [["role", "tablist", 1, "drx-tabs"], ["type", "button", "role", "tab", 1, "drx-tabs__tab", 3, "drx-tabs__tab--active", "drx-tabs__tab--completed", "disabled"], ["type", "button", "role", "tab", 1, "drx-tabs__tab", 3, "click", "keydown", "disabled"], ["aria-hidden", "true", 1, "drx-tabs__prefix"], ["aria-hidden", "true", 1, "drx-tabs__icon", 3, "name"], [1, "drx-tabs__label"], ["name", "check", "aria-hidden", "true", 1, "drx-tabs__completed-icon"], [1, "drx-tabs__badge"]], template: function (i, o) { i & 1 && (e.\u0275\u0275elementStart(0, "nav", 0), e.\u0275\u0275repeaterCreate(1, xt, 7, 13, "button", 1, te), e.\u0275\u0275elementEnd()), i & 2 && (e.\u0275\u0275classProp("drx-tabs--small", o.size() === "small")("drx-tabs--stretch", o.stretch())("drx-tabs--steps", o.variant() === "steps"), e.\u0275\u0275attribute("aria-label", o.ariaLabel()), e.\u0275\u0275advance(), e.\u0275\u0275repeater(o.tabs())); }, dependencies: [v], styles: ['[_nghost-%COMP%]{display:block;width:100%;min-width:0}.drx-tabs[_ngcontent-%COMP%]{display:flex;align-items:stretch;gap:4px;width:100%;min-width:0;overflow-x:auto;border-bottom:1px solid var(--drx-gray-300);scrollbar-width:thin}.drx-tabs--stretch[_ngcontent-%COMP%]   .drx-tabs__tab[_ngcontent-%COMP%]{flex:1 1 0;justify-content:center}.drx-tabs__tab[_ngcontent-%COMP%]{position:relative;min-width:max-content;min-height:44px;display:inline-flex;align-items:center;justify-content:flex-start;gap:8px;padding:0 16px;color:var(--drx-gray-600);font-family:var(--drx-font-family-base);font-size:var(--drx-font-size-body-sm);font-weight:var(--drx-font-weight-semibold);line-height:var(--drx-line-height-sm);white-space:nowrap;border:0;background:transparent;cursor:pointer;transition:color .14s ease,background-color .14s ease;text-transform:uppercase}.drx-tabs__tab[_ngcontent-%COMP%]:after{content:"";position:absolute;right:0;bottom:0;left:0;height:2px;border-radius:2px 2px 0 0;background:transparent;transform:scaleX(.5);transition:background-color .14s ease,transform .14s ease}.drx-tabs__tab[_ngcontent-%COMP%]:hover:not(:disabled){color:var(--drx-brand-primary);background:color-mix(in srgb,var(--drx-brand-primary) 4%,transparent)}.drx-tabs__tab[_ngcontent-%COMP%]:focus-visible{outline:2px solid color-mix(in srgb,var(--drx-brand-primary) 45%,transparent);outline-offset:-2px;border-radius:4px 4px 0 0}.drx-tabs__tab[_ngcontent-%COMP%]:disabled{opacity:.45;cursor:not-allowed}.drx-tabs__tab--active[_ngcontent-%COMP%]{color:var(--drx-brand-primary)}.drx-tabs__tab--active[_ngcontent-%COMP%]:after{background:currentColor;transform:scaleX(1)}.drx-tabs__icon[_ngcontent-%COMP%]{--hub-icon-size: 18px;flex:0 0 auto}.drx-tabs__label[_ngcontent-%COMP%]{overflow:hidden;text-overflow:ellipsis}.drx-tabs__badge[_ngcontent-%COMP%]{min-width:20px;height:20px;display:inline-flex;align-items:center;justify-content:center;padding:0 6px;color:currentColor;font-size:var(--drx-font-size-caption);font-weight:var(--drx-font-weight-bold);border-radius:999px;background:color-mix(in srgb,currentColor 10%,transparent)}.drx-tabs--small[_ngcontent-%COMP%]   .drx-tabs__tab[_ngcontent-%COMP%]{min-height:36px;gap:6px;padding:0 12px;font-size:var(--drx-font-size-caption)}.drx-tabs--small[_ngcontent-%COMP%]   .drx-tabs__icon[_ngcontent-%COMP%]{--hub-icon-size: 16px}@media(prefers-reduced-motion:reduce){.drx-tabs__tab[_ngcontent-%COMP%], .drx-tabs__tab[_ngcontent-%COMP%]:after{transition:none}}'], changeDetection: 0 });
} return n; })();
function P(n) { return String(n ?? "").replace(/\D/g, ""); }
function de(n) { let a = P(n).slice(0, 11); return a.length <= 3 ? a : a.length <= 6 ? `${a.slice(0, 3)}.${a.slice(3)}` : a.length <= 9 ? `${a.slice(0, 3)}.${a.slice(3, 6)}.${a.slice(6)}` : `${a.slice(0, 3)}.${a.slice(3, 6)}.${a.slice(6, 9)}-${a.slice(9)}`; }
function le(n) { let a = P(n).slice(0, 14); return a.length <= 2 ? a : a.length <= 5 ? `${a.slice(0, 2)}.${a.slice(2)}` : a.length <= 8 ? `${a.slice(0, 2)}.${a.slice(2, 5)}.${a.slice(5)}` : a.length <= 12 ? `${a.slice(0, 2)}.${a.slice(2, 5)}.${a.slice(5, 8)}/${a.slice(8)}` : `${a.slice(0, 2)}.${a.slice(2, 5)}.${a.slice(5, 8)}/${a.slice(8, 12)}-${a.slice(12)}`; }
function ce(n) { let a = P(n); return a.length <= 11 ? de(a) : le(a); }
function se(n) { let a = P(n).slice(0, 8); return a.length <= 5 ? a : `${a.slice(0, 5)}-${a.slice(5)}`; }
function pe(n) { let a = P(n).slice(0, 11); if (!a)
    return ""; if (a.length <= 2)
    return `(${a}`; let t = a.slice(0, 2), i = a.slice(2); return i.length <= 4 ? `(${t}) ${i}` : a.length <= 10 ? `(${t}) ${i.slice(0, 4)}-${i.slice(4)}` : `(${t}) ${i.slice(0, 5)}-${i.slice(5)}`; }
function Ui(n, a) { switch (a) {
    case "cpf": return de(n);
    case "cnpj": return le(n);
    case "document": return ce(n);
    case "cep": return se(n);
    case "phone": return pe(n);
    default: return String(n ?? "");
} }
function Co(n) { let a = P(n); if (a.length !== 11 || /^(\d)\1{10}$/.test(a))
    return !1; let t = [...a].map(Number), i = 0; for (let c = 0; c < 9; c += 1)
    i += t[c] * (10 - c); let o = i % 11, d = o < 2 ? 0 : 11 - o; if (t[9] !== d)
    return !1; i = 0; for (let c = 0; c < 10; c += 1)
    i += t[c] * (11 - c); o = i % 11; let l = o < 2 ? 0 : 11 - o; return t[10] === l; }
function yo(n) { let a = P(n); if (a.length !== 14 || /^(\d)\1{13}$/.test(a))
    return !1; let t = [...a].map(Number), i = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2], o = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2], d = i.reduce((_, m, x) => _ + t[x] * m, 0), l = d % 11, c = l < 2 ? 0 : 11 - l; if (t[12] !== c)
    return !1; d = o.reduce((_, m, x) => _ + t[x] * m, 0), l = d % 11; let s = l < 2 ? 0 : 11 - l; return t[13] === s; }
var Gi = 0, Ji = (() => { class n {
    value = C("");
    disabled = r(!1);
    readonly = r(!1);
    required = r(!1);
    invalid = r(!1);
    errors = r([]);
    name = r("");
    label = r("");
    placeholder = r("");
    type = r("text");
    autocomplete = r("off");
    id = r(null);
    minLength = r(void 0);
    maxLength = r(void 0);
    inputMode = r("text");
    mask = r("none");
    touch = p();
    hasBeenTouched = g(!1);
    showValidation = u(() => this.hasBeenTouched() && this.invalid());
    inputElement = D("inputElement");
    inputId = `drx-input-${Gi++}`;
    get resolvedInputId() { return this.id() ?? this.inputId; }
    handleInput(t) { let i = t.target, o = Ui(i.value, this.mask()); i.value = o, this.value.set(o); }
    handleBlur() { this.hasBeenTouched.set(!0), this.touch.emit(); }
    focus(t) { this.inputElement()?.nativeElement.focus(t); }
    reset() { this.value.set(""), this.hasBeenTouched.set(!1); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-input"]], viewQuery: function (i, o) { i & 1 && e.\u0275\u0275viewQuerySignal(o.inputElement, ne, 5), i & 2 && e.\u0275\u0275queryAdvance(); }, inputs: { value: [1, "value"], disabled: [1, "disabled"], readonly: [1, "readonly"], required: [1, "required"], invalid: [1, "invalid"], errors: [1, "errors"], name: [1, "name"], label: [1, "label"], placeholder: [1, "placeholder"], type: [1, "type"], autocomplete: [1, "autocomplete"], id: [1, "id"], minLength: [1, "minLength"], maxLength: [1, "maxLength"], inputMode: [1, "inputMode"], mask: [1, "mask"] }, outputs: { value: "valueChange", touch: "touch" }, decls: 5, vars: 17, consts: [["inputElement", ""], [1, "drx-input"], [1, "drx-input__label", 3, "for"], [1, "drx-input__field", 3, "input", "blur", "id", "name", "type", "value", "placeholder", "autocomplete", "disabled", "readonly", "required"], ["role", "alert", 1, "drx-input__errors"], ["aria-hidden", "true", 1, "drx-input__required"], [1, "drx-input__error"]], template: function (i, o) { i & 1 && (e.\u0275\u0275domElementStart(0, "div", 1), e.\u0275\u0275conditionalCreate(1, bt, 3, 3, "label", 2), e.\u0275\u0275domElementStart(2, "input", 3, 0), e.\u0275\u0275domListener("input", function (l) { return o.handleInput(l); })("blur", function () { return o.handleBlur(); }), e.\u0275\u0275domElementEnd(), e.\u0275\u0275conditionalCreate(4, ht, 3, 0, "div", 4), e.\u0275\u0275domElementEnd()), i & 2 && (e.\u0275\u0275classProp("drx-input--invalid", o.showValidation()), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.label() ? 1 : -1), e.\u0275\u0275advance(), e.\u0275\u0275domProperty("id", o.resolvedInputId)("name", o.name())("type", o.type())("value", o.value())("placeholder", o.placeholder())("autocomplete", o.autocomplete())("disabled", o.disabled())("readOnly", o.readonly())("required", o.required()), e.\u0275\u0275attribute("inputmode", o.inputMode())("minlength", o.minLength())("maxlength", o.maxLength())("aria-invalid", o.showValidation()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.showValidation() && o.errors().length > 0 ? 4 : -1)); }, styles: ["[_nghost-%COMP%]{display:block;width:100%;min-width:0}.drx-input[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px;width:100%;min-width:0}.drx-input__label[_ngcontent-%COMP%]{display:inline-flex;align-items:center;width:fit-content;margin:0;color:var(--drx-color-text-primary);font-family:var(--drx-font-family-brand);font-size:var(--drx-font-size-body-sm);font-weight:700;line-height:1.25}.drx-input__required[_ngcontent-%COMP%]{margin-left:2px;color:var(--drx-brand-primary)}.drx-input__field[_ngcontent-%COMP%]{display:block;width:100%;min-width:0;min-height:44px;padding:8px;box-sizing:border-box;color:var(--drx-color-text-primary);background-color:var(--ex-gray-scale-100, #fff);border:1px solid var(--drx-brand-secondary-hover);border-radius:8px;outline:none;font-family:var(--drx-font-family-base);font-size:var(--drx-font-size-body-sm);transition:border-color .15s ease,box-shadow .15s ease}.drx-input__field[_ngcontent-%COMP%]::placeholder{color:var(--ex-gray-scale-600)}.drx-input__field[_ngcontent-%COMP%]:hover:not(:disabled):not(:focus){border-color:var(--drx-brand-secondary)}.drx-input__field[_ngcontent-%COMP%]:focus{border-color:var(--drx-brand-primary);box-shadow:0 0 0 2px color-mix(in srgb,var(--drx-brand-primary) 15%,transparent)}.drx-input__field[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.6}.drx-input__field[_ngcontent-%COMP%]:read-only{cursor:default}.drx-input--invalid[_ngcontent-%COMP%]   .drx-input__field[_ngcontent-%COMP%]{border-color:var(--drx-brand-primary)}.drx-input--invalid[_ngcontent-%COMP%]   .drx-input__field[_ngcontent-%COMP%]:focus{box-shadow:0 0 0 2px color-mix(in srgb,var(--drx-brand-primary) 15%,transparent)}.drx-input__errors[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px}.drx-input__error[_ngcontent-%COMP%]{margin:0;color:var(--drx-brand-primary);font-family:var(--drx-font-family-base);font-size:var(--drx-font-size-caption);font-weight:700;line-height:1.25}.drx-input__field[_ngcontent-%COMP%]:read-only{cursor:default;background-color:var(--ex-gray-scale-400)}.drx-input__field[_ngcontent-%COMP%]:disabled{cursor:not-allowed;background-color:var(--ex-gray-scale-400);opacity:1}"], changeDetection: 0 });
} return n; })(), Mo = (() => { class n {
    disabled = r(!1);
    saving = r(!1);
    editing = r(!1);
    showSaveAndContinue = r(!0);
    showCancel = r(!0);
    showSave = r(!0);
    sticky = r(!1);
    stickyOffset = r("0px");
    wrapActions = r(!0);
    cancelLabel = r("Cancelar");
    saveLabel = r("Salvar");
    updateLabel = r("Atualizar");
    saveAndContinueLabel = r("Salvar e continuar");
    savingLabel = r("Salvando...");
    cancelIcon = r("circle-slash");
    saveIcon = r("save");
    saveAndContinueIcon = r("step-forward");
    cancel = p();
    save = p();
    saveAndContinue = p();
    saveDisabled = u(() => this.disabled() || this.saving());
    primaryLabel = u(() => this.saving() ? this.savingLabel() : this.editing() ? this.updateLabel() : this.saveLabel());
    handleCancel() { this.saving() || this.cancel.emit(); }
    handleSave() { this.saveDisabled() || this.save.emit(); }
    handleSaveAndContinue() { this.saveDisabled() || this.saveAndContinue.emit(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-save-footer"]], inputs: { disabled: [1, "disabled"], saving: [1, "saving"], editing: [1, "editing"], showSaveAndContinue: [1, "showSaveAndContinue"], showCancel: [1, "showCancel"], showSave: [1, "showSave"], sticky: [1, "sticky"], stickyOffset: [1, "stickyOffset"], wrapActions: [1, "wrapActions"], cancelLabel: [1, "cancelLabel"], saveLabel: [1, "saveLabel"], updateLabel: [1, "updateLabel"], saveAndContinueLabel: [1, "saveAndContinueLabel"], savingLabel: [1, "savingLabel"], cancelIcon: [1, "cancelIcon"], saveIcon: [1, "saveIcon"], saveAndContinueIcon: [1, "saveAndContinueIcon"] }, outputs: { cancel: "cancel", save: "save", saveAndContinue: "saveAndContinue" }, ngContentSelectors: Ct, decls: 9, vars: 9, consts: [[1, "drx-save-footer"], [1, "drx-save-footer__start"], ["type", "button", "font", "gothic", "size", "medium", "variant", "secondary", 1, "drx-save-footer__cancel", 3, "disabled"], [1, "drx-save-footer__actions"], ["type", "button", "font", "gothic", "size", "medium", "variant", "tertiary", 1, "drx-save-footer__continue", 3, "disabled"], ["type", "button", "font", "gothic", "size", "medium", "variant", "primary", 1, "drx-save-footer__save", 3, "disabled"], ["type", "button", "font", "gothic", "size", "medium", "variant", "secondary", 1, "drx-save-footer__cancel", 3, "click", "disabled"], [3, "name"], ["type", "button", "font", "gothic", "size", "medium", "variant", "tertiary", 1, "drx-save-footer__continue", 3, "click", "disabled"], ["type", "button", "font", "gothic", "size", "medium", "variant", "primary", 1, "drx-save-footer__save", 3, "click", "disabled"]], template: function (i, o) { i & 1 && (e.\u0275\u0275projectionDef(vt), e.\u0275\u0275elementStart(0, "footer", 0)(1, "div", 1), e.\u0275\u0275projection(2), e.\u0275\u0275conditionalCreate(3, yt, 4, 3, "drx-button", 2), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(4, "div", 3), e.\u0275\u0275projection(5, 1), e.\u0275\u0275conditionalCreate(6, Mt, 4, 3, "drx-button", 4), e.\u0275\u0275conditionalCreate(7, wt, 4, 3, "drx-button", 5), e.\u0275\u0275projection(8, 2), e.\u0275\u0275elementEnd()()), i & 2 && (e.\u0275\u0275styleProp("--drx-save-footer-sticky-offset", o.stickyOffset()), e.\u0275\u0275classProp("drx-save-footer--sticky", o.sticky())("drx-save-footer--no-wrap", !o.wrapActions()), e.\u0275\u0275advance(3), e.\u0275\u0275conditional(o.showCancel() ? 3 : -1), e.\u0275\u0275advance(3), e.\u0275\u0275conditional(o.showSaveAndContinue() ? 6 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.showSave() ? 7 : -1)); }, dependencies: [re, v], styles: ['@charset "UTF-8";[_nghost-%COMP%]{display:block;width:100%;min-width:0}.drx-save-footer[_ngcontent-%COMP%]{position:static;display:flex;flex-shrink:0;align-items:center;justify-content:space-between;gap:16px;width:100%;min-width:0;min-height:75px;margin-top:auto;padding:12px 16px;box-sizing:border-box;background-color:var(--drx-save-footer-background, var(--ex-gray-scale-100, #fff));border:1px solid var(--drx-save-footer-border-color, var(--ex-gray-scale-400));border-radius:var(--drx-save-footer-border-radius, 8px);box-shadow:var(--drx-save-footer-shadow, 0 2px 8px rgba(37, 40, 49, .0588235294))}.drx-save-footer--sticky[_ngcontent-%COMP%]{position:sticky;bottom:var(--drx-save-footer-sticky-offset, 0px);z-index:var(--drx-save-footer-z-index, 20);background-color:var(--drx-save-footer-sticky-background, rgba(255, 255, 255, .96));-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px)}.drx-save-footer__start[_ngcontent-%COMP%], .drx-save-footer__actions[_ngcontent-%COMP%]{display:flex;align-items:center;gap:16px;min-width:0}.drx-save-footer__start[_ngcontent-%COMP%]{flex:0 1 auto}.drx-save-footer__actions[_ngcontent-%COMP%]{flex:1 1 auto;flex-wrap:wrap;justify-content:flex-end}.drx-save-footer--no-wrap[_ngcontent-%COMP%]   .drx-save-footer__actions[_ngcontent-%COMP%]{flex-wrap:nowrap}.drx-save-footer__cancel[_ngcontent-%COMP%], .drx-save-footer__continue[_ngcontent-%COMP%], .drx-save-footer__save[_ngcontent-%COMP%]{margin:0}.drx-save-footer[_ngcontent-%COMP%]     .drx-button--primary, .drx-save-footer[_ngcontent-%COMP%]     .drx-button--secondary{border:2px solid transparent}.drx-save-footer[_ngcontent-%COMP%]     .drx-button--tertiary{border:2px solid var(--drx-button-tertiary-color, var(--drx-color-primary))}@media(max-width:600px){.drx-save-footer[_ngcontent-%COMP%]{position:static;flex-direction:column-reverse;align-items:stretch;padding:12px}.drx-save-footer__start[_ngcontent-%COMP%], .drx-save-footer__actions[_ngcontent-%COMP%]{width:100%}.drx-save-footer__start[_ngcontent-%COMP%], .drx-save-footer__actions[_ngcontent-%COMP%]{flex-direction:column;align-items:stretch}.drx-save-footer__cancel[_ngcontent-%COMP%], .drx-save-footer__continue[_ngcontent-%COMP%], .drx-save-footer__save[_ngcontent-%COMP%], .drx-save-footer[_ngcontent-%COMP%]     [drxFooterStart], .drx-save-footer[_ngcontent-%COMP%]     [drxFooterAction], .drx-save-footer[_ngcontent-%COMP%]     [drxFooterEnd]{display:block;width:100%}.drx-save-footer[_ngcontent-%COMP%]     .drx-button{width:100%}}'], changeDetection: 0 });
} return n; })(), wo = (() => { class n {
    transform(t) { return ce(t); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275pipe = e.\u0275\u0275definePipe({ name: "drxDocument", type: n, pure: !0 });
} return n; })(), Do = (() => { class n {
    transform(t) { return se(t); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275pipe = e.\u0275\u0275definePipe({ name: "drxPostalCode", type: n, pure: !0 });
} return n; })(), Po = (() => { class n {
    transform(t) { return pe(t); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275pipe = e.\u0275\u0275definePipe({ name: "drxPhone", type: n, pure: !0 });
} return n; })(), Yi = 0, Zi = (() => { class n {
    value = C("");
    disabled = r(!1);
    readonly = r(!1);
    required = r(!1);
    invalid = r(!1);
    errors = r([]);
    name = r("");
    label = r("");
    hint = r("");
    placeholder = r("dd/mm/aaaa");
    id = r(null);
    minDate = r(null);
    maxDate = r(null);
    touch = p();
    inputElement = D("inputElement");
    generatedId = `drx-calendar-${Yi++}`;
    get resolvedId() { return this.id() ?? this.generatedId; }
    handleInput(t) { this.value.set(t.target.value); }
    handleBlur() { this.touch.emit(); }
    openCalendar() { if (this.disabled() || this.readonly())
        return; let t = this.inputElement()?.nativeElement; if (t && (t.focus(), "showPicker" in t))
        try {
            t.showPicker();
        }
        catch { } }
    focus(t) { this.inputElement()?.nativeElement.focus(t); }
    reset() { this.value.set(""); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-calendar"]], viewQuery: function (i, o) { i & 1 && e.\u0275\u0275viewQuerySignal(o.inputElement, ne, 5), i & 2 && e.\u0275\u0275queryAdvance(); }, inputs: { value: [1, "value"], disabled: [1, "disabled"], readonly: [1, "readonly"], required: [1, "required"], invalid: [1, "invalid"], errors: [1, "errors"], name: [1, "name"], label: [1, "label"], hint: [1, "hint"], placeholder: [1, "placeholder"], id: [1, "id"], minDate: [1, "minDate"], maxDate: [1, "maxDate"] }, outputs: { value: "valueChange", touch: "touch" }, decls: 9, vars: 21, consts: [["inputElement", ""], [1, "drx-calendar"], [1, "drx-calendar__label", 3, "for"], [1, "drx-calendar__control", "quicksand-sm"], ["type", "date", 1, "drx-calendar__field", 3, "input", "blur", "id", "name", "value", "placeholder", "disabled", "readonly", "required"], ["type", "button", "aria-label", "Abrir calend\xE1rio", 1, "drx-calendar__button", 3, "click", "disabled"], [3, "name"], [1, "drx-calendar__hint"], ["role", "alert", 1, "drx-calendar__errors"], ["aria-hidden", "true", 1, "drx-calendar__required"], [1, "drx-calendar__error"]], template: function (i, o) { i & 1 && (e.\u0275\u0275elementStart(0, "div", 1), e.\u0275\u0275conditionalCreate(1, Pt, 3, 3, "label", 2), e.\u0275\u0275elementStart(2, "div", 3)(3, "input", 4, 0), e.\u0275\u0275listener("input", function (l) { return o.handleInput(l); })("blur", function () { return o.handleBlur(); }), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(5, "button", 5), e.\u0275\u0275listener("click", function () { return o.openCalendar(); }), e.\u0275\u0275element(6, "app-hub-icon", 6), e.\u0275\u0275elementEnd()(), e.\u0275\u0275conditionalCreate(7, Ot, 2, 1, "p", 7), e.\u0275\u0275conditionalCreate(8, Tt, 3, 0, "div", 8), e.\u0275\u0275elementEnd()), i & 2 && (e.\u0275\u0275classProp("drx-calendar--invalid", o.invalid())("drx-calendar--disabled", o.disabled())("drx-calendar--readonly", o.readonly()), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.label() ? 1 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275property("id", o.resolvedId)("name", o.name())("value", o.value())("placeholder", o.placeholder())("disabled", o.disabled())("readonly", o.readonly())("required", o.required()), e.\u0275\u0275attribute("min", o.minDate())("max", o.maxDate())("aria-invalid", o.invalid()), e.\u0275\u0275advance(2), e.\u0275\u0275property("disabled", o.disabled() || o.readonly()), e.\u0275\u0275advance(), e.\u0275\u0275property("name", "calendar-days"), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.hint() && !(o.invalid() && o.errors().length > 0) ? 7 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.invalid() && o.errors().length > 0 ? 8 : -1)); }, dependencies: [v], styles: ["[_nghost-%COMP%]{display:block;width:100%;min-width:0}.drx-calendar[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:8px;width:100%;min-width:0}.drx-calendar__label[_ngcontent-%COMP%]{color:var(--drx-color-heading, #252831);font-family:var(--drx-font-family-display);font-size:var(--drx-font-size-body-sm, 13px);font-weight:600}.drx-calendar__required[_ngcontent-%COMP%]{color:var(--drx-brand-primary, #c00d0e)}.drx-calendar__control[_ngcontent-%COMP%]{position:relative;display:flex;align-items:stretch;width:100%;min-width:0}.drx-calendar__field[_ngcontent-%COMP%]{width:100%;min-width:0;min-height:44px;padding:9px 44px 9px 12px;box-sizing:border-box;outline:0;color:var(--drx-color-text-default, #34415a);background:var(--drx-color-surface-default, #fff);border:1px solid var(--drx-color-border-default, #d6d8e7);border-radius:8px;font:inherit}.drx-calendar__field[_ngcontent-%COMP%]:focus{border-color:var(--drx-color-focus-ring, #759cff);box-shadow:0 0 0 3px #759cff1f}.drx-calendar__field[_ngcontent-%COMP%]::-webkit-calendar-picker-indicator{opacity:0;width:0;height:0;margin:0}.drx-calendar__button[_ngcontent-%COMP%]{position:absolute;top:1px;right:1px;bottom:1px;width:40px;padding:0;cursor:pointer;color:var(--drx-color-text-muted, #6e7191);background:transparent;border:0;border-radius:0 7px 7px 0;font-size:18px}.drx-calendar__button[_ngcontent-%COMP%]:hover:not(:disabled){background:var(--ex-gray-scale-200, #f2f3f8)}.drx-calendar__button[_ngcontent-%COMP%]:disabled{cursor:default;opacity:.45}.drx-calendar__hint[_ngcontent-%COMP%], .drx-calendar__error[_ngcontent-%COMP%]{margin:0;font-family:var(--drx-font-family-body);font-size:var(--drx-font-size-body-sm, 12px);line-height:1.35}.drx-calendar__hint[_ngcontent-%COMP%]{color:var(--drx-color-text-muted, #6e7191)}.drx-calendar__errors[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:2px}.drx-calendar__error[_ngcontent-%COMP%]{color:var(--drx-color-danger, #c00d0e)}.drx-calendar--invalid[_ngcontent-%COMP%]   .drx-calendar__field[_ngcontent-%COMP%]{border-color:var(--drx-color-danger, #c00d0e);box-shadow:0 0 0 1px #c00d0e1a}.drx-calendar--readonly[_ngcontent-%COMP%]   .drx-calendar__field[_ngcontent-%COMP%], .drx-calendar--disabled[_ngcontent-%COMP%]   .drx-calendar__field[_ngcontent-%COMP%]{background:var(--ex-gray-scale-200, #f2f3f8)}"], changeDetection: 0 });
} return n; })(), Xi = 0, eo = (() => { class n {
    value = C("");
    disabled = r(!1);
    readonly = r(!1);
    required = r(!1);
    invalid = r(!1);
    errors = r([]);
    name = r("");
    label = r("");
    hint = r("");
    placeholder = r("Selecione uma op\xE7\xE3o");
    id = r(null);
    options = r([]);
    touch = p();
    selectionChange = p();
    selectElement = D("selectElement");
    generatedId = `drx-select-${Xi++}`;
    get resolvedId() { return this.id() ?? this.generatedId; }
    handleChange(t) { let i = t.target.value; this.value.set(i), this.selectionChange.emit(i); }
    handleBlur() { this.touch.emit(); }
    focus(t) { this.selectElement()?.nativeElement.focus(t); }
    reset() { this.value.set(""); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-select"]], viewQuery: function (i, o) { i & 1 && e.\u0275\u0275viewQuerySignal(o.selectElement, St, 5), i & 2 && e.\u0275\u0275queryAdvance(); }, inputs: { value: [1, "value"], disabled: [1, "disabled"], readonly: [1, "readonly"], required: [1, "required"], invalid: [1, "invalid"], errors: [1, "errors"], name: [1, "name"], label: [1, "label"], hint: [1, "hint"], placeholder: [1, "placeholder"], id: [1, "id"], options: [1, "options"] }, outputs: { value: "valueChange", touch: "touch", selectionChange: "selectionChange" }, decls: 11, vars: 15, consts: [["selectElement", ""], [1, "drx-select"], [1, "drx-select__label", 3, "for"], [1, "drx-select__control"], [1, "drx-select__field", "quicksand-sm", 3, "change", "blur", "id", "name", "value", "disabled", "required"], ["value", "", 3, "disabled"], [3, "value", "disabled"], [1, "drx-select__chevron", 3, "name"], [1, "drx-select__hint"], ["role", "alert", 1, "drx-select__errors"], ["aria-hidden", "true", 1, "drx-select__required"], [1, "drx-select__error"]], template: function (i, o) { i & 1 && (e.\u0275\u0275elementStart(0, "div", 1), e.\u0275\u0275conditionalCreate(1, Ft, 3, 3, "label", 2), e.\u0275\u0275elementStart(2, "div", 3)(3, "select", 4, 0), e.\u0275\u0275listener("change", function (l) { return o.handleChange(l); })("blur", function () { return o.handleBlur(); }), e.\u0275\u0275conditionalCreate(5, It, 2, 2, "option", 5), e.\u0275\u0275repeaterCreate(6, At, 2, 3, "option", 6, kt), e.\u0275\u0275elementEnd(), e.\u0275\u0275element(8, "app-hub-icon", 7), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(9, zt, 2, 1, "p", 8), e.\u0275\u0275conditionalCreate(10, $t, 3, 0, "div", 9), e.\u0275\u0275elementEnd()), i & 2 && (e.\u0275\u0275classProp("drx-select--invalid", o.invalid())("drx-select--disabled", o.disabled()), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.label() ? 1 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275property("id", o.resolvedId)("name", o.name())("value", o.value())("disabled", o.disabled() || o.readonly())("required", o.required()), e.\u0275\u0275attribute("aria-invalid", o.invalid()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.placeholder() ? 5 : -1), e.\u0275\u0275advance(), e.\u0275\u0275repeater(o.options()), e.\u0275\u0275advance(2), e.\u0275\u0275property("name", "chevron-down"), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.hint() && !(o.invalid() && o.errors().length > 0) ? 9 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.invalid() && o.errors().length > 0 ? 10 : -1)); }, dependencies: [v], styles: ["[_nghost-%COMP%]{display:block;width:100%;min-width:0}.drx-select[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:7px;width:100%;min-width:0}.drx-select__label[_ngcontent-%COMP%]{color:var(--drx-color-heading, #252831);font-family:var(--drx-font-family-display);font-size:var(--drx-font-size-body-sm, 13px);font-weight:600}.drx-select__required[_ngcontent-%COMP%]{color:var(--drx-brand-primary, #c00d0e)}.drx-select__control[_ngcontent-%COMP%]{position:relative;width:100%;min-width:0}.drx-select__field[_ngcontent-%COMP%]{width:100%;min-width:0;min-height:44px;padding:9px 38px 9px 12px;box-sizing:border-box;appearance:none;outline:0;cursor:pointer;color:var(--drx-color-text-default, #34415a);background:var(--drx-color-surface-default, #fff);border:1px solid var(--drx-color-border-default, #d6d8e7);border-radius:8px;font:inherit}.drx-select__field[_ngcontent-%COMP%]:focus{border-color:var(--drx-color-focus-ring, #759cff);box-shadow:0 0 0 3px #759cff1f}.drx-select__field[_ngcontent-%COMP%]:disabled{cursor:default;background:var(--ex-gray-scale-200, #f2f3f8);opacity:.7}.drx-select__chevron[_ngcontent-%COMP%]{position:absolute;top:50%;right:13px;pointer-events:none;color:var(--drx-color-text-muted, #6e7191);transform:translateY(-55%)}.drx-select__hint[_ngcontent-%COMP%], .drx-select__error[_ngcontent-%COMP%]{margin:0;font-family:var(--drx-font-family-base);font-size:var(--drx-font-size-caption);line-height:1.35}.drx-select__hint[_ngcontent-%COMP%]{color:var(--drx-color-text-muted, #6e7191)}.drx-select__errors[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:2px}.drx-select__error[_ngcontent-%COMP%]{color:var(--drx-color-danger, #c00d0e)}.drx-select--invalid[_ngcontent-%COMP%]   .drx-select__field[_ngcontent-%COMP%]{border-color:var(--drx-color-danger, #c00d0e);box-shadow:0 0 0 1px #c00d0e1a}"], changeDetection: 0 });
} return n; })(), to = (() => { class n {
    label = r.required();
    tone = r("neutral");
    size = r("small");
    icon = r(null);
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-badge"]], inputs: { label: [1, "label"], tone: [1, "tone"], size: [1, "size"], icon: [1, "icon"] }, decls: 4, vars: 4, consts: [[1, "drx-badge"], [1, "drx-badge__icon", 3, "name"], [1, "gothic-sm", "bolder-font"]], template: function (i, o) { i & 1 && (e.\u0275\u0275elementStart(0, "span", 0), e.\u0275\u0275conditionalCreate(1, Vt, 1, 1, "app-hub-icon", 1), e.\u0275\u0275elementStart(2, "span", 2), e.\u0275\u0275text(3), e.\u0275\u0275elementEnd()()), i & 2 && (e.\u0275\u0275classMap("drx-badge drx-badge--" + o.tone() + " drx-badge--" + o.size()), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.icon() ? 1 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate(o.label())); }, dependencies: [v], styles: ["[_nghost-%COMP%]{display:inline-flex}.drx-badge[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:5px;width:fit-content;max-width:100%;border-radius:999px;font-family:var(--drx-font-family-body);font-weight:600;line-height:1.2;white-space:nowrap}.drx-badge--small[_ngcontent-%COMP%]{min-height:24px;padding:3px 9px;font-size:var(--drx-font-size-body-sm, 12px)}.drx-badge--medium[_ngcontent-%COMP%]{min-height:28px;padding:4px 11px;font-size:var(--drx-font-size-body-md, 14px)}.drx-badge--neutral[_ngcontent-%COMP%]{color:#596274;background:#edf0f3}.drx-badge--info[_ngcontent-%COMP%]{color:#28639c;background:#e1eefc}.drx-badge--warning[_ngcontent-%COMP%]{color:#b8530c;background:#fff0e1}.drx-badge--success[_ngcontent-%COMP%]{color:#178b4d;background:#e1f6e9}.drx-badge--danger[_ngcontent-%COMP%]{color:#a12222;background:#fde7e7}.drx-badge--purple[_ngcontent-%COMP%]{color:#734dc2;background:#eee7ff}.drx-badge__icon[_ngcontent-%COMP%]{display:inline-flex;flex:0 0 auto}"], changeDetection: 0 });
} return n; })(), Oo = (() => { class n {
    destroyRef = M(X);
    rows = r([]);
    columns = r.required();
    actions = r([]);
    rowKey = r((t, i) => i);
    mode = r("client");
    loading = r(!1);
    total = r(0);
    page = r(1);
    pageSize = r(10);
    pageSizeOptions = r([10, 20, 50]);
    pagination = r(!0);
    search = r("");
    filters = r({});
    sort = r(null);
    title = r("");
    icon = r(null);
    searchable = r(!0);
    columnFilters = r(!0);
    searchPlaceholder = r("Pesquisar...");
    emptyText = r("Nenhum registro encontrado.");
    loadingText = r("Carregando...");
    searchDebounceMs = r(350);
    primaryActionLabel = r("");
    primaryActionIcon = r(null);
    primaryActionDisabled = r(!1);
    queryChange = p();
    rowAction = p();
    primaryAction = p();
    currentSearch = E(() => this.search());
    currentFilters = E(() => w({}, this.filters()));
    currentSort = E(() => this.sort());
    currentPage = E(() => this.page());
    currentPageSize = E(() => this.pageSize());
    searchChanges = new N;
    filterChanges = new N;
    clientFilteredRows = u(() => { let t = [...this.rows()], i = this.normalize(this.currentSearch()), o = this.currentFilters(); if (i) {
        let l = this.columns().filter(c => c.searchable !== !1);
        t = t.filter(c => l.some(s => this.normalize(this.displayValue(c, s)).includes(i)));
    } for (let [l, c] of Object.entries(o)) {
        let s = this.normalize(c);
        if (!s)
            continue;
        let _ = this.columns().find(m => m.key === l);
        _ && (t = t.filter(m => { let x = this.normalize(String(_.value(m) ?? "")); return (_.filter?.type ?? "text") === "text" ? x.includes(s) : x === s; }));
    } let d = this.currentSort(); if (d) {
        let l = this.columns().find(c => c.key === d.key);
        l && t.sort((c, s) => { let _ = l.value(c), m = l.value(s), x = this.compareValues(_, m); return d.direction === "asc" ? x : x * -1; });
    } return t; });
    effectiveTotal = u(() => this.mode() === "client" ? this.clientFilteredRows().length : this.total());
    pageSizeSelectOptions = u(() => this.pageSizeOptions().map(t => ({ value: String(t), label: String(t) })));
    totalPages = u(() => Math.max(Math.ceil(this.effectiveTotal() / this.currentPageSize()), 1));
    displayedRows = u(() => { if (this.mode() === "server")
        return this.rows(); if (!this.pagination())
        return this.clientFilteredRows(); let i = (Math.min(this.currentPage(), this.totalPages()) - 1) * this.currentPageSize(); return this.clientFilteredRows().slice(i, i + this.currentPageSize()); });
    rangeStart = u(() => this.effectiveTotal() ? (this.currentPage() - 1) * this.currentPageSize() + 1 : 0);
    rangeEnd = u(() => Math.min(this.currentPage() * this.currentPageSize(), this.effectiveTotal()));
    constructor() { this.searchChanges.pipe(A(() => z(this.searchDebounceMs())), I(this.destroyRef)).subscribe(t => { this.currentSearch.set(t), this.currentPage.set(1), this.emitQuery(); }), this.filterChanges.pipe(A(() => z(this.searchDebounceMs())), I(this.destroyRef)).subscribe(({ key: t, value: i }) => { this.applyFilter(t, i); }); }
    onSearchChange(t) { this.searchChanges.next(t); }
    onFilterChange(t, i) { if ((t.filter?.type ?? "text") === "text") {
        this.filterChanges.next({ key: t.key, value: i });
        return;
    } this.applyFilter(t.key, i); }
    filterValue(t) { return this.currentFilters()[t] ?? ""; }
    toggleSort(t) { if (!t.sortable)
        return; let i = this.currentSort(), o; !i || i.key !== t.key ? o = { key: t.key, direction: "asc" } : o = { key: t.key, direction: i.direction === "asc" ? "desc" : "asc" }, this.currentSort.set(o), this.currentPage.set(1), this.emitQuery(); }
    sortIndicator(t) { let i = this.currentSort(); return !i || i.key !== t.key ? "" : i.direction === "asc" ? "\u25B2" : "\u25BC"; }
    goToPreviousPage() { this.currentPage() <= 1 || (this.currentPage.update(t => t - 1), this.emitQuery()); }
    goToNextPage() { this.currentPage() >= this.totalPages() || (this.currentPage.update(t => t + 1), this.emitQuery()); }
    onPageSizeChange(t) { let i = Number(t); !Number.isFinite(i) || i <= 0 || (this.currentPageSize.set(i), this.currentPage.set(1), this.emitQuery()); }
    displayValue(t, i) { if (i.display)
        return i.display(t); let o = i.value(t); return o == null || o === "" ? "-" : String(o); }
    badgeConfig(t, i) { return i.badge?.(t) ?? null; }
    isActionHidden(t, i) { return t.hidden?.(i) ?? !1; }
    isActionDisabled(t, i) { return t.disabled?.(i) ?? !1; }
    emitRowAction(t, i) { this.isActionDisabled(t, i) || this.rowAction.emit({ action: t, row: i }); }
    alignClass(t) { return `drx-data-table__cell--${t.align ?? "left"}`; }
    applyFilter(t, i) { let o = w({}, this.currentFilters()); i.trim() ? o[t] = i : delete o[t], this.currentFilters.set(o), this.currentPage.set(1), this.emitQuery(); }
    emitQuery() { this.queryChange.emit({ search: this.currentSearch().trim(), page: this.currentPage(), pageSize: this.currentPageSize(), filters: this.currentFilters(), sort: this.currentSort() }); }
    normalize(t) { return String(t ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLocaleLowerCase("pt-BR"); }
    compareValues(t, i) { return t === i ? 0 : t == null ? -1 : i == null ? 1 : typeof t == "number" && typeof i == "number" ? t - i : String(t).localeCompare(String(i), "pt-BR", { numeric: !0, sensitivity: "base" }); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-data-table"]], inputs: { rows: [1, "rows"], columns: [1, "columns"], actions: [1, "actions"], rowKey: [1, "rowKey"], mode: [1, "mode"], loading: [1, "loading"], total: [1, "total"], page: [1, "page"], pageSize: [1, "pageSize"], pageSizeOptions: [1, "pageSizeOptions"], pagination: [1, "pagination"], search: [1, "search"], filters: [1, "filters"], sort: [1, "sort"], title: [1, "title"], icon: [1, "icon"], searchable: [1, "searchable"], columnFilters: [1, "columnFilters"], searchPlaceholder: [1, "searchPlaceholder"], emptyText: [1, "emptyText"], loadingText: [1, "loadingText"], searchDebounceMs: [1, "searchDebounceMs"], primaryActionLabel: [1, "primaryActionLabel"], primaryActionIcon: [1, "primaryActionIcon"], primaryActionDisabled: [1, "primaryActionDisabled"] }, outputs: { queryChange: "queryChange", rowAction: "rowAction", primaryAction: "primaryAction" }, decls: 14, vars: 5, consts: [[1, "drx-data-table"], [1, "drx-data-table__toolbar"], [1, "drx-data-table__scroll"], [3, "width", "class"], [1, "drx-data-table__actions-heading"], [1, "drx-data-table__filters-row"], [1, "drx-data-table__pagination"], [1, "drx-data-table__title"], [1, "drx-data-table__title-icon"], [1, "drx-data-table__toolbar-actions"], [1, "drx-data-table__search"], ["type", "button", "variant", "primary", "size", "medium", 3, "disabled"], [3, "name"], ["type", "search", 3, "valueChange", "placeholder", "value"], ["type", "button", "variant", "primary", "size", "medium", 3, "click", "disabled"], ["type", "button", 1, "drx-data-table__heading", 3, "click", "disabled"], [1, "drx-data-table__sort-indicator"], [3, "placeholder", "options", "value"], [3, "value"], ["type", "search", 3, "placeholder", "value"], [3, "valueChange", "placeholder", "options", "value"], [3, "valueChange", "value"], [1, "drx-data-table__empty", "quicksand-sm"], [1, "quicksand-sm", 3, "class"], [1, "drx-data-table__row-actions", "quicksand-sm"], [1, "quicksand-sm"], [3, "label", "tone", "size", "icon"], ["type", "button", 1, "drx-data-table__action", 3, "title", "disabled"], ["type", "button", 1, "drx-data-table__action", 3, "click", "title", "disabled"], [1, "drx-data-table__page-size"], [1, "gothic-sm", "bolder-font"], [3, "valueChange", "value", "options"], [1, "drx-data-table__range", "gothic-sm", "bolder-font"], [1, "drx-data-table__page-controls"], ["type", "button", "aria-label", "P\xE1gina anterior", 3, "click", "disabled"], [1, "drx-data-table__current-page", "gothic-sm"], ["type", "button", "aria-label", "Pr\xF3xima p\xE1gina", 3, "click", "disabled"]], template: function (i, o) { i & 1 && (e.\u0275\u0275elementStart(0, "section", 0), e.\u0275\u0275conditionalCreate(1, Qt, 7, 4, "header", 1), e.\u0275\u0275elementStart(2, "div", 2)(3, "table")(4, "thead")(5, "tr"), e.\u0275\u0275repeaterCreate(6, Ut, 5, 9, "th", 3, y), e.\u0275\u0275conditionalCreate(8, Gt, 2, 0, "th", 4), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(9, nn, 4, 1, "tr", 5), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(10, "tbody"), e.\u0275\u0275conditionalCreate(11, on, 3, 2, "tr")(12, _n, 3, 1), e.\u0275\u0275elementEnd()()(), e.\u0275\u0275conditionalCreate(13, mn, 16, 11, "footer", 6), e.\u0275\u0275elementEnd()), i & 2 && (e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.title() || o.searchable() || o.primaryActionLabel() ? 1 : -1), e.\u0275\u0275advance(5), e.\u0275\u0275repeater(o.columns()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.actions().length > 0 ? 8 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.columnFilters() ? 9 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.loading() ? 11 : 12), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.pagination() ? 13 : -1)); }, dependencies: [re, to, Zi, eo, v, Ji], styles: ["[_nghost-%COMP%]{display:block;width:100%;min-width:0}.drx-data-table[_ngcontent-%COMP%]{width:100%;min-width:0;overflow:hidden;background:var(--drx-color-surface-default, #fff);border:1px solid var(--drx-color-border-default, #d6d8e7);border-radius:var(--drx-radius-card, 10px)}.drx-data-table__toolbar[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;gap:16px;min-height:58px;padding:10px 16px;border-bottom:1px solid var(--ex-gray-scale-300, #e6e8f0)}.drx-data-table__title[_ngcontent-%COMP%], .drx-data-table__toolbar-actions[_ngcontent-%COMP%], .drx-data-table__search[_ngcontent-%COMP%], .drx-data-table__page-controls[_ngcontent-%COMP%], .drx-data-table__page-size[_ngcontent-%COMP%]{display:flex;align-items:center}.drx-data-table__title[_ngcontent-%COMP%]{gap:10px;color:var(--drx-color-heading, #252831);font-family:var(--drx-font-family-display)}.drx-data-table__title-icon[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;color:#fff;background:var(--drx-brand-primary, #c00d0e);border-radius:50%}.drx-data-table__toolbar-actions[_ngcontent-%COMP%]{gap:12px}.drx-data-table__search[_ngcontent-%COMP%]{gap:8px;min-width:min(360px,40vw)}.drx-data-table__search[_ngcontent-%COMP%]   drx-input[_ngcontent-%COMP%]{flex:1 1 auto;min-width:0}.drx-data-table__scroll[_ngcontent-%COMP%]{width:100%;overflow-x:auto}.drx-data-table[_ngcontent-%COMP%]   table[_ngcontent-%COMP%]{width:100%;min-width:760px;border-collapse:collapse}.drx-data-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], .drx-data-table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{padding:11px 16px;color:var(--drx-color-text-default, #3d4960);vertical-align:middle;border-bottom:1px solid var(--ex-gray-scale-300, #edf0f3)}.drx-data-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]{background:var(--ex-gray-scale-200, #fafbfc)}.drx-data-table[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:hover{background:#14142b05}.drx-data-table__heading[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:7px;padding:0;color:var(--drx-color-text-muted, #687386);background:transparent;border:0;font:inherit;font-family:var(--drx-font-family-display);font-size:var(--drx-font-size-body-sm, 13px);font-weight:600}.drx-data-table__heading--sortable[_ngcontent-%COMP%]{cursor:pointer}.drx-data-table__heading[_ngcontent-%COMP%]:disabled{opacity:1}.drx-data-table__sort-indicator[_ngcontent-%COMP%]{color:var(--drx-brand-primary, #c00d0e);font-size:9px}.drx-data-table__filters-row[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]{padding-top:8px;padding-bottom:8px;background:var(--drx-color-surface-default, #fff)}.drx-data-table__filters-row[_ngcontent-%COMP%]   drx-input[_ngcontent-%COMP%], .drx-data-table__filters-row[_ngcontent-%COMP%]   drx-select[_ngcontent-%COMP%], .drx-data-table__filters-row[_ngcontent-%COMP%]   drx-calendar[_ngcontent-%COMP%]{display:block;min-width:130px}.drx-data-table__cell--left[_ngcontent-%COMP%]{text-align:left}.drx-data-table__cell--center[_ngcontent-%COMP%]{text-align:center}.drx-data-table__cell--right[_ngcontent-%COMP%]{text-align:right}.drx-data-table__actions-heading[_ngcontent-%COMP%]{font-family:var(--drx-font-family-display);font-size:var(--drx-font-size-body-sm, 13px);font-weight:600;color:var(--drx-color-text-muted, #687386)}.drx-data-table__actions-heading[_ngcontent-%COMP%], .drx-data-table__row-actions[_ngcontent-%COMP%]{width:104px;text-align:center;white-space:nowrap}.drx-data-table__action[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;padding:0;color:var(--drx-color-text-default, #3d4960);cursor:pointer;background:transparent;border:0;border-radius:6px}.drx-data-table__action[_ngcontent-%COMP%]:hover:not(:disabled){color:var(--drx-brand-primary, #c00d0e);background:var(--ex-gray-scale-200, #f2f3f8)}.drx-data-table__action[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--drx-color-focus, var(--drx-brand-primary, #c00d0e));outline-offset:2px}.drx-data-table__action[_ngcontent-%COMP%]:disabled{cursor:default;opacity:.35}.drx-data-table__empty[_ngcontent-%COMP%]{padding:32px 18px!important;text-align:center;color:var(--drx-color-text-muted, #7b8493)}.drx-data-table__pagination[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:flex-end;gap:18px;min-height:50px;padding:8px 16px;color:var(--drx-color-text-muted, #5c6677);border-top:1px solid var(--ex-gray-scale-300, #edf0f3)}.drx-data-table__page-size[_ngcontent-%COMP%]{gap:8px;margin-right:auto}.drx-data-table__page-size[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]{min-height:32px;padding:4px 28px 4px 9px;background:#fff;border:1px solid var(--drx-color-border-default, #d6d8e7);border-radius:6px}.drx-data-table__page-controls[_ngcontent-%COMP%]{gap:8px}.drx-data-table__page-controls[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;padding:0;cursor:pointer;background:#fff;border:1px solid var(--drx-color-border-default, #d6d8e7);border-radius:6px}.drx-data-table__page-controls[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:disabled{cursor:default;opacity:.35}.drx-data-table__current-page[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;min-width:32px;height:32px;color:var(--drx-brand-primary, #c00d0e);border:1px solid currentColor;border-radius:6px}@media(max-width:800px){.drx-data-table__toolbar[_ngcontent-%COMP%], .drx-data-table__toolbar-actions[_ngcontent-%COMP%], .drx-data-table__pagination[_ngcontent-%COMP%]{align-items:stretch;flex-direction:column}.drx-data-table__search[_ngcontent-%COMP%]{width:100%;min-width:0}.drx-data-table__page-size[_ngcontent-%COMP%]{margin-right:0}.drx-data-table__pagination[_ngcontent-%COMP%]{align-items:flex-end}}"], changeDetection: 0 });
} return n; })(), U = (() => { class n {
    columnKey = r.required({ alias: "drxEditableCell" });
    template = M(T);
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = e.\u0275\u0275defineDirective({ type: n, selectors: [["ng-template", "drxEditableCell", ""]], inputs: { columnKey: [1, "drxEditableCell", "columnKey"] } });
} return n; })(), G = (() => { class n {
    columnKey = r.required({ alias: "drxEditableEditor" });
    template = M(T);
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = e.\u0275\u0275defineDirective({ type: n, selectors: [["ng-template", "drxEditableEditor", ""]], inputs: { columnKey: [1, "drxEditableEditor", "columnKey"] } });
} return n; })(), J = (() => { class n {
    template = M(T);
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = e.\u0275\u0275defineDirective({ type: n, selectors: [["ng-template", "drxEditableRowDetails", ""]] });
} return n; })(), Y = (() => { class n {
    template = M(T);
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = e.\u0275\u0275defineDirective({ type: n, selectors: [["ng-template", "drxEditableRowActions", ""]] });
} return n; })(), Eo = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = e.\u0275\u0275defineDirective({ type: n, selectors: [["", "drxEditableCommitOnEnter", ""]] });
} return n; })(), To = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = e.\u0275\u0275defineDirective({ type: n, selectors: [["", "drxEditableNextOnEnter", ""]] });
} return n; })(), So = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = e.\u0275\u0275defineDirective({ type: n, selectors: [["", "drxEditableAutofocus", ""]] });
} return n; })(), Z = (() => { class n {
    columnKey = r.required({ alias: "drxEditableTreeCell" });
    template = M(T);
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = e.\u0275\u0275defineDirective({ type: n, selectors: [["ng-template", "drxEditableTreeCell", ""]], inputs: { columnKey: [1, "drxEditableTreeCell", "columnKey"] } });
} return n; })(), ko = (() => { class n {
    columns = r.required();
    rows = C([]);
    draft = C.required();
    rowKey = r.required();
    createDraft = r.required();
    toDraft = r.required();
    createRow = r.required();
    updateRow = r.required();
    mergeRow = r(null);
    validate = r(() => ({}));
    findDuplicate = r(null);
    duplicateStrategy = r("reject");
    duplicateErrorText = r("Este item j\xE1 foi adicionado.");
    editable = r(!0);
    busy = r(!1);
    showActions = r(!0);
    canEditRow = r(() => !0);
    canRemoveRow = r(() => !0);
    rowState = r(() => null);
    rowChildren = r(null);
    isRowExpandable = r(null);
    rowChildrenStatus = r(() => "");
    treeColumn = r(null);
    treeRowLabel = r(() => "itens da linha");
    expandedRowKeys = C([]);
    expandedTreeKeys = C([]);
    rowExpansionChange = p();
    treeExpansionChange = p();
    treeCellDefinitions = F(Z, { descendants: !0 });
    visibleTreeRows = u(() => { let t = new Map, i = this.rowChildren(); if (!i)
        return t; let o = new Set(this.expandedTreeKeys()), d = new Set(this.expandedRowKeys()); for (let l of this.rows()) {
        let c = this.rowKey()(l);
        if (!d.has(c))
            continue;
        let s = [], _ = (m, x, b) => { for (let h of m) {
            if (b.has(h))
                continue;
            let f = [...x, h.key], O = this.treeKey(c, f);
            s.push({ node: h, path: f, key: O, depth: f.length }), o.has(O) && h.children?.length && _(h.children, f, new Set([...b, h]));
        } };
        _(i(l), [], new Set), t.set(c, s);
    } return t; });
    treeCellTemplate(t) { return this.treeCellDefinitions().find(i => i.columnKey() === t); }
    isTreeColumn(t) { return t === (this.treeColumn() ?? this.columns()[0]?.key); }
    canExpand(t) { return this.rowChildren() !== null && (this.isRowExpandable()?.(t) ?? !!this.rowChildren()?.(t).length); }
    isRowExpanded(t) { return this.expandedRowKeys().includes(this.rowKey()(t)); }
    toggleRowExpansion(t, i) { if (i?.stopPropagation(), !this.canExpand(t))
        return; let o = this.rowKey()(t), d = !this.isRowExpanded(t); this.expandedRowKeys.update(l => d ? [...l, o] : l.filter(c => c !== o)), this.rowExpansionChange.emit({ row: t, expanded: d }); }
    canExpandTreeNode(t) { return t.expandable ?? !!t.children?.length; }
    isTreeNodeExpanded(t) { return this.expandedTreeKeys().includes(t); }
    toggleTreeExpansion(t, i, o) { if (o?.stopPropagation(), !this.canExpandTreeNode(i.node))
        return; let d = !this.isTreeNodeExpanded(i.key); this.expandedTreeKeys.update(l => d ? [...l, i.key] : l.filter(c => c !== i.key)), this.treeExpansionChange.emit({ row: t, node: i.node, path: i.path, expanded: d }); }
    treeKey(t, i) { return JSON.stringify([t, ...i]); }
    isDraftEmpty = r(null);
    confirmRemove = r(null);
    ariaLabel = r("Tabela edit\xE1vel");
    emptyText = r("Nenhum item cadastrado.");
    actionsLabel = r("A\xE7\xF5es");
    addLabel = r("Adicionar item");
    saveLabel = r("Salvar altera\xE7\xE3o");
    columnMinimum(t) { let i = t.key.toLowerCase(), o = t.label.toLowerCase(); return /action|acoes|ações/.test(i) ? 130 : /description|descricao|descrição|composition|composicao|composição|supply|insumo|servico|serviço|item/.test(i) || /descrição|composição|insumo|serviço/.test(o) ? 320 : /note|observ|especifica/.test(i + o) ? 190 : /price|valor|discount|desconto|total|quant|quantity/.test(i + o) ? 155 : /bdi/.test(i) ? 145 : /unit|unidade|order|ordem/.test(i + o) ? 105 : t.editor && t.editor !== "readonly" && t.editor !== "none" ? 150 : 130; }
    columnWidthPx(t) { let i = t.width?.trim(), o = this.columnMinimum(t); if (i) {
        let d = /^([\d.]+)px$/i.exec(i);
        if (d)
            return Math.max(o, Number(d[1]));
        let l = /^([\d.]+)rem$/i.exec(i);
        if (l)
            return Math.max(o, Number(l[1]) * 16);
        let c = /^([\d.]+)%$/.exec(i);
        if (c)
            return Math.max(o, Math.round(Number(c[1]) * 12));
    } return o; }
    tableMinWidthPx = u(() => this.columns().reduce((t, i) => t + this.columnWidthPx(i), this.showActions() ? 150 : 0));
    responsiveLayout = r("scroll");
    rowAdded = p();
    rowChanged = p();
    rowRemoved = p();
    committed = p();
    duplicateFound = p();
    invalidCommit = p();
    editStarted = p();
    editCancelled = p();
    editingKey = g(null);
    tableError = g("");
    validationAttempted = g(!1);
    touchedColumns = g(new Set);
    isEditing = u(() => this.editingKey() !== null);
    validationErrors = u(() => this.validate()(this.draft()));
    canCommit = u(() => this.editable() && !this.busy() && Object.keys(this.validationErrors()).length === 0);
    draftDirty = u(() => { let t = this.draft(), i = this.isDraftEmpty(); return i ? !i(t) : JSON.stringify(t) !== JSON.stringify(this.createDraft()()); });
    draftRow = D("draftRow");
    cellDefinitions = F(U, { descendants: !0 });
    editorDefinitions = F(G, { descendants: !0 });
    rowDetailsDefinition = K(J);
    rowActionsDefinition = K(Y);
    patchDraftContext = t => this.patchDraft(t);
    cellTemplate(t) { return this.cellDefinitions().find(i => i.columnKey() === t); }
    editorTemplate(t) { return this.editorDefinitions().find(i => i.columnKey() === t); }
    rowDetailsTemplate() { return this.rowDetailsDefinition(); }
    rowActionsTemplate() { return this.rowActionsDefinition(); }
    renderedColumnCount() { return this.columns().length + (this.showActions() ? 1 : 0); }
    isEditingRow(t) { return this.editingKey() === this.rowKey()(t); }
    patchDraft(t) { this.tableError.set(""), this.draft.update(i => w(w({}, i), t)); }
    markColumnTouched(t, i) { let o = i?.currentTarget, d = i?.relatedTarget; o && d && o.contains(d) || this.touchedColumns.update(l => { if (l.has(t))
        return l; let c = new Set(l); return c.add(t), c; }); }
    visibleColumnErrors(t) { return !this.validationAttempted() && !this.touchedColumns().has(t) ? [] : this.columnErrors(t); }
    startEditing(t) { !this.editable() || this.busy() || !this.canEditRow()(t) || (this.tableError.set(""), this.resetValidationState(), this.editingKey.set(this.rowKey()(t)), this.draft.set(this.toDraft()(t)), this.editStarted.emit(t), this.focusFirstEditor()); }
    cancelEditing() { !this.isEditing() && !this.draftDirty() || (this.resetDraft(), this.editCancelled.emit()); }
    remove(t) { return B(this, null, function* () { if (!this.editable() || this.busy() || !this.canRemoveRow()(t))
        return; let i = this.confirmRemove(); if (i && !(yield i(t)))
        return; let o = this.rows(), d = this.rowKey()(t), l = o.findIndex(s => this.rowKey()(s) === d); if (l < 0)
        return; this.rows.set(o.filter((s, _) => _ !== l)), this.expandedRowKeys.update(s => s.filter(_ => _ !== d)); let c = JSON.stringify([d]).slice(0, -1) + ","; this.expandedTreeKeys.update(s => s.filter(_ => !_.startsWith(c))), this.rowRemoved.emit({ row: t, index: l }), this.editingKey() === d && this.resetDraft(); }); }
    commitDraft() { this.validationAttempted.set(!0); let t = this.validationErrors(); if (!this.canCommit()) {
        this.invalidCommit.emit(t), this.focusFirstInvalidEditor(t);
        return;
    } let i = this.draft(), o = this.rows(), d = this.editingKey(), l = d === null ? -1 : o.findIndex(b => this.rowKey()(b) === d), c = this.findDuplicate()?.(o, i), s = c ? o.findIndex(b => this.rowKey()(b) === this.rowKey()(c)) : -1; if (s >= 0 && s !== l && this.duplicateStrategy() !== "allow") {
        let b = this.duplicateStrategy();
        if (this.duplicateFound.emit({ existing: c, draft: i, strategy: b }), b === "reject" || l >= 0) {
            this.tableError.set(this.duplicateErrorText()), this.focusFirstEditor();
            return;
        }
        let f = (b === "merge" && this.mergeRow() ? this.mergeRow() : this.updateRow())(c, i);
        this.replaceRow(s, f, b === "merge" ? "merged" : "replaced");
        return;
    } if (l >= 0) {
        let b = this.updateRow()(o[l], i);
        this.replaceRow(l, b, "updated");
        return;
    } let m = this.createRow()(i), x = o.length; this.rows.set([...o, m]), this.rowAdded.emit(m), this.committed.emit({ row: m, mode: "inserted", index: x }), this.resetDraft(!0); }
    handleDraftKeydown(t) { if (t.defaultPrevented || t.isComposing || t.repeat || !this.editable() || this.busy())
        return; let i = t.target; if (!(i instanceof HTMLElement) || i.closest('[aria-expanded="true"]'))
        return; if (t.key === "Escape") {
        t.preventDefault(), t.stopPropagation(), this.cancelEditing();
        return;
    } if (t.key !== "Enter" || t.altKey || t.ctrlKey || t.metaKey || t.shiftKey)
        return; let o = i.closest("[drxEditableCommitOnEnter]"), d = i.closest("[drxEditableNextOnEnter]"); !o && !d || (t.preventDefault(), t.stopPropagation(), (o || !this.focusNextEditor(i)) && this.commitDraft()); }
    displayValue(t, i) { if (i.display)
        return i.display(t); let o = i.value(t); return o == null || o === "" ? "-" : String(o); }
    draftValue(t) { if (t.draftValue)
        return t.draftValue(this.draft()); let i = t.draftField ?? t.key; return this.draft()[i] ?? ""; }
    columnErrors(t) { let i = this.validationErrors()[t]; return i ? typeof i == "string" ? [i] : i : []; }
    updateDefaultEditor(t, i) { let o = i.target, d = t.draftField ?? t.key, l = t.editor === "number" ? this.parseNullableNumber(o.value) : o.value; this.patchDraft({ [d]: l }); }
    isLastEditableColumn(t) { return this.columns().filter(o => o.editor !== "none" && o.editor !== "readonly").at(-1)?.key === t.key; }
    isFirstEditableColumn(t) { return this.columns().filter(o => o.editor !== "none" && o.editor !== "readonly")[0]?.key === t.key; }
    replaceRow(t, i, o) { let d = this.rows(), l = d[t]; this.rows.set(d.map((c, s) => s === t ? i : c)), this.rowChanged.emit({ previous: l, current: i, index: t }), this.committed.emit({ row: i, mode: o, index: t }), this.resetDraft(o !== "updated"); }
    resetDraft(t = !1) { this.tableError.set(""), this.editingKey.set(null), this.resetValidationState(), this.draft.set(this.createDraft()()), t && this.focusFirstEditor(); }
    resetValidationState() { this.validationAttempted.set(!1), this.touchedColumns.set(new Set); }
    focusFirstInvalidEditor(t) { let i = this.columns().find(o => t[o.key])?.key; if (!i) {
        this.focusFirstEditor();
        return;
    } queueMicrotask(() => { let o = [...this.draftRow()?.nativeElement.querySelectorAll("[data-column-key]") ?? []].find(d => d.dataset.columnKey === i); this.resolveFocusable(o)?.focus(); }); }
    focusFirstEditor() { queueMicrotask(() => { let t = this.draftRow()?.nativeElement, i = t?.querySelector("[drxEditableAutofocus]"), o = t?.querySelector('input:not([readonly]):not([disabled]), select:not([disabled]), textarea:not([readonly]):not([disabled]), button:not([disabled]), [tabindex]:not([tabindex="-1"])'); this.resolveFocusable(i ?? o)?.focus(); }); }
    focusNextEditor(t) { let i = this.draftRow()?.nativeElement; if (!i)
        return !1; let o = t.closest("[data-column-key]"), d = Array.from(i.children).filter(c => c instanceof HTMLElement && c.hasAttribute("data-column-key")), l = o ? d.indexOf(o) : -1; if (l < 0)
        return !1; for (let c of d.slice(l + 1)) {
        let s = this.resolveFocusable(c);
        if (s)
            return s.focus(), !0;
    } return !1; }
    resolveFocusable(t) { return t ? t.matches("input, select, textarea, button, [tabindex]") ? t : t.querySelector('input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), [tabindex]:not([tabindex="-1"])') : null; }
    parseNullableNumber(t) { let i = t.trim().replace(/\s/g, "").replace(",", "."); if (!i)
        return null; let o = Number(i); return Number.isFinite(o) ? o : null; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-editable-table"]], contentQueries: function (i, o, d) { i & 1 && e.\u0275\u0275contentQuerySignal(d, o.treeCellDefinitions, Z, 5)(d, o.cellDefinitions, U, 5)(d, o.editorDefinitions, G, 5)(d, o.rowDetailsDefinition, J, 5)(d, o.rowActionsDefinition, Y, 5), i & 2 && e.\u0275\u0275queryAdvance(5); }, viewQuery: function (i, o) { i & 1 && e.\u0275\u0275viewQuerySignal(o.draftRow, xn, 5), i & 2 && e.\u0275\u0275queryAdvance(); }, inputs: { columns: [1, "columns"], rows: [1, "rows"], draft: [1, "draft"], rowKey: [1, "rowKey"], createDraft: [1, "createDraft"], toDraft: [1, "toDraft"], createRow: [1, "createRow"], updateRow: [1, "updateRow"], mergeRow: [1, "mergeRow"], validate: [1, "validate"], findDuplicate: [1, "findDuplicate"], duplicateStrategy: [1, "duplicateStrategy"], duplicateErrorText: [1, "duplicateErrorText"], editable: [1, "editable"], busy: [1, "busy"], showActions: [1, "showActions"], canEditRow: [1, "canEditRow"], canRemoveRow: [1, "canRemoveRow"], rowState: [1, "rowState"], rowChildren: [1, "rowChildren"], isRowExpandable: [1, "isRowExpandable"], rowChildrenStatus: [1, "rowChildrenStatus"], treeColumn: [1, "treeColumn"], treeRowLabel: [1, "treeRowLabel"], expandedRowKeys: [1, "expandedRowKeys"], expandedTreeKeys: [1, "expandedTreeKeys"], isDraftEmpty: [1, "isDraftEmpty"], confirmRemove: [1, "confirmRemove"], ariaLabel: [1, "ariaLabel"], emptyText: [1, "emptyText"], actionsLabel: [1, "actionsLabel"], addLabel: [1, "addLabel"], saveLabel: [1, "saveLabel"], responsiveLayout: [1, "responsiveLayout"] }, outputs: { rows: "rowsChange", draft: "draftChange", expandedRowKeys: "expandedRowKeysChange", expandedTreeKeys: "expandedTreeKeysChange", rowExpansionChange: "rowExpansionChange", treeExpansionChange: "treeExpansionChange", rowAdded: "rowAdded", rowChanged: "rowChanged", rowRemoved: "rowRemoved", committed: "committed", duplicateFound: "duplicateFound", invalidCommit: "invalidCommit", editStarted: "editStarted", editCancelled: "editCancelled" }, decls: 24, vars: 10, consts: [["editorCellsTemplate", ""], ["editorActionsTemplate", ""], ["draftRow", ""], [1, "drx-editable-table"], [1, "drx-editable-table__scroll"], [1, "drx-editable-table__caption"], [3, "width"], [1, "drx-editable-table__actions-column"], ["scope", "col", 3, "class"], ["scope", "col", 1, "drx-editable-table__actions-heading"], [1, "drx-editable-table__draft"], [1, "drx-editable-table__editor-cell", 3, "class", "drx-editable-table__editor-cell--invalid"], [1, "drx-editable-table__editor-cell", 3, "focusout"], [1, "drx-editable-table__field"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], ["role", "alert", 1, "drx-editable-table__field-error"], ["readonly", "", "tabindex", "-1", 3, "value"], [3, "type", "placeholder", "value"], [3, "input", "type", "placeholder", "value"], ["data-label", "A\xE7\xF5es", 1, "drx-editable-table__row-actions"], ["type", "button", 1, "drx-editable-table__action", "drx-editable-table__action--commit", 3, "click", "title", "disabled"], [3, "name"], ["type", "button", "aria-label", "Cancelar edi\xE7\xE3o", "title", "Cancelar edi\xE7\xE3o", 1, "drx-editable-table__action", "drx-editable-table__action--cancel-edit", 3, "disabled"], ["type", "button", "aria-label", "Cancelar edi\xE7\xE3o", "title", "Cancelar edi\xE7\xE3o", 1, "drx-editable-table__action", "drx-editable-table__action--cancel-edit", 3, "click", "disabled"], ["name", "circle-slash"], ["scope", "col"], [1, "drx-editable-table__draft", "drx-editable-table__draft--editing"], [1, "drx-editable-table__draft", "drx-editable-table__draft--editing", 3, "keydown"], [3, "ngTemplateOutlet"], [3, "class"], ["type", "button", 1, "drx-editable-table__expand", 3, "is-expanded"], [1, "drx-editable-table__cell-content"], ["type", "button", 1, "drx-editable-table__expand", 3, "click"], ["name", "chevron-right"], ["type", "button", "aria-label", "Editar item", "title", "Editar item", 1, "drx-editable-table__action", "drx-editable-table__action--edit", 3, "click", "disabled"], ["name", "pencil"], ["type", "button", "aria-label", "Excluir item", "title", "Excluir item", 1, "drx-editable-table__action", "drx-editable-table__action--remove", 3, "click", "disabled"], ["name", "trash"], [1, "drx-editable-table__tree-status"], ["role", "status"], [1, "drx-editable-table__tree-row"], [1, "drx-editable-table__empty", "quicksand-sm"], [1, "drx-editable-table__draft", 3, "keydown"], ["role", "alert", 1, "drx-editable-table__table-error"]], template: function (i, o) { i & 1 && (e.\u0275\u0275elementStart(0, "section", 3), e.\u0275\u0275template(1, En, 2, 0, "ng-template", null, 0, e.\u0275\u0275templateRefExtractor)(3, kn, 1, 1, "ng-template", null, 1, e.\u0275\u0275templateRefExtractor), e.\u0275\u0275elementStart(5, "div", 4)(6, "table")(7, "caption", 5), e.\u0275\u0275text(8), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(9, "colgroup"), e.\u0275\u0275repeaterCreate(10, Nn, 1, 2, "col", 6, y), e.\u0275\u0275conditionalCreate(12, Fn, 1, 0, "col", 7), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(13, "thead")(14, "tr"), e.\u0275\u0275repeaterCreate(15, In, 2, 3, "th", 8, y), e.\u0275\u0275conditionalCreate(17, An, 2, 1, "th", 9), e.\u0275\u0275elementEnd()(), e.\u0275\u0275elementStart(18, "tbody"), e.\u0275\u0275repeaterCreate(19, oi, 2, 1, null, null, vn, !0, ai, 3, 2, "tr"), e.\u0275\u0275conditionalCreate(22, ri, 4, 2, "tr", 10), e.\u0275\u0275conditionalCreate(23, di, 3, 2, "tr"), e.\u0275\u0275elementEnd()()()()), i & 2 && (e.\u0275\u0275attribute("aria-busy", o.busy())("data-responsive-layout", o.responsiveLayout()), e.\u0275\u0275advance(6), e.\u0275\u0275styleProp("min-width", o.tableMinWidthPx(), "px"), e.\u0275\u0275advance(2), e.\u0275\u0275textInterpolate1(" ", o.ariaLabel(), " "), e.\u0275\u0275advance(2), e.\u0275\u0275repeater(o.columns()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.showActions() ? 12 : -1), e.\u0275\u0275advance(3), e.\u0275\u0275repeater(o.columns()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.showActions() ? 17 : -1), e.\u0275\u0275advance(2), e.\u0275\u0275repeater(o.rows()), e.\u0275\u0275advance(3), e.\u0275\u0275conditional(o.editable() && !o.isEditing() ? 22 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.tableError() ? 23 : -1)); }, dependencies: [ee, v], styles: ['@charset "UTF-8";[_nghost-%COMP%]{display:block;width:100%;min-width:0}.drx-editable-table[_ngcontent-%COMP%]{width:100%;min-width:0;overflow:hidden;background:var(--drx-color-surface-default, #fff);border:1px solid var(--drx-color-border-default, #d6d8e7);border-radius:var(--drx-radius-card, 10px)}.drx-editable-table__scroll[_ngcontent-%COMP%]{width:100%;overflow-x:auto}.drx-editable-table[_ngcontent-%COMP%]   table[_ngcontent-%COMP%]{width:100%;min-width:760px;border-collapse:collapse;table-layout:fixed;font-family:var(--drx-font-family-base, "Quicksand", Arial, sans-serif)}.drx-editable-table[data-responsive-layout=scroll][_ngcontent-%COMP%]   table[_ngcontent-%COMP%]{table-layout:fixed}.drx-editable-table__caption[_ngcontent-%COMP%]{position:absolute;width:1px;height:1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.drx-editable-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], .drx-editable-table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{padding:11px 16px;color:var(--drx-color-text-default, #3d4960);vertical-align:middle;border-bottom:1px solid var(--ex-gray-scale-300, #edf0f3)}.drx-editable-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]{color:var(--drx-color-text-muted, #687386);font-family:var(--drx-font-family-display);font-size:var(--drx-font-size-body-sm, 13px);font-weight:600;background:var(--ex-gray-scale-200, #fafbfc)}.drx-editable-table[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:not(.drx-editable-table__draft):hover{background:#14142b05}.drx-editable-table[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[data-state=inserted][_ngcontent-%COMP%]{box-shadow:inset 4px 0 0 var(--drx-color-success, #0dcea8)}.drx-editable-table[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[data-state=updated][_ngcontent-%COMP%]{box-shadow:inset 4px 0 0 var(--drx-color-warning, #f5a623)}.drx-editable-table[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[data-state=changed][_ngcontent-%COMP%]{background:var(--drx-color-success-subtle, #f6fff9);box-shadow:inset 4px 0 0 var(--drx-color-success, #0dcea8)}.drx-editable-table[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:first-child{font-weight:bolder;font-family:var(--drx-font-family-brand, "Quicksand", Arial, sans-serif)!important}.drx-editable-table[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{font-family:var(--drx-font-family-base, "Quicksand", Arial, sans-serif)}.drx-editable-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], .drx-editable-table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{overflow-wrap:normal;word-break:normal}.drx-editable-table__cell--left[_ngcontent-%COMP%]{text-align:left}.drx-editable-table__cell--center[_ngcontent-%COMP%]{text-align:center}.drx-editable-table__cell--right[_ngcontent-%COMP%]{text-align:right}.drx-editable-table__actions-heading[_ngcontent-%COMP%], .drx-editable-table__row-actions[_ngcontent-%COMP%]{text-align:center;white-space:nowrap}.drx-editable-table__row-actions[_ngcontent-%COMP%]{padding-right:8px;padding-left:8px}.drx-editable-table__action[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;padding:0;color:var(--drx-color-text-default, #3d4960);cursor:pointer;background:transparent;border:0;border-radius:6px}.drx-editable-table__action[_ngcontent-%COMP%]:hover:not(:disabled){color:var(--drx-brand-primary, #c00d0e);background:var(--ex-gray-scale-200, #f2f3f8)}.drx-editable-table__action[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--drx-color-focus, var(--drx-brand-primary, #c00d0e));outline-offset:2px}.drx-editable-table__action[_ngcontent-%COMP%]:disabled{cursor:default;opacity:.35}.drx-editable-table__action--commit[_ngcontent-%COMP%]{color:var(--drx-green-400)}.drx-editable-table__action--edit[_ngcontent-%COMP%]{color:var(--drx-blue-400)}.drx-editable-table__action--remove[_ngcontent-%COMP%]{color:var(--drx-color-danger, #c00d0e)}.drx-editable-table__action--cancel-edit[_ngcontent-%COMP%]{color:var(--drx-yellow-400)}.drx-editable-table__empty[_ngcontent-%COMP%]{padding:28px 18px!important;color:var(--drx-color-text-muted, #7b8493);text-align:center}.drx-editable-table__draft[_ngcontent-%COMP%]{background:color-mix(in srgb,var(--drx-color-action-primary, var(--drx-brand-primary, #c00d0e)) 3%,#fff)}.drx-editable-table__draft--editing[_ngcontent-%COMP%]{box-shadow:inset 4px 0 0 var(--drx-color-warning, #f5a623)}.drx-editable-table__editor-cell[_ngcontent-%COMP%]{min-width:0;vertical-align:top}.drx-editable-table__editor-cell[_ngcontent-%COMP%]   drx-autocomplete[_ngcontent-%COMP%], .drx-editable-table__editor-cell[_ngcontent-%COMP%]   drx-input[_ngcontent-%COMP%], .drx-editable-table__editor-cell[_ngcontent-%COMP%]   drx-select[_ngcontent-%COMP%], .drx-editable-table__editor-cell[_ngcontent-%COMP%]   drx-textarea[_ngcontent-%COMP%]{display:block;width:100%;min-width:0}.drx-editable-table__editor-cell[_ngcontent-%COMP%]   input[_ngcontent-%COMP%], .drx-editable-table__editor-cell[_ngcontent-%COMP%]   select[_ngcontent-%COMP%], .drx-editable-table__editor-cell[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%]{display:block;width:100%;min-width:0;min-height:42px;padding:8px 10px;box-sizing:border-box;color:var(--drx-color-text-default, #3d4960);font:inherit;background:var(--drx-color-surface-default, #fff);border:1px solid var(--drx-color-border-default, #d6d8e7);border-radius:7px;outline:0}.drx-editable-table__editor-cell[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]:focus-visible, .drx-editable-table__editor-cell[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]:focus-visible, .drx-editable-table__editor-cell[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%]:focus-visible{border-color:var(--drx-color-focus, var(--drx-brand-primary, #c00d0e));box-shadow:0 0 0 3px #c00d0e1f}.drx-editable-table__editor-cell[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]:disabled, .drx-editable-table__editor-cell[_ngcontent-%COMP%]   input[readonly][_ngcontent-%COMP%], .drx-editable-table__editor-cell[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]:disabled, .drx-editable-table__editor-cell[_ngcontent-%COMP%]   select[readonly][_ngcontent-%COMP%], .drx-editable-table__editor-cell[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%]:disabled, .drx-editable-table__editor-cell[_ngcontent-%COMP%]   textarea[readonly][_ngcontent-%COMP%]{color:var(--drx-color-text-muted, #98a2b3);background:var(--ex-gray-scale-200, #f5f6f8);cursor:not-allowed;opacity:1}.drx-editable-table__editor-cell--invalid[_ngcontent-%COMP%]   input[_ngcontent-%COMP%], .drx-editable-table__editor-cell--invalid[_ngcontent-%COMP%]   select[_ngcontent-%COMP%], .drx-editable-table__editor-cell--invalid[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%]{border-color:var(--drx-color-danger, #c00d0e)}.drx-editable-table__field[_ngcontent-%COMP%]{display:flex;min-width:0;flex-direction:column;gap:4px}.drx-editable-table__field-error[_ngcontent-%COMP%], .drx-editable-table__table-error[_ngcontent-%COMP%]{color:var(--drx-color-danger, #c00d0e)}.drx-editable-table__field-error[_ngcontent-%COMP%]{display:block;margin-top:5px;font-size:11px;text-align:left}.drx-editable-table__table-error[_ngcontent-%COMP%]{padding:10px 16px;font-size:13px;background:var(--drx-color-danger-subtle, #fff2f2)}[_nghost-%COMP%]     .drx-editable-table tbody td{box-sizing:border-box;font-family:var(--drx-font-family-base, "Quicksand", Arial, sans-serif)}[_nghost-%COMP%]     .drx-editable-table tbody td:first-child{font-family:var(--drx-font-family-brand, "Quicksand", Arial, sans-serif)!important}[_nghost-%COMP%]     .drx-editable-table .drx-editable-table__editor-cell>input, [_nghost-%COMP%]     .drx-editable-table .drx-editable-table__editor-cell>select, [_nghost-%COMP%]     .drx-editable-table .drx-editable-table__editor-cell>textarea{display:block;width:100%;min-width:0;min-height:42px;padding:8px 10px;box-sizing:border-box;border:1px solid var(--drx-color-border-default, #d6d8e7);border-radius:7px;color:var(--drx-color-text-default, #3d4960);background:var(--drx-color-surface-default, #fff);font-family:var(--drx-font-family-base, "Quicksand", Arial, sans-serif);font-size:var(--drx-font-size-body-sm, 13px);line-height:1.25;outline:0}[_nghost-%COMP%]     .drx-editable-table .drx-editable-table__editor-cell>input:focus-visible, [_nghost-%COMP%]     .drx-editable-table .drx-editable-table__editor-cell>select:focus-visible, [_nghost-%COMP%]     .drx-editable-table .drx-editable-table__editor-cell>textarea:focus-visible{border-color:var(--drx-color-focus, var(--drx-brand-primary, #c00d0e));box-shadow:0 0 0 3px #c00d0e1f}[_nghost-%COMP%]     .drx-editable-table .drx-editable-table__editor-cell>input:disabled, [_nghost-%COMP%]     .drx-editable-table .drx-editable-table__editor-cell>input[readonly], [_nghost-%COMP%]     .drx-editable-table .drx-editable-table__editor-cell>select:disabled, [_nghost-%COMP%]     .drx-editable-table .drx-editable-table__editor-cell>select[readonly], [_nghost-%COMP%]     .drx-editable-table .drx-editable-table__editor-cell>textarea:disabled, [_nghost-%COMP%]     .drx-editable-table .drx-editable-table__editor-cell>textarea[readonly]{color:var(--drx-color-text-muted, #98a2b3);background:var(--ex-gray-scale-200, #f5f6f8);cursor:not-allowed;opacity:1}@media(max-width:800px){.drx-editable-table[data-responsive-layout=stack][_ngcontent-%COMP%]   table[_ngcontent-%COMP%]{min-width:0;table-layout:auto}.drx-editable-table[data-responsive-layout=stack][_ngcontent-%COMP%]   colgroup[_ngcontent-%COMP%], .drx-editable-table[data-responsive-layout=stack][_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]{display:none}.drx-editable-table[data-responsive-layout=stack][_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%], .drx-editable-table[data-responsive-layout=stack][_ngcontent-%COMP%]   tr[_ngcontent-%COMP%], .drx-editable-table[data-responsive-layout=stack][_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{display:block;width:100%;box-sizing:border-box}.drx-editable-table[data-responsive-layout=stack][_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]{padding:10px 12px;border-bottom:1px solid var(--ex-gray-scale-300, #edf0f3)}.drx-editable-table[data-responsive-layout=stack][_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{display:grid;grid-template-columns:minmax(110px,36%) 1fr;gap:10px;padding:7px 4px;text-align:left;border:0}.drx-editable-table[data-responsive-layout=stack][_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:before{color:var(--drx-color-text-muted, #687386);font-family:var(--drx-font-family-display);font-size:12px;font-weight:600;content:attr(data-label)}.drx-editable-table[data-responsive-layout=stack][_ngcontent-%COMP%]   .drx-editable-table__row-actions[_ngcontent-%COMP%]{display:flex;justify-content:flex-end}.drx-editable-table[data-responsive-layout=stack][_ngcontent-%COMP%]   .drx-editable-table__empty[_ngcontent-%COMP%], .drx-editable-table[data-responsive-layout=stack][_ngcontent-%COMP%]   .drx-editable-table__table-error[_ngcontent-%COMP%]{display:block}}.drx-editable-table__tree-cell[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px;min-width:0}.drx-editable-table__cell-content[_ngcontent-%COMP%]{min-width:0;overflow-wrap:break-word;word-break:normal;-webkit-hyphens:none;hyphens:none}.drx-editable-table__expand[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;flex:0 0 28px;width:28px;height:28px;padding:0;border:0;border-radius:6px;color:var(--drx-color-primary, #5f07f6);background:transparent;cursor:pointer}.drx-editable-table__expand[_ngcontent-%COMP%]   app-hub-icon[_ngcontent-%COMP%]{transition:transform .15s ease}.drx-editable-table__expand.is-expanded[_ngcontent-%COMP%]   app-hub-icon[_ngcontent-%COMP%]{transform:rotate(90deg)}.drx-editable-table__expand[_ngcontent-%COMP%]:hover{background:var(--ex-gray-scale-300, #eff0f6)}.drx-editable-table__expand[_ngcontent-%COMP%]:focus-visible{outline:2px solid currentColor;outline-offset:2px}.drx-editable-table__tree-row[_ngcontent-%COMP%]{background:var(--ex-gray-scale-200, #f7f7fc)}.drx-editable-table__tree-row[data-state=group][_ngcontent-%COMP%]{background:#f1ebfc;font-weight:600}.drx-editable-table__tree-row[data-state=disabled][_ngcontent-%COMP%]{color:var(--ex-gray-scale-600, #98a2b3)}.drx-editable-table__tree-status[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{padding:12px 24px;color:var(--ex-gray-scale-700, #4e4b66);background:var(--ex-gray-scale-200, #f7f7fc)}@media(prefers-reduced-motion:reduce){.drx-editable-table__expand[_ngcontent-%COMP%]   app-hub-icon[_ngcontent-%COMP%]{transition:none}}'], changeDetection: 0 });
} return n; })(), No = (() => { class n {
    items = r.required();
    currentRoute = r("");
    collapsed = r(!1);
    logoSrc = r("");
    compactLogoSrc = r("");
    logoAlt = r("Daruix Hub");
    logoutLabel = r("Sair");
    iconTemplate = r(null);
    brandSelected = p();
    itemSelected = p();
    logoutSelected = p();
    expandedModuleId = g(null);
    expandedCategoryId = g(null);
    flyoutModuleId = g(null);
    activePath = u(() => this.findActivePath(this.items(), this.currentRoute()));
    activeModuleId = u(() => this.activePath()?.module.id ?? null);
    activeCategoryId = u(() => this.activePath()?.category?.id ?? null);
    activeFeatureId = u(() => this.activePath()?.feature?.id ?? null);
    flyoutModule = u(() => { let t = this.flyoutModuleId(); return this.items().find(i => i.id === t) ?? null; });
    constructor() { j(() => { this.currentRoute(), this.items(); let t = this.activePath(); this.expandedModuleId.set(t?.module.id ?? null), this.expandedCategoryId.set(t?.category?.id ?? null), this.flyoutModuleId.set(null); }), j(() => { this.collapsed() || this.flyoutModuleId.set(null); }); }
    selectBrand() { this.closeFlyout(), this.brandSelected.emit(); }
    toggleModule(t) { if (t.categories.length === 0 && t.route) {
        this.emitSelection(t, null, null, t.route);
        return;
    } if (this.collapsed()) {
        this.flyoutModuleId.update(o => o === t.id ? null : t.id), this.expandedModuleId.set(t.id), this.expandedCategoryId.set(this.activeModuleId() === t.id ? this.activeCategoryId() : null);
        return;
    } let i = this.expandedModuleId() !== t.id; this.expandedModuleId.set(i ? t.id : null), this.expandedCategoryId.set(i && this.activeModuleId() === t.id ? this.activeCategoryId() : null); }
    toggleCategory(t, i) { this.expandedModuleId.set(t.id), this.expandedCategoryId.update(o => o === i.id ? null : i.id); }
    selectFeature(t, i, o) { o.disabled || !o.route?.trim() || (this.closeFlyout(), window.open(o.route, "_blank", "noopener,noreferrer")); }
    isModuleExpanded(t) { return this.expandedModuleId() === t.id; }
    isCategoryExpanded(t) { return this.expandedCategoryId() === t.id; }
    isModuleActive(t) { return this.activeModuleId() === t.id; }
    isFeatureActive(t) { return this.activeFeatureId() === t.id; }
    openFlyout(t) { !this.collapsed() || t.categories.length === 0 || (this.flyoutModuleId.set(t.id), this.expandedModuleId.set(t.id), this.expandedCategoryId.set(this.activeModuleId() === t.id ? this.activeCategoryId() : null)); }
    closeFlyout() { this.flyoutModuleId.set(null); }
    trackModule(t, i) { return i.id; }
    trackCategory(t, i) { return i.id; }
    trackFeature(t, i) { return i.id; }
    emitSelection(t, i, o, d) { this.closeFlyout(), this.itemSelected.emit({ module: t, category: i, feature: o, route: d }); }
    findActivePath(t, i) { let o = this.normalizeRoute(i), d = []; for (let c of t) {
        c.route && this.routeMatches(o, c.route) && d.push({ module: c, category: null, feature: null, normalizedRoute: this.normalizeRoute(c.route) });
        for (let s of c.categories)
            for (let _ of s.features)
                this.routeMatches(o, _.route) && d.push({ module: c, category: s, feature: _, normalizedRoute: this.normalizeRoute(_.route) });
    } d.sort((c, s) => s.normalizedRoute.length - c.normalizedRoute.length); let l = d[0]; return l ? { module: l.module, category: l.category, feature: l.feature } : null; }
    routeMatches(t, i) { let o = this.normalizeRoute(i); return t === o || t.startsWith(`${o}/`); }
    normalizeRoute(t) { return t && t.split("?")[0].split("#")[0].replace(/\/+$/, "") || "/"; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-sidebar"]], hostVars: 2, hostBindings: function (i, o) { i & 2 && e.\u0275\u0275classProp("is-collapsed", o.collapsed()); }, inputs: { items: [1, "items"], currentRoute: [1, "currentRoute"], collapsed: [1, "collapsed"], logoSrc: [1, "logoSrc"], compactLogoSrc: [1, "compactLogoSrc"], logoAlt: [1, "logoAlt"], logoutLabel: [1, "logoutLabel"], iconTemplate: [1, "iconTemplate"] }, outputs: { brandSelected: "brandSelected", itemSelected: "itemSelected", logoutSelected: "logoutSelected" }, decls: 12, vars: 4, consts: [["categoryTree", ""], [1, "drx-sidebar", 3, "mouseleave"], [1, "drx-sidebar__header"], ["type", "button", "aria-label", "Ir para o in\xEDcio", 1, "drx-sidebar__brand", 3, "click"], [3, "src", "alt"], ["aria-label", "Menu principal", 1, "drx-sidebar__navigation"], [1, "drx-sidebar__modules"], [1, "drx-sidebar__module", 3, "is-expanded"], [1, "drx-sidebar__flyout"], [1, "drx-sidebar__module"], ["type", "button", 1, "drx-sidebar__module-button", 3, "click", "mouseenter"], ["aria-hidden", "true", 1, "drx-sidebar__module-icon"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], [3, "name"], [1, "drx-sidebar__module-label", "gothic-ss"], ["aria-hidden", "true", 1, "drx-sidebar__chevron"], ["name", "chevron-down"], [1, "drx-sidebar__flyout", 3, "mouseenter"], [1, "drx-sidebar__flyout-title"], [1, "drx-sidebar__categories"], [1, "drx-sidebar__category", 3, "is-expanded"], [1, "drx-sidebar__category"], ["type", "button", 1, "drx-sidebar__category-button", 3, "click"], [1, "drx-sidebar__category-content"], ["aria-hidden", "true", 1, "drx-sidebar__category-icon"], [1, "drx-sidebar__category-label", "drx-button--font-quicksand"], ["aria-hidden", "true", 1, "drx-sidebar__category-chevron"], [1, "drx-sidebar__features"], ["type", "button", 1, "drx-sidebar__feature-button", 3, "click", "disabled"], ["aria-hidden", "true", 1, "drx-sidebar__feature-icon"], [1, "drx-sidebar__feature-label", "drx-button--font-quicksand"]], template: function (i, o) { if (i & 1 && (e.\u0275\u0275elementStart(0, "aside", 1), e.\u0275\u0275listener("mouseleave", function () { return o.closeFlyout(); }), e.\u0275\u0275elementStart(1, "header", 2)(2, "button", 3), e.\u0275\u0275listener("click", function () { return o.selectBrand(); }), e.\u0275\u0275conditionalCreate(3, li, 1, 2, "img", 4)(4, ci, 1, 2, "img", 4), e.\u0275\u0275elementEnd()(), e.\u0275\u0275elementStart(5, "nav", 5)(6, "ul", 6), e.\u0275\u0275repeaterCreate(7, xi, 7, 8, "li", 7, o.trackModule, !0), e.\u0275\u0275elementEnd()(), e.\u0275\u0275conditionalCreate(9, gi, 4, 6, "section", 8), e.\u0275\u0275elementEnd(), e.\u0275\u0275template(10, Pi, 3, 0, "ng-template", null, 0, e.\u0275\u0275templateRefExtractor)), i & 2) {
            let d;
            e.\u0275\u0275classProp("is-collapsed", o.collapsed()), e.\u0275\u0275advance(3), e.\u0275\u0275conditional(!o.collapsed() && o.logoSrc() ? 3 : o.compactLogoSrc() ? 4 : -1), e.\u0275\u0275advance(4), e.\u0275\u0275repeater(o.items()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional((d = o.collapsed() && o.flyoutModule()) ? 9 : -1, d);
        } }, dependencies: [ee, v], styles: ['@charset "UTF-8";[_nghost-%COMP%]{display:block;width:var(--drx-sidebar-expanded-width, 242px);height:100%;min-height:0;transition:width .24s ease}.is-collapsed[_nghost-%COMP%]{width:var(--drx-sidebar-collapsed-width, 58px)}.drx-sidebar[_ngcontent-%COMP%]{position:relative;width:100%;height:100%;min-height:0;display:flex;flex-direction:column;color:#fff;background:linear-gradient(180deg,#151b24,#10161d 48%,#0c1117);border-right:1px solid rgba(255,255,255,.06);box-shadow:10px 0 28px #0000001f;overflow:visible}.drx-sidebar__header[_ngcontent-%COMP%]{flex:0 0 66px;display:flex;align-items:center;padding:0 16px;border-bottom:1px solid rgba(255,255,255,.06)}.drx-sidebar__brand[_ngcontent-%COMP%], .drx-sidebar__module-button[_ngcontent-%COMP%], .drx-sidebar__category-button[_ngcontent-%COMP%], .drx-sidebar__feature-button[_ngcontent-%COMP%]{border:0;font:inherit;text-align:left;cursor:pointer}.drx-sidebar__brand[_ngcontent-%COMP%]{width:100%;height:42px;display:flex;align-items:center;padding:0;background:transparent}.drx-sidebar__brand[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{display:block;max-width:100%;max-height:42px;object-fit:contain}.drx-sidebar__navigation[_ngcontent-%COMP%]{flex:1;min-height:0;padding:12px 8px;overflow-x:hidden;overflow-y:auto;scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.22) transparent}.drx-sidebar__modules[_ngcontent-%COMP%], .drx-sidebar__categories[_ngcontent-%COMP%], .drx-sidebar__features[_ngcontent-%COMP%]{padding:0;margin:0;list-style:none}.drx-sidebar__modules[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px}.drx-sidebar__module-button[_ngcontent-%COMP%]{position:relative;width:100%;min-height:40px;display:flex;align-items:center;gap:10px;padding:0 10px;border-radius:9px;color:#ffffffc7;background:transparent;transition:color .18s ease,background-color .18s ease}.drx-sidebar__module-button[_ngcontent-%COMP%]:hover{color:#fff;background:#ffffff0e}.drx-sidebar__module-button.is-active[_ngcontent-%COMP%]{color:#fff;background:#c00d0e52;box-shadow:inset 0 0 0 1px var(--drx-sidebar-accent, #e22122)}.drx-sidebar__module-icon[_ngcontent-%COMP%], .drx-sidebar__category-icon[_ngcontent-%COMP%], .drx-sidebar__feature-icon[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto}.drx-sidebar__module-icon[_ngcontent-%COMP%]   app-hub-icon[_ngcontent-%COMP%], .drx-sidebar__category-icon[_ngcontent-%COMP%]   app-hub-icon[_ngcontent-%COMP%], .drx-sidebar__feature-icon[_ngcontent-%COMP%]   app-hub-icon[_ngcontent-%COMP%]{--hub-icon-size: 16px}.drx-sidebar__module-icon[_ngcontent-%COMP%]{width:18px;height:18px}.drx-sidebar__module-label[_ngcontent-%COMP%]{flex:1;min-width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-size:13px;font-weight:700}.drx-sidebar__chevron[_ngcontent-%COMP%], .drx-sidebar__category-chevron[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;transition:transform .18s ease}.drx-sidebar__module.is-expanded[_ngcontent-%COMP%] > .drx-sidebar__module-button[_ngcontent-%COMP%]   .drx-sidebar__chevron[_ngcontent-%COMP%], .drx-sidebar__category.is-expanded[_ngcontent-%COMP%] > .drx-sidebar__category-button[_ngcontent-%COMP%]   .drx-sidebar__category-chevron[_ngcontent-%COMP%]{transform:rotate(180deg)}.drx-sidebar__categories[_ngcontent-%COMP%]{margin:5px 0 9px 28px;padding-left:12px;border-left:1px solid rgba(255,255,255,.13)}.drx-sidebar__category[_ngcontent-%COMP%] + .drx-sidebar__category[_ngcontent-%COMP%]{margin-top:2px}.drx-sidebar__category-button[_ngcontent-%COMP%]{width:100%;min-height:30px;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:2px 6px 2px 2px;color:#fffc;background:transparent;font-size:12px;font-weight:700}.drx-sidebar__category-content[_ngcontent-%COMP%]{min-width:0;display:flex;align-items:center;gap:7px}.drx-sidebar__category-icon[_ngcontent-%COMP%]{width:16px;height:16px}.drx-sidebar__category-label[_ngcontent-%COMP%], .drx-sidebar__feature-label[_ngcontent-%COMP%]{min-width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.drx-sidebar__feature-label[_ngcontent-%COMP%]{flex:1}.drx-sidebar__category-button[_ngcontent-%COMP%]:hover{color:#fff}.drx-sidebar__features[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:1px;padding:1px 0 5px 9px}.drx-sidebar__feature-button[_ngcontent-%COMP%]{position:relative;width:100%;min-height:28px;display:flex;align-items:center;gap:7px;padding:3px 7px 3px 11px;border-radius:5px;color:#ffffffa1;background:transparent;font-size:11px}.drx-sidebar__feature-button[_ngcontent-%COMP%]:before{content:"";position:absolute;left:1px;top:7px;bottom:7px;width:2px;border-radius:999px;background:transparent}.drx-sidebar__feature-button[_ngcontent-%COMP%]:hover{color:#fff;background:#ffffff0b}.drx-sidebar__feature-button.is-active[_ngcontent-%COMP%]{color:#fff;font-weight:700}.drx-sidebar__feature-button.is-active[_ngcontent-%COMP%]:before{background:var(--drx-sidebar-accent, #e22122)}.drx-sidebar__feature-button[_ngcontent-%COMP%]:disabled{opacity:.4;cursor:not-allowed}.drx-sidebar.is-collapsed[_ngcontent-%COMP%]   .drx-sidebar__header[_ngcontent-%COMP%]{justify-content:center;padding-inline:6px}.drx-sidebar.is-collapsed[_ngcontent-%COMP%]   .drx-sidebar__brand[_ngcontent-%COMP%], .drx-sidebar.is-collapsed[_ngcontent-%COMP%]   .drx-sidebar__module-button[_ngcontent-%COMP%]{justify-content:center;padding-inline:0}.drx-sidebar.is-collapsed[_ngcontent-%COMP%]   .drx-sidebar__navigation[_ngcontent-%COMP%]{padding-inline:6px}.drx-sidebar__flyout[_ngcontent-%COMP%]{position:absolute;z-index:200;left:calc(100% + 10px);top:76px;width:240px;max-height:calc(100% - 88px);padding:12px;overflow-y:auto;color:#fff;background:#151a21;border-radius:8px;box-shadow:0 18px 42px #0000005c,0 0 0 1px #ffffff14}.drx-sidebar__flyout[_ngcontent-%COMP%]:before{content:"";position:absolute;left:-10px;top:0;width:10px;height:100%}.drx-sidebar__flyout-title[_ngcontent-%COMP%]{display:block;margin-bottom:8px;font-size:13px}.drx-sidebar__flyout[_ngcontent-%COMP%]   .drx-sidebar__categories[_ngcontent-%COMP%]{margin-left:0}@media(prefers-reduced-motion:reduce){[_nghost-%COMP%], .drx-sidebar__module-button[_ngcontent-%COMP%], .drx-sidebar__chevron[_ngcontent-%COMP%], .drx-sidebar__category-chevron[_ngcontent-%COMP%]{transition:none}}'], changeDetection: 0 });
} return n; })(), no = 0, Fo = (() => { class n {
    value = C("");
    disabled = r(!1);
    readonly = r(!1);
    required = r(!1);
    invalid = r(!1);
    errors = r([]);
    name = r("");
    label = r("");
    placeholder = r("");
    autocomplete = r("off");
    id = r(null);
    rows = r(3);
    minLength = r(void 0);
    maxLength = r(void 0);
    resize = r("vertical");
    wrap = r("soft");
    touch = p();
    hasBeenTouched = g(!1);
    showValidation = u(() => this.hasBeenTouched() && this.invalid());
    textareaElement = D("textareaElement");
    textareaId = `drx-textarea-${no++}`;
    get resolvedTextareaId() { return this.id() ?? this.textareaId; }
    handleInput(t) { let i = t.target; this.value.set(i.value); }
    handleBlur() { this.hasBeenTouched.set(!0), this.touch.emit(); }
    focus(t) { this.textareaElement()?.nativeElement.focus(t); }
    reset() { this.value.set(""), this.hasBeenTouched.set(!1); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-textarea"]], viewQuery: function (i, o) { i & 1 && e.\u0275\u0275viewQuerySignal(o.textareaElement, Oi, 5), i & 2 && e.\u0275\u0275queryAdvance(); }, inputs: { value: [1, "value"], disabled: [1, "disabled"], readonly: [1, "readonly"], required: [1, "required"], invalid: [1, "invalid"], errors: [1, "errors"], name: [1, "name"], label: [1, "label"], placeholder: [1, "placeholder"], autocomplete: [1, "autocomplete"], id: [1, "id"], rows: [1, "rows"], minLength: [1, "minLength"], maxLength: [1, "maxLength"], resize: [1, "resize"], wrap: [1, "wrap"] }, outputs: { value: "valueChange", touch: "touch" }, decls: 5, vars: 19, consts: [["textareaElement", ""], [1, "drx-textarea"], [1, "drx-textarea__label", 3, "for"], [1, "drx-textarea__field", 3, "input", "blur", "id", "name", "value", "placeholder", "autocomplete", "disabled", "readonly", "required", "rows", "wrap"], ["role", "alert", 1, "drx-textarea__errors"], ["aria-hidden", "true", 1, "drx-textarea__required"], [1, "drx-textarea__error"]], template: function (i, o) { i & 1 && (e.\u0275\u0275domElementStart(0, "div", 1), e.\u0275\u0275conditionalCreate(1, Ti, 3, 3, "label", 2), e.\u0275\u0275domElementStart(2, "textarea", 3, 0), e.\u0275\u0275domListener("input", function (l) { return o.handleInput(l); })("blur", function () { return o.handleBlur(); }), e.\u0275\u0275domElementEnd(), e.\u0275\u0275conditionalCreate(4, ki, 3, 0, "div", 4), e.\u0275\u0275domElementEnd()), i & 2 && (e.\u0275\u0275classProp("drx-textarea--invalid", o.showValidation()), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.label() ? 1 : -1), e.\u0275\u0275advance(), e.\u0275\u0275styleProp("resize", o.resize()), e.\u0275\u0275domProperty("id", o.resolvedTextareaId)("name", o.name())("value", o.value())("placeholder", o.placeholder())("autocomplete", o.autocomplete())("disabled", o.disabled())("readOnly", o.readonly())("required", o.required())("rows", o.rows())("wrap", o.wrap()), e.\u0275\u0275attribute("minlength", o.minLength())("maxlength", o.maxLength())("aria-invalid", o.showValidation()), e.\u0275\u0275advance(2), e.\u0275\u0275conditional(o.showValidation() && o.errors().length > 0 ? 4 : -1)); }, styles: ["[_nghost-%COMP%]{display:block;width:100%;min-width:0}.drx-textarea[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px;width:100%;min-width:0}.drx-textarea__label[_ngcontent-%COMP%]{display:inline-flex;align-items:center;width:fit-content;margin:0;color:var(--drx-color-text-primary);font-family:var(--drx-font-family-brand);font-size:var(--drx-font-size-body-sm);font-weight:700;line-height:1.25}.drx-textarea__required[_ngcontent-%COMP%]{margin-left:2px;color:var(--drx-brand-primary)}.drx-textarea__field[_ngcontent-%COMP%]{display:block;width:100%;min-width:0;min-height:72px;padding:8px;box-sizing:border-box;color:var(--drx-color-text-primary);background-color:var(--ex-gray-scale-100, #fff);border:1px solid var(--drx-brand-secondary-hover);border-radius:8px;outline:none;font-family:var(--drx-font-family-base);font-size:var(--drx-font-size-body-sm);line-height:1.45;transition:border-color .15s ease,box-shadow .15s ease}.drx-textarea__field[_ngcontent-%COMP%]::placeholder{color:var(--ex-gray-scale-600)}.drx-textarea__field[_ngcontent-%COMP%]:hover:not(:disabled):not(:focus):not(:read-only){border-color:var(--drx-brand-secondary)}.drx-textarea__field[_ngcontent-%COMP%]:focus{border-color:var(--drx-brand-primary);box-shadow:0 0 0 2px color-mix(in srgb,var(--drx-brand-primary) 15%,transparent)}.drx-textarea__field[_ngcontent-%COMP%]:read-only{cursor:default;background-color:var(--ex-gray-scale-400)}.drx-textarea__field[_ngcontent-%COMP%]:disabled{cursor:not-allowed;background-color:var(--ex-gray-scale-400);opacity:1}.drx-textarea--invalid[_ngcontent-%COMP%]   .drx-textarea__field[_ngcontent-%COMP%]{border-color:var(--drx-brand-primary)}.drx-textarea--invalid[_ngcontent-%COMP%]   .drx-textarea__field[_ngcontent-%COMP%]:focus{box-shadow:0 0 0 2px color-mix(in srgb,var(--drx-brand-primary) 15%,transparent)}.drx-textarea__errors[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px}.drx-textarea__error[_ngcontent-%COMP%]{margin:0;color:var(--drx-brand-primary);font-family:var(--drx-font-family-base);font-size:var(--drx-font-size-caption);font-weight:700;line-height:1.25}"], changeDetection: 0 });
} return n; })(), Io = (() => { class n {
    open = r(!1);
    title = r("");
    subtitle = r("");
    position = r("right");
    width = r("min(720px, 92vw)");
    closeOnBackdrop = r(!0);
    closeOnEscape = r(!0);
    showCloseButton = r(!0);
    stickyFooter = r(!0);
    ariaLabel = r("Painel lateral");
    close = p();
    panelLabel = u(() => this.title().trim() || this.ariaLabel());
    requestClose(t) { this.open() && (t === "backdrop" && !this.closeOnBackdrop() || t === "escape" && !this.closeOnEscape() || this.close.emit(t)); }
    onEscape() { this.requestClose("escape"); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-sidenav"]], hostBindings: function (i, o) { i & 1 && e.\u0275\u0275listener("keydown.escape", function () { return o.onEscape(); }, e.\u0275\u0275resolveDocument); }, inputs: { open: [1, "open"], title: [1, "title"], subtitle: [1, "subtitle"], position: [1, "position"], width: [1, "width"], closeOnBackdrop: [1, "closeOnBackdrop"], closeOnEscape: [1, "closeOnEscape"], showCloseButton: [1, "showCloseButton"], stickyFooter: [1, "stickyFooter"], ariaLabel: [1, "ariaLabel"] }, outputs: { close: "close" }, ngContentSelectors: Fi, decls: 12, vars: 15, consts: [[1, "drx-sidenav"], ["type", "button", "tabindex", "-1", "aria-label", "Fechar painel", 1, "drx-sidenav__backdrop", 3, "click"], ["role", "dialog", "aria-modal", "true", 1, "drx-sidenav__panel"], [1, "drx-sidenav__header"], [1, "drx-sidenav__heading"], [1, "drx-sidenav__default-heading", "drx-font-gothic-body-md", "bold-font"], ["type", "button", "aria-label", "Fechar painel", 1, "drx-sidenav__close"], [1, "drx-sidenav__body"], [1, "drx-sidenav__footer"], ["type", "button", "aria-label", "Fechar painel", 1, "drx-sidenav__close", 3, "click"], ["name", "x"]], template: function (i, o) { i & 1 && (e.\u0275\u0275projectionDef(Ni), e.\u0275\u0275elementStart(0, "div", 0)(1, "button", 1), e.\u0275\u0275listener("click", function () { return o.requestClose("backdrop"); }), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(2, "aside", 2)(3, "header", 3)(4, "div", 4), e.\u0275\u0275projection(5), e.\u0275\u0275conditionalCreate(6, Ai, 4, 2, "div", 5), e.\u0275\u0275elementEnd(), e.\u0275\u0275conditionalCreate(7, zi, 2, 0, "button", 6), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(8, "section", 7), e.\u0275\u0275projection(9, 1), e.\u0275\u0275elementEnd(), e.\u0275\u0275elementStart(10, "footer", 8), e.\u0275\u0275projection(11, 2), e.\u0275\u0275elementEnd()()()), i & 2 && (e.\u0275\u0275classProp("is-open", o.open())("is-left", o.position() === "left")("is-right", o.position() === "right"), e.\u0275\u0275attribute("aria-hidden", !o.open()), e.\u0275\u0275advance(), e.\u0275\u0275attribute("aria-hidden", !o.open()), e.\u0275\u0275advance(), e.\u0275\u0275styleProp("--drx-sidenav-width", o.width()), e.\u0275\u0275attribute("aria-label", o.panelLabel()), e.\u0275\u0275advance(4), e.\u0275\u0275conditional(o.title() ? 6 : -1), e.\u0275\u0275advance(), e.\u0275\u0275conditional(o.showCloseButton() ? 7 : -1), e.\u0275\u0275advance(3), e.\u0275\u0275classProp("is-sticky", o.stickyFooter())); }, dependencies: [v], styles: ["[_nghost-%COMP%]{display:contents}.drx-sidenav[_ngcontent-%COMP%]{position:fixed;inset:0;z-index:var(--drx-sidenav-z-index, 1200);pointer-events:none}.drx-sidenav__backdrop[_ngcontent-%COMP%]{position:absolute;inset:0;width:100%;height:100%;margin:0;padding:0;border:0;background:var(--drx-sidenav-backdrop, rgba(20, 20, 43, .42));opacity:0;cursor:default;transition:opacity .18s ease}.drx-sidenav__panel[_ngcontent-%COMP%]{position:absolute;top:0;bottom:0;display:grid;grid-template-rows:auto minmax(0,1fr) auto;width:var(--drx-sidenav-width, min(720px, 92vw));max-width:100vw;min-width:0;overflow:hidden;background:var(--drx-sidenav-background, var(--drx-color-surface-default, #fff));color:var(--drx-sidenav-color, var(--drx-color-text-default, #14142b));box-shadow:var(--drx-sidenav-shadow, -12px 0 32px rgba(20, 20, 43, .14));transition:transform .22s ease}.drx-sidenav.is-right[_ngcontent-%COMP%]   .drx-sidenav__panel[_ngcontent-%COMP%]{right:0;transform:translate(102%)}.drx-sidenav.is-left[_ngcontent-%COMP%]   .drx-sidenav__panel[_ngcontent-%COMP%]{left:0;transform:translate(-102%);box-shadow:var(--drx-sidenav-shadow-left, 12px 0 32px rgba(20, 20, 43, .14))}.drx-sidenav.is-open[_ngcontent-%COMP%]{pointer-events:auto}.drx-sidenav.is-open[_ngcontent-%COMP%]   .drx-sidenav__backdrop[_ngcontent-%COMP%]{opacity:1}.drx-sidenav.is-open[_ngcontent-%COMP%]   .drx-sidenav__panel[_ngcontent-%COMP%]{transform:translate(0)}.drx-sidenav__header[_ngcontent-%COMP%]{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;min-width:0;padding:20px 24px;border-bottom:1px solid var(--drx-sidenav-border, var(--drx-color-border-default, #d9dbe9));background:var(--drx-sidenav-header-background, var(--drx-color-surface-default, #fff))}.drx-sidenav__heading[_ngcontent-%COMP%]{min-width:0}.drx-sidenav__default-heading[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{margin:0;color:var(--drx-sidenav-heading-color, var(--drx-color-heading, #252831));font-size:1.125rem;font-weight:700;line-height:1.3}.drx-sidenav__default-heading[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:5px 0 0;color:var(--drx-sidenav-muted-color, var(--drx-color-text-muted, #4e4b66));font-size:.875rem;line-height:1.4}.drx-sidenav__close[_ngcontent-%COMP%]{display:inline-flex;flex:0 0 auto;align-items:center;justify-content:center;width:40px;height:40px;margin:-8px -8px -8px 0;padding:0;border:0;border-radius:8px;background:transparent;color:var(--drx-sidenav-close-color, var(--drx-color-text-muted, #4e4b66));cursor:pointer}.drx-sidenav__close[_ngcontent-%COMP%]:hover{background:var(--drx-sidenav-close-hover-background, var(--drx-gray-200, #f7f7fc))}.drx-sidenav__close[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--drx-color-focus-ring, #315cea);outline-offset:2px}.drx-sidenav__body[_ngcontent-%COMP%]{min-width:0;min-height:0;overflow:auto;overscroll-behavior:contain;padding:var(--drx-sidenav-body-padding, 20px 24px 28px)}.drx-sidenav__footer[_ngcontent-%COMP%]{min-width:0}.drx-sidenav__footer[_ngcontent-%COMP%]:empty{display:none}.drx-sidenav__footer.is-sticky[_ngcontent-%COMP%]:not(:empty){padding:12px 24px;border-top:1px solid var(--drx-sidenav-border, var(--drx-color-border-default, #d9dbe9));background:var(--drx-sidenav-footer-background, var(--drx-color-surface-default, #fff));box-shadow:0 -6px 18px #14142b0d}@media(max-width:600px){.drx-sidenav__panel[_ngcontent-%COMP%]{width:100vw}.drx-sidenav__header[_ngcontent-%COMP%]{padding:16px}.drx-sidenav__body[_ngcontent-%COMP%]{padding:var(--drx-sidenav-body-padding-mobile, 16px 16px 24px)}.drx-sidenav__footer.is-sticky[_ngcontent-%COMP%]:not(:empty){padding:12px 16px}}@media(prefers-reduced-motion:reduce){.drx-sidenav__backdrop[_ngcontent-%COMP%], .drx-sidenav__panel[_ngcontent-%COMP%]{transition:none}}"], changeDetection: 0 });
} return n; })(), Ao = (() => { class n {
    items = r.required();
    ariaLabel = r("Navega\xE7\xE3o estrutural");
    title = u(() => this.items().at(-1)?.label ?? "");
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = e.\u0275\u0275defineComponent({ type: n, selectors: [["drx-breadcrumb"]], inputs: { items: [1, "items"], ariaLabel: [1, "ariaLabel"] }, decls: 4, vars: 1, consts: [[1, "drx-breadcrumb"], [1, "drx-breadcrumb__list"], [1, "drx-breadcrumb__item"], ["aria-hidden", "true", 1, "drx-breadcrumb__separator"], [1, "drx-breadcrumb__link", 3, "routerLink"], [3, "drx-breadcrumb__current"]], template: function (i, o) { i & 1 && (e.\u0275\u0275elementStart(0, "nav", 0)(1, "ol", 1), e.\u0275\u0275repeaterCreate(2, Ri, 4, 2, "li", 2, e.\u0275\u0275repeaterTrackByIndex), e.\u0275\u0275elementEnd()()), i & 2 && (e.\u0275\u0275attribute("aria-label", o.ariaLabel()), e.\u0275\u0275advance(2), e.\u0275\u0275repeater(o.items())); }, dependencies: [fe], styles: ['[_nghost-%COMP%]{display:block;min-width:0}.drx-breadcrumb[_ngcontent-%COMP%]{color:var(--drx-color-text-secondary, #68728e);font-family:var(--drx-font-quicksand, "Quicksand", sans-serif);font-size:.875rem;margin-bottom:16px}.drx-breadcrumb__list[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;gap:.4rem;align-items:center;padding:0;margin:0;list-style:none}.drx-breadcrumb__item[_ngcontent-%COMP%]{display:inline-flex;gap:.4rem;align-items:center;min-width:0}.drx-breadcrumb__separator[_ngcontent-%COMP%]{color:var(--drx-color-text-muted, #9ba3b8)}.drx-breadcrumb__link[_ngcontent-%COMP%]{color:inherit;text-decoration:none}.drx-breadcrumb__link[_ngcontent-%COMP%]:hover{text-decoration:underline}.drx-breadcrumb__link[_ngcontent-%COMP%]:focus-visible{outline:2px solid currentColor;outline-offset:3px;border-radius:2px}.drx-breadcrumb__current[_ngcontent-%COMP%]{color:var(--drx-color-text-primary, #20253b);font-weight:700}'], changeDetection: 0 });
} return n; })();
export { re as ButtonComponent, xo as CardComponent, bo as CardListComponent, fo as CardListItemComponent, go as CardSquareComponent, wo as DocumentPipe, ho as DrxAutocompleteComponent, to as DrxBadgeComponent, Ao as DrxBreadcrumbComponent, Zi as DrxCalendarComponent, Oo as DrxDataTableComponent, So as DrxEditableAutofocusDirective, U as DrxEditableCellDefDirective, Eo as DrxEditableCommitOnEnterDirective, G as DrxEditableEditorDefDirective, To as DrxEditableNextOnEnterDirective, Y as DrxEditableRowActionsDefDirective, J as DrxEditableRowDetailsDefDirective, ko as DrxEditableTableComponent, Z as DrxEditableTreeCellDefDirective, eo as DrxSelectComponent, No as DrxSidebarComponent, Io as DrxSidenavComponent, v as HubIconComponent, Ji as InputComponent, Po as PhonePipe, Do as PostalCodePipe, Mo as SaveFooterComponent, vo as TabsComponent, Fo as TextareaComponent, mo as Ui, Ui as applyBrazilianMask, le as formatCnpj, de as formatCpf, ce as formatDocument, pe as formatPhone, se as formatPostalCode, yo as isValidCnpj, Co as isValidCpf, P as onlyDigits };
