import { a as v, b as S } from "@nf-internal/chunk-4CLCTAJ7";
import * as d from "@angular/core";
import { InjectionToken as f, inject as o, signal as m, computed as u } from "@angular/core";
import { Router as p } from "@angular/router";
import { HttpBackend as _, HttpClient as E, HttpErrorResponse as w } from "@angular/common/http";
import { throwError as a, tap as K, finalize as A, shareReplay as R, catchError as h, EMPTY as L, switchMap as k } from "rxjs";
import { DOCUMENT as U } from "@angular/common";
var H = new f("HUB_ACCESS_TOKEN_KEY", { providedIn: "root", factory: () => "daruix_hub_access_token" }), N = new f("HUB_REFRESH_TOKEN_KEY", { providedIn: "root", factory: () => "daruix_hub_refresh_token" }), F = new f("HUB_USER_KEY", { providedIn: "root", factory: () => "daruix_hub_user" }), M = new f("HUB_SESSION_KEY", { providedIn: "root", factory: () => "daruix_hub_session" }), g = (() => { class t {
    accessTokenKey = o(H);
    refreshTokenKey = o(N);
    userKey = o(F);
    sessionKey = o(M);
    usuarioSignal = m(this.loadUserFromStorage());
    accessTokenSignal = m(localStorage.getItem(this.accessTokenKey));
    refreshTokenSignal = m(localStorage.getItem(this.refreshTokenKey));
    sessaoSignal = m(this.loadSessionFromStorage());
    usuario = this.usuarioSignal.asReadonly();
    accessToken = this.accessTokenSignal.asReadonly();
    refreshToken = this.refreshTokenSignal.asReadonly();
    sessao = this.sessaoSignal.asReadonly();
    isSessionExpired = u(() => { let e = this.sessao(); return e?.expira_em ? new Date(e.expira_em).getTime() <= Date.now() : !1; });
    isLoggedIn = u(() => !!this.accessToken() && !!this.usuario() && !this.isSessionExpired());
    userName = u(() => this.usuario()?.nome ?? this.usuario()?.username ?? "");
    userPermissions = u(() => this.usuario()?.permissoes ?? []);
    userModules = u(() => this.usuario()?.modulos ?? []);
    hasPermission(e) { return this.userPermissions().includes(e); }
    hasModule(e) { return this.userModules().some(s => s.slug === e); }
    setSession(e) { localStorage.setItem(this.userKey, JSON.stringify(e.usuario)), localStorage.setItem(this.accessTokenKey, e.accessToken), localStorage.setItem(this.refreshTokenKey, e.refreshToken), localStorage.setItem(this.sessionKey, JSON.stringify(e.sessao)), this.usuarioSignal.set(e.usuario), this.accessTokenSignal.set(e.accessToken), this.refreshTokenSignal.set(e.refreshToken), this.sessaoSignal.set(e.sessao); }
    setLoginResponse(e) { this.setSession({ usuario: e.usuario, accessToken: e.access_token, refreshToken: e.refresh_token, sessao: e.sessao }); }
    setRefreshResponse(e) { localStorage.setItem(this.accessTokenKey, e.access_token), localStorage.setItem(this.refreshTokenKey, e.refresh_token), localStorage.setItem(this.sessionKey, JSON.stringify(e.sessao)), this.accessTokenSignal.set(e.access_token), this.refreshTokenSignal.set(e.refresh_token), this.sessaoSignal.set(e.sessao); }
    setUsuario(e) { localStorage.setItem(this.userKey, JSON.stringify(e)), this.usuarioSignal.set(e); }
    setAccessToken(e) { localStorage.setItem(this.accessTokenKey, e), this.accessTokenSignal.set(e); }
    updateModuleFavorite(e, s) { let n = this.usuario(); if (!n)
        return; let r = this.updateFavoriteRecursively(n.modulos ?? [], e, s); this.setUsuario(S(v({}, n), { modulos: r })); }
    clearSession() { localStorage.removeItem(this.userKey), localStorage.removeItem(this.accessTokenKey), localStorage.removeItem(this.refreshTokenKey), localStorage.removeItem(this.sessionKey), this.usuarioSignal.set(null), this.accessTokenSignal.set(null), this.refreshTokenSignal.set(null), this.sessaoSignal.set(null); }
    reloadFromStorage() { this.usuarioSignal.set(this.loadUserFromStorage()), this.accessTokenSignal.set(localStorage.getItem(this.accessTokenKey)), this.refreshTokenSignal.set(localStorage.getItem(this.refreshTokenKey)), this.sessaoSignal.set(this.loadSessionFromStorage()), this.isSessionExpired() && this.clearSession(); }
    updateFavoriteRecursively(e, s, n) { return e.map(r => S(v({}, r), { favorito: r.slug === s ? n : r.favorito, children: r.children?.length ? this.updateFavoriteRecursively(r.children, s, n) : r.children })); }
    loadUserFromStorage() { let e = localStorage.getItem(this.userKey); if (!e)
        return null; try {
        return JSON.parse(e);
    }
    catch {
        return localStorage.removeItem(this.userKey), null;
    } }
    loadSessionFromStorage() { let e = localStorage.getItem(this.sessionKey); if (!e)
        return null; try {
        return JSON.parse(e);
    }
    catch {
        return localStorage.removeItem(this.sessionKey), null;
    } }
    static \u0275fac = function (s) { return new (s || t); };
    static \u0275prov = d.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac, providedIn: "root" });
} return t; })(), q = (() => { class t {
    router = o(p);
    navigateRoute(e, s) { if (!e?.trim())
        return; let r = this.resolveRoute(e, s).trim().replace(/^\/hub\/?/, "").replace(/^\/+|\/+$/g, ""); r && this.router.navigate(["/hub", ...r.split("/")], { state: { moduleColor: s?.cor_icone, moduleIcone: s?.icone } }); }
    resolveRoute(e, s) { if (!s?.children?.length)
        return e; for (let n of s.children) {
        if (n.children?.length) {
            let r = n.children.find(c => c.rota === e);
            if (r)
                return `${n.rota}/${r.rota}`;
        }
        if (n.rota === e)
            return s.modulo_slug ? `${s.modulo_slug}/${e}` : e;
    } return e; }
    static \u0275fac = function (s) { return new (s || t); };
    static \u0275prov = d.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac, providedIn: "root" });
} return t; })(), b = new f("HUB_AUTH_API_URL", { providedIn: "root", factory: () => "/api" }), D = (() => { class t {
    backend = o(_);
    session = o(g);
    apiUrl = o(b);
    rawHttp = new E(this.backend);
    refreshInFlight$ = null;
    refreshAccessToken() { if (this.refreshInFlight$)
        return this.refreshInFlight$; let e = this.session.refreshToken(); if (!e)
        return a(() => new Error("Refresh token n\xE3o dispon\xEDvel.")); let s = this.rawHttp.post(this.authUrl("refresh/"), { refresh_token: e }).pipe(K(n => this.session.setRefreshResponse(n)), A(() => { this.refreshInFlight$ = null; }), R({ bufferSize: 1, refCount: !1 })); return this.refreshInFlight$ = s, s; }
    authUrl(e) { return `${this.apiUrl.replace(/\/+$/, "")}/auth/${e}`; }
    static \u0275fac = function (s) { return new (s || t); };
    static \u0275prov = d.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac, providedIn: "root" });
} return t; })(), $ = 300 * 1e3, O = 30 * 1e3, ee = (() => { class t {
    document = o(U);
    http = o(E);
    session = o(g);
    apiUrl = o(b);
    started = !1;
    heartbeatInFlight = !1;
    activityPending = !1;
    lastHumanActivityAt = 0;
    lastHeartbeatAt = Date.now();
    timerId = null;
    markActivityListener = () => this.markActivity();
    visibilityListener = () => { this.document.visibilityState === "visible" && this.markActivity(); };
    start() { this.started || (this.started = !0, this.document.addEventListener("pointerdown", this.markActivityListener, { passive: !0 }), this.document.addEventListener("keydown", this.markActivityListener), this.document.addEventListener("wheel", this.markActivityListener, { passive: !0 }), this.document.addEventListener("touchstart", this.markActivityListener, { passive: !0 }), this.document.addEventListener("visibilitychange", this.visibilityListener), this.timerId = window.setInterval(() => this.flushActivityIfNeeded(), O)); }
    markActivity() { this.lastHumanActivityAt = Date.now(), this.activityPending = !0; }
    ngOnDestroy() { this.started && (this.document.removeEventListener("pointerdown", this.markActivityListener), this.document.removeEventListener("keydown", this.markActivityListener), this.document.removeEventListener("wheel", this.markActivityListener), this.document.removeEventListener("touchstart", this.markActivityListener), this.document.removeEventListener("visibilitychange", this.visibilityListener), this.timerId !== null && (window.clearInterval(this.timerId), this.timerId = null), this.started = !1); }
    flushActivityIfNeeded() { if (!this.activityPending || this.heartbeatInFlight || !this.session.isLoggedIn() || Date.now() - this.lastHeartbeatAt < $)
        return; let s = this.lastHumanActivityAt; this.heartbeatInFlight = !0, this.http.get(this.authUrl("me/")).pipe(h(() => L), A(() => { this.heartbeatInFlight = !1; })).subscribe(() => { this.lastHeartbeatAt = Date.now(), this.activityPending = this.lastHumanActivityAt > s; }); }
    authUrl(e) { return `${this.apiUrl.replace(/\/+$/, "")}/auth/${e}`; }
    static \u0275fac = function (s) { return new (s || t); };
    static \u0275prov = d.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac, providedIn: "root" });
} return t; })(), P = 90, T = !1, te = (t, i) => { let e = o(g), s = o(D); if (!B(t))
    return i(t); let n = e.accessToken(); return n ? j(n, P) ? s.refreshAccessToken().pipe(k(() => { let r = e.accessToken(); return r ? i(y(t, r)) : (l(e), a(() => new Error("Access token n\xE3o dispon\xEDvel ap\xF3s refresh."))); }), h(r => (l(e), a(() => r)))) : i(y(t, n)).pipe(h(r => I(r) ? s.refreshAccessToken().pipe(k(() => { let c = e.accessToken(); return c ? i(y(t, c)) : (l(e), a(() => new Error("Access token n\xE3o dispon\xEDvel ap\xF3s refresh."))); }), h(c => (l(e), a(() => c)))) : a(() => r))) : i(t).pipe(h(r => (I(r) && l(e), a(() => r)))); };
function y(t, i) { return t.clone({ setHeaders: { Authorization: `Bearer ${i}` } }); }
function B(t) { let i = Y(t.url); return !C(i) && !J(i); }
function I(t) { return t instanceof w && t.status === 401; }
function l(t) { t.clearSession(), x(); }
function x() { T || (T = !0, window.location.replace("/login")); }
function C(t) { return t.endsWith("/auth/login") || t.endsWith("/auth/login/"); }
function J(t) { return t.endsWith("/auth/refresh") || t.endsWith("/auth/refresh/"); }
function Y(t) { try {
    return new URL(t, window.location.origin).pathname;
}
catch {
    return t.split("?")[0];
} }
function j(t, i) { let e = z(t); return e === null ? !1 : e * 1e3 <= Date.now() + i * 1e3; }
function z(t) { let i = t.split("."); if (i.length !== 3)
    return null; try {
    let e = i[1].replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(i[1].length / 4) * 4, "="), s = JSON.parse(atob(e));
    return typeof s.exp == "number" ? s.exp : null;
}
catch {
    return null;
} }
var se = () => { let t = o(g), i = o(p); return t.reloadFromStorage(), t.isLoggedIn() ? !0 : i.createUrlTree(["/login"]); }, re = t => { let i = o(g), e = o(p); i.reloadFromStorage(); let s = t.data?.permission; return !s || i.hasPermission(s) ? !0 : e.createUrlTree(["/unauthorized"]); };
export { H as HUB_ACCESS_TOKEN_KEY, b as HUB_AUTH_API_URL, N as HUB_REFRESH_TOKEN_KEY, M as HUB_SESSION_KEY, F as HUB_USER_KEY, D as HubAuthRefreshService, q as HubNavigationService, g as HubSessionService, ee as HubUserActivityService, se as hubAuthGuard, te as hubAuthInterceptor, re as hubPermissionGuard };
