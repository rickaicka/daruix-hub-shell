import { a as re, b as E, f as oe } from "@nf-internal/chunk-74IHY5CB";
import { F as qe, G as Ue, H as ie, I as Ge, J as Be, K as Ze, a as I, b as T, c as Ve, s as te, w as $e, y as He } from "@nf-internal/chunk-WBZPGP5R";
import { a as V, b as $, d as ne } from "@nf-internal/chunk-4CLCTAJ7";
import { BehaviorSubject as Kn, Observable as Xn, Subject as zn, Subscription as et } from "rxjs";
import { setActiveConsumer as C } from "@angular/core/primitives/signals";
import { isNotFound as nt } from "@angular/core/primitives/di";
var ue = class {
    full;
    major;
    minor;
    patch;
    constructor(n) { this.full = n; let t = n.split("."); this.major = t[0], this.minor = t[1], this.patch = t.slice(2).join("."); }
}, We = new ue("21.2.20"), Pr = (() => { let e = We.full; return `https://${e.includes("-next") || e.includes("-rc") || e === "0.0.0-PLACEHOLDER" ? "next" : `v${We.major}`}.angular.dev`; })();
var Lr = "https://angular.dev/best-practices/security#preventing-cross-site-scripting-xss", f = class extends Error {
    code;
    constructor(n, t) { super(be(n, t)), this.code = n; }
};
function tt(e) { return `NG0${Math.abs(e)}`; }
function be(e, n) { return `${tt(e)}${n ? ": " + n : ""}`; }
var Sr = globalThis;
function d(e) { for (let n in e)
    if (e[n] === d)
        return n; throw Error(""); }
function Ar(e, n) { for (let t in n)
    n.hasOwnProperty(t) && !e.hasOwnProperty(t) && (e[t] = n[t]); }
function rt(e) {
    if (typeof e == "string")
        return e;
    if (Array.isArray(e))
        return `[${e.map(rt).join(", ")}]`;
    if (e == null)
        return "" + e;
    let n = e.overriddenName || e.name;
    if (n)
        return `${n}`;
    let t = e.toString();
    if (t == null)
        return "" + t;
    let r = t.indexOf(`
`);
    return r >= 0 ? t.slice(0, r) : t;
}
function Vr(e, n) { return e ? n ? `${e} ${n}` : e : n || ""; }
function $r(e, n = 100) { if (!e || n < 1 || e.length <= n)
    return e; if (n == 1)
    return e.substring(0, 1) + "..."; let t = Math.round(n / 2); return e.substring(0, t) + "..." + e.substring(e.length - t); }
var ot = d({ __forward_ref__: d });
function an(e) { return e.__forward_ref__ = an, e; }
function y(e) { return it(e) ? e() : e; }
function it(e) { return typeof e == "function" && e.hasOwnProperty(ot) && e.__forward_ref__ === an; }
function Hr(e, n, t) { e != n && cn(t, e, n, "=="); }
function cn(e, n, t, r) { throw new Error(`ASSERTION ERROR: ${e}` + (r == null ? "" : ` [Expected=> ${t} ${r} ${n} <=Actual]`)); }
function S(e) { return { token: e.token, providedIn: e.providedIn || null, factory: e.factory, value: void 0 }; }
function qr(e) { return { providers: e.providers || [], imports: e.imports || [] }; }
function K(e) { return st(e, dn); }
function Ur(e) { return K(e) !== null; }
function st(e, n) { return e.hasOwnProperty(n) && e[n] || null; }
function ut(e) { let n = e?.[dn] ?? null; return n || null; }
function Ye(e) { return e && e.hasOwnProperty(Je) ? e[Je] : null; }
var dn = d({ \u0275prov: d }), Je = d({ \u0275inj: d }), g = class {
    _desc;
    ngMetadataName = "InjectionToken";
    \u0275prov;
    constructor(n, t) { this._desc = n, this.\u0275prov = void 0, typeof t == "number" ? this.__NG_ELEMENT_ID__ = t : t !== void 0 && (this.\u0275prov = S({ token: this, providedIn: t.providedIn || "root", factory: t.factory })); }
    get multi() { return this; }
    toString() { return `InjectionToken ${this._desc}`; }
}, Qe;
function Gr(e) { cn("setInjectorProfilerContext should never be called in production mode"); let n = Qe; return Qe = e, n; }
function ln(e) { return e && !!e.\u0275providers; }
var at = d({ \u0275cmp: d }), ct = d({ \u0275dir: d }), dt = d({ \u0275pipe: d }), lt = d({ \u0275mod: d }), Ke = d({ \u0275fac: d }), Br = d({ __NG_ELEMENT_ID__: d }), Xe = d({ __NG_ENV_ID__: d });
function ft(e) { return X(e, "@NgModule"), e[lt] || null; }
function Zr(e) { let n = ft(e); if (!n)
    throw new f(915, !1); return n; }
function fn(e) { return X(e, "@Component"), e[at] || null; }
function ht(e) { return X(e, "@Directive"), e[ct] || null; }
function gt(e) { return X(e, "@Pipe"), e[dt] || null; }
function X(e, n) { if (e == null)
    throw new f(-919, !1); }
function Wr(e) { let n = fn(e) || ht(e) || gt(e); return n !== null && n.standalone; }
function pt(e) { return typeof e == "string" ? e : e == null ? "" : String(e); }
function Yr(e) { return typeof e == "function" ? e.name || e.toString() : typeof e == "object" && e != null && typeof e.type == "function" ? e.type.name || e.type.toString() : pt(e); }
var hn = d({ ngErrorCode: d }), mt = d({ ngErrorMessage: d }), vt = d({ ngTokenPath: d });
function yt(e, n) { return gn("", -200, n); }
function Dt(e, n) { throw new f(-201, !1); }
function gn(e, n, t) { let r = new f(n, e); return r[hn] = n, r[mt] = e, t && (r[vt] = t), r; }
function It(e) { return e[hn]; }
var ae;
function pn() { return ae; }
function N(e) { let n = ae; return ae = e, n; }
function Et(e, n, t) { let r = K(e); if (r && r.providedIn == "root")
    return r.value === void 0 ? r.value = r.factory() : r.value; if (t & 8)
    return null; if (n !== void 0)
    return n; Dt(e, ""); }
var Tt = {}, M = Tt, ce = "__NG_DI_FLAG__", de = class {
    injector;
    constructor(n) { this.injector = n; }
    retrieve(n, t) { let r = U(t) || 0; try {
        return this.injector.get(n, r & 8 ? null : M, r);
    }
    catch (o) {
        if (oe(o))
            return o;
        throw o;
    } }
};
function wt(e, n = 0) { let t = re(); if (t === void 0)
    throw new f(-203, !1); if (t === null)
    return Et(e, void 0, n); {
    let r = Nt(n), o = t.retrieve(e, r);
    if (oe(o)) {
        if (r.optional)
            return null;
        throw o;
    }
    return o;
} }
function F(e, n = 0) { return (pn() || wt)(y(e), n); }
function Jr(e) { throw new f(202, !1); }
function h(e, n) { return F(e, U(n)); }
function U(e) { return typeof e > "u" || typeof e == "number" ? e : 0 | (e.optional && 8) | (e.host && 1) | (e.self && 2) | (e.skipSelf && 4); }
function Nt(e) { return { optional: !!(e & 8), host: !!(e & 1), self: !!(e & 2), skipSelf: !!(e & 4) }; }
function le(e) { let n = []; for (let t = 0; t < e.length; t++) {
    let r = y(e[t]);
    if (Array.isArray(r)) {
        if (r.length === 0)
            throw new f(900, !1);
        let o, i = 0;
        for (let s = 0; s < r.length; s++) {
            let l = r[s], u = bt(l);
            typeof u == "number" ? u === -1 ? o = l.token : i |= u : o = l;
        }
        n.push(F(o, i));
    }
    else
        n.push(F(r));
} return n; }
function Qr(e, n) { return e[ce] = n, e.prototype[ce] = n, e; }
function bt(e) { return e[ce]; }
function G(e, n) { let t = e.hasOwnProperty(Ke); return t ? e[Ke] : null; }
function Kr(e, n, t) { if (e.length !== n.length)
    return !1; for (let r = 0; r < e.length; r++) {
    let o = e[r], i = n[r];
    if (t && (o = t(o), i = t(i)), i !== o)
        return !1;
} return !0; }
function Xr(e) { return e.flat(Number.POSITIVE_INFINITY); }
function Me(e, n) { e.forEach(t => Array.isArray(t) ? Me(t, n) : n(t)); }
function zr(e, n, t) { n >= e.length ? e.push(t) : e.splice(n, 0, t); }
function eo(e, n) { return n >= e.length - 1 ? e.pop() : e.splice(n, 1)[0]; }
function no(e, n) { let t = []; for (let r = 0; r < e; r++)
    t.push(n); return t; }
function to(e, n, t) { let r = e.length - t; for (; n < r;)
    e[n] = e[n + t], n++; for (; t--;)
    e.pop(); }
function Mt(e, n, t, r) { let o = e.length; if (o == n)
    e.push(t, r);
else if (o === 1)
    e.push(r, e[0]), e[0] = t;
else {
    for (o--, e.push(e[o - 1], e[o]); o > n;) {
        let i = o - 2;
        e[o] = e[i], o--;
    }
    e[n] = t, e[n + 1] = r;
} }
function ro(e, n, t) { let r = mn(e, n); return r >= 0 ? e[r | 1] = t : (r = ~r, Mt(e, r, n, t)), r; }
function oo(e, n) { let t = mn(e, n); if (t >= 0)
    return e[t | 1]; }
function mn(e, n) { return _t(e, n, 1); }
function _t(e, n, t) { let r = 0, o = e.length >> t; for (; o !== r;) {
    let i = r + (o - r >> 1), s = e[i << t];
    if (n === s)
        return i << t;
    s > n ? o = i : r = i + 1;
} return ~(o << t); }
var io = {}, B = [], z = new g(""), vn = new g("", -1), yn = new g(""), Z = class {
    get(n, t = M) { if (t === M) {
        let o = gn("", -201);
        throw o.name = "\u0275NotFound", o;
    } return t; }
};
function Dn(e) { return { \u0275providers: e }; }
function xt(e) { return Dn([{ provide: z, multi: !0, useValue: e }]); }
function Ct(...e) { return { \u0275providers: kt(!0, e), \u0275fromNgModule: !0 }; }
function kt(e, ...n) { let t = [], r = new Set, o, i = s => { t.push(s); }; return Me(n, s => { let l = s; fe(l, i, [], r) && (o ||= [], o.push(l)); }), o !== void 0 && In(o, i), t; }
function In(e, n) { for (let t = 0; t < e.length; t++) {
    let { ngModule: r, providers: o } = e[t];
    _e(o, i => { n(i, r); });
} }
function fe(e, n, t, r) { if (e = y(e), !e)
    return !1; let o = null, i = Ye(e), s = !i && fn(e); if (!i && !s) {
    let u = e.ngModule;
    if (i = Ye(u), i)
        o = u;
    else
        return !1;
}
else {
    if (s && !s.standalone)
        return !1;
    o = e;
} let l = r.has(o); if (s) {
    if (l)
        return !1;
    if (r.add(o), s.dependencies) {
        let u = typeof s.dependencies == "function" ? s.dependencies() : s.dependencies;
        for (let c of u)
            fe(c, n, t, r);
    }
}
else if (i) {
    if (i.imports != null && !l) {
        r.add(o);
        let c;
        Me(i.imports, m => { fe(m, n, t, r) && (c ||= [], c.push(m)); }), c !== void 0 && In(c, n);
    }
    if (!l) {
        let c = G(o) || (() => new o);
        n({ provide: o, useFactory: c, deps: B }, o), n({ provide: yn, useValue: o, multi: !0 }, o), n({ provide: z, useValue: () => F(o), multi: !0 }, o);
    }
    let u = i.providers;
    if (u != null && !l) {
        let c = e;
        _e(u, m => { n(m, c); });
    }
}
else
    return !1; return o !== e && e.providers !== void 0; }
function _e(e, n) { for (let t of e)
    ln(t) && (t = t.\u0275providers), Array.isArray(t) ? _e(t, n) : n(t); }
var Rt = d({ provide: String, useValue: d });
function En(e) { return e !== null && typeof e == "object" && Rt in e; }
function Ft(e) { return !!(e && e.useExisting); }
function jt(e) { return !!(e && e.useFactory); }
function he(e) { return typeof e == "function"; }
function so(e) { return !!e.useClass; }
var Ot = new g(""), H = {}, ze = {}, se;
function Tn() { return se === void 0 && (se = new Z), se; }
var P = class {
}, W = class extends P {
    parent;
    source;
    scopes;
    records = new Map;
    _ngOnDestroyHooks = new Set;
    _onDestroyHooks = [];
    get destroyed() { return this._destroyed; }
    _destroyed = !1;
    injectorDefTypes;
    constructor(n, t, r, o) { super(), this.parent = t, this.source = r, this.scopes = o, pe(n, s => this.processProvider(s)), this.records.set(vn, k(void 0, this)), o.has("environment") && this.records.set(P, k(void 0, this)); let i = this.records.get(Ot); i != null && typeof i.value == "string" && this.scopes.add(i.value), this.injectorDefTypes = new Set(this.get(yn, B, { self: !0 })); }
    retrieve(n, t) { let r = U(t) || 0; try {
        return this.get(n, M, r);
    }
    catch (o) {
        if (nt(o))
            return o;
        throw o;
    } }
    destroy() { O(this), this._destroyed = !0; let n = C(null); try {
        for (let r of this._ngOnDestroyHooks)
            r.ngOnDestroy();
        let t = this._onDestroyHooks;
        this._onDestroyHooks = [];
        for (let r of t)
            r();
    }
    finally {
        this.records.clear(), this._ngOnDestroyHooks.clear(), this.injectorDefTypes.clear(), C(n);
    } }
    onDestroy(n) { return O(this), this._onDestroyHooks.push(n), () => this.removeOnDestroy(n); }
    runInContext(n) { O(this); let t = E(this), r = N(void 0), o; try {
        return n();
    }
    finally {
        E(t), N(r);
    } }
    get(n, t = M, r) { if (O(this), n.hasOwnProperty(Xe))
        return n[Xe](this); let o = U(r), i, s = E(this), l = N(void 0); try {
        if (!(o & 4)) {
            let c = this.records.get(n);
            if (c === void 0) {
                let m = $t(n) && K(n);
                m && this.injectableDefInScope(m) ? c = k(ge(n), H) : c = null, this.records.set(n, c);
            }
            if (c != null)
                return this.hydrate(n, c, o);
        }
        let u = o & 2 ? Tn() : this.parent;
        return t = o & 8 && t === M ? null : t, u.get(n, t);
    }
    catch (u) {
        let c = It(u);
        throw c === -200 || c === -201 ? new f(c, null) : u;
    }
    finally {
        N(l), E(s);
    } }
    resolveInjectorInitializers() { let n = C(null), t = E(this), r = N(void 0), o; try {
        let i = this.get(z, B, { self: !0 });
        for (let s of i)
            s();
    }
    finally {
        E(t), N(r), C(n);
    } }
    toString() { return "R3Injector[...]"; }
    processProvider(n) { n = y(n); let t = he(n) ? n : y(n && n.provide), r = Lt(n); if (!he(n) && n.multi === !0) {
        let o = this.records.get(t);
        o || (o = k(void 0, H, !0), o.factory = () => le(o.multi), this.records.set(t, o)), t = n, o.multi.push(n);
    } this.records.set(t, r); }
    hydrate(n, t, r) { let o = C(null); try {
        if (t.value === ze)
            throw yt("");
        return t.value === H && (t.value = ze, t.value = t.factory(void 0, r)), typeof t.value == "object" && t.value && Vt(t.value) && this._ngOnDestroyHooks.add(t.value), t.value;
    }
    finally {
        C(o);
    } }
    injectableDefInScope(n) { if (!n.providedIn)
        return !1; let t = y(n.providedIn); return typeof t == "string" ? t === "any" || this.scopes.has(t) : this.injectorDefTypes.has(t); }
    removeOnDestroy(n) { let t = this._onDestroyHooks.indexOf(n); t !== -1 && this._onDestroyHooks.splice(t, 1); }
};
function ge(e) { let n = K(e), t = n !== null ? n.factory : G(e); if (t !== null)
    return t; if (e instanceof g)
    throw new f(-204, !1); if (e instanceof Function)
    return Pt(e); throw new f(-204, !1); }
function Pt(e) { if (e.length > 0)
    throw new f(-204, !1); let t = ut(e); return t !== null ? () => t.factory(e) : () => new e; }
function Lt(e) { if (En(e))
    return k(void 0, e.useValue); {
    let n = St(e);
    return k(n, H);
} }
function St(e, n, t) { let r; if (he(e)) {
    let o = y(e);
    return G(o) || ge(o);
}
else if (En(e))
    r = () => y(e.useValue);
else if (jt(e))
    r = () => e.useFactory(...le(e.deps || []));
else if (Ft(e))
    r = (o, i) => F(y(e.useExisting), i !== void 0 && i & 8 ? 8 : void 0);
else {
    let o = y(e && (e.useClass || e.provide));
    if (At(e))
        r = () => new o(...le(e.deps));
    else
        return G(o) || ge(o);
} return r; }
function O(e) { if (e.destroyed)
    throw new f(-205, !1); }
function k(e, n, t = !1) { return { factory: e, value: n, multi: t ? [] : void 0 }; }
function At(e) { return !!e.deps; }
function Vt(e) { return e !== null && typeof e == "object" && typeof e.ngOnDestroy == "function"; }
function $t(e) { return typeof e == "function" || typeof e == "object" && e.ngMetadataName === "InjectionToken"; }
function pe(e, n) { for (let t of e)
    Array.isArray(t) ? pe(t, n) : t && ln(t) ? pe(t.\u0275providers, n) : n(t); }
function uo(e, n) { let t; e instanceof W ? (O(e), t = e) : t = new de(e); let r, o = E(t), i = N(void 0); try {
    return n();
}
finally {
    E(o), N(i);
} }
function wn() { return pn() !== void 0 || re() != null; }
function ao(e) { if (!wn())
    throw new f(-203, !1); }
var xe = 0, Nn = 1, p = 2, me = 3, co = 4, Ht = 5, lo = 6, qt = 7, bn = 8, fo = 9, Mn = 10, ho = 11, go = 12, po = 13, _n = 14, mo = 15, vo = 16, Ut = 17, yo = 18, Do = 19, Io = 20, R = 21, Eo = 22, ve = 23, Gt = 24, To = 25, wo = 26, No = 27, Ce = 1, bo = 6, Mo = 7, _o = 8, xo = 9, Co = 10;
function Bt(e) { return Array.isArray(e) && typeof e[Ce] == "object"; }
function xn(e) { return Array.isArray(e) && e[Ce] === !0; }
function ko(e) { return (e.flags & 4) !== 0; }
function Ro(e) { return e.componentOffset > -1; }
function Fo(e) { return (e.flags & 1) === 1; }
function jo(e) { return !!e.template; }
function Oo(e) { return (e[p] & 512) !== 0; }
function Po(e) { return (e.type & 16) === 16; }
function Lo(e) { return (e[p] & 32) === 32; }
function Cn(e) { return (e[p] & 256) === 256; }
var v = (function (e) { return e[e.NONE = 0] = "NONE", e[e.HTML = 1] = "HTML", e[e.STYLE = 2] = "STYLE", e[e.SCRIPT = 3] = "SCRIPT", e[e.URL = 4] = "URL", e[e.RESOURCE_URL = 5] = "RESOURCE_URL", e[e.ATTRIBUTE_NO_BINDING = 6] = "ATTRIBUTE_NO_BINDING", e; })(v || {}), q, ye = "svg", kn = "math";
function Zt() { return q || (q = {}, w(v.HTML, void 0, [["iframe", ["srcdoc"]], ["*", ["innerHTML", "outerHTML"]]]), w(v.STYLE, void 0, [["*", ["style"]]]), w(v.URL, void 0, [["*", ["formAction"]], ["area", ["href"]], ["a", ["href", "xlink:href"]], ["form", ["action"]], ["img", ["src"]], ["video", ["src"]]]), w(v.URL, kn, [["*", ["href", "xlink:href"]], ["annotation", ["href", "xlink:href"]], ["annotation-xml", ["href", "xlink:href"]], ["maction", ["href", "xlink:href"]], ["malignmark", ["href", "xlink:href"]], ["math", ["href", "xlink:href"]], ["mroot", ["href", "xlink:href"]], ["msqrt", ["href", "xlink:href"]], ["merror", ["href", "xlink:href"]], ["mfrac", ["href", "xlink:href"]], ["mglyph", ["href", "xlink:href"]], ["msub", ["href", "xlink:href"]], ["msup", ["href", "xlink:href"]], ["msubsup", ["href", "xlink:href"]], ["mmultiscripts", ["href", "xlink:href"]], ["mprescripts", ["href", "xlink:href"]], ["mi", ["href", "xlink:href"]], ["mn", ["href", "xlink:href"]], ["mo", ["href", "xlink:href"]], ["mpadded", ["href", "xlink:href"]], ["mphantom", ["href", "xlink:href"]], ["mrow", ["href", "xlink:href"]], ["ms", ["href", "xlink:href"]], ["mspace", ["href", "xlink:href"]], ["mstyle", ["href", "xlink:href"]], ["mtable", ["href", "xlink:href"]], ["mtd", ["href", "xlink:href"]], ["mtr", ["href", "xlink:href"]], ["mtext", ["href", "xlink:href"]], ["mover", ["href", "xlink:href"]], ["munder", ["href", "xlink:href"]], ["munderover", ["href", "xlink:href"]], ["semantics", ["href", "xlink:href"]], ["none", ["href", "xlink:href"]]]), w(v.RESOURCE_URL, void 0, [["base", ["href"]], ["embed", ["src"]], ["frame", ["src"]], ["iframe", ["src"]], ["link", ["href"]], ["object", ["codebase", "data"]]]), w(v.URL, ye, [["a", ["href", "xlink:href"]]]), w(v.ATTRIBUTE_NO_BINDING, ye, [["animate", ["attributeName", "values", "to", "from"]], ["set", ["to", "attributeName"]], ["animateMotion", ["attributeName"]], ["animateTransform", ["attributeName"]]]), w(v.ATTRIBUTE_NO_BINDING, void 0, [["unknown", ["attributeName", "values", "to", "from", "sandbox", "allow", "allowFullscreen", "referrerPolicy", "csp", "fetchPriority"]], ["iframe", ["sandbox", "allow", "allowFullscreen", "referrerPolicy", "csp", "fetchPriority"]]])), q; }
function w(e, n, t) { for (let [r, o] of t) {
    let i = n && r !== "unknown" ? `:${n}:${r}` : r;
    i = i.toLowerCase();
    for (let s of o)
        q[`${i}|${s.toLowerCase()}`] = e;
} }
function So(e, n, t) { let r = Zt(), o = e.toLowerCase(), i = n.toLowerCase(), s = t && o !== "*" && o !== "unknown" ? r[`:${t}:${o}|${i}`] : void 0, l = t ? r[`:${t}:*|${i}`] : void 0; return s ?? l ?? r[`${o}|${i}`] ?? r[`*|${i}`] ?? v.NONE; }
function ke(e) { for (; Array.isArray(e);)
    e = e[xe]; return e; }
function Ao(e) { for (; Array.isArray(e);) {
    if (typeof e[Ce] == "object")
        return e;
    e = e[xe];
} return null; }
function Vo(e, n) { return ke(n[e]); }
function $o(e, n) { return ke(n[e.index]); }
function Ho(e, n) { let t = e === null ? -1 : e.index; return t !== -1 ? ke(n[t]) : null; }
function Wt(e, n) { return e.data[n]; }
function qo(e, n) { return e[n]; }
function Uo(e, n, t, r) { t >= e.data.length && (e.data[t] = null, e.blueprint[t] = null), n[t] = r; }
function Go(e, n) { let t = n[e]; return Bt(t) ? t : t[xe]; }
function Bo(e) { return (e[p] & 4) === 4; }
function Rn(e) { return (e[p] & 128) === 128; }
function Zo(e) { return xn(e[me]); }
function Wo(e, n) { return n == null ? null : e[n]; }
function Yo(e) { e[Ut] = 0; }
function Jo(e) { e[p] & 1024 || (e[p] |= 1024, Rn(e) && Re(e)); }
function Yt(e, n) { for (; e > 0;)
    n = n[_n], e--; return n; }
function Jt(e) { return !!(e[p] & 9216 || e[Gt]?.dirty); }
function Qo(e) { e[Mn].changeDetectionScheduler?.notify(8), e[p] & 64 && (e[p] |= 1024), Jt(e) && Re(e); }
function Re(e) { e[Mn].changeDetectionScheduler?.notify(0); let n = en(e); for (; n !== null && !(n[p] & 8192 || (n[p] |= 8192, !Rn(n)));)
    n = en(n); }
function Qt(e, n) { if (Cn(e))
    throw new f(911, !1); e[R] === null && (e[R] = []), e[R].push(n); }
function Kt(e, n) { if (e[R] === null)
    return; let t = e[R].indexOf(n); t !== -1 && e[R].splice(t, 1); }
function en(e) { let n = e[me]; return xn(n) ? n[me] : n; }
function Xt(e) { return e[qt] ??= []; }
function zt(e) { return e.cleanup ??= []; }
function Ko(e, n, t, r) { let o = Xt(n); o.push(t), e.firstCreatePass && zt(e).push(r, o.length - 1); }
var a = { lFrame: On(null), bindingsEnabled: !0, skipHydrationRootTNode: null };
var De = !1;
function Xo() { return a.lFrame.elementDepthCount; }
function zo() { a.lFrame.elementDepthCount++; }
function ei() { a.lFrame.elementDepthCount--; }
function ni() { return a.bindingsEnabled; }
function ti() { return a.skipHydrationRootTNode !== null; }
function ri(e) { return a.skipHydrationRootTNode === e; }
function oi() { a.bindingsEnabled = !0; }
function ii(e) { a.skipHydrationRootTNode = e; }
function si() { a.bindingsEnabled = !1; }
function ui() { a.skipHydrationRootTNode = null; }
function Fn() { return a.lFrame.lView; }
function ai() { return a.lFrame.tView; }
function ci(e) { return a.lFrame.contextLView = e, e[bn]; }
function di(e) { return a.lFrame.contextLView = null, e; }
function er() { let e = nr(); for (; e !== null && e.type === 64;)
    e = e.parent; return e; }
function nr() { return a.lFrame.currentTNode; }
function li() { let e = a.lFrame, n = e.currentTNode; return e.isParent ? n : n.parent; }
function fi(e, n) { let t = a.lFrame; t.currentTNode = e, t.isParent = n; }
function hi() { return a.lFrame.isParent; }
function gi() { a.lFrame.isParent = !1; }
function pi() { return a.lFrame.contextLView; }
function mi() { return De; }
function nn(e) { let n = De; return De = e, n; }
function vi() { let e = a.lFrame, n = e.bindingRootIndex; return n === -1 && (n = e.bindingRootIndex = e.tView.bindingStartIndex), n; }
function yi() { return a.lFrame.bindingIndex; }
function Di(e) { return a.lFrame.bindingIndex = e; }
function Ii() { return a.lFrame.bindingIndex++; }
function Ei(e) { let n = a.lFrame, t = n.bindingIndex; return n.bindingIndex = n.bindingIndex + e, t; }
function Ti() { return a.lFrame.inI18n; }
function wi(e) { a.lFrame.inI18n = e; }
function Ni(e, n) { let t = a.lFrame; t.bindingIndex = t.bindingRootIndex = e, tr(n); }
function bi() { return a.lFrame.currentDirectiveIndex; }
function tr(e) { a.lFrame.currentDirectiveIndex = e; }
function Mi(e) { let n = a.lFrame.currentDirectiveIndex; return n === -1 ? null : e[n]; }
function _i() { return a.lFrame.currentQueryIndex; }
function xi(e) { a.lFrame.currentQueryIndex = e; }
function rr(e) { let n = e[Nn]; return n.type === 2 ? n.declTNode : n.type === 1 ? e[Ht] : null; }
function Ci(e, n, t) { if (t & 4) {
    let o = n, i = e;
    for (; o = o.parent, o === null && !(t & 1);)
        if (o = rr(i), o === null || (i = i[_n], o.type & 10))
            break;
    if (o === null)
        return !1;
    n = o, e = i;
} let r = a.lFrame = jn(); return r.currentTNode = n, r.lView = e, !0; }
function ki(e) { let n = jn(), t = e[Nn]; a.lFrame = n, n.currentTNode = t.firstChild, n.lView = e, n.tView = t, n.contextLView = e, n.bindingIndex = t.bindingStartIndex, n.inI18n = !1; }
function jn() { let e = a.lFrame, n = e === null ? null : e.child; return n === null ? On(e) : n; }
function On(e) { let n = { currentTNode: null, isParent: !0, lView: null, tView: null, selectedIndex: -1, contextLView: null, elementDepthCount: 0, currentNamespace: null, currentDirectiveIndex: -1, bindingRootIndex: -1, bindingIndex: -1, currentQueryIndex: 0, parent: e, child: null, inI18n: !1 }; return e !== null && (e.child = n), n; }
function Pn() { let e = a.lFrame; return a.lFrame = e.parent, e.currentTNode = null, e.lView = null, e; }
var Ri = Pn;
function Fi() { let e = Pn(); e.isParent = !0, e.tView = null, e.selectedIndex = -1, e.contextLView = null, e.elementDepthCount = 0, e.currentDirectiveIndex = -1, e.currentNamespace = null, e.bindingRootIndex = -1, e.bindingIndex = -1, e.currentQueryIndex = 0; }
function ji(e) { return (a.lFrame.contextLView = Yt(e, a.lFrame.contextLView))[bn]; }
function Oi() { return a.lFrame.selectedIndex; }
function Pi(e) { a.lFrame.selectedIndex = e; }
function Li() { let e = a.lFrame; return Wt(e.tView, e.selectedIndex); }
function Si() { a.lFrame.currentNamespace = ye; }
function Ai() { a.lFrame.currentNamespace = kn; }
function Vi() { or(); }
function or() { a.lFrame.currentNamespace = null; }
function $i() { return a.lFrame.currentNamespace; }
var Ln = !0;
function Hi() { return Ln; }
function qi(e) { Ln = e; }
function tn(e, n = null, t = null, r) { let o = ir(e, n, t, r); return o.resolveInjectorInitializers(), o; }
function ir(e, n = null, t = null, r, o = new Set) { let i = [t || B, Ct(e)], s; return new W(i, n || Tn(), s || null, o); }
var L = class e {
    static THROW_IF_NOT_FOUND = M;
    static NULL = new Z;
    static create(n, t) { if (Array.isArray(n))
        return tn({ name: "" }, t, n, ""); {
        let r = n.name ?? "";
        return tn({ name: r }, n.parent, n.providers, r);
    } }
    static \u0275prov = S({ token: e, providedIn: "any", factory: () => F(vn) });
    static __NG_ELEMENT_ID__ = -1;
}, sr = new g(""), _ = (() => { class e {
    static __NG_ELEMENT_ID__ = ur;
    static __NG_ENV_ID__ = t => t;
} return e; })(), Y = class extends _ {
    _lView;
    constructor(n) { super(), this._lView = n; }
    get destroyed() { return Cn(this._lView); }
    onDestroy(n) { let t = this._lView; return Qt(t, n), () => Kt(t, n); }
};
function ur() { return new Y(Fn()); }
var ar = !1, cr = new g(""), Sn = (() => { class e {
    taskId = 0;
    pendingTasks = new Set;
    destroyed = !1;
    pendingTask = new Kn(!1);
    debugTaskTracker = h(cr, { optional: !0 });
    get hasPendingTasks() { return this.destroyed ? !1 : this.pendingTask.value; }
    get hasPendingTasksObservable() { return this.destroyed ? new Xn(t => { t.next(!1), t.complete(); }) : this.pendingTask; }
    add() { !this.hasPendingTasks && !this.destroyed && this.pendingTask.next(!0); let t = this.taskId++; return this.pendingTasks.add(t), this.debugTaskTracker?.add(t), t; }
    has(t) { return this.pendingTasks.has(t); }
    remove(t) { this.pendingTasks.delete(t), this.debugTaskTracker?.remove(t), this.pendingTasks.size === 0 && this.hasPendingTasks && this.pendingTask.next(!1); }
    ngOnDestroy() { this.pendingTasks.clear(), this.hasPendingTasks && this.pendingTask.next(!1), this.destroyed = !0, this.pendingTask.unsubscribe(); }
    static \u0275prov = S({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), Ie = class extends zn {
    __isAsync;
    destroyRef = void 0;
    pendingTasks = void 0;
    constructor(n = !1) { super(), this.__isAsync = n, wn() && (this.destroyRef = h(_, { optional: !0 }) ?? void 0, this.pendingTasks = h(Sn, { optional: !0 }) ?? void 0); }
    emit(n) { let t = T(null); try {
        super.next(n);
    }
    finally {
        T(t);
    } }
    subscribe(n, t, r) { let o = n, i = t || (() => null), s = r; if (n && typeof n == "object") {
        let u = n;
        o = u.next?.bind(u), i = u.error?.bind(u), s = u.complete?.bind(u);
    } this.__isAsync && (i = this.wrapInTimeout(i), o && (o = this.wrapInTimeout(o)), s && (s = this.wrapInTimeout(s))); let l = super.subscribe({ next: o, error: i, complete: s }); return n instanceof et && n.add(l), l; }
    wrapInTimeout(n) { return t => { let r = this.pendingTasks?.add(); setTimeout(() => { try {
        n(t);
    }
    finally {
        r !== void 0 && this.pendingTasks?.remove(r);
    } }); }; }
}, b = Ie;
function J(...e) { }
function dr(e) { let n, t; function r() { e = J; try {
    t !== void 0 && typeof cancelAnimationFrame == "function" && cancelAnimationFrame(t), n !== void 0 && clearTimeout(n);
}
catch { } } return n = setTimeout(() => { e(), r(); }), typeof requestAnimationFrame == "function" && (t = requestAnimationFrame(() => { e(), r(); })), () => r(); }
function Ui(e) { return queueMicrotask(() => e()), () => { e = J; }; }
var Fe = "isAngularZone", rn = Fe + "_ID", lr = 0, Ee = class e {
    hasPendingMacrotasks = !1;
    hasPendingMicrotasks = !1;
    isStable = !0;
    onUnstable = new b(!1);
    onMicrotaskEmpty = new b(!1);
    onStable = new b(!1);
    onError = new b(!1);
    constructor(n) { let { enableLongStackTrace: t = !1, shouldCoalesceEventChangeDetection: r = !1, shouldCoalesceRunChangeDetection: o = !1, scheduleInRootZone: i = ar } = n; if (typeof Zone > "u")
        throw new f(908, !1); Zone.assertZonePatched(); let s = this; s._nesting = 0, s._outer = s._inner = Zone.current, Zone.TaskTrackingZoneSpec && (s._inner = s._inner.fork(new Zone.TaskTrackingZoneSpec)), t && Zone.longStackTraceZoneSpec && (s._inner = s._inner.fork(Zone.longStackTraceZoneSpec)), s.shouldCoalesceEventChangeDetection = !o && r, s.shouldCoalesceRunChangeDetection = o, s.callbackScheduled = !1, s.scheduleInRootZone = i, gr(s); }
    static isInAngularZone() { return typeof Zone < "u" && Zone.current.get(Fe) === !0; }
    static assertInAngularZone() { if (!e.isInAngularZone())
        throw new f(909, !1); }
    static assertNotInAngularZone() { if (e.isInAngularZone())
        throw new f(909, !1); }
    run(n, t, r) { return this._inner.run(n, t, r); }
    runTask(n, t, r, o) { let i = this._inner, s = i.scheduleEventTask("NgZoneEvent: " + o, n, fr, J, J); try {
        return i.runTask(s, t, r);
    }
    finally {
        i.cancelTask(s);
    } }
    runGuarded(n, t, r) { return this._inner.runGuarded(n, t, r); }
    runOutsideAngular(n) { return this._outer.run(n); }
}, fr = {};
function je(e) { if (e._nesting == 0 && !e.hasPendingMicrotasks && !e.isStable)
    try {
        e._nesting++, e.onMicrotaskEmpty.emit(null);
    }
    finally {
        if (e._nesting--, !e.hasPendingMicrotasks)
            try {
                e.runOutsideAngular(() => e.onStable.emit(null));
            }
            finally {
                e.isStable = !0;
            }
    } }
function hr(e) { if (e.isCheckStableRunning || e.callbackScheduled)
    return; e.callbackScheduled = !0; function n() { dr(() => { e.callbackScheduled = !1, Te(e), e.isCheckStableRunning = !0, je(e), e.isCheckStableRunning = !1; }); } e.scheduleInRootZone ? Zone.root.run(() => { n(); }) : e._outer.run(() => { n(); }), Te(e); }
function gr(e) { let n = () => { hr(e); }, t = lr++; e._inner = e._inner.fork({ name: "angular", properties: { [Fe]: !0, [rn]: t, [rn + t]: !0 }, onInvokeTask: (r, o, i, s, l, u) => { if (pr(u))
        return r.invokeTask(i, s, l, u); try {
        return on(e), r.invokeTask(i, s, l, u);
    }
    finally {
        (e.shouldCoalesceEventChangeDetection && s.type === "eventTask" || e.shouldCoalesceRunChangeDetection) && n(), sn(e);
    } }, onInvoke: (r, o, i, s, l, u, c) => { try {
        return on(e), r.invoke(i, s, l, u, c);
    }
    finally {
        e.shouldCoalesceRunChangeDetection && !e.callbackScheduled && !mr(u) && n(), sn(e);
    } }, onHasTask: (r, o, i, s) => { r.hasTask(i, s), o === i && (s.change == "microTask" ? (e._hasPendingMicrotasks = s.microTask, Te(e), je(e)) : s.change == "macroTask" && (e.hasPendingMacrotasks = s.macroTask)); }, onHandleError: (r, o, i, s) => (r.handleError(i, s), e.runOutsideAngular(() => e.onError.emit(s)), !1) }); }
function Te(e) { e._hasPendingMicrotasks || (e.shouldCoalesceEventChangeDetection || e.shouldCoalesceRunChangeDetection) && e.callbackScheduled === !0 ? e.hasPendingMicrotasks = !0 : e.hasPendingMicrotasks = !1; }
function on(e) { e._nesting++, e.isStable && (e.isStable = !1, e.onUnstable.emit(null)); }
function sn(e) { e._nesting--, je(e); }
var un = class {
    hasPendingMicrotasks = !1;
    hasPendingMacrotasks = !1;
    isStable = !0;
    onUnstable = new b;
    onMicrotaskEmpty = new b;
    onStable = new b;
    onError = new b;
    run(n, t, r) { return n.apply(t, r); }
    runGuarded(n, t, r) { return n.apply(t, r); }
    runOutsideAngular(n) { return n(); }
    runTask(n, t, r, o) { return n.apply(t, r); }
};
function pr(e) { return An(e, "__ignore_ng_zone__"); }
function mr(e) { return An(e, "__scheduler_tick__"); }
function An(e, n) { return !Array.isArray(e) || e.length !== 1 ? !1 : e[0]?.data?.[n] === !0; }
var j = class {
    _console = console;
    handleError(n) { this._console.error("ERROR", n); }
}, Vn = new g("", { factory: () => { let e = h(Ee), n = h(P), t; return r => { e.runOutsideAngular(() => { n.destroyed && !t ? setTimeout(() => { throw r; }) : (t ??= n.get(j), t.handleError(r)); }); }; } }), Gi = { provide: z, useValue: () => { let e = h(j, { optional: !0 }); }, multi: !0 }, vr = new g("", { factory: () => { if (typeof ngServerMode < "u" && ngServerMode)
        return; let e = h(sr).defaultView; if (!e)
        return; let n = h(Vn), t = i => { n(i.reason), i.preventDefault(); }, r = i => { i.error ? n(i.error) : n(new Error(i.message, { cause: i })), i.preventDefault(); }, o = () => { e.addEventListener("unhandledrejection", t), e.addEventListener("error", r); }; typeof Zone < "u" ? Zone.root.run(o) : o(), h(_).onDestroy(() => { e.removeEventListener("error", r), e.removeEventListener("unhandledrejection", t); }); } });
function Bi() { return Dn([xt(() => { h(vr); })]); }
function Zi(e) { return null; }
function A(e, n) { let [t, r, o] = He(e, n?.equal), i = t, s = i[I]; return i.set = r, i.update = o, i.asReadonly = ee.bind(i), i; }
function ee() { let e = this[I]; if (e.readonlyFn === void 0) {
    let n = () => this();
    n[I] = e, e.readonlyFn = n;
} return e.readonlyFn; }
function Wi(e, n) { if (Ve() !== null)
    throw new f(-602, !1); }
var $n = (() => { class e {
    view;
    node;
    constructor(t, r) { this.view = t, this.node = r; }
    static __NG_ELEMENT_ID__ = yr;
} return e; })();
function yr() { return new $n(Fn(), er()); }
var Q = class {
}, Yi = new g("", { factory: () => !0 }), Ji = new g("", { factory: () => !1 }), Qi = new g(""), Hn = (() => { class e {
    internalPendingTasks = h(Sn);
    scheduler = h(Q);
    errorHandler = h(Vn);
    add() { let t = this.internalPendingTasks.add(); return () => { this.internalPendingTasks.has(t) && (this.scheduler.notify(11), this.internalPendingTasks.remove(t)); }; }
    run(t) { let r = this.add(); t().catch(this.errorHandler).finally(r); }
    static \u0275prov = S({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), Dr = (() => { class e {
    static \u0275prov = S({ token: e, providedIn: "root", factory: () => new we });
} return e; })(), we = class {
    dirtyEffectCount = 0;
    queues = new Map;
    add(n) { this.enqueue(n), this.schedule(n); }
    schedule(n) { n.dirty && this.dirtyEffectCount++; }
    remove(n) { let t = n.zone, r = this.queues.get(t); r.has(n) && (r.delete(n), n.dirty && this.dirtyEffectCount--); }
    enqueue(n) { let t = n.zone; this.queues.has(t) || this.queues.set(t, new Set); let r = this.queues.get(t); r.has(n) || r.add(n); }
    flush() { for (; this.dirtyEffectCount > 0;) {
        let n = !1;
        for (let [t, r] of this.queues)
            t === null ? n ||= this.flushQueue(r) : n ||= t.run(() => this.flushQueue(r));
        n || (this.dirtyEffectCount = 0);
    } }
    flushQueue(n) { let t = !1; for (let r of n)
        r.dirty && (this.dirtyEffectCount--, t = !0, r.run()); return t; }
}, Ne = class {
    [I];
    constructor(n) { this[I] = n; }
    destroy() { this[I].destroy(); }
};
function qn(e, n) { let t = n?.injector ?? h(L), r = n?.manualCleanup !== !0 ? t.get(_) : null, o, i = t.get($n, null, { optional: !0 }), s = t.get(Q); return i !== null ? (o = Tr(i.view, s, e), r instanceof Y && r._lView === i.view && (r = null)) : o = wr(e, t.get(Dr), s), o.injector = t, r !== null && (o.onDestroyFns = [r.onDestroy(() => o.destroy())]), new Ne(o); }
var Un = $(V({}, qe), { cleanupFns: void 0, zone: null, onDestroyFns: null, run() { let e = nn(!1); try {
        Ue(this);
    }
    finally {
        nn(e);
    } }, cleanup() { if (!this.cleanupFns?.length)
        return; let e = T(null); try {
        for (; this.cleanupFns.length;)
            this.cleanupFns.pop()();
    }
    finally {
        this.cleanupFns = [], T(e);
    } } }), Ir = $(V({}, Un), { consumerMarkedDirty() { this.scheduler.schedule(this), this.notifier.notify(12); }, destroy() { if (te(this), this.onDestroyFns !== null)
        for (let e of this.onDestroyFns)
            e(); this.cleanup(), this.scheduler.remove(this); } }), Er = $(V({}, Un), { consumerMarkedDirty() { this.view[p] |= 8192, Re(this.view), this.notifier.notify(13); }, destroy() { if (te(this), this.onDestroyFns !== null)
        for (let e of this.onDestroyFns)
            e(); this.cleanup(), this.view[ve]?.delete(this); } });
function Tr(e, n, t) { let r = Object.create(Er); return r.view = e, r.zone = typeof Zone < "u" ? Zone.current : null, r.notifier = n, r.fn = Gn(r, t), e[ve] ??= new Set, e[ve].add(r), r.consumerMarkedDirty(r), r; }
function wr(e, n, t) { let r = Object.create(Ir); return r.fn = Gn(r, e), r.scheduler = n, r.notifier = t, r.zone = typeof Zone < "u" ? Zone.current : null, r.scheduler.add(r), r.notifier.notify(12), r; }
function Gn(e, n) { return () => { n(t => (e.cleanupFns ??= []).push(t)); }; }
var Bn = class {
    destroyed = !1;
    listeners = null;
    errorHandler = h(j, { optional: !0 });
    destroyRef = h(_);
    constructor() { this.destroyRef.onDestroy(() => { this.destroyed = !0, this.listeners = null; }); }
    subscribe(n) { if (this.destroyed)
        throw new f(953, !1); return (this.listeners ??= []).push(n), { unsubscribe: () => { let t = this.listeners?.indexOf(n); t !== void 0 && t !== -1 && this.listeners?.splice(t, 1); } }; }
    emit(n) { if (this.destroyed) {
        console.warn(be(953, !1));
        return;
    } if (this.listeners === null)
        return; let t = T(null); try {
        for (let r of this.listeners)
            try {
                r(n);
            }
            catch (o) {
                this.errorHandler?.handleError(o);
            }
    }
    finally {
        T(t);
    } }
};
function rs(e) { return e.destroyRef; }
function D(e) { return Ze(e); }
function x(e, n) { return $e(e, n?.equal); }
var Nr = e => e;
function Zn(e, n) { if (typeof e == "function") {
    let t = ie(e, Nr, n?.equal);
    return Wn(t, n?.debugName);
}
else {
    let t = ie(e.source, e.computation, e.equal);
    return Wn(t, e.debugName);
} }
function Wn(e, n) { let t = e[I], r = e; return r.set = o => Ge(t, o), r.update = o => Be(t, o), r.asReadonly = ee.bind(e), r; }
function os(e) { let n = e.request, t = e.params ?? n ?? (() => null); return new Pe(t, Mr(e), e.defaultValue, e.equal ? br(e.equal) : void 0, e.debugName, e.injector ?? h(L)); }
var Oe = class {
    value;
    isLoading;
    constructor(n, t) { this.value = n, this.value.set = this.set.bind(this), this.value.update = this.update.bind(this), this.value.asReadonly = ee, this.isLoading = x(() => this.status() === "loading" || this.status() === "reloading", void 0); }
    isError = x(() => this.status() === "error");
    update(n) { this.set(n(D(this.value))); }
    isValueDefined = x(() => this.isError() ? !1 : this.value() !== void 0);
    _snapshot;
    get snapshot() { return this._snapshot ??= x(() => { let n = this.status(); return n === "error" ? { status: "error", error: this.error() } : { status: n, value: this.value() }; }); }
    hasValue() { return this.isValueDefined(); }
    asReadonly() { return this; }
}, Pe = class extends Oe {
    loaderFn;
    equal;
    debugName;
    pendingTasks;
    state;
    extRequest;
    effectRef;
    pendingController;
    resolvePendingTask = void 0;
    destroyed = !1;
    unregisterOnDestroy;
    status;
    error;
    constructor(n, t, r, o, i, s, l) { super(x(() => { let u = this.state().stream?.(); if (!u || this.state().status === "loading" && this.error())
        return r; if (!Le(u))
        throw new Se(this.error()); return u.value; }, { equal: o }), i), this.loaderFn = t, this.equal = o, this.debugName = i, this.extRequest = Zn({ source: n, computation: u => ({ request: u, reload: 0 }) }), this.state = Zn({ source: this.extRequest, computation: (u, c) => { if (c) {
            let m = u.request === void 0 ? "idle" : "loading";
            return { extRequest: u, status: m, previousStatus: Yn(c.value), stream: c.value.extRequest.request === u.request ? c.value.stream : void 0 };
        }
        else {
            let m = l?.(u.request);
            l = void 0;
            let Qn = u.request === void 0 ? "idle" : m ? "resolved" : "loading";
            return { extRequest: u, status: Qn, previousStatus: "idle", stream: m };
        } } }), this.effectRef = qn(this.loadEffect.bind(this), { injector: s, manualCleanup: !0 }), this.pendingTasks = s.get(Hn), this.unregisterOnDestroy = s.get(_).onDestroy(() => this.destroy()), this.status = x(() => Yn(this.state()), void 0), this.error = x(() => { let u = this.state().stream?.(); return u && !Le(u) ? u.error : void 0; }, void 0); }
    set(n) { if (this.destroyed)
        return; let t = D(this.error), r = D(this.state); if (!t) {
        let o = D(this.value);
        if (r.status === "local" && (this.equal ? this.equal(o, n) : o === n))
            return;
    } this.state.set({ extRequest: r.extRequest, status: "local", previousStatus: "local", stream: A({ value: n }, void 0) }), this.abortInProgressLoad(); }
    reload() { let { status: n } = D(this.state); return n === "idle" || n === "loading" ? !1 : (this.extRequest.update(({ request: t, reload: r }) => ({ request: t, reload: r + 1 })), !0); }
    destroy() { this.destroyed = !0, this.unregisterOnDestroy(), this.effectRef.destroy(), this.abortInProgressLoad(), this.state.set({ extRequest: { request: void 0, reload: 0 }, status: "idle", previousStatus: "idle", stream: void 0 }); }
    loadEffect() { return ne(this, null, function* () { let n = this.extRequest(), { status: t, previousStatus: r } = D(this.state); if (n.request === void 0)
        return; if (t !== "loading")
        return; this.abortInProgressLoad(); let o = this.resolvePendingTask = this.pendingTasks.add(), { signal: i } = this.pendingController = new AbortController; try {
        let s = yield D(() => this.loaderFn({ params: n.request, abortSignal: i, previous: { status: r } }));
        if (i.aborted || D(this.extRequest) !== n)
            return;
        this.state.set({ extRequest: n, status: "resolved", previousStatus: "resolved", stream: s });
    }
    catch (s) {
        if (i.aborted || D(this.extRequest) !== n)
            return;
        this.state.set({ extRequest: n, status: "resolved", previousStatus: "error", stream: A({ error: Jn(s) }, void 0) });
    }
    finally {
        o?.(), o = void 0;
    } }); }
    abortInProgressLoad() { D(() => this.pendingController?.abort()), this.pendingController = void 0, this.resolvePendingTask?.(), this.resolvePendingTask = void 0; }
};
function br(e) { return (n, t) => n === void 0 || t === void 0 ? n === t : e(n, t); }
function Mr(e) { return _r(e) ? e.stream : n => ne(null, null, function* () { try {
    return A({ value: yield e.loader(n) }, void 0);
}
catch (t) {
    return A({ error: Jn(t) }, void 0);
} }); }
function _r(e) { return !!e.stream; }
function Yn(e) { switch (e.status) {
    case "loading": return e.extRequest.reload === 0 ? "loading" : "reloading";
    case "resolved": return Le(e.stream()) ? "resolved" : "error";
    default: return e.status;
} }
function Le(e) { return e.error === void 0; }
function Jn(e) { return xr(e) ? e : new Ae(e); }
function xr(e) { return e instanceof Error || typeof e == "object" && typeof e.name == "string" && typeof e.message == "string"; }
var Se = class extends Error {
    constructor(n) { super(n.message, { cause: n }); }
}, Ae = class extends Error {
    constructor(n) { super(String(n), { cause: n }); }
};
export { ue as a, We as b, Pr as c, Lr as d, f as e, be as f, Sr as g, d as h, Ar as i, rt as j, Vr as k, $r as l, an as m, y as n, it as o, Hr as p, S as q, qr as r, K as s, Ur as t, dn as u, Je as v, g as w, Gr as x, ln as y, at as z, ct as A, dt as B, lt as C, Ke as D, Br as E, ft as F, Zr as G, fn as H, ht as I, gt as J, Wr as K, pt as L, Yr as M, yt as N, Dt as O, N as P, Et as Q, F as R, Jr as S, h as T, U, Qr as V, G as W, Kr as X, Xr as Y, zr as Z, eo as _, no as $, to as aa, Mt as ba, ro as ca, oo as da, mn as ea, io as fa, B as ga, z as ha, vn as ia, Dn as ja, xt as ka, Ct as la, kt as ma, he as na, so as oa, Ot as pa, Tn as qa, P as ra, W as sa, St as ta, uo as ua, wn as va, ao as wa, xe as xa, Nn as ya, p as za, me as Aa, co as Ba, Ht as Ca, lo as Da, qt as Ea, bn as Fa, fo as Ga, Mn as Ha, ho as Ia, go as Ja, po as Ka, _n as La, mo as Ma, vo as Na, Ut as Oa, yo as Pa, Do as Qa, Io as Ra, R as Sa, Eo as Ta, ve as Ua, Gt as Va, To as Wa, wo as Xa, No as Ya, bo as Za, Mo as _a, _o as $a, xo as ab, Co as bb, Bt as cb, xn as db, ko as eb, Ro as fb, Fo as gb, jo as hb, Oo as ib, Po as jb, Lo as kb, Cn as lb, v as mb, ye as nb, kn as ob, Zt as pb, So as qb, ke as rb, Ao as sb, Vo as tb, $o as ub, Ho as vb, Wt as wb, qo as xb, Uo as yb, Go as zb, Bo as Ab, Rn as Bb, Zo as Cb, Wo as Db, Yo as Eb, Jo as Fb, Yt as Gb, Jt as Hb, Qo as Ib, Re as Jb, Qt as Kb, Kt as Lb, en as Mb, Xt as Nb, zt as Ob, Ko as Pb, Xo as Qb, zo as Rb, ei as Sb, ni as Tb, ti as Ub, ri as Vb, oi as Wb, ii as Xb, si as Yb, ui as Zb, Fn as _b, ai as $b, ci as ac, di as bc, er as cc, nr as dc, li as ec, fi as fc, hi as gc, gi as hc, pi as ic, mi as jc, nn as kc, vi as lc, yi as mc, Di as nc, Ii as oc, Ei as pc, Ti as qc, wi as rc, Ni as sc, bi as tc, tr as uc, Mi as vc, _i as wc, xi as xc, Ci as yc, ki as zc, Ri as Ac, Fi as Bc, ji as Cc, Oi as Dc, Pi as Ec, Li as Fc, Si as Gc, Ai as Hc, Vi as Ic, $i as Jc, Hi as Kc, qi as Lc, tn as Mc, ir as Nc, L as Oc, sr as Pc, _ as Qc, ar as Rc, cr as Sc, Sn as Tc, b as Uc, dr as Vc, Ui as Wc, rn as Xc, Ee as Yc, un as Zc, j as _c, Vn as $c, Gi as ad, Bi as bd, Zi as cd, A as dd, ee as ed, Wi as fd, $n as gd, Q as hd, Yi as id, Ji as jd, Qi as kd, Hn as ld, Dr as md, qn as nd, Bn as od, rs as pd, D as qd, x as rd, Zn as sd, os as td, Pe as ud, Jn as vd, Se as wd };
/*! Bundled license information:

@angular/core/fesm2022/_effect-chunk2.mjs:
@angular/core/fesm2022/_resource-chunk.mjs:
  (**
   * @license Angular v21.2.20
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
