import{a as m,n as h}from"@nf-internal/chunk-V4GFIEGC";import{c as p}from"@nf-internal/chunk-5TYO4LSL";import"@nf-internal/chunk-CQE4ZXWS";import"@nf-internal/chunk-JHI3MBHO";var W=(o,X,w,g,v)=>{let s=o.ownerDocument.defaultView,n=m(o),l=t=>n?-t.deltaX:t.deltaX;return p({el:o,gestureName:"goback-swipe",gesturePriority:101,threshold:10,canStart:t=>(n=m(o),(e=>{let{startX:r}=e;return n?r>=s.innerWidth-50:r<=50})(t)&&X()),onStart:w,onMove:t=>{let e=l(t);g(e/s.innerWidth)},onEnd:t=>{let e=l(t),r=s.innerWidth,a=e/r,c=(i=>n?-i.velocityX:i.velocityX)(t),u=c>=0&&(c>.2||e>r/2),d=(u?1-a:a)*r,f=0;if(d>5){let i=d/Math.abs(c);f=Math.min(i,540)}v(u,a<=0?.01:h(0,a,.9999),f)}})};export{W as createSwipeBackGesture};
/*! Bundled license information:

@ionic/core/components/p-CgkrslTX.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
