var l=i=>{var e,r;for(let t=i;t;t=t.parentElement){let o=(e=t.getAttribute("dir"))===null||e===void 0?void 0:e.toLowerCase();if(o==="rtl")return!0;if(o==="ltr")return!1}return((r=document?.dir)===null||r===void 0?void 0:r.toLowerCase())==="rtl"};export{l as a};
/*! Bundled license information:

@ionic/core/dist/esm/dir-o8OKV5aD.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
