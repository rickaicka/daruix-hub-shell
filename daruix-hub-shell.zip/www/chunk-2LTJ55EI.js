import{a as o}from"@nf-internal/chunk-JYWXGWOM";import{a as u,f as h}from"@nf-internal/chunk-CQE4ZXWS";import{e as d}from"@nf-internal/chunk-JHI3MBHO";var B=()=>u.get("experimentalCloseWatcher",!1)&&o!==void 0&&"CloseWatcher"in o,m=()=>{document.addEventListener("backbutton",()=>{})},f=()=>{let s=document,i=!1,c=()=>{if(i)return;let r=0,e=[],p=new CustomEvent("ionBackButton",{bubbles:!1,detail:{register(a,t){e.push({priority:a,handler:t,id:r++})}}});s.dispatchEvent(p);let l=()=>{if(e.length>0){let a={priority:Number.MIN_SAFE_INTEGER,handler:()=>{},id:-1};e.forEach(t=>{t.priority>=a.priority&&(a=t)}),i=!0,e=e.filter(t=>t.id!==a.id),(t=>d(null,null,function*(){try{if(t?.handler){let n=t.handler(l);n!=null&&(yield n)}}catch(n){h("[ion-app] - Exception in startHardwareBackButton:",n)}}))(a).then(()=>i=!1)}};l()};if(B()){let r,e=()=>{r?.destroy(),r=new o.CloseWatcher,r.onclose=()=>{c(),e()}};e()}else s.addEventListener("backbutton",c)},_=100,k=99;export{B as a,m as b,f as c,_ as d,k as e};
/*! Bundled license information:

@ionic/core/components/p-Bz0dSlXZ.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
