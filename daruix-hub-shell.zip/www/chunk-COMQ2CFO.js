import{b as i}from"@nf-internal/chunk-RZV246CZ";import{g as u}from"@nf-internal/chunk-H7UI3L2Q";import{e as l}from"@nf-internal/chunk-JHI3MBHO";var f="ION-CONTENT",n="ion-content",s=".ion-content-scroll-host",a=`${n}, ${s}`,e=o=>o.tagName===f,m=o=>l(null,null,function*(){return e(o)?(yield new Promise(r=>i(o,r)),o.getScrollElement()):o}),O=o=>{let r=o.querySelector(s);return r||o.querySelector(a)},p=o=>o.closest(a),C=o=>o.querySelector(s),y=o=>{if(e(o))return o.querySelector("ion-refresher");let r=o.closest(n);if(r===null)return null;let t=C(r);return t===null||!t.contains(o)?null:r.querySelector("ion-refresher")},E=(o,r)=>e(o)?o.scrollToTop(r):Promise.resolve(o.scrollTo({top:0,left:0,behavior:"smooth"})),h=(o,r,t,c)=>e(o)?o.scrollByPoint(r,t,c):Promise.resolve(o.scrollBy({top:t,left:r,behavior:c>0?"smooth":"auto"})),I=o=>u(o,n),_=o=>{if(e(o)){let r=o,t=r.scrollY;return r.scrollY=!1,t}else return o.style.setProperty("overflow","hidden"),!0},d=(o,r)=>{e(o)?o.scrollY=r:o.style.removeProperty("overflow")};export{n as a,s as b,e as c,m as d,O as e,p as f,C as g,y as h,E as i,h as j,I as k,_ as l,d as m};
/*! Bundled license information:

@ionic/core/dist/esm/index-B_8X7INq.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
